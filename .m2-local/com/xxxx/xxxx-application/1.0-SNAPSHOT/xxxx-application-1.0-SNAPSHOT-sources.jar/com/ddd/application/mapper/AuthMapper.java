package com.xxxx.ddd.application.mapper;

import com.xxxx.ddd.application.model.CurrentUserDTO;
import com.xxxx.ddd.application.model.PermissionDTO;
import com.xxxx.ddd.application.model.RoleDTO;
import com.xxxx.ddd.application.model.RoleLevelDTO;
import com.xxxx.ddd.application.model.UserDTO;
import com.xxxx.ddd.domain.model.auth.FixedRoleLevel;
import com.xxxx.ddd.domain.model.entity.Permission;
import com.xxxx.ddd.domain.model.entity.Role;
import com.xxxx.ddd.domain.model.entity.User;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class AuthMapper {

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    private AuthMapper() {
    }

    public static UserDTO toUserDTO(User user) {
        if (user == null) {
            return null;
        }
        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setFullName(user.getFullName());
        dto.setUsername(user.getUsername());
        dto.setEmail(user.getEmail());
        dto.setPhone(user.getPhone());
        dto.setRole(user.getRoleCode());
        dto.setLevelId(user.getLevelCode());
        if (user.getSaleRoom() != null) {
            dto.setSaleRoomId(user.getSaleRoom().getId());
            dto.setSaleRoomName(user.getSaleRoom().getName());
        }
        dto.setBaseSalary(user.getBaseSalary());
        dto.setActive(user.getActive());
        dto.setCreatedAt(format(user.getCreatedAt()));
        dto.setUpdatedAt(format(user.getUpdatedAt()));
        return dto;
    }

    public static CurrentUserDTO toCurrentUserDTO(User user) {
        UserDTO base = toUserDTO(user);
        CurrentUserDTO dto = new CurrentUserDTO();
        dto.setId(base.getId());
        dto.setFullName(base.getFullName());
        dto.setUsername(base.getUsername());
        dto.setEmail(base.getEmail());
        dto.setPhone(base.getPhone());
        dto.setRole(base.getRole());
        dto.setLevelId(base.getLevelId());
        dto.setSaleRoomId(base.getSaleRoomId());
        dto.setSaleRoomName(base.getSaleRoomName());
        dto.setBaseSalary(base.getBaseSalary());
        dto.setActive(base.getActive());
        dto.setCreatedAt(base.getCreatedAt());
        dto.setUpdatedAt(base.getUpdatedAt());
        dto.setRoleName(user.getRole() == null ? null : user.getRole().getName());
        dto.setPermissions(toPermissionDTOs(user.getEffectivePermissions()));
        return dto;
    }

    public static RoleDTO toRoleDTO(Role role) {
        if (role == null) {
            return null;
        }
        RoleDTO dto = new RoleDTO();
        dto.setId(role.getId());
        dto.setCode(role.getCode());
        dto.setName(role.getName());
        dto.setSummary(role.getSummary());
        dto.setPermissions(toPermissionDTOs(role.getPermissions()));
        if (role.hasNoLevels()) {
            dto.setLevels(List.of());
        } else if (role.hasOnlyOtherLevel()) {
            Set<Permission> otherPermissions = role.permissionsForLevel(FixedRoleLevel.OTHER.getCode());
            dto.setLevels(List.of(toRoleLevelDTO(
                    FixedRoleLevel.OTHER,
                    otherPermissions.isEmpty() ? role.getPermissions() : otherPermissions
            )));
        } else {
            dto.setLevels(role.resolvedLevels().stream()
                    .map(fixed -> toRoleLevelDTO(fixed, role.permissionsForLevel(fixed.getCode())))
                    .toList());
        }
        return dto;
    }

    public static RoleLevelDTO toRoleLevelDTO(FixedRoleLevel level, Set<Permission> permissions) {
        RoleLevelDTO dto = new RoleLevelDTO();
        dto.setId(level.getCode());
        dto.setName(level.getName());
        dto.setSeat(level.getSeat());
        dto.setDescription(level.getDescription());
        dto.setPermissionIds(permissions == null ? List.of() : permissions.stream()
                .map(Permission::getCode)
                .toList());
        return dto;
    }

    public static PermissionDTO toPermissionDTO(Permission permission) {
        PermissionDTO dto = new PermissionDTO();
        dto.setId(permission.getCode());
        dto.setCode(permission.getCode());
        dto.setLabel(permission.getLabel());
        dto.setNote(permission.getNote());
        return dto;
    }

    public static List<PermissionDTO> toPermissionDTOs(Set<Permission> permissions) {
        if (permissions == null) {
            return List.of();
        }
        return permissions.stream()
                .sorted(Comparator.comparing(Permission::getCode, Comparator.nullsLast(String::compareTo)))
                .map(AuthMapper::toPermissionDTO)
                .collect(Collectors.toList());
    }

    private static String format(LocalDateTime value) {
        return value == null ? null : value.format(ISO);
    }
}
