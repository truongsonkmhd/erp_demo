package com.xxxx.ddd.application.model;

import lombok.Data;

@Data
public class AssignmentDTO {
    private Long id;
    private String refType;
    private Long refId;
    private Long assigneeId;
    private String assigneeName;
    private String assigneeEmail;
    private Long assignedById;
    private String assignedByName;
    private String status;
    private String note;
    private String assignedAt;
    private String acceptedAt;
    private Long supersededById;
}
