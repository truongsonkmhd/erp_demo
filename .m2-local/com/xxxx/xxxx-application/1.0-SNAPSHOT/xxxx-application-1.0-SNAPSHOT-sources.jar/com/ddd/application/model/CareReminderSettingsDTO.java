package com.xxxx.ddd.application.model;

import java.math.BigDecimal;

public record CareReminderSettingsDTO(int intervalMinutes, int l0IntervalMinutes, int l11IntervalMinutes,
                                      int l21IntervalMinutes, int l22IntervalMinutes,
                                      int unassignedCustomerInitialMinutes, int unassignedCustomerRepeatMinutes,
                                      int unassignedLeadInitialMinutes, int unassignedLeadRepeatMinutes,
                                      int warehouseAddressInitialMinutes, int warehouseAddressRepeatMinutes,
                                      int warehouseDebtInitialMinutes, int warehouseDebtRepeatMinutes,
                                      int customerInactiveFirstDays, int customerInactiveSecondDays,
                                      int customerInactiveThirdDays,
                                      BigDecimal utvcNorthSouthCostRateVnd, String updatedAt) {
}
