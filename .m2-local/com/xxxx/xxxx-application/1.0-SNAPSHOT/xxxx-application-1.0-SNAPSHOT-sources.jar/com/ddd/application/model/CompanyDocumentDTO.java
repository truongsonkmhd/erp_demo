package com.xxxx.ddd.application.model;

import lombok.Data;

@Data
public class CompanyDocumentDTO {
    private Long id;
    private Long categoryId;
    private String categoryName;
    private String name;
    private String fileName;
    private String contentType;
    private Long fileSize;
    private Long uploadedById;
    private String uploadedByName;
    private String createdAt;
    private String updatedAt;
}
