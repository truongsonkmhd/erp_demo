package com.xxxx.ddd.application.model;

import lombok.Data;

@Data
public class CustomerCareLogDTO {
    private Long id;
    private Long leadId;
    private String careProgress;
    private String careProgressNote;
    private String dataEvaluation;
    private Boolean hasIssue;
    private String issueNote;
    private Long changedById;
    private String changedByName;
    private String createdAt;
}
