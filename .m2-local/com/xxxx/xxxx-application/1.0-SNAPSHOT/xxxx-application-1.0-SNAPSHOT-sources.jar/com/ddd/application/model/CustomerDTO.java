package com.xxxx.ddd.application.model;

import lombok.Data;

@Data
public class CustomerDTO {
    private Long id;
    private String code;
    private String fullName;
    private String companyName;
    private String phone;
    private String email;
    private String category;
    private String taxCode;
    private String businessType;
    private java.math.BigDecimal chinaVietnamRateKg;
    private java.math.BigDecimal chinaVietnamRateCbm;
    private java.math.BigDecimal walletBalanceVnd;
    private String leadSource;
    private String address;
    private String province;
    private String ward;
    private String detailAddress;
    private String note;
    private Long createdById;
    private String createdByName;
    private Long customerCareStaffId;
    private String customerCareStaffName;
    private Integer orderCount;
    private String createdAt;
    private String updatedAt;
}
