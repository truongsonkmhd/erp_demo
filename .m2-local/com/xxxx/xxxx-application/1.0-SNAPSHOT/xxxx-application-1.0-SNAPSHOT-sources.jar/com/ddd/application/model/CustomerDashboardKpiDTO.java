package com.xxxx.ddd.application.model;

import lombok.Data;
import lombok.experimental.Accessors;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Data
@Accessors(chain = true)
public class CustomerDashboardKpiDTO {
    private boolean canEdit;
    private boolean teamManager;
    private Long selectedUserId;
    private String periodMonth;
    private List<Member> members = new ArrayList<>();

    @Data
    @Accessors(chain = true)
    public static class Member {
        private Long userId;
        private String userName;
        private Map<String, BigDecimal> values = new LinkedHashMap<>();
    }
}
