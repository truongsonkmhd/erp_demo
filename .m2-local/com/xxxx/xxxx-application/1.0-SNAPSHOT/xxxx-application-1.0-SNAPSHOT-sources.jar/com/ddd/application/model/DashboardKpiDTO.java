package com.xxxx.ddd.application.model;

import lombok.Data;
import lombok.experimental.Accessors;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
@Accessors(chain = true)
public class DashboardKpiDTO {
    private boolean canEdit;
    private boolean teamManager;
    private Long selectedUserId;
    private String periodMonth;
    private boolean locked;
    private List<Member> members = new ArrayList<>();
    private List<Room> rooms = new ArrayList<>();

    @Data
    @Accessors(chain = true)
    public static class Room {
        private Long saleRoomId;
        private String saleRoomName;
        private List<Long> memberUserIds = new ArrayList<>();
        private BigDecimal totalData;
        private BigDecimal overallData;
        private BigDecimal wrongInsight;
        private BigDecimal levelL0;
        private BigDecimal levelL1;
        private BigDecimal levelL2;
        private BigDecimal levelL3;
        private BigDecimal levelL5;
        private BigDecimal newCustomers;
        private BigDecimal newProfitVnd;
        private BigDecimal conversionTimeDays;
    }

    @Data
    @Accessors(chain = true)
    public static class Member {
        private Long userId;
        private String userName;
        private Long saleRoomId;
        private String saleRoomName;
        private BigDecimal totalData;
        private BigDecimal overallData;
        private BigDecimal wrongInsight;
        private BigDecimal levelL0;
        private BigDecimal levelL1;
        private BigDecimal levelL2;
        private BigDecimal levelL3;
        private BigDecimal levelL5;
        private BigDecimal newCustomers;
        private BigDecimal newProfitVnd;
        private BigDecimal conversionTimeDays;
    }
}
