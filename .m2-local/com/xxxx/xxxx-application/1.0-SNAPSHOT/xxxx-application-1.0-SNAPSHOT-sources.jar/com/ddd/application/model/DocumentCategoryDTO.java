package com.xxxx.ddd.application.model;

import lombok.Data;

@Data
public class DocumentCategoryDTO {
    private Long id;
    private String name;
    private Integer sortOrder;
    private Boolean active;
    private Boolean editable;
    private Long createdById;
    private String createdAt;
    private String updatedAt;
}
