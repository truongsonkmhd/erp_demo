package com.xxxx.ddd.application.model;

import org.springframework.core.io.Resource;

public record DocumentFilePayload(
        Resource resource,
        String fileName,
        String contentType,
        long fileSize
) {
}
