package com.xxxx.ddd.application.model;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
public class LeadKpiEmployeeDTO {
    private Long userId;
    private String userName;
    private Long saleRoomId;
    private String saleRoomName;
    private String comment;
    private BigDecimal totalPercent;
    private String grade;
    private BigDecimal coefficient;
    private List<LeadKpiScoreDTO> scores = new ArrayList<>();

    @Data
    public static class LeadKpiScoreDTO {
        private String criterionId;
        private BigDecimal actualValue;
    }
}
