package com.xxxx.ddd.application.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class LeadKpiPeriodDTO {
    private String period;
    private boolean canViewAllRooms;
    private Long scopedSaleRoomId;
    private String scopedSaleRoomName;
    private String scopeMessage;
    private List<LeadKpiEmployeeDTO> employees = new ArrayList<>();
    /** NV Sale trong phạm vi — dùng cho dropdown thêm KPI. */
    private List<EligibleUser> eligibleUsers = new ArrayList<>();

    @Data
    public static class EligibleUser {
        private Long userId;
        private String userName;
        private Long saleRoomId;
        private String saleRoomName;
    }
}
