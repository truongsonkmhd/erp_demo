package com.xxxx.ddd.application.model;

import lombok.Data;

@Data
public class MarketingLeadDTO {
    private Long id;
    private String code;
    private Long customerId;
    private String customerCode;
    private String fullName;
    private String phone;
    private String email;
    private String category;
    private String leadSource;
    private String leadSourceNote;
    /** JSON array string of campaign names. */
    private String campaignNames;
    private String initialNeed;
    private String note;

    private String stage;
    private String marketingStatus;
    private String taskStatus;
    private String managerNotifiedAt;
    private String careProgress;
    private String careProgressNote;
    private String careL4At;
    private String orderCreatedAt;

    private Long createdById;
    private String createdByName;
    private String createdAt;
    private String updatedAt;

    /** Phân việc đang hiệu lực ở chặng marketing. */
    private AssignmentDTO marketingAssignment;

    /** Phân việc đang hiệu lực ở chặng giao nhiệm vụ. */
    private AssignmentDTO taskAssignment;
}
