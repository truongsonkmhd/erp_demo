package com.xxxx.ddd.application.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class MarketingLeadImportResultDTO {
    private int totalRows;
    private int importedRows;
    private int skippedRows;
    private List<String> errors = new ArrayList<>();
}
