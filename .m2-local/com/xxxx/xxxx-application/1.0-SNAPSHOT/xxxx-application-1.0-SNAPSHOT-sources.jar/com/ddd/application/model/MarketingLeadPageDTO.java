package com.xxxx.ddd.application.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class MarketingLeadPageDTO {
    private List<MarketingLeadDTO> items = new ArrayList<>();
    private int pageNo;
    private int pageSize;
    private long totalElements;
    private int totalPages;
}
