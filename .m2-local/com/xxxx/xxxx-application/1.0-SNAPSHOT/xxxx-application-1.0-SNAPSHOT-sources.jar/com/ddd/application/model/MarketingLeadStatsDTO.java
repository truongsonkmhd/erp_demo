package com.xxxx.ddd.application.model;

import lombok.Data;

import java.util.LinkedHashMap;
import java.util.Map;

@Data
public class MarketingLeadStatsDTO {
    private long total;
    private long withCareProgress;
    private long withoutCareProgress;
    private long wrongInsight;
    private long customerCreated;
    private long marketingSourceTotal;
    private long assignedTotal;
    private long unassignedTotal;
    private boolean salesDirectorView;
    private boolean allocationOverview;
    private Map<String, Long> byStage = new LinkedHashMap<>();
    private Map<String, Long> byCareProgress = new LinkedHashMap<>();
}
