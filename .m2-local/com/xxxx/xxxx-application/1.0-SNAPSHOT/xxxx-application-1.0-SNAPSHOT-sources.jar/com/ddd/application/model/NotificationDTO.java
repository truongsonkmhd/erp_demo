package com.xxxx.ddd.application.model;

import lombok.Data;

@Data
public class NotificationDTO {
    private Long id;
    private String type;
    private String title;
    private String body;
    private String refType;
    private Long refId;
    private String link;
    private Boolean isRead;
    private String readAt;
    private Long actorId;
    private String actorName;
    private String emailStatus;
    private String createdAt;
}
