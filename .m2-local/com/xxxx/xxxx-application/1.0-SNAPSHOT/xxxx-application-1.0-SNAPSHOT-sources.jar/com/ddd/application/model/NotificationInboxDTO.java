package com.xxxx.ddd.application.model;

import lombok.Data;

import java.util.List;

@Data
public class NotificationInboxDTO {
    private List<NotificationDTO> items;
    private Long unreadCount;
    private Boolean hasMore;
}
