package com.xxxx.ddd.application.model;

import lombok.Data;

import java.util.Map;

@Data
public class OnlyOfficeEditorConfigDTO {
    private String documentServerUrl;
    private Map<String, Object> config;
}
