package com.xxxx.ddd.application.model;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OrderDTO {
    private Long id;
    private String internalCode;
    private String orderCode;
    private Long customerId;
    private String customerCode;
    private String customerName;
    private String customerPhone;
    private Long leadId;
    private String batchCode;
    private String serviceType;
    private String contractType;
    private String productName;
    private String category;
    private BigDecimal quantity;
    private BigDecimal unitPriceRmb;
    private BigDecimal totalPaymentAmountVnd;
    private String paidAt;
    private String transportMode;
    private String calculationUnit;
    private BigDecimal weightKg;
    private BigDecimal volumeCbm;
    private BigDecimal totalGoodsRmb;
    private BigDecimal importServiceFeeVnd;
    private BigDecimal totalRevenueVnd;
    private BigDecimal remainingPaymentVnd;
    private BigDecimal sellingChinaVietnamRateVnd;
    private BigDecimal totalRevenueNorthSouthVnd;
    private BigDecimal outputVatVnd;
    private BigDecimal statementAmountVnd;
    private BigDecimal utvcDebtVnd;
    private BigDecimal costProfitVnd;
    private BigDecimal floorProfitVnd;
    private String salaryCustomerKind;
    private Long assigneeId;
    private String assigneeName;
    private Long salesOwnerId;
    private String salesOwnerName;
    private Long customerCareStaffId;
    private String customerCareStaffName;
    private String notes;
    private String saleOverlayJson;
    private String source;
    private String editApprovalStatus;
    private Long editRequestedBy;
    private Long editApprovedBy;
    private String editRequestedAt;
    private String editApprovedAt;
    private String createdAt;
    private String updatedAt;
}
