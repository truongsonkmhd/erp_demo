package com.xxxx.ddd.application.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class OrderPageDTO {
    private List<OrderDTO> items = new ArrayList<>();
    private int pageNo;
    private int pageSize;
    private long totalElements;
    private int totalPages;
}
