package com.xxxx.ddd.application.model;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
public class SalaryLineDTO {
    private Long id;
    private Long userId;
    private String userName;
    private Long saleRoomId;
    private String saleRoomName;
    private String scheme;
    private BigDecimal baseSalary;
    private BigDecimal kpiPercent;
    private BigDecimal coefficient;
    private BigDecimal newKpiVnd;
    private BigDecimal oldKpiVnd;
    private BigDecimal newActualVnd;
    private BigDecimal oldActualVnd;
    private Boolean actualIsOverride;
    private BigDecimal payoutVnd;
    private BigDecimal commissionVnd;
    private BigDecimal totalVnd;
    private List<SalaryOrderDTO> orders = new ArrayList<>();
    private String createdAt;
    private String updatedAt;
}
