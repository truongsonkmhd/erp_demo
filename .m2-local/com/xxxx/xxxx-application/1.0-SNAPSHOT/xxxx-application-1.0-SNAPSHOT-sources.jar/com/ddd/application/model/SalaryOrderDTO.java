package com.xxxx.ddd.application.model;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class SalaryOrderDTO {
    private Long id;
    private Long orderId;
    private String orderCode;
    private Long customerId;
    private String customerName;
    private String customerKind;
    private BigDecimal netProfitVnd;
    private String handedOverAt;
    private Long assigneeId;
    private String assigneeName;
    private String createdAt;
}
