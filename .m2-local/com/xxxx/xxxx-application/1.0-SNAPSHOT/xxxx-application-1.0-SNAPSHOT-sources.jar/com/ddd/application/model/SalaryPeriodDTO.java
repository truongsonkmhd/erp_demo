package com.xxxx.ddd.application.model;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
public class SalaryPeriodDTO {
    private Long id;
    private String period;
    private String status;
    private BigDecimal deptProfitOverrideVnd;
    private BigDecimal deptNewActualVnd;
    private BigDecimal deptOldActualVnd;
    private BigDecimal deptProfitVnd;
    private String lockedAt;
    private Long lockedById;
    private String lockedByName;
    private boolean preview;
    private boolean canViewAllRooms;
    private Long scopedSaleRoomId;
    private String scopedSaleRoomName;
    private String scopeMessage;
    private List<SalaryLineDTO> lines = new ArrayList<>();
    private String createdAt;
    private String updatedAt;
}
