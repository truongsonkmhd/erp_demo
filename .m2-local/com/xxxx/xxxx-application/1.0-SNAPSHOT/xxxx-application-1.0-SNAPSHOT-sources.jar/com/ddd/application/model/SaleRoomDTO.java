package com.xxxx.ddd.application.model;

import lombok.Data;

import java.util.List;

@Data
public class SaleRoomDTO {
    private Long id;
    private String code;
    private String name;
    private String description;
    private Long leaderId;
    private String leaderName;
    private List<Long> memberIds;
    private Boolean active;
    private String createdAt;
    private String updatedAt;
}
