package com.xxxx.ddd.application.model.command;

import lombok.Data;

@Data
public class AssignLeadCommand {
    private Long assigneeId;
    private String note;
    private Boolean notifyMail = true;
    private Boolean notifySystem = true;
}
