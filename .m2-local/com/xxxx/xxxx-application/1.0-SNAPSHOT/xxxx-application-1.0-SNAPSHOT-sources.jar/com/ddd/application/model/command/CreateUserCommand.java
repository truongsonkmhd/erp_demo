package com.xxxx.ddd.application.model.command;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CreateUserCommand {
    private String fullName;
    private String username;
    private String password;
    private String email;
    private String phone;
    private String roleCode;
    private String levelId;
    private Long saleRoomId;
    private BigDecimal baseSalary;
    private Boolean active;
}
