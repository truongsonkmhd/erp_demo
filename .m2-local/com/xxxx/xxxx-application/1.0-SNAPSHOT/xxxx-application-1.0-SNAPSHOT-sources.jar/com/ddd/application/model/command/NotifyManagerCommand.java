package com.xxxx.ddd.application.model.command;

import lombok.Data;

@Data
public class NotifyManagerCommand {
    private String message;
    private Boolean notifyMail = true;
    private Boolean notifySystem = true;
}
