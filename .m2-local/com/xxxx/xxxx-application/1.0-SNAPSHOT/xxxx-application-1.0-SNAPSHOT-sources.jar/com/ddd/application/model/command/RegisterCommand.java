package com.xxxx.ddd.application.model.command;

import lombok.Data;

@Data
public class RegisterCommand {
    private String fullName;
    private String username;
    private String password;
    private String email;
    private String phone;
}
