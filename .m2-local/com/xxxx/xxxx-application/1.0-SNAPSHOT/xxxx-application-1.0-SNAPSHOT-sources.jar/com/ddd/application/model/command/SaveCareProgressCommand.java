package com.xxxx.ddd.application.model.command;

import lombok.Data;

@Data
public class SaveCareProgressCommand {
    private String careProgress;
    private String careProgressNote;
    private Boolean hasIssue;
    private String issueNote;
}
