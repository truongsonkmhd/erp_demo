package com.xxxx.ddd.application.model.command;

import lombok.Data;

@Data
public class SaveCustomerCommand {
    private Long leadId;
    private String code;
    private String fullName;
    private String companyName;
    private String phone;
    private String email;
    private String category;
    private String taxCode;
    private String businessType;
    private java.math.BigDecimal chinaVietnamRateKg;
    private java.math.BigDecimal chinaVietnamRateCbm;
    private Long customerCareStaffId;
    private String leadSource;
    private String address;
    private String province;
    private String ward;
    private String detailAddress;
    private String note;
}
