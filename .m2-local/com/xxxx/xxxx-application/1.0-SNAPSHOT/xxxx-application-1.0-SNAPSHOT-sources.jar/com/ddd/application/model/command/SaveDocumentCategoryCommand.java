package com.xxxx.ddd.application.model.command;

import lombok.Data;

@Data
public class SaveDocumentCategoryCommand {
    private String name;
    private Integer sortOrder;
    private Boolean active;
    private Boolean editable;
    /** When true, create as shared/fixed company menu (visible to all users). */
    private Boolean sharedMenu;
}
