package com.xxxx.ddd.application.model.command;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Data
public class SaveLeadKpiCommand {

    private List<Employee> employees = new ArrayList<>();

    @Data
    public static class Employee {
        private Long userId;
        private String comment;
        /** criterionId → actual value */
        private Map<String, BigDecimal> actuals = new LinkedHashMap<>();
    }
}
