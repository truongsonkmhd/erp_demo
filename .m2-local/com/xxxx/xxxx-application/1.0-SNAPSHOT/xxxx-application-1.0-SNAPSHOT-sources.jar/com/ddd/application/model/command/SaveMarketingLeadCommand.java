package com.xxxx.ddd.application.model.command;

import lombok.Data;

@Data
public class SaveMarketingLeadCommand {
    private String fullName;
    private String phone;
    private String email;
    private String category;
    private String leadSource;
    private String leadSourceNote;
    private String campaignNames;
    private String initialNeed;
    private String note;
}
