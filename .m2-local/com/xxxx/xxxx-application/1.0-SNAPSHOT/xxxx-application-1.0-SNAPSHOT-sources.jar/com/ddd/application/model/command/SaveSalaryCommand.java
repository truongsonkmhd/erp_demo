package com.xxxx.ddd.application.model.command;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
public class SaveSalaryCommand {
    private BigDecimal deptProfitOverrideVnd;
    private List<LineInput> lines = new ArrayList<>();

    @Data
    public static class LineInput {
        private Long userId;
        private String scheme;
        private BigDecimal newKpiVnd;
        private BigDecimal oldKpiVnd;
        private BigDecimal newActualVnd;
        private BigDecimal oldActualVnd;
        private Boolean actualIsOverride;
        private BigDecimal baseSalary;
        private BigDecimal kpiPercent;
        private BigDecimal coefficient;
    }
}
