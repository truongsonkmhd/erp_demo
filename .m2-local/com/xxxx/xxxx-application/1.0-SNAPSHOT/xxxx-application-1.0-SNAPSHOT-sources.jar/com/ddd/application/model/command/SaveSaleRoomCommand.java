package com.xxxx.ddd.application.model.command;

import lombok.Data;

import java.util.List;

@Data
public class SaveSaleRoomCommand {
    private String code;
    private String name;
    private String description;
    private Long leaderId;
    private List<Long> memberIds;
    private Boolean active;
}
