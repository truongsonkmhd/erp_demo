package com.xxxx.ddd.application.model.command;

import com.xxxx.ddd.domain.model.workflow.NotificationType;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class SendNotificationCommand {
    private Long recipientId;
    private Long actorId;
    private NotificationType type;
    private String title;
    private String body;
    private String refType;
    private Long refId;
    private String link;
    private Boolean sendEmail = true;
    private Boolean sendRealtime = true;
}
