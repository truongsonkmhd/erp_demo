package com.xxxx.ddd.application.model.command;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class UpdateUserCommand {
    private String fullName;
    private String username;
    private String email;
    private String phone;
    private String roleCode;
    private String levelId;
    private Long saleRoomId;
    private BigDecimal baseSalary;
    private Boolean active;
}
