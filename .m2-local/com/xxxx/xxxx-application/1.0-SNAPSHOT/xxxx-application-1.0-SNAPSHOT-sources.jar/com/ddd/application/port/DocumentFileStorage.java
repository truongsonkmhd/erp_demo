package com.xxxx.ddd.application.port;

import java.io.InputStream;
import java.nio.file.Path;

public interface DocumentFileStorage {

    String store(String originalFileName, InputStream content) throws java.io.IOException;

    String copy(String storagePath, String originalFileName) throws java.io.IOException;

    Path resolve(String storagePath);

    void delete(String storagePath);

    void replace(String storagePath, InputStream content) throws java.io.IOException;
}
