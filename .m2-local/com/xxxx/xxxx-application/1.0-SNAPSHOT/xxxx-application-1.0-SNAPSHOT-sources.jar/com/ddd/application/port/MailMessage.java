package com.xxxx.ddd.application.port;

/**
 * Một email cần gửi. HTML body để template thông báo trình bày được rõ ràng.
 */
public record MailMessage(String to, String subject, String htmlBody) {
}
