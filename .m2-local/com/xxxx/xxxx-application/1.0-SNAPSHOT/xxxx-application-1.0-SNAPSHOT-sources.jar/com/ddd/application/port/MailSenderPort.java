package com.xxxx.ddd.application.port;

/**
 * Cổng gửi email. Adapter thật (SMTP) và adapter dev (ghi log) đều nằm ở pts-infrastructure.
 */
public interface MailSenderPort {

    /** true nếu đã gửi thành công. Adapter không được ném exception ra ngoài. */
    boolean send(MailMessage message);

    /** false khi đang ở chế độ dev (chỉ ghi log). */
    boolean isRealDelivery();
}
