package com.xxxx.ddd.application.port;

/**
 * Cổng đẩy thông báo realtime tới một user. Adapter STOMP nằm ở pts-controller.
 */
public interface RealtimeNotificationPort {

    void sendToUser(String username, Object payload);
}
