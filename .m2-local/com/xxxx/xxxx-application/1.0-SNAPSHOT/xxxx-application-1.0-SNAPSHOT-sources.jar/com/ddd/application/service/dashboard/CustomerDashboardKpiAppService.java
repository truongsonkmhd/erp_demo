package com.xxxx.ddd.application.service.dashboard;

import com.xxxx.ddd.application.model.CustomerDashboardKpiDTO;
import java.math.BigDecimal;
import java.util.Map;

public interface CustomerDashboardKpiAppService {
    CustomerDashboardKpiDTO get(Long actorId, String periodMonth);
    CustomerDashboardKpiDTO save(Long actorId, Long userId, String periodMonth, Map<String, BigDecimal> values);
}
