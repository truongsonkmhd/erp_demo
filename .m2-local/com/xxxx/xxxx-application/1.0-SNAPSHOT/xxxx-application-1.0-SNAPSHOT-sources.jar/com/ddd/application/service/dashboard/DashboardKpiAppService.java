package com.xxxx.ddd.application.service.dashboard;

import com.xxxx.ddd.application.model.DashboardKpiDTO;
import com.xxxx.ddd.application.model.command.SaveDashboardKpiCommand;

public interface DashboardKpiAppService {
    DashboardKpiDTO get(Long actorId, String periodMonth);
    DashboardKpiDTO save(Long actorId, Long userId, String periodMonth, SaveDashboardKpiCommand command);
    DashboardKpiDTO saveRoom(Long actorId, Long saleRoomId, String periodMonth, SaveDashboardKpiCommand command);
}
