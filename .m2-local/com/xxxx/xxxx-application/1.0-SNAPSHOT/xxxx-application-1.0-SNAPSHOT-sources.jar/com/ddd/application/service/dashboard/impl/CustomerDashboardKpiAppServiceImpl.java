package com.xxxx.ddd.application.service.dashboard.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.xxxx.ddd.application.model.CustomerDashboardKpiDTO;
import com.xxxx.ddd.application.service.dashboard.CustomerDashboardKpiAppService;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.UserRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.*;

@Service
public class CustomerDashboardKpiAppServiceImpl implements CustomerDashboardKpiAppService {
    private static final Set<String> KEYS = Set.of(
            "totalCustomers", "diamondCustomers", "goldCustomers", "silverCustomers", "oldCustomers",
            "newCustomers", "customersWithoutOrders", "averageProfitPerCustomer", "averageProfitPerOrder",
            "averageOrderIntervalDays", "totalDebtVnd", "totalProfitVnd", "newCustomerProfitVnd",
            "oldCustomerProfitVnd", "importEntrustProfitVnd", "transportEntrustProfitVnd");

    @Autowired private UserRepository userRepository;
    @Autowired private JdbcTemplate jdbcTemplate;
    @Autowired private ObjectMapper objectMapper;

    @PostConstruct
    public void ensureSchema() {
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS tbl_customer_dashboard_kpi (
              id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
              user_id BIGINT NOT NULL,
              period_month VARCHAR(7) NOT NULL,
              values_json LONGTEXT NOT NULL,
              updated_at DATETIME NULL,
              updated_by BIGINT NULL,
              UNIQUE KEY uk_customer_dashboard_kpi_user_month (user_id, period_month),
              CONSTRAINT fk_customer_dashboard_kpi_user FOREIGN KEY (user_id) REFERENCES tbl_user(id),
              CONSTRAINT fk_customer_dashboard_kpi_updated_by FOREIGN KEY (updated_by) REFERENCES tbl_user(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            """);
    }

    @Override
    @Transactional(readOnly = true)
    public CustomerDashboardKpiDTO get(Long actorId, String periodMonth) {
        String month = normalizeMonth(periodMonth);
        User actor = requireActor(actorId);
        boolean leader = isCskhLeader(actor);
        boolean admin = isAdmin(actor);
        List<User> members = (leader || admin)
                ? userRepository.findAllActiveWithAuth().stream()
                    .filter(CustomerDashboardKpiAppServiceImpl::isCskh)
                    .filter(user -> !Objects.equals(user.getId(), actor.getId()))
                    .filter(user -> canManage(actor, user))
                    .toList()
                : List.of(actor);
        Map<Long, Map<String, BigDecimal>> saved = new HashMap<>();
        if (!members.isEmpty()) {
            String placeholders = String.join(",", Collections.nCopies(members.size(), "?"));
            List<Object> args = new ArrayList<>(members.stream().map(User::getId).toList());
            args.add(month);
            jdbcTemplate.query("SELECT user_id, values_json FROM tbl_customer_dashboard_kpi WHERE user_id IN (" + placeholders + ") AND period_month = ?",
                    args.toArray(), (rs, rowNum) -> Map.entry(rs.getLong("user_id"), parseValues(rs.getString("values_json"))))
                    .forEach(entry -> saved.put(entry.getKey(), entry.getValue()));
        }
        CustomerDashboardKpiDTO dto = new CustomerDashboardKpiDTO()
                .setCanEdit(leader || admin).setTeamManager(leader || admin)
                .setSelectedUserId(actor.getId()).setPeriodMonth(month);
        dto.setMembers(members.stream().map(user -> new CustomerDashboardKpiDTO.Member()
                .setUserId(user.getId()).setUserName(user.getFullName())
                .setValues(withDefaults(saved.get(user.getId())))).toList());
        return dto;
    }

    @Override
    @Transactional
    public CustomerDashboardKpiDTO save(Long actorId, Long userId, String periodMonth, Map<String, BigDecimal> values) {
        String month = normalizeMonth(periodMonth);
        User actor = requireActor(actorId);
        if (!isAdmin(actor) && !isCskhLeader(actor)) throw new IllegalArgumentException("Bạn không có quyền phân KPI khách hàng");
        User target = userRepository.findByIdWithAuth(userId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy nhân viên"));
        if (!isCskh(target)) throw new IllegalArgumentException("Chỉ được phân KPI cho nhân viên CSKH");
        if (!canManage(actor, target)) throw new IllegalArgumentException("Bạn không có quyền phân KPI cho nhân viên này");
        Map<String, BigDecimal> normalized = withDefaults(values);
        normalized.forEach((key, value) -> {
            if (value.signum() < 0) throw new IllegalArgumentException("KPI phải lớn hơn hoặc bằng 0");
        });
        try {
            String json = objectMapper.writeValueAsString(normalized);
            jdbcTemplate.update("""
                INSERT INTO tbl_customer_dashboard_kpi(user_id, period_month, values_json, updated_at, updated_by)
                VALUES (?, ?, ?, NOW(), ?)
                ON DUPLICATE KEY UPDATE values_json = VALUES(values_json), updated_at = NOW(), updated_by = VALUES(updated_by)
                """, userId, month, json, actorId);
        } catch (Exception e) {
            throw new IllegalArgumentException("Dữ liệu KPI không hợp lệ", e);
        }
        CustomerDashboardKpiDTO result = get(actorId, month);
        result.setSelectedUserId(userId);
        return result;
    }

    private Map<String, BigDecimal> parseValues(String json) {
        try { return objectMapper.readValue(json, new TypeReference<LinkedHashMap<String, BigDecimal>>() {}); }
        catch (Exception ignored) { return Map.of(); }
    }
    private static Map<String, BigDecimal> withDefaults(Map<String, BigDecimal> source) {
        Map<String, BigDecimal> result = new LinkedHashMap<>();
        KEYS.forEach(key -> result.put(key, source == null || source.get(key) == null ? BigDecimal.ZERO : source.get(key)));
        return result;
    }
    private User requireActor(Long id) { return userRepository.findByIdWithAuth(id).orElseThrow(() -> new IllegalArgumentException("Unauthorized")); }
    private static boolean isAdmin(User user) { return user.getRole() != null && user.getRole().isAdmin(); }
    private static boolean isCskh(User user) { return user.getRoleCode() != null && "cskh".equalsIgnoreCase(user.getRoleCode()); }
    private static boolean isCskhLeader(User user) {
        return isCskh(user) && user.getLevelCode() != null
                && ("manager".equalsIgnoreCase(user.getLevelCode()) || "director".equalsIgnoreCase(user.getLevelCode()));
    }
    private static boolean canManage(User actor, User target) {
        if (isAdmin(actor)) return true;
        if (!isCskhLeader(actor) || !isCskh(target)) return false;
        if ("director".equalsIgnoreCase(actor.getLevelCode())) return true;
        String targetLevel = target.getLevelCode();
        return targetLevel == null
                || (!"manager".equalsIgnoreCase(targetLevel) && !"director".equalsIgnoreCase(targetLevel));
    }
    private static String normalizeMonth(String value) {
        if (value == null || value.isBlank()) return YearMonth.now().toString();
        try { return YearMonth.parse(value.trim()).toString(); }
        catch (Exception e) { throw new IllegalArgumentException("Tháng KPI không hợp lệ"); }
    }
}
