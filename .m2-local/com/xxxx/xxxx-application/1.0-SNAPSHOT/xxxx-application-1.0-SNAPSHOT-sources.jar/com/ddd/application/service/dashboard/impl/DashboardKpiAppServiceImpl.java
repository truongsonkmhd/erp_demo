package com.xxxx.ddd.application.service.dashboard.impl;

import com.xxxx.ddd.application.model.DashboardKpiDTO;
import com.xxxx.ddd.application.model.command.SaveDashboardKpiCommand;
import com.xxxx.ddd.application.service.dashboard.DashboardKpiAppService;
import com.xxxx.ddd.domain.model.entity.*;
import com.xxxx.ddd.domain.respository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.jdbc.core.JdbcTemplate;
import jakarta.annotation.PostConstruct;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class DashboardKpiAppServiceImpl implements DashboardKpiAppService {
    public static final String EDIT_PERMISSION = "edit_data_dashboard_kpi";
    private static final BigDecimal D_TOTAL = new BigDecimal("100");
    private static final BigDecimal D_OVERALL = new BigDecimal("100");
    private static final BigDecimal D_WRONG = new BigDecimal("10");
    private static final BigDecimal D_L0 = new BigDecimal("20");
    private static final BigDecimal D_L1 = new BigDecimal("15");
    private static final BigDecimal D_L2 = new BigDecimal("10");
    private static final BigDecimal D_L3 = new BigDecimal("8");
    private static final BigDecimal D_L5 = new BigDecimal("2");
    private static final BigDecimal D_CUSTOMERS = new BigDecimal("10");
    private static final BigDecimal D_PROFIT = new BigDecimal("100000000");
    private static final BigDecimal D_DAYS = new BigDecimal("7");
    @Autowired private UserRepository userRepository;
    @Autowired private DashboardKpiRepository dashboardKpiRepository;
    @Autowired private DashboardRoomKpiRepository dashboardRoomKpiRepository;
    @Autowired private SaleRoomRepository saleRoomRepository;
    @Autowired private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void ensureMonthlyKpiSchema() {
        Integer columnCount = jdbcTemplate.queryForObject("""
                SELECT COUNT(*) FROM information_schema.columns
                WHERE table_schema = DATABASE() AND table_name = 'tbl_dashboard_kpi' AND column_name = 'period_month'
                """, Integer.class);
        if (columnCount == null || columnCount == 0) {
            jdbcTemplate.execute("ALTER TABLE tbl_dashboard_kpi ADD COLUMN period_month VARCHAR(7) NULL AFTER user_id");
        }
        ensureKpiColumn("level_l0", "DECIMAL(18,2) NOT NULL DEFAULT 20");
        ensureKpiColumn("overall_data", "DECIMAL(18,2) NOT NULL DEFAULT 100");
        ensureKpiColumn("level_l1", "DECIMAL(18,2) NOT NULL DEFAULT 15");
        ensureKpiColumn("level_l2", "DECIMAL(18,2) NOT NULL DEFAULT 10");
        ensureKpiColumn("level_l3", "DECIMAL(18,2) NOT NULL DEFAULT 8");
        ensureKpiColumn("level_l5", "DECIMAL(18,2) NOT NULL DEFAULT 2");
        jdbcTemplate.update("UPDATE tbl_dashboard_kpi SET period_month = ? WHERE period_month IS NULL OR period_month = ''", YearMonth.now().toString());
        jdbcTemplate.execute("ALTER TABLE tbl_dashboard_kpi MODIFY COLUMN period_month VARCHAR(7) NOT NULL");
        Integer oldIndex = jdbcTemplate.queryForObject("""
                SELECT COUNT(*) FROM information_schema.statistics
                WHERE table_schema = DATABASE() AND table_name = 'tbl_dashboard_kpi' AND index_name = 'uk_dashboard_kpi_user'
                """, Integer.class);
        if (oldIndex != null && oldIndex > 0) {
            Integer userIndex = jdbcTemplate.queryForObject("""
                    SELECT COUNT(*) FROM information_schema.statistics
                    WHERE table_schema = DATABASE() AND table_name = 'tbl_dashboard_kpi' AND index_name = 'idx_dashboard_kpi_user'
                    """, Integer.class);
            if (userIndex == null || userIndex == 0) {
                jdbcTemplate.execute("ALTER TABLE tbl_dashboard_kpi ADD INDEX idx_dashboard_kpi_user (user_id)");
            }
            jdbcTemplate.execute("ALTER TABLE tbl_dashboard_kpi DROP INDEX uk_dashboard_kpi_user");
        }
        Integer monthlyIndex = jdbcTemplate.queryForObject("""
                SELECT COUNT(*) FROM information_schema.statistics
                WHERE table_schema = DATABASE() AND table_name = 'tbl_dashboard_kpi' AND index_name = 'uk_dashboard_kpi_user_month'
                """, Integer.class);
        if (monthlyIndex == null || monthlyIndex == 0) {
            jdbcTemplate.execute("ALTER TABLE tbl_dashboard_kpi ADD UNIQUE KEY uk_dashboard_kpi_user_month (user_id, period_month)");
        }
        jdbcTemplate.execute("""
                CREATE TABLE IF NOT EXISTS tbl_dashboard_room_kpi (
                  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, sale_room_id BIGINT NOT NULL,
                  period_month VARCHAR(7) NOT NULL, total_data DECIMAL(18,2) NOT NULL DEFAULT 100,
                  overall_data DECIMAL(18,2) NOT NULL DEFAULT 100, wrong_insight DECIMAL(18,2) NOT NULL DEFAULT 10,
                  level_l0 DECIMAL(18,2) NOT NULL DEFAULT 20, level_l1 DECIMAL(18,2) NOT NULL DEFAULT 15,
                  level_l2 DECIMAL(18,2) NOT NULL DEFAULT 10, level_l3 DECIMAL(18,2) NOT NULL DEFAULT 8,
                  level_l5 DECIMAL(18,2) NOT NULL DEFAULT 2, new_customers DECIMAL(18,2) NOT NULL DEFAULT 10,
                  new_profit_vnd DECIMAL(20,2) NOT NULL DEFAULT 100000000,
                  conversion_time_days DECIMAL(18,2) NOT NULL DEFAULT 7, updated_at DATETIME NULL, updated_by BIGINT NULL,
                  UNIQUE KEY uk_dashboard_room_kpi_month (sale_room_id, period_month),
                  CONSTRAINT fk_dashboard_room_kpi_room FOREIGN KEY (sale_room_id) REFERENCES tbl_sale_room(id),
                  CONSTRAINT fk_dashboard_room_kpi_updated_by FOREIGN KEY (updated_by) REFERENCES tbl_user(id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """);
    }

    private void ensureKpiColumn(String columnName, String definition) {
        Integer count = jdbcTemplate.queryForObject("""
                SELECT COUNT(*) FROM information_schema.columns
                WHERE table_schema = DATABASE() AND table_name = 'tbl_dashboard_kpi' AND column_name = ?
                """, Integer.class, columnName);
        if (count == null || count == 0) {
            jdbcTemplate.execute("ALTER TABLE tbl_dashboard_kpi ADD COLUMN " + columnName + " " + definition);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardKpiDTO get(Long actorId, String periodMonth) {
        String month = normalizeMonth(periodMonth);
        User actor = requireActor(actorId);
        boolean manager = isSaleLeader(actor);
        boolean director = isSaleDirector(actor);
        boolean admin = actor.getRole() != null && actor.getRole().isAdmin();
        boolean canEdit = admin || manager || hasPermission(actor, EDIT_PERMISSION);
        List<User> users;
        if (admin || director) {
            users = userRepository.findAllActiveWithAuth().stream()
                    .filter(u -> u.getRole() != null && u.getRole().isSale()).toList();
        } else if (manager) {
            users = actor.getSaleRoom() == null ? List.of() : userRepository.findBySaleRoomId(actor.getSaleRoom().getId()).stream()
                    .filter(user -> !Objects.equals(user.getId(), actor.getId())).toList();
        } else {
            users = List.of(actor);
        }
        // Danh sách chỉnh KPI chỉ gồm nhân viên đang hoạt động, nhưng số thực đạt
        // theo phòng phải giữ cả dữ liệu lịch sử của tài khoản đã khóa/nghỉ việc.
        List<User> roomHistoryUsers;
        if (admin || director) {
            roomHistoryUsers = userRepository.findAllWithAuth().stream()
                    .filter(u -> u.getRole() != null && u.getRole().isSale()).toList();
        } else if (manager) {
            roomHistoryUsers = actor.getSaleRoom() == null ? List.of()
                    : userRepository.findBySaleRoomId(actor.getSaleRoom().getId());
        } else {
            roomHistoryUsers = users;
        }
        Map<Long, DashboardKpi> saved = dashboardKpiRepository.findByUserIdsAndPeriodMonth(
                        users.stream().map(User::getId).toList(), month).stream()
                .collect(Collectors.toMap(k -> k.getUser().getId(), Function.identity()));
        DashboardKpiDTO result = new DashboardKpiDTO()
                .setCanEdit(canEdit)
                .setTeamManager(manager || admin)
                .setSelectedUserId(actor.getId())
                .setPeriodMonth(month)
                .setLocked(!canEdit);
        // KPI cá nhân chưa được Manager phân phải luôn là 0, kể cả khi chính nhân viên xem Dashboard.
        // Không dùng bộ KPI mặc định vì sẽ khiến Executive tưởng rằng đã được giao chỉ tiêu.
        boolean zeroUnassignedMemberKpi = true;
        result.setMembers(users.stream().map(user -> toMember(user, saved.get(user.getId()), zeroUnassignedMemberKpi)).toList());
        Map<Long, DashboardRoomKpi> savedRooms = dashboardRoomKpiRepository.findByPeriodMonth(month).stream()
                .collect(Collectors.toMap(k -> k.getSaleRoom().getId(), Function.identity()));
        List<SaleRoom> visibleRooms = (admin || director) ? saleRoomRepository.findAllActive()
                : actor.getSaleRoom() == null ? List.of() : List.of(actor.getSaleRoom());
        result.setRooms(visibleRooms.stream().map(room -> toRoom(room, savedRooms.get(room.getId()), roomHistoryUsers)).toList());
        return result;
    }

    @Override
    @Transactional
    public DashboardKpiDTO saveRoom(Long actorId, Long saleRoomId, String periodMonth, SaveDashboardKpiCommand command) {
        String month = normalizeMonth(periodMonth);
        User actor = requireActor(actorId);
        if (!isAdmin(actor) && !isSaleDirector(actor)) {
            throw new IllegalArgumentException("Chỉ Director hoặc Admin được phân KPI cho phòng");
        }
        if (command == null) throw new IllegalArgumentException("Dữ liệu KPI là bắt buộc");
        SaleRoom room = saleRoomRepository.findByIdActive(saleRoomId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy phòng Sale"));
        DashboardRoomKpi entity = dashboardRoomKpiRepository.findBySaleRoomIdAndPeriodMonth(saleRoomId, month)
                .orElseGet(() -> new DashboardRoomKpi().setSaleRoom(room).setPeriodMonth(month));
        applyRoomValues(entity, command).setUpdatedAt(LocalDateTime.now()).setUpdatedBy(actor);
        dashboardRoomKpiRepository.save(entity);
        return get(actorId, month);
    }

    @Override
    @Transactional
    public DashboardKpiDTO save(Long actorId, Long userId, String periodMonth, SaveDashboardKpiCommand command) {
        String month = normalizeMonth(periodMonth);
        User actor = requireActor(actorId);
        if (!isAdmin(actor) && !isSaleLeader(actor) && !hasPermission(actor, EDIT_PERMISSION)) {
            throw new IllegalArgumentException("Bạn không có quyền chỉnh sửa KPI");
        }
        User target = userRepository.findByIdWithAuth(userId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy nhân viên"));
        if (!canManage(actor, target)) {
            throw new IllegalArgumentException("Bạn chỉ được chỉnh sửa KPI của nhân viên trong phòng mình quản lý");
        }
        if (command == null) throw new IllegalArgumentException("Dữ liệu KPI là bắt buộc");
        if (isSaleLeader(actor) && !isSaleDirector(actor) && !isAdmin(actor)) {
            validateRoomAllocation(actor, target, month, command);
        }
        DashboardKpi entity = dashboardKpiRepository.findByUserIdAndPeriodMonth(userId, month)
                .orElseGet(() -> new DashboardKpi().setUser(target).setPeriodMonth(month));
        entity.setTotalData(nonNegative(command.getTotalData(), "Tổng data mới"))
                .setOverallData(nonNegative(command.getOverallData(), "Tổng data"))
                .setWrongInsight(nonNegative(command.getWrongInsight(), "Data sai insight"))
                .setLevelL0(nonNegative(command.getLevelL0(), "Data chưa telesales (L0)"))
                .setLevelL1(nonNegative(command.getLevelL1(), "Data đã telesales (L1)"))
                .setLevelL2(nonNegative(command.getLevelL2(), "Data đã báo giá (L2)"))
                .setLevelL3(nonNegative(command.getLevelL3(), "Data đã direct sales (L3)"))
                .setLevelL5(nonNegative(command.getLevelL5(), "Data đã chuyển đổi khách hàng (L4)"))
                .setCorrectInsight(entity.getCorrectInsight() == null ? BigDecimal.ZERO : entity.getCorrectInsight())
                .setNewCustomers(nonNegative(command.getNewCustomers(), "Khách hàng mới"))
                .setNewProfitVnd(nonNegative(command.getNewProfitVnd(), "Lợi nhuận mới"))
                .setConversionTimeDays(nonNegative(command.getConversionTimeDays(), "Thời gian chuyển đổi"))
                .setUpdatedAt(LocalDateTime.now()).setUpdatedBy(actor);
        dashboardKpiRepository.save(entity);
        DashboardKpiDTO result = get(actorId, month);
        result.setSelectedUserId(userId);
        return result;
    }

    private DashboardKpiDTO.Member toMember(User user, DashboardKpi kpi, boolean zeroWhenMissing) {
        BigDecimal total = zeroWhenMissing ? BigDecimal.ZERO : D_TOTAL;
        BigDecimal overall = zeroWhenMissing ? BigDecimal.ZERO : D_OVERALL;
        BigDecimal wrong = zeroWhenMissing ? BigDecimal.ZERO : D_WRONG;
        BigDecimal l0 = zeroWhenMissing ? BigDecimal.ZERO : D_L0;
        BigDecimal l1 = zeroWhenMissing ? BigDecimal.ZERO : D_L1;
        BigDecimal l2 = zeroWhenMissing ? BigDecimal.ZERO : D_L2;
        BigDecimal l3 = zeroWhenMissing ? BigDecimal.ZERO : D_L3;
        BigDecimal l5 = zeroWhenMissing ? BigDecimal.ZERO : D_L5;
        BigDecimal customers = zeroWhenMissing ? BigDecimal.ZERO : D_CUSTOMERS;
        BigDecimal profit = zeroWhenMissing ? BigDecimal.ZERO : D_PROFIT;
        BigDecimal days = zeroWhenMissing ? BigDecimal.ZERO : D_DAYS;
        DashboardKpiDTO.Member row = new DashboardKpiDTO.Member()
                .setUserId(user.getId()).setUserName(user.getFullName())
                .setTotalData(valueOrDefault(kpi == null ? null : kpi.getTotalData(), total))
                .setOverallData(valueOrDefault(kpi == null ? null : kpi.getOverallData(), overall))
                .setWrongInsight(valueOrDefault(kpi == null ? null : kpi.getWrongInsight(), wrong))
                .setLevelL0(valueOrDefault(kpi == null ? null : kpi.getLevelL0(), l0))
                .setLevelL1(valueOrDefault(kpi == null ? null : kpi.getLevelL1(), l1))
                .setLevelL2(valueOrDefault(kpi == null ? null : kpi.getLevelL2(), l2))
                .setLevelL3(valueOrDefault(kpi == null ? null : kpi.getLevelL3(), l3))
                .setLevelL5(valueOrDefault(kpi == null ? null : kpi.getLevelL5(), l5))
                .setNewCustomers(valueOrDefault(kpi == null ? null : kpi.getNewCustomers(), customers))
                .setNewProfitVnd(valueOrDefault(kpi == null ? null : kpi.getNewProfitVnd(), profit))
                .setConversionTimeDays(valueOrDefault(kpi == null ? null : kpi.getConversionTimeDays(), days));
        if (user.getSaleRoom() != null) row.setSaleRoomId(user.getSaleRoom().getId()).setSaleRoomName(user.getSaleRoom().getName());
        return row;
    }

    private DashboardKpiDTO.Room toRoom(SaleRoom room, DashboardRoomKpi kpi, List<User> visibleUsers) {
        List<User> roomUsers = visibleUsers.stream()
                .filter(user -> user.getSaleRoom() != null && Objects.equals(user.getSaleRoom().getId(), room.getId())).toList();
        return new DashboardKpiDTO.Room()
                .setSaleRoomId(room.getId()).setSaleRoomName(room.getName())
                .setMemberUserIds(roomUsers.stream().map(User::getId).toList())
                .setTotalData(valueOrDefault(kpi == null ? null : kpi.getTotalData(), BigDecimal.ZERO))
                .setOverallData(valueOrDefault(kpi == null ? null : kpi.getOverallData(), BigDecimal.ZERO))
                .setWrongInsight(valueOrDefault(kpi == null ? null : kpi.getWrongInsight(), BigDecimal.ZERO))
                .setLevelL0(valueOrDefault(kpi == null ? null : kpi.getLevelL0(), BigDecimal.ZERO))
                .setLevelL1(valueOrDefault(kpi == null ? null : kpi.getLevelL1(), BigDecimal.ZERO))
                .setLevelL2(valueOrDefault(kpi == null ? null : kpi.getLevelL2(), BigDecimal.ZERO))
                .setLevelL3(valueOrDefault(kpi == null ? null : kpi.getLevelL3(), BigDecimal.ZERO))
                .setLevelL5(valueOrDefault(kpi == null ? null : kpi.getLevelL5(), BigDecimal.ZERO))
                .setNewCustomers(valueOrDefault(kpi == null ? null : kpi.getNewCustomers(), BigDecimal.ZERO))
                .setNewProfitVnd(valueOrDefault(kpi == null ? null : kpi.getNewProfitVnd(), BigDecimal.ZERO))
                .setConversionTimeDays(valueOrDefault(kpi == null ? null : kpi.getConversionTimeDays(), BigDecimal.ZERO));
    }

    private DashboardRoomKpi applyRoomValues(DashboardRoomKpi entity, SaveDashboardKpiCommand command) {
        return entity.setTotalData(nonNegative(command.getTotalData(), "Tổng data mới"))
                .setOverallData(nonNegative(command.getOverallData(), "Tổng data"))
                .setWrongInsight(nonNegative(command.getWrongInsight(), "Data sai insight"))
                .setLevelL0(nonNegative(command.getLevelL0(), "Data chưa telesales (L0)"))
                .setLevelL1(nonNegative(command.getLevelL1(), "Data đã telesales (L1)"))
                .setLevelL2(nonNegative(command.getLevelL2(), "Data đã báo giá (L2)"))
                .setLevelL3(nonNegative(command.getLevelL3(), "Data đã direct sales (L3)"))
                .setLevelL5(nonNegative(command.getLevelL5(), "Data chuyển đổi (L4)"))
                .setNewCustomers(nonNegative(command.getNewCustomers(), "Khách hàng mới"))
                .setNewProfitVnd(nonNegative(command.getNewProfitVnd(), "Lợi nhuận mới"))
                .setConversionTimeDays(nonNegative(command.getConversionTimeDays(), "Thời gian chuyển đổi"));
    }

    private void validateRoomAllocation(User actor, User target, String month, SaveDashboardKpiCommand command) {
        if (actor.getSaleRoom() == null || target.getSaleRoom() == null
                || !Objects.equals(actor.getSaleRoom().getId(), target.getSaleRoom().getId())) {
            throw new IllegalArgumentException("Nhân viên không thuộc phòng bạn quản lý");
        }
        DashboardRoomKpi roomTarget = dashboardRoomKpiRepository
                .findBySaleRoomIdAndPeriodMonth(actor.getSaleRoom().getId(), month)
                .orElseThrow(() -> new IllegalArgumentException("Director chưa phân KPI cho phòng trong tháng này"));
        List<Long> memberIds = userRepository.findBySaleRoomId(actor.getSaleRoom().getId()).stream()
                .map(User::getId).filter(id -> !Objects.equals(id, actor.getId())).toList();
        List<DashboardKpi> existing = dashboardKpiRepository.findByUserIdsAndPeriodMonth(memberIds, month).stream()
                .filter(kpi -> !Objects.equals(kpi.getUser().getId(), target.getId())).toList();

        validateAllocated("Tổng data", command.getOverallData(), roomTarget.getOverallData(), existing, DashboardKpi::getOverallData);
        validateAllocated("Tổng data mới", command.getTotalData(), roomTarget.getTotalData(), existing, DashboardKpi::getTotalData);
        validateAllocated("Data không đúng insight", command.getWrongInsight(), roomTarget.getWrongInsight(), existing, DashboardKpi::getWrongInsight);
        validateAllocated("Data L0", command.getLevelL0(), roomTarget.getLevelL0(), existing, DashboardKpi::getLevelL0);
        validateAllocated("Data L1", command.getLevelL1(), roomTarget.getLevelL1(), existing, DashboardKpi::getLevelL1);
        validateAllocated("Data L2", command.getLevelL2(), roomTarget.getLevelL2(), existing, DashboardKpi::getLevelL2);
        validateAllocated("Data L3", command.getLevelL3(), roomTarget.getLevelL3(), existing, DashboardKpi::getLevelL3);
        validateAllocated("Data L4", command.getLevelL5(), roomTarget.getLevelL5(), existing, DashboardKpi::getLevelL5);
        validateAllocated("Khách hàng mới", command.getNewCustomers(), roomTarget.getNewCustomers(), existing, DashboardKpi::getNewCustomers);
        validateAllocated("Lợi nhuận mới", command.getNewProfitVnd(), roomTarget.getNewProfitVnd(), existing, DashboardKpi::getNewProfitVnd);
        validateAllocated("Thời gian chuyển đổi", command.getConversionTimeDays(), roomTarget.getConversionTimeDays(), existing, DashboardKpi::getConversionTimeDays);
    }

    private static void validateAllocated(String label, BigDecimal requested, BigDecimal roomTarget,
                                          List<DashboardKpi> existing,
                                          Function<DashboardKpi, BigDecimal> getter) {
        BigDecimal total = nonNegative(requested, label);
        for (DashboardKpi kpi : existing) {
            BigDecimal value = getter.apply(kpi);
            if (value != null) total = total.add(value);
        }
        BigDecimal limit = roomTarget == null ? BigDecimal.ZERO : roomTarget;
        if (total.compareTo(limit) > 0) {
            throw new IllegalArgumentException(label + " đã phân vượt KPI phòng (" + total.stripTrailingZeros().toPlainString()
                    + "/" + limit.stripTrailingZeros().toPlainString() + ")");
        }
    }

    private User requireActor(Long actorId) {
        return userRepository.findByIdWithAuth(actorId).orElseThrow(() -> new IllegalArgumentException("Unauthorized"));
    }
    private static boolean isAdmin(User user) { return user.getRole() != null && user.getRole().isAdmin(); }
    private static boolean isSaleLeader(User user) {
        if (user.getRole() == null || !user.getRole().isSale() || user.getLevelCode() == null) return false;
        String level = user.getLevelCode().trim();
        return "manager".equalsIgnoreCase(level) || "director".equalsIgnoreCase(level);
    }
    private static boolean isSaleDirector(User user) {
        return user.getRole() != null && user.getRole().isSale() && user.getLevelCode() != null
                && "director".equalsIgnoreCase(user.getLevelCode().trim());
    }
    private static boolean canManage(User actor, User target) {
        if (isAdmin(actor)) return true;
        if (isSaleDirector(actor)) return target.getRole() != null && target.getRole().isSale();
        if (isSaleLeader(actor)) return actor.getSaleRoom() != null && target.getSaleRoom() != null
                && Objects.equals(actor.getSaleRoom().getId(), target.getSaleRoom().getId());
        return Objects.equals(actor.getId(), target.getId());
    }
    private static boolean hasPermission(User user, String code) {
        return user.getEffectivePermissions().stream().map(Permission::getCode).filter(Objects::nonNull)
                .anyMatch(code::equalsIgnoreCase);
    }
    private static BigDecimal nonNegative(BigDecimal value, String label) {
        if (value == null || value.signum() < 0) throw new IllegalArgumentException(label + " phải lớn hơn hoặc bằng 0");
        return value;
    }

    private static BigDecimal valueOrDefault(BigDecimal value, BigDecimal defaultValue) {
        return value == null ? defaultValue : value;
    }

    private static String normalizeMonth(String value) {
        if (value == null || value.isBlank()) return YearMonth.now().toString();
        try { return YearMonth.parse(value.trim()).toString(); }
        catch (Exception e) { throw new IllegalArgumentException("Tháng KPI không hợp lệ, định dạng đúng là YYYY-MM"); }
    }
}
