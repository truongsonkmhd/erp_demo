package com.xxxx.ddd.application.service.document;

import com.xxxx.ddd.application.model.CompanyDocumentDTO;
import com.xxxx.ddd.application.model.DocumentFilePayload;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public interface CompanyDocumentAppService {
    List<CompanyDocumentDTO> findVisible(Long categoryId, Long userId);

    CompanyDocumentDTO create(
            Long categoryId,
            String name,
            String originalFileName,
            String contentType,
            long fileSize,
            InputStream content,
            Long uploadedById,
            boolean canManageShared
    ) throws IOException;

    CompanyDocumentDTO update(
            Long id,
            Long categoryId,
            String name,
            String originalFileName,
            String contentType,
            Long fileSize,
            InputStream content,
            Long actorId,
            boolean canManageShared
    ) throws IOException;

    CompanyDocumentDTO move(Long id, Long targetCategoryId, Long actorId, boolean canManageShared);

    CompanyDocumentDTO copy(Long id, Long targetCategoryId, String name, Long actorId, boolean canManageShared)
            throws IOException;

    void delete(Long id, Long actorId, boolean canManageShared);

    DocumentFilePayload getFile(Long id, Long userId);

    DocumentFilePayload getFileWithOoToken(Long id, String ooToken);
}
