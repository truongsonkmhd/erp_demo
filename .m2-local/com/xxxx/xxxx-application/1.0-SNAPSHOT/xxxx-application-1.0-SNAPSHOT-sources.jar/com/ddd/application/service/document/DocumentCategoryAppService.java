package com.xxxx.ddd.application.service.document;

import com.xxxx.ddd.application.model.DocumentCategoryDTO;
import com.xxxx.ddd.application.model.command.SaveDocumentCategoryCommand;

import java.util.List;

public interface DocumentCategoryAppService {
    List<DocumentCategoryDTO> findVisible(Long userId);

    DocumentCategoryDTO create(SaveDocumentCategoryCommand command, Long ownerId, boolean canManageSharedMenu);

    DocumentCategoryDTO update(Long id, SaveDocumentCategoryCommand command, Long actorId, boolean canManageShared);

    void delete(Long id, Long actorId, boolean canManageShared);
}
