package com.xxxx.ddd.application.service.document.impl;

import com.xxxx.ddd.application.model.CompanyDocumentDTO;
import com.xxxx.ddd.application.model.DocumentFilePayload;
import com.xxxx.ddd.application.port.DocumentFileStorage;
import com.xxxx.ddd.application.service.document.CompanyDocumentAppService;
import com.xxxx.ddd.application.service.document.onlyoffice.OnlyOfficeAccessTokenService;
import com.xxxx.ddd.domain.model.entity.CompanyDocument;
import com.xxxx.ddd.domain.service.CompanyDocumentDomainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class CompanyDocumentAppServiceImpl implements CompanyDocumentAppService {

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    @Autowired
    private CompanyDocumentDomainService companyDocumentDomainService;

    @Autowired
    private DocumentFileStorage documentFileStorage;

    @Autowired
    private OnlyOfficeAccessTokenService onlyOfficeAccessTokenService;

    @Override
    @Transactional(readOnly = true)
    public List<CompanyDocumentDTO> findVisible(Long categoryId, Long userId) {
        return companyDocumentDomainService.findVisible(categoryId, userId).stream().map(this::toDTO).toList();
    }

    @Override
    @Transactional
    public CompanyDocumentDTO create(
            Long categoryId,
            String name,
            String originalFileName,
            String contentType,
            long fileSize,
            InputStream content,
            Long uploadedById,
            boolean canManageShared
    ) throws IOException {
        if (content == null || originalFileName == null || originalFileName.isBlank()) {
            throw new IllegalArgumentException("File is required");
        }
        String storagePath = documentFileStorage.store(originalFileName, content);
        try {
            CompanyDocument document = new CompanyDocument()
                    .setName(name)
                    .setFileName(originalFileName)
                    .setContentType(contentType)
                    .setFileSize(fileSize)
                    .setStoragePath(storagePath);
            return toDTO(companyDocumentDomainService.create(document, categoryId, uploadedById, canManageShared));
        } catch (RuntimeException ex) {
            documentFileStorage.delete(storagePath);
            throw ex;
        }
    }

    @Override
    @Transactional
    public CompanyDocumentDTO update(
            Long id,
            Long categoryId,
            String name,
            String originalFileName,
            String contentType,
            Long fileSize,
            InputStream content,
            Long actorId,
            boolean canManageShared
    ) throws IOException {
        CompanyDocument current = companyDocumentDomainService.getVisibleById(id, actorId);
        CompanyDocument updated = companyDocumentDomainService.update(id, name, categoryId, actorId, canManageShared);
        if (content != null && originalFileName != null && !originalFileName.isBlank()) {
            String oldPath = current.getStoragePath();
            String storagePath = documentFileStorage.store(originalFileName, content);
            try {
                updated = companyDocumentDomainService.updateFileMeta(
                        id,
                        originalFileName,
                        contentType,
                        fileSize == null ? 0L : fileSize,
                        storagePath,
                        actorId,
                        canManageShared
                );
                documentFileStorage.delete(oldPath);
            } catch (RuntimeException ex) {
                documentFileStorage.delete(storagePath);
                throw ex;
            }
        }
        return toDTO(updated);
    }

    @Override
    @Transactional
    public CompanyDocumentDTO move(Long id, Long targetCategoryId, Long actorId, boolean canManageShared) {
        if (targetCategoryId == null) {
            throw new IllegalArgumentException("Category is required");
        }
        return toDTO(companyDocumentDomainService.update(id, null, targetCategoryId, actorId, canManageShared));
    }

    @Override
    @Transactional
    public CompanyDocumentDTO copy(
            Long id,
            Long targetCategoryId,
            String name,
            Long actorId,
            boolean canManageShared
    ) throws IOException {
        CompanyDocument source = companyDocumentDomainService.getVisibleById(id, actorId);
        if (source.getCategory() != null && source.getCategory().getCreatedBy() == null) {
            companyDocumentDomainService.assertCopyTargetIsPersonal(targetCategoryId, actorId);
        }
        String storagePath = documentFileStorage.copy(source.getStoragePath(), source.getFileName());
        String copyName = (name == null || name.isBlank()) ? source.getName() + " (bản sao)" : name.trim();
        try {
            CompanyDocument document = new CompanyDocument()
                    .setName(copyName)
                    .setFileName(source.getFileName())
                    .setContentType(source.getContentType())
                    .setFileSize(source.getFileSize())
                    .setStoragePath(storagePath);
            return toDTO(companyDocumentDomainService.create(document, targetCategoryId, actorId, canManageShared));
        } catch (RuntimeException ex) {
            documentFileStorage.delete(storagePath);
            throw ex;
        }
    }

    @Override
    @Transactional
    public void delete(Long id, Long actorId, boolean canManageShared) {
        CompanyDocument document = companyDocumentDomainService.getVisibleById(id, actorId);
        String path = document.getStoragePath();
        companyDocumentDomainService.delete(id, actorId, canManageShared);
        documentFileStorage.delete(path);
    }

    @Override
    @Transactional(readOnly = true)
    public DocumentFilePayload getFile(Long id, Long userId) {
        CompanyDocument document = companyDocumentDomainService.getVisibleById(id, userId);
        Path path = documentFileStorage.resolve(document.getStoragePath());
        if (!Files.exists(path)) {
            throw new IllegalArgumentException("File is missing");
        }
        String contentType = document.getContentType();
        if (contentType == null || contentType.isBlank()) {
            contentType = "application/octet-stream";
        }
        long size;
        try {
            size = Files.size(path);
        } catch (IOException e) {
            size = document.getFileSize() == null ? 0L : document.getFileSize();
        }
        return new DocumentFilePayload(
                new FileSystemResource(path),
                document.getFileName(),
                contentType,
                size
        );
    }

    @Override
    @Transactional(readOnly = true)
    public DocumentFilePayload getFileWithOoToken(Long id, String ooToken) {
        OnlyOfficeAccessTokenService.TokenClaims claims = onlyOfficeAccessTokenService.parseAndValidate(ooToken, id);
        return getFile(id, claims.userId());
    }

    private CompanyDocumentDTO toDTO(CompanyDocument document) {
        CompanyDocumentDTO dto = new CompanyDocumentDTO();
        dto.setId(document.getId());
        if (document.getCategory() != null) {
            dto.setCategoryId(document.getCategory().getId());
            dto.setCategoryName(document.getCategory().getName());
        }
        dto.setName(document.getName());
        dto.setFileName(document.getFileName());
        dto.setContentType(document.getContentType());
        dto.setFileSize(document.getFileSize());
        if (document.getUploadedBy() != null) {
            dto.setUploadedById(document.getUploadedBy().getId());
            dto.setUploadedByName(document.getUploadedBy().getFullName());
        }
        dto.setCreatedAt(format(document.getCreatedAt()));
        dto.setUpdatedAt(format(document.getUpdatedAt()));
        return dto;
    }

    private static String format(LocalDateTime value) {
        return value == null ? null : value.format(ISO);
    }
}
