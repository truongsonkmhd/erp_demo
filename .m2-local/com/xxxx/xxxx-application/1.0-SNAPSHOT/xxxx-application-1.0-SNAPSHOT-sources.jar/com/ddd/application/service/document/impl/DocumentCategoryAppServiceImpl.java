package com.xxxx.ddd.application.service.document.impl;

import com.xxxx.ddd.application.port.DocumentFileStorage;
import com.xxxx.ddd.application.model.DocumentCategoryDTO;
import com.xxxx.ddd.application.model.command.SaveDocumentCategoryCommand;
import com.xxxx.ddd.application.service.document.DocumentCategoryAppService;
import com.xxxx.ddd.domain.model.entity.CompanyDocument;
import com.xxxx.ddd.domain.model.entity.DocumentCategory;
import com.xxxx.ddd.domain.respository.CompanyDocumentRepository;
import com.xxxx.ddd.domain.service.DocumentCategoryDomainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class DocumentCategoryAppServiceImpl implements DocumentCategoryAppService {

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    @Autowired
    private DocumentCategoryDomainService documentCategoryDomainService;

    @Autowired
    private CompanyDocumentRepository companyDocumentRepository;

    @Autowired
    private DocumentFileStorage documentFileStorage;

    @Override
    @Transactional(readOnly = true)
    public List<DocumentCategoryDTO> findVisible(Long userId) {
        return documentCategoryDomainService.findVisible(userId).stream().map(this::toDTO).toList();
    }

    @Override
    @Transactional
    public DocumentCategoryDTO create(SaveDocumentCategoryCommand command, Long ownerId, boolean canManageSharedMenu) {
        boolean sharedMenu = Boolean.TRUE.equals(command.getSharedMenu());
        DocumentCategory category = new DocumentCategory()
                .setName(command.getName())
                .setSortOrder(command.getSortOrder())
                .setActive(command.getActive())
                .setEditable(command.getEditable());
        return toDTO(documentCategoryDomainService.create(category, ownerId, sharedMenu, canManageSharedMenu));
    }

    @Override
    @Transactional
    public DocumentCategoryDTO update(Long id, SaveDocumentCategoryCommand command, Long actorId, boolean canManageShared) {
        DocumentCategory patch = new DocumentCategory()
                .setName(command.getName())
                .setSortOrder(command.getSortOrder())
                .setActive(command.getActive())
                .setEditable(command.getEditable());
        return toDTO(documentCategoryDomainService.update(
                id, patch, actorId, canManageShared, command.getSharedMenu()));
    }

    @Override
    @Transactional
    public void delete(Long id, Long actorId, boolean canManageShared) {
        List<CompanyDocument> documents = companyDocumentRepository.findActiveByCategoryId(id);
        documentCategoryDomainService.delete(id, actorId, canManageShared);
        for (CompanyDocument document : documents) {
            if (document.getStoragePath() != null && !document.getStoragePath().isBlank()) {
                documentFileStorage.delete(document.getStoragePath());
            }
        }
    }

    private DocumentCategoryDTO toDTO(DocumentCategory category) {
        DocumentCategoryDTO dto = new DocumentCategoryDTO();
        dto.setId(category.getId());
        dto.setName(category.getName());
        dto.setSortOrder(category.getSortOrder());
        dto.setActive(category.getActive());
        dto.setEditable(category.getEditable());
        if (category.getCreatedBy() != null) {
            dto.setCreatedById(category.getCreatedBy().getId());
        }
        dto.setCreatedAt(format(category.getCreatedAt()));
        dto.setUpdatedAt(format(category.getUpdatedAt()));
        return dto;
    }

    private static String format(LocalDateTime value) {
        return value == null ? null : value.format(ISO);
    }
}
