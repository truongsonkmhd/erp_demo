package com.xxxx.ddd.application.service.document.onlyoffice;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;

@Service
public class OnlyOfficeAccessTokenService {

    private static final Base64.Encoder ENCODER = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder DECODER = Base64.getUrlDecoder();

    private final OnlyOfficeProperties properties;
    private final ObjectMapper objectMapper;
    private final SecretKey hmacKey;

    public OnlyOfficeAccessTokenService(
            OnlyOfficeProperties properties,
            ObjectMapper objectMapper,
            @Value("${security.jwt.base64-secret}") String base64Secret
    ) {
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.hmacKey = Keys.hmacShaKeyFor(Decoders.BASE64.decode(base64Secret));
    }

    public String createToken(Long documentId, Long userId, String mode) {
        long exp = Instant.now().getEpochSecond() + properties.getTokenTtlMinutes() * 60L;
        try {
            String payloadJson = objectMapper.writeValueAsString(Map.of(
                    "docId", documentId,
                    "userId", userId,
                    "mode", mode,
                    "exp", exp
            ));
            String payload = ENCODER.encodeToString(payloadJson.getBytes(StandardCharsets.UTF_8));
            String signature = ENCODER.encodeToString(sign(payload));
            return payload + "." + signature;
        } catch (Exception e) {
            throw new IllegalStateException("Failed to create OnlyOffice token", e);
        }
    }

    public TokenClaims parseAndValidate(String token, Long expectedDocumentId) {
        if (token == null || token.isBlank()) {
            throw new IllegalArgumentException("OnlyOffice token is required");
        }
        String[] parts = token.split("\\.", 2);
        if (parts.length != 2) {
            throw new IllegalArgumentException("Invalid OnlyOffice token");
        }
        byte[] expectedSig = sign(parts[0]);
        byte[] actualSig;
        try {
            actualSig = DECODER.decode(parts[1]);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid OnlyOffice token");
        }
        if (!java.security.MessageDigest.isEqual(expectedSig, actualSig)) {
            throw new IllegalArgumentException("Invalid OnlyOffice token");
        }
        try {
            String json = new String(DECODER.decode(parts[0]), StandardCharsets.UTF_8);
            @SuppressWarnings("unchecked")
            Map<String, Object> map = objectMapper.readValue(json, Map.class);
            long exp = ((Number) map.get("exp")).longValue();
            if (Instant.now().getEpochSecond() > exp) {
                throw new IllegalArgumentException("OnlyOffice token expired");
            }
            Long docId = ((Number) map.get("docId")).longValue();
            Long userId = ((Number) map.get("userId")).longValue();
            String mode = String.valueOf(map.get("mode"));
            if (expectedDocumentId != null && !expectedDocumentId.equals(docId)) {
                throw new IllegalArgumentException("OnlyOffice token mismatch");
            }
            return new TokenClaims(docId, userId, mode);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid OnlyOffice token", e);
        }
    }

    private byte[] sign(String payloadPart) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(hmacKey.getEncoded(), "HmacSHA256"));
            return mac.doFinal(payloadPart.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new IllegalStateException("Failed to sign OnlyOffice token", e);
        }
    }

    public record TokenClaims(Long documentId, Long userId, String mode) {}
}
