package com.xxxx.ddd.application.service.document.onlyoffice;

import com.xxxx.ddd.application.model.OnlyOfficeEditorConfigDTO;
import com.xxxx.ddd.application.port.DocumentFileStorage;
import com.xxxx.ddd.domain.model.entity.CompanyDocument;
import com.xxxx.ddd.domain.service.CompanyDocumentDomainService;
import com.xxxx.ddd.domain.service.impl.DocumentCategoryDomainServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

@Service
public class OnlyOfficeDocumentAppService {

    private static final DateTimeFormatter KEY_FORMAT = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private final OnlyOfficeProperties properties;
    private final OnlyOfficeAccessTokenService tokenService;
    private final CompanyDocumentDomainService companyDocumentDomainService;
    private final DocumentFileStorage documentFileStorage;
    private final RestTemplate restTemplate;

    public OnlyOfficeDocumentAppService(
            OnlyOfficeProperties properties,
            OnlyOfficeAccessTokenService tokenService,
            CompanyDocumentDomainService companyDocumentDomainService,
            DocumentFileStorage documentFileStorage,
            RestTemplate restTemplate
    ) {
        this.properties = properties;
        this.tokenService = tokenService;
        this.companyDocumentDomainService = companyDocumentDomainService;
        this.documentFileStorage = documentFileStorage;
        this.restTemplate = restTemplate;
    }

    @Transactional(readOnly = true)
    public OnlyOfficeEditorConfigDTO buildEditorConfig(
            Long documentId,
            Long userId,
            String userName,
            String requestedMode,
            boolean canManageShared
    ) {
        CompanyDocument document = companyDocumentDomainService.getVisibleById(documentId, userId);
        if (!OnlyOfficeFormatSupport.isSupported(document.getFileName())) {
            throw new IllegalArgumentException("This file type is not supported by OnlyOffice");
        }
        boolean canEdit = "edit".equalsIgnoreCase(requestedMode)
                && DocumentCategoryDomainServiceImpl.canWriteDocuments(
                document.getCategory(), userId, canManageShared);
        String mode = canEdit ? "edit" : "view";
        String ooToken = tokenService.createToken(documentId, userId, mode);
        String baseUrl = normalizeBaseUrl(properties.getPublicBaseUrl());
        String encodedToken = urlEncode(ooToken);
        String fileUrl = baseUrl + "/api/documents/" + documentId + "/file?ooToken=" + encodedToken;
        String callbackUrl = baseUrl + "/api/onlyoffice/callback/" + documentId + "?ooToken=" + encodedToken;

        String ext = OnlyOfficeFormatSupport.extension(document.getFileName());
        // Include publicBaseUrl host so a bad cached download from a previous tunnel/URL is not reused.
        String documentKey = document.getId() + "_"
                + (document.getUpdatedAt() == null ? "0" : document.getUpdatedAt().format(KEY_FORMAT))
                + "_" + Integer.toHexString(baseUrl.hashCode());

        Map<String, Object> permissions = new HashMap<>();
        permissions.put("edit", canEdit);
        permissions.put("download", true);
        permissions.put("print", true);

        Map<String, Object> documentConfig = new HashMap<>();
        documentConfig.put("fileType", ext);
        documentConfig.put("key", documentKey);
        documentConfig.put("title", document.getFileName());
        documentConfig.put("url", fileUrl);
        documentConfig.put("permissions", permissions);

        Map<String, Object> user = new HashMap<>();
        user.put("id", String.valueOf(userId));
        user.put("name", userName == null || userName.isBlank() ? "User" : userName);

        Map<String, Object> editorConfig = new HashMap<>();
        editorConfig.put("callbackUrl", callbackUrl);
        editorConfig.put("mode", mode);
        editorConfig.put("lang", "vi");
        editorConfig.put("user", user);

        Map<String, Object> config = new HashMap<>();
        config.put("document", documentConfig);
        config.put("documentType", OnlyOfficeFormatSupport.documentType(document.getFileName()));
        config.put("editorConfig", editorConfig);

        OnlyOfficeEditorConfigDTO dto = new OnlyOfficeEditorConfigDTO();
        dto.setDocumentServerUrl(normalizeServerUrl(properties.getDocumentServerUrl()));
        dto.setConfig(config);
        return dto;
    }

    @Transactional
    public Map<String, Object> handleCallback(Long documentId, String ooToken, Map<String, Object> body) throws IOException {
        OnlyOfficeAccessTokenService.TokenClaims claims = tokenService.parseAndValidate(ooToken, documentId);
        if (!"edit".equalsIgnoreCase(claims.mode())) {
            return Map.of("error", 0);
        }
        int status = body.get("status") instanceof Number number ? number.intValue() : -1;
        if (status == 2 || status == 6) {
            Object urlObj = body.get("url");
            if (urlObj == null || String.valueOf(urlObj).isBlank()) {
                return Map.of("error", 1);
            }
            byte[] bytes = restTemplate.getForObject(URI.create(String.valueOf(urlObj)), byte[].class);
            if (bytes == null || bytes.length == 0) {
                return Map.of("error", 1);
            }
            CompanyDocument document = companyDocumentDomainService.getVisibleById(documentId, claims.userId());
            try (InputStream stream = new java.io.ByteArrayInputStream(bytes)) {
                documentFileStorage.replace(document.getStoragePath(), stream);
            }
            companyDocumentDomainService.updateFileSize(documentId, bytes.length, claims.userId());
        }
        return Map.of("error", 0);
    }

    private static String normalizeBaseUrl(String url) {
        if (url == null || url.isBlank()) {
            return "http://host.docker.internal:1122";
        }
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }

    private static String normalizeServerUrl(String url) {
        if (url == null || url.isBlank()) {
            return "http://127.0.0.1:8090/";
        }
        return url.endsWith("/") ? url : url + "/";
    }

    private static String urlEncode(String value) {
        return java.net.URLEncoder.encode(value, StandardCharsets.UTF_8);
    }
}
