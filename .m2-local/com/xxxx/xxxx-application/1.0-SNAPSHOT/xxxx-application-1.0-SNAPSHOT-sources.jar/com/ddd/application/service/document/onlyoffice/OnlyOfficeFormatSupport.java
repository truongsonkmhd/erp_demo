package com.xxxx.ddd.application.service.document.onlyoffice;

import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class OnlyOfficeFormatSupport {

    private static final Set<String> SUPPORTED = Set.of(
            "doc", "docx", "xls", "xlsx", "ppt", "pptx", "pdf"
    );

    private static final Map<String, String> DOCUMENT_TYPE = Map.of(
            "doc", "word", "docx", "word",
            "xls", "cell", "xlsx", "cell",
            "ppt", "slide", "pptx", "slide",
            "pdf", "pdf"
    );

    private OnlyOfficeFormatSupport() {
    }

    public static boolean isSupported(String fileName) {
        return SUPPORTED.contains(extension(fileName));
    }

    public static String extension(String fileName) {
        if (fileName == null || !fileName.contains(".")) {
            return "";
        }
        return fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
    }

    public static String documentType(String fileName) {
        return DOCUMENT_TYPE.getOrDefault(extension(fileName), "word");
    }
}
