package com.xxxx.ddd.application.service.document.onlyoffice;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "pts.onlyoffice")
public class OnlyOfficeProperties {

    private String documentServerUrl = "http://127.0.0.1:8090/";

    /** Backend URL reachable from OnlyOffice Document Server inside Docker (not localhost). */
    private String publicBaseUrl = "http://host.docker.internal:1122";

    private int tokenTtlMinutes = 60;
}
