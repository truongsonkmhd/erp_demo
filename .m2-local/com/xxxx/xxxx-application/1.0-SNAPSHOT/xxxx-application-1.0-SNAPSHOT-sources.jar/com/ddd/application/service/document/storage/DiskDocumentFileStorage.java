package com.xxxx.ddd.application.service.document.storage;

import com.xxxx.ddd.application.port.DocumentFileStorage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.UUID;

@Service
public class DiskDocumentFileStorage implements DocumentFileStorage {

    private final Path root;

    public DiskDocumentFileStorage(@Value("${pts.documents.storage-dir:./data/company-documents}") String storageDir) {
        this.root = Path.of(storageDir).toAbsolutePath().normalize();
    }

    @Override
    public String store(String originalFileName, InputStream content) throws IOException {
        Files.createDirectories(root);
        String safeName = sanitize(originalFileName);
        String stored = UUID.randomUUID() + "_" + safeName;
        Path target = root.resolve(stored).normalize();
        if (!target.startsWith(root)) {
            throw new IOException("Invalid storage path");
        }
        Files.copy(content, target, StandardCopyOption.REPLACE_EXISTING);
        return stored;
    }

    @Override
    public String copy(String storagePath, String originalFileName) throws IOException {
        Path source = resolve(storagePath);
        if (!Files.exists(source)) {
            throw new IOException("File is missing");
        }
        Files.createDirectories(root);
        String stored = UUID.randomUUID() + "_" + sanitize(originalFileName);
        Path target = root.resolve(stored).normalize();
        if (!target.startsWith(root)) {
            throw new IOException("Invalid storage path");
        }
        Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
        return stored;
    }

    @Override
    public Path resolve(String storagePath) {
        if (storagePath == null || storagePath.isBlank()) {
            throw new IllegalArgumentException("File is missing");
        }
        Path target = root.resolve(storagePath).normalize();
        if (!target.startsWith(root)) {
            throw new IllegalArgumentException("Invalid storage path");
        }
        return target;
    }

    @Override
    public void delete(String storagePath) {
        if (storagePath == null || storagePath.isBlank()) {
            return;
        }
        try {
            Files.deleteIfExists(resolve(storagePath));
        } catch (Exception ignored) {
            // best-effort cleanup
        }
    }

    @Override
    public void replace(String storagePath, InputStream content) throws IOException {
        Path target = resolve(storagePath);
        Files.createDirectories(target.getParent());
        Files.copy(content, target, StandardCopyOption.REPLACE_EXISTING);
    }

    private static String sanitize(String originalFileName) {
        String name = originalFileName == null || originalFileName.isBlank() ? "file" : originalFileName;
        name = Path.of(name).getFileName().toString();
        name = name.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (name.length() > 80) {
            int dot = name.lastIndexOf('.');
            String ext = dot >= 0 ? name.substring(dot).toLowerCase(Locale.ROOT) : "";
            name = name.substring(0, Math.min(60, name.length())) + ext;
        }
        return name.isBlank() ? "file" : name;
    }
}
