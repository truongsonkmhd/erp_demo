package com.xxxx.ddd.application.service.leadkpi;

import com.xxxx.ddd.application.model.LeadKpiPeriodDTO;
import com.xxxx.ddd.application.model.command.SaveLeadKpiCommand;

public interface LeadKpiAppService {

    LeadKpiPeriodDTO getByPeriod(String period, Long actorId, Long saleRoomId);

    LeadKpiPeriodDTO savePeriod(String period, SaveLeadKpiCommand command, Long actorId, Long saleRoomId);
}
