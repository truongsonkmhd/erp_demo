package com.xxxx.ddd.application.service.leadkpi;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Port of pts-frontend.com/src/constants/leadKpi.ts scoring + classify rules.
 * Grade persisted as A/B/C only.
 */
public final class LeadKpiRules {

    public static final String ATTENDANCE = "attendance";
    public static final String DEADLINE = "deadline";
    public static final String SELF_DATA = "self_data";
    public static final String TELESALE = "telesale";
    public static final String QUOTE = "quote";
    public static final String MEETING = "meeting";
    public static final String CONVERT = "convert";

    public static final List<String> CRITERION_IDS = List.of(
            ATTENDANCE, DEADLINE, SELF_DATA, TELESALE, QUOTE, MEETING, CONVERT
    );

    public static final Set<String> CRITERION_ID_SET = Set.copyOf(CRITERION_IDS);

    private LeadKpiRules() {
    }

    public static BigDecimal score(String criterionId, BigDecimal actual) {
        double value = actual == null ? 0d : actual.doubleValue();
        double percent = switch (criterionId) {
            case ATTENDANCE -> value >= 19 ? 10 : -10;
            case DEADLINE -> {
                double late = Math.max(0, value);
                yield 30 - Math.min(late, 3) * 10;
            }
            case SELF_DATA -> value >= 60 ? 20 : -10;
            case TELESALE -> value >= 80 ? 10 : -10;
            case QUOTE -> value >= 50 ? 10 : -10;
            case MEETING -> {
                if (value >= 20) yield 10;
                if (value >= 10) yield 0;
                yield -10;
            }
            case CONVERT -> {
                if (value >= 8) yield 10;
                if (value > 4) yield 0;
                yield -10;
            }
            default -> throw new IllegalArgumentException("Tiêu chí KPI không hợp lệ: " + criterionId);
        };
        return BigDecimal.valueOf(percent).setScale(2, RoundingMode.HALF_UP);
    }

    public static BigDecimal totalPercent(Map<String, BigDecimal> actuals) {
        Map<String, BigDecimal> safe = actuals == null ? Map.of() : actuals;
        BigDecimal total = BigDecimal.ZERO;
        for (String id : CRITERION_IDS) {
            total = total.add(score(id, safe.getOrDefault(id, BigDecimal.ZERO)));
        }
        return total.setScale(2, RoundingMode.HALF_UP);
    }

    public static Classification classify(BigDecimal total) {
        double t = total == null ? 0d : total.doubleValue();
        if (t >= 90) {
            return new Classification("A", bd("1.0000"));
        }
        if (t >= 70) {
            return new Classification("B", bd("0.8000"));
        }
        return new Classification("C", bd("0.6000"));
    }

    public static Evaluation evaluate(Map<String, BigDecimal> actuals) {
        Map<String, BigDecimal> safe = actuals == null ? Map.of() : actuals;
        Map<String, BigDecimal> breakdown = new LinkedHashMap<>();
        BigDecimal total = BigDecimal.ZERO;
        for (String id : CRITERION_IDS) {
            BigDecimal percent = score(id, safe.getOrDefault(id, BigDecimal.ZERO));
            breakdown.put(id, percent);
            total = total.add(percent);
        }
        total = total.setScale(2, RoundingMode.HALF_UP);
        Classification classification = classify(total);
        return new Evaluation(breakdown, total, classification.grade(), classification.coefficient());
    }

    private static BigDecimal bd(String value) {
        return new BigDecimal(value);
    }

    public record Classification(String grade, BigDecimal coefficient) {
    }

    public record Evaluation(
            Map<String, BigDecimal> breakdown,
            BigDecimal totalPercent,
            String grade,
            BigDecimal coefficient
    ) {
    }
}
