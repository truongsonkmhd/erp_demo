package com.xxxx.ddd.application.service.leadkpi.impl;

import com.xxxx.ddd.application.model.LeadKpiEmployeeDTO;
import com.xxxx.ddd.application.model.LeadKpiPeriodDTO;
import com.xxxx.ddd.application.model.command.SaveLeadKpiCommand;
import com.xxxx.ddd.application.service.leadkpi.LeadKpiAppService;
import com.xxxx.ddd.application.service.leadkpi.LeadKpiRules;
import com.xxxx.ddd.application.service.salary.SalaryScopeResolver;
import com.xxxx.ddd.domain.model.entity.LeadKpiEmployee;
import com.xxxx.ddd.domain.model.entity.LeadKpiPeriod;
import com.xxxx.ddd.domain.model.entity.LeadKpiScore;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.LeadKpiEmployeeRepository;
import com.xxxx.ddd.domain.respository.LeadKpiPeriodRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class LeadKpiAppServiceImpl implements LeadKpiAppService {

    private static final Pattern PERIOD_PATTERN = Pattern.compile("^\\d{4}-(0[1-9]|1[0-2])$");

    @Autowired
    private LeadKpiPeriodRepository leadKpiPeriodRepository;

    @Autowired
    private LeadKpiEmployeeRepository leadKpiEmployeeRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SalaryScopeResolver salaryScopeResolver;

    @Override
    @Transactional(readOnly = true)
    public LeadKpiPeriodDTO getByPeriod(String period, Long actorId, Long saleRoomId) {
        String normalized = requireValidPeriod(period);
        SalaryScopeResolver.Scope scope = salaryScopeResolver.resolve(actorId, saleRoomId);
        LeadKpiPeriodDTO dto = baseDto(normalized, scope);

        LeadKpiPeriod entity = leadKpiPeriodRepository.findByPeriod(normalized).orElse(null);
        if (entity == null) {
            dto.setEmployees(List.of());
            return dto;
        }

        List<LeadKpiEmployee> employees = leadKpiEmployeeRepository.findByPeriodId(entity.getId()).stream()
                .filter(e -> e.getUser() != null && scope.allows(e.getUser().getId()))
                .toList();
        dto.setEmployees(employees.stream().map(this::toEmployeeDTO).toList());
        return dto;
    }

    @Override
    @Transactional
    public LeadKpiPeriodDTO savePeriod(String period, SaveLeadKpiCommand command, Long actorId, Long saleRoomId) {
        String normalized = requireValidPeriod(period);
        SalaryScopeResolver.Scope scope = salaryScopeResolver.resolve(actorId, saleRoomId);
        if (command == null) {
            command = new SaveLeadKpiCommand();
        }
        List<SaveLeadKpiCommand.Employee> incoming =
                command.getEmployees() == null ? List.of() : command.getEmployees();

        validateEmployees(incoming, scope);

        LocalDateTime now = LocalDateTime.now();
        LeadKpiPeriod periodEntity = leadKpiPeriodRepository.findByPeriod(normalized)
                .orElseGet(() -> new LeadKpiPeriod()
                        .setPeriod(normalized)
                        .setCreatedAt(now));
        periodEntity.setUpdatedAt(now);
        periodEntity = leadKpiPeriodRepository.save(periodEntity);

        if (scope.canViewAllRooms()) {
            leadKpiEmployeeRepository.deleteByPeriodId(periodEntity.getId());
        } else {
            List<LeadKpiEmployee> existing = leadKpiEmployeeRepository.findByPeriodId(periodEntity.getId());
            for (LeadKpiEmployee employee : existing) {
                if (employee.getUser() != null && scope.allows(employee.getUser().getId())) {
                    leadKpiEmployeeRepository.delete(employee);
                }
            }
        }

        for (SaveLeadKpiCommand.Employee item : incoming) {
            User user = userRepository.findById(item.getUserId())
                    .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy user id=" + item.getUserId()));

            Map<String, BigDecimal> actuals = normalizeActuals(item.getActuals());
            LeadKpiRules.Evaluation evaluation = LeadKpiRules.evaluate(actuals);

            LeadKpiEmployee employee = new LeadKpiEmployee()
                    .setPeriod(periodEntity)
                    .setUser(user)
                    .setComment(trimToNull(item.getComment()))
                    .setTotalPercent(evaluation.totalPercent())
                    .setGrade(evaluation.grade())
                    .setCoefficient(evaluation.coefficient())
                    .setCreatedAt(now)
                    .setUpdatedAt(now);

            for (String criterionId : LeadKpiRules.CRITERION_IDS) {
                LeadKpiScore score = new LeadKpiScore()
                        .setCriterionId(criterionId)
                        .setActualValue(actuals.getOrDefault(criterionId, BigDecimal.ZERO))
                        .setCreatedAt(now)
                        .setUpdatedAt(now);
                employee.addScore(score);
            }

            leadKpiEmployeeRepository.save(employee);
        }

        return getByPeriod(normalized, actorId, saleRoomId);
    }

    private LeadKpiPeriodDTO baseDto(String period, SalaryScopeResolver.Scope scope) {
        LeadKpiPeriodDTO dto = new LeadKpiPeriodDTO();
        dto.setPeriod(period);
        dto.setCanViewAllRooms(scope.canViewAllRooms());
        dto.setScopedSaleRoomId(scope.scopedSaleRoomId());
        dto.setScopedSaleRoomName(scope.scopedSaleRoomName());
        dto.setScopeMessage(scope.emptyReason());
        dto.setEligibleUsers(scope.users().stream().map(user -> {
            LeadKpiPeriodDTO.EligibleUser item = new LeadKpiPeriodDTO.EligibleUser();
            item.setUserId(user.getId());
            item.setUserName(user.getFullName());
            if (user.getSaleRoom() != null) {
                item.setSaleRoomId(user.getSaleRoom().getId());
                item.setSaleRoomName(user.getSaleRoom().getName());
            }
            return item;
        }).collect(Collectors.toList()));
        return dto;
    }

    private LeadKpiEmployeeDTO toEmployeeDTO(LeadKpiEmployee employee) {
        LeadKpiEmployeeDTO dto = new LeadKpiEmployeeDTO();
        if (employee.getUser() != null) {
            dto.setUserId(employee.getUser().getId());
            dto.setUserName(employee.getUser().getFullName());
            if (employee.getUser().getSaleRoom() != null) {
                dto.setSaleRoomId(employee.getUser().getSaleRoom().getId());
                dto.setSaleRoomName(employee.getUser().getSaleRoom().getName());
            }
        }
        dto.setComment(employee.getComment());
        dto.setTotalPercent(employee.getTotalPercent());
        dto.setGrade(employee.getGrade());
        dto.setCoefficient(employee.getCoefficient());

        List<LeadKpiEmployeeDTO.LeadKpiScoreDTO> scores = new ArrayList<>();
        Map<String, BigDecimal> byCriterion = new LinkedHashMap<>();
        if (employee.getScores() != null) {
            for (LeadKpiScore score : employee.getScores()) {
                byCriterion.put(score.getCriterionId(), score.getActualValue());
            }
        }
        for (String criterionId : LeadKpiRules.CRITERION_IDS) {
            LeadKpiEmployeeDTO.LeadKpiScoreDTO scoreDto = new LeadKpiEmployeeDTO.LeadKpiScoreDTO();
            scoreDto.setCriterionId(criterionId);
            scoreDto.setActualValue(byCriterion.getOrDefault(criterionId, BigDecimal.ZERO));
            scores.add(scoreDto);
        }
        dto.setScores(scores);
        return dto;
    }

    private void validateEmployees(List<SaveLeadKpiCommand.Employee> employees, SalaryScopeResolver.Scope scope) {
        Set<Long> seen = new LinkedHashSet<>();
        for (SaveLeadKpiCommand.Employee item : employees) {
            if (item.getUserId() == null) {
                throw new IllegalArgumentException("userId là bắt buộc");
            }
            if (!scope.allows(item.getUserId())) {
                throw new IllegalArgumentException("Không được lưu KPI ngoài phạm vi phòng của bạn: " + item.getUserId());
            }
            if (!seen.add(item.getUserId())) {
                throw new IllegalArgumentException("Trùng userId trong kỳ KPI: " + item.getUserId());
            }
            if (item.getActuals() != null) {
                for (String key : item.getActuals().keySet()) {
                    if (!LeadKpiRules.CRITERION_ID_SET.contains(key)) {
                        throw new IllegalArgumentException("Tiêu chí KPI không hợp lệ: " + key);
                    }
                }
            }
        }
    }

    private static Map<String, BigDecimal> normalizeActuals(Map<String, BigDecimal> actuals) {
        Map<String, BigDecimal> result = new LinkedHashMap<>();
        for (String id : LeadKpiRules.CRITERION_IDS) {
            BigDecimal value = actuals == null ? null : actuals.get(id);
            result.put(id, value == null ? BigDecimal.ZERO : value);
        }
        return result;
    }

    private static String requireValidPeriod(String period) {
        if (period == null || period.isBlank()) {
            throw new IllegalArgumentException("period là bắt buộc (YYYY-MM)");
        }
        String normalized = period.trim();
        if (!PERIOD_PATTERN.matcher(normalized).matches()) {
            throw new IllegalArgumentException("period phải có dạng YYYY-MM");
        }
        return normalized;
    }

    private static String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
