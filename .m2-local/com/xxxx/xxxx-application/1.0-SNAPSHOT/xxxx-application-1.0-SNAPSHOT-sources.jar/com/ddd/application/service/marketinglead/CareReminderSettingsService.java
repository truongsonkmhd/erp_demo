package com.xxxx.ddd.application.service.marketinglead;

import com.xxxx.ddd.application.model.CareReminderSettingsDTO;
import java.math.BigDecimal;

public interface CareReminderSettingsService {
    CareReminderSettingsDTO get();
    CareReminderSettingsDTO save(int intervalMinutes, int l0, int l11, int l21, int l22,
                                 int unassignedCustomerInitialMinutes, int unassignedCustomerRepeatMinutes,
                                 int unassignedLeadInitialMinutes, int unassignedLeadRepeatMinutes,
                                 int warehouseAddressInitialMinutes, int warehouseAddressRepeatMinutes,
                                 int warehouseDebtInitialMinutes, int warehouseDebtRepeatMinutes,
                                 int customerInactiveFirstDays, int customerInactiveSecondDays,
                                 int customerInactiveThirdDays,
                                 BigDecimal utvcNorthSouthCostRateVnd, Long actorId);
}
