package com.xxxx.ddd.application.service.marketinglead;

import com.xxxx.ddd.application.model.MarketingLeadDTO;
import com.xxxx.ddd.application.model.command.AssignLeadCommand;
import com.xxxx.ddd.application.model.command.NotifyManagerCommand;
import com.xxxx.ddd.application.model.command.SaveCareProgressCommand;

/**
 * Điều phối 2 chặng assign-accept và các thông báo kèm theo.
 * taskStage = false là chặng dữ liệu marketing, true là chặng giao nhiệm vụ.
 */
public interface LeadWorkflowAppService {

    MarketingLeadDTO notifyManager(Long leadId, NotifyManagerCommand command, Long actorId);

    /** Sale/CSKH yêu cầu tạo đơn: chuyển sang tab giao nhiệm vụ và báo quản lý phân việc. */
    MarketingLeadDTO requestCreateOrder(Long leadId, NotifyManagerCommand command, Long actorId);

    MarketingLeadDTO assign(Long leadId, AssignLeadCommand command, Long actorId, boolean taskStage);

    MarketingLeadDTO accept(Long leadId, Long actorId, boolean taskStage);

    MarketingLeadDTO saveCareProgress(Long leadId, SaveCareProgressCommand command, Long actorId);

    MarketingLeadDTO updateCareLog(Long leadId, Long logId, SaveCareProgressCommand command, Long actorId);

    MarketingLeadDTO deleteCareLog(Long leadId, Long logId, Long actorId);

}
