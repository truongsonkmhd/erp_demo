package com.xxxx.ddd.application.service.marketinglead;

import com.xxxx.ddd.application.model.AssignmentDTO;
import com.xxxx.ddd.application.model.CustomerCareLogDTO;
import com.xxxx.ddd.application.model.MarketingLeadDTO;
import com.xxxx.ddd.application.model.MarketingLeadPageDTO;
import com.xxxx.ddd.application.model.MarketingLeadStatsDTO;
import com.xxxx.ddd.application.model.command.SaveMarketingLeadCommand;

import java.util.List;

public interface MarketingLeadAppService {

    /**
     * Phân trang + filter. pageNo 1-based, mặc định size=10.
     * stages rỗng = tất cả; nhiều stage cách nhau bởi dấu phẩy.
     */
    MarketingLeadPageDTO search(
            String stages,
            String name,
            String phone,
            String category,
            String source,
            String careProgress,
            String assignee,
            Boolean customerCreated,
            String campaignName,
            String fromDate,
            String toDate,
            String fromMonth,
            String toMonth,
            boolean pendingForMe,
            boolean dashboard,
            int pageNo,
            int pageSize,
            String sortBy,
            String sortDir,
            Long actorId
    );

    MarketingLeadStatsDTO stats(String fromDate, String toDate, String fromMonth, String toMonth, boolean dashboard, Long dashboardUserId, Long actorId);

    MarketingLeadDTO lookup(String query, String code, String phone, Long actorId);

    /** @deprecated dùng {@link #search} — giữ cho tương thích nội bộ nếu còn gọi. */
    List<MarketingLeadDTO> findAll(String stages, Long actorId);

    MarketingLeadDTO getById(Long id, Long actorId);

    MarketingLeadDTO create(SaveMarketingLeadCommand command, Long actorId);

    MarketingLeadDTO update(Long id, SaveMarketingLeadCommand command, Long actorId);

    void delete(Long id, Long actorId);

    List<CustomerCareLogDTO> findCareLogs(Long leadId, Long actorId);

    List<AssignmentDTO> findAssignmentHistory(Long leadId, String refType, Long actorId);

    List<String> listCampaignNames(Long actorId);
}
