package com.xxxx.ddd.application.service.marketinglead.impl;

import com.xxxx.ddd.application.model.CareReminderSettingsDTO;
import com.xxxx.ddd.application.service.marketinglead.CareReminderSettingsService;
import com.xxxx.ddd.domain.model.entity.CareReminderSettings;
import com.xxxx.ddd.domain.respository.CareReminderSettingsRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.math.BigDecimal;

@Service
public class CareReminderSettingsServiceImpl implements CareReminderSettingsService {
    private final CareReminderSettingsRepository repository;
    private final JdbcTemplate jdbcTemplate;

    public CareReminderSettingsServiceImpl(CareReminderSettingsRepository repository, JdbcTemplate jdbcTemplate) {
        this.repository = repository;
        this.jdbcTemplate = jdbcTemplate;
    }

    @PostConstruct
    public void ensureWarehouseReminderColumns() {
        ensureColumn("warehouse_address_initial_minutes", 1440);
        ensureColumn("warehouse_address_repeat_minutes", 180);
        ensureColumn("warehouse_debt_initial_minutes", 10080);
        ensureColumn("warehouse_debt_repeat_minutes", 10080);
        ensureColumn("customer_inactive_first_days", 30);
        ensureColumn("customer_inactive_second_days", 60);
        ensureColumn("customer_inactive_third_days", 90);
    }

    private void ensureColumn(String columnName, int defaultValue) {
        Integer count = jdbcTemplate.queryForObject("""
                SELECT COUNT(*) FROM information_schema.columns
                WHERE table_schema = DATABASE() AND table_name = 'tbl_care_reminder_settings' AND column_name = ?
                """, Integer.class, columnName);
        if (count == null || count == 0) {
            jdbcTemplate.execute("ALTER TABLE tbl_care_reminder_settings ADD COLUMN " + columnName
                    + " INT NOT NULL DEFAULT " + defaultValue);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public CareReminderSettingsDTO get() {
        return toDto(repository.find().orElseGet(CareReminderSettings::new));
    }

    @Override
    @Transactional
    public CareReminderSettingsDTO save(int intervalMinutes, int l0, int l11, int l21, int l22,
                                        int unassignedCustomerInitialMinutes, int unassignedCustomerRepeatMinutes,
                                        int unassignedLeadInitialMinutes, int unassignedLeadRepeatMinutes,
                                        int warehouseAddressInitialMinutes, int warehouseAddressRepeatMinutes,
                                        int warehouseDebtInitialMinutes, int warehouseDebtRepeatMinutes,
                                        int customerInactiveFirstDays, int customerInactiveSecondDays,
                                        int customerInactiveThirdDays,
                                        BigDecimal utvcNorthSouthCostRateVnd, Long actorId) {
        if (intervalMinutes < 1 || intervalMinutes > 10080) {
            throw new IllegalArgumentException("Tần suất phải từ 1 phút đến 7 ngày");
        }
        if (utvcNorthSouthCostRateVnd == null || utvcNorthSouthCostRateVnd.signum() < 0) {
            throw new IllegalArgumentException("Đơn giá cost tàu Bắc - Nam phải từ 0 trở lên");
        }
        for (int value : new int[]{l0, l11, l21, l22, unassignedCustomerInitialMinutes, unassignedCustomerRepeatMinutes,
                unassignedLeadInitialMinutes, unassignedLeadRepeatMinutes,
                warehouseAddressInitialMinutes, warehouseAddressRepeatMinutes,
                warehouseDebtInitialMinutes, warehouseDebtRepeatMinutes}) {
            if (value < 1 || value > 525600) throw new IllegalArgumentException("Thời gian nhắc phải từ 1 phút đến 365 ngày");
        }
        if (customerInactiveFirstDays < 1 || customerInactiveSecondDays <= customerInactiveFirstDays
                || customerInactiveThirdDays <= customerInactiveSecondDays || customerInactiveThirdDays > 3650) {
            throw new IllegalArgumentException("Ba mốc ngày phải tăng dần và nằm trong khoảng 1 đến 3.650 ngày");
        }
        CareReminderSettings settings = repository.find().orElseGet(CareReminderSettings::new);
        settings.setIntervalMinutes(intervalMinutes)
                .setL0IntervalMinutes(l0).setL11IntervalMinutes(l11)
                .setL21IntervalMinutes(l21).setL22IntervalMinutes(l22)
                .setUnassignedCustomerInitialMinutes(unassignedCustomerInitialMinutes)
                .setUnassignedCustomerRepeatMinutes(unassignedCustomerRepeatMinutes)
                .setUnassignedLeadInitialMinutes(unassignedLeadInitialMinutes)
                .setUnassignedLeadRepeatMinutes(unassignedLeadRepeatMinutes)
                .setWarehouseAddressInitialMinutes(warehouseAddressInitialMinutes)
                .setWarehouseAddressRepeatMinutes(warehouseAddressRepeatMinutes)
                .setWarehouseDebtInitialMinutes(warehouseDebtInitialMinutes)
                .setWarehouseDebtRepeatMinutes(warehouseDebtRepeatMinutes)
                .setCustomerInactiveFirstDays(customerInactiveFirstDays)
                .setCustomerInactiveSecondDays(customerInactiveSecondDays)
                .setCustomerInactiveThirdDays(customerInactiveThirdDays)
                .setUtvcNorthSouthCostRateVnd(utvcNorthSouthCostRateVnd)
                .setUpdatedBy(actorId)
                .setUpdatedAt(LocalDateTime.now());
        return toDto(repository.save(settings));
    }

    private static CareReminderSettingsDTO toDto(CareReminderSettings settings) {
        return new CareReminderSettingsDTO(
                settings.getIntervalMinutes() == null ? 30 : settings.getIntervalMinutes(),
                settings.getL0IntervalMinutes() == null ? 30 : settings.getL0IntervalMinutes(),
                settings.getL11IntervalMinutes() == null ? 1440 : settings.getL11IntervalMinutes(),
                settings.getL21IntervalMinutes() == null ? 1440 : settings.getL21IntervalMinutes(),
                settings.getL22IntervalMinutes() == null ? 10080 : settings.getL22IntervalMinutes(),
                settings.getUnassignedCustomerInitialMinutes() == null ? 1440 : settings.getUnassignedCustomerInitialMinutes(),
                settings.getUnassignedCustomerRepeatMinutes() == null ? 720 : settings.getUnassignedCustomerRepeatMinutes(),
                settings.getUnassignedLeadInitialMinutes() == null ? 1440 : settings.getUnassignedLeadInitialMinutes(),
                settings.getUnassignedLeadRepeatMinutes() == null ? 720 : settings.getUnassignedLeadRepeatMinutes(),
                settings.getWarehouseAddressInitialMinutes() == null ? 1440 : settings.getWarehouseAddressInitialMinutes(),
                settings.getWarehouseAddressRepeatMinutes() == null ? 180 : settings.getWarehouseAddressRepeatMinutes(),
                settings.getWarehouseDebtInitialMinutes() == null ? 10080 : settings.getWarehouseDebtInitialMinutes(),
                settings.getWarehouseDebtRepeatMinutes() == null ? 10080 : settings.getWarehouseDebtRepeatMinutes(),
                settings.getCustomerInactiveFirstDays() == null ? 30 : settings.getCustomerInactiveFirstDays(),
                settings.getCustomerInactiveSecondDays() == null ? 60 : settings.getCustomerInactiveSecondDays(),
                settings.getCustomerInactiveThirdDays() == null ? 90 : settings.getCustomerInactiveThirdDays(),
                settings.getUtvcNorthSouthCostRateVnd() == null ? BigDecimal.ZERO : settings.getUtvcNorthSouthCostRateVnd(),
                settings.getUpdatedAt() == null ? null : settings.getUpdatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
    }
}
