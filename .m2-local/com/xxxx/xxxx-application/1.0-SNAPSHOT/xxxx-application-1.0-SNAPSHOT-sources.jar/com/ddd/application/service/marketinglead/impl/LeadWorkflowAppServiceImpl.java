package com.xxxx.ddd.application.service.marketinglead.impl;

import com.xxxx.ddd.application.model.MarketingLeadDTO;
import com.xxxx.ddd.application.model.command.AssignLeadCommand;
import com.xxxx.ddd.application.model.command.NotifyManagerCommand;
import com.xxxx.ddd.application.model.command.SaveCareProgressCommand;
import com.xxxx.ddd.application.model.command.SendNotificationCommand;
import com.xxxx.ddd.application.service.marketinglead.LeadWorkflowAppService;
import com.xxxx.ddd.application.service.marketinglead.MarketingLeadAppService;
import com.xxxx.ddd.application.service.notification.NotificationAppService;
import com.xxxx.ddd.application.service.notification.NotificationRecipientResolver;
import com.xxxx.ddd.application.service.visibility.AssignedDataScope;
import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.entity.CustomerCareLog;
import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;
import com.xxxx.ddd.domain.model.workflow.AssignmentStatus;
import com.xxxx.ddd.domain.model.workflow.CareProgressRules;
import com.xxxx.ddd.domain.model.workflow.LeadStage;
import com.xxxx.ddd.domain.model.workflow.NotificationType;
import com.xxxx.ddd.domain.service.AssignmentDomainService;
import com.xxxx.ddd.domain.service.CustomerOrderDomainService;
import com.xxxx.ddd.domain.service.MarketingLeadDomainService;
import com.xxxx.ddd.domain.respository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class LeadWorkflowAppServiceImpl implements LeadWorkflowAppService {

    private static final String ASSIGN_PERMISSION = "assign_task_for_sale";
    /** Ai nhận thông báo khi Marketing bấm "Thông báo quản lý" (cấu hình trên Cấu hình quyền). */
    private static final String RECEIVE_NOTIFY_MANAGER = "receive_notify_manager_for_assign";
    private static final String REF_TYPE_LEAD = "MARKETING_LEAD";
    private static final String LINK_MARKETING = "/data";
    private static final String LINK_TASKS = "/tasks";
    private static final String LINK_HOME = "/dashboard";
    private static final String LINK_ORDERS = "/projects-sale";
    private static final String MARKETING_CARE_NOTE_PLACEHOLDER = "—";

    @Autowired
    private MarketingLeadDomainService marketingLeadDomainService;

    @Autowired
    private AssignmentDomainService assignmentDomainService;

    @Autowired
    private CustomerOrderDomainService customerOrderDomainService;

    @Autowired
    private MarketingLeadAppService marketingLeadAppService;

    @Autowired
    private NotificationAppService notificationAppService;

    @Autowired
    private NotificationRecipientResolver recipientResolver;

    @Autowired
    private AssignedDataScope assignedDataScope;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public MarketingLeadDTO notifyManager(Long leadId, NotifyManagerCommand command, Long actorId) {
        MarketingLead lead = marketingLeadDomainService.markManagerNotified(leadId);
        List<User> managers = recipientResolver.findByPermission(RECEIVE_NOTIFY_MANAGER);
        if (managers.isEmpty()) {
            log.warn("Không tìm thấy người có quyền {} để gửi thông báo lead {}", RECEIVE_NOTIFY_MANAGER, leadId);
        }

        String body = command != null && command.getMessage() != null && !command.getMessage().isBlank()
                ? command.getMessage()
                : "Dữ liệu marketing %s - %s%s đã nhập xong, cần phân việc cho nhân viên.".formatted(
                        lead.getCode(), lead.getFullName(), phoneSuffix(lead));

        notificationAppService.sendAll(managers.stream()
                .map(manager -> notification(command, actorId, manager.getId())
                        .setType(NotificationType.LEAD_READY_FOR_ASSIGN)
                        .setTitle("Dữ liệu marketing mới cần phân việc")
                        .setBody(body)
                        .setRefType(REF_TYPE_LEAD)
                        .setRefId(lead.getId())
                        .setLink(LINK_MARKETING + "?highlightId=" + lead.getId()))
                .toList());

        return marketingLeadAppService.getById(leadId, actorId);
    }

    @Override
    @Transactional
    public MarketingLeadDTO requestCreateOrder(Long leadId, NotifyManagerCommand command, Long actorId) {
        MarketingLead lead = marketingLeadDomainService.requestCreateOrder(leadId);
        List<User> managers = recipientResolver.findByPermission(ASSIGN_PERMISSION);
        if (managers.isEmpty()) {
            log.warn("Không tìm thấy quản lý có quyền {} để gửi yêu cầu tạo đơn lead {}", ASSIGN_PERMISSION, leadId);
        }

        String body = command != null && command.getMessage() != null && !command.getMessage().isBlank()
                ? command.getMessage()
                : "%s - %s%s cần phân việc để tạo đơn hàng.".formatted(
                        lead.getCode(), lead.getFullName(), phoneSuffix(lead));

        notificationAppService.sendAll(managers.stream()
                .map(manager -> notification(command, actorId, manager.getId())
                        .setType(NotificationType.LEAD_READY_FOR_TASK)
                        .setTitle("Yêu cầu tạo đơn hàng, cần phân việc")
                        .setBody(body)
                        .setRefType(REF_TYPE_LEAD)
                        .setRefId(lead.getId())
                        .setLink(LINK_TASKS + "?highlightId=" + lead.getId()))
                .toList());

        return marketingLeadAppService.getById(leadId, actorId);
    }

    @Override
    @Transactional
    public MarketingLeadDTO assign(Long leadId, AssignLeadCommand command, Long actorId, boolean taskStage) {
        if (!taskStage && assignedDataScope.isCustomerCareManager(actorId)) {
            throw new IllegalArgumentException("CSKH Manager chỉ được nhập Data, không được phân hoặc đổi Sales");
        }
        MarketingLead lead = marketingLeadDomainService.getById(leadId);
        AssignmentRefType refType = taskStage ? AssignmentRefType.TASK : AssignmentRefType.MARKETING_LEAD;

        if (!taskStage) {
            User actor = userRepository.findByIdWithAuth(actorId)
                    .orElseThrow(() -> new IllegalArgumentException("Người phân việc không tồn tại"));
            User assignee = userRepository.findById(command.getAssigneeId())
                    .orElseThrow(() -> new IllegalArgumentException("Nhân viên nhận việc không tồn tại"));
            String roleCode = assignee.getRole() == null ? "" : assignee.getRole().getCode();
            validateSaleAssignment(actor, assignee, roleCode);
        }

        Assignment previous = assignmentDomainService.findCurrent(refType, leadId).orElse(null);
        Assignment assignment = assignmentDomainService.assign(
                refType, leadId, command.getAssigneeId(), actorId, command.getNote());
        // Phân việc có hiệu lực ngay ở cả hai chặng, không cần nhân viên xác nhận nhận việc.
        assignmentDomainService.accept(refType, leadId, command.getAssigneeId());
        marketingLeadDomainService.markAccepted(leadId, taskStage);

        boolean reassigned = previous != null
                && !previous.getAssignee().getId().equals(assignment.getAssignee().getId());

        String title = taskStage ? "Bạn được giao nhiệm vụ mới" : "Bạn được giao dữ liệu marketing mới";
        String body = "%s %s - %s%s.%s".formatted(
                reassigned ? "Nhiệm vụ được chuyển sang cho bạn:" : "Nội dung:",
                lead.getCode(),
                lead.getFullName(),
                phoneSuffix(lead),
                command.getNote() == null || command.getNote().isBlank() ? "" : " Ghi chú: " + command.getNote());

        String targetLink = (taskStage ? LINK_TASKS : LINK_MARKETING) + "?highlightId=" + leadId;

        List<SendNotificationCommand> notifications = new ArrayList<>();
        boolean selfAssigned = actorId != null && actorId.equals(assignment.getAssignee().getId());
        if (!selfAssigned) {
            notifications.add(notification(command.getNotifyMail(), command.getNotifySystem(), actorId,
                    assignment.getAssignee().getId())
                    .setType(taskStage ? NotificationType.TASK_ASSIGNED : NotificationType.LEAD_ASSIGNED)
                    .setTitle(title)
                    .setBody(body)
                    .setRefType(REF_TYPE_LEAD)
                    .setRefId(leadId)
                    .setLink(targetLink));
        }

        if (reassigned) {
            notifications.add(notification(command.getNotifyMail(), command.getNotifySystem(), actorId,
                    previous.getAssignee().getId())
                    .setType(taskStage ? NotificationType.TASK_ASSIGNED : NotificationType.LEAD_ASSIGNED)
                    .setTitle("Nhiệm vụ đã được chuyển cho người khác")
                    .setBody("%s - %s không còn thuộc bạn phụ trách.".formatted(lead.getCode(), lead.getFullName()))
                    .setRefType(REF_TYPE_LEAD)
                    .setRefId(leadId)
                    .setLink(targetLink));
        }

        notificationAppService.sendAll(notifications);
        return marketingLeadAppService.getById(leadId, actorId);
    }

    private static void validateSaleAssignment(User actor, User assignee, String assigneeRole) {
        if (actor.getRole() != null && actor.getRole().isAdmin()) return;
        if (!"sale".equalsIgnoreCase(actor.getRoleCode()) || !"sale".equalsIgnoreCase(assigneeRole)) {
            throw new IllegalArgumentException("Data bán hàng chỉ được phân trong bộ phận Sale");
        }
        String actorLevel = actor.getLevelCode() == null ? "" : actor.getLevelCode().trim().toLowerCase();
        String targetLevel = assignee.getLevelCode() == null ? "" : assignee.getLevelCode().trim().toLowerCase();
        if (actor.getId().equals(assignee.getId())) return;
        if ("manager".equals(actorLevel)) {
            boolean sameRoom = actor.getSaleRoom() != null && assignee.getSaleRoom() != null
                    && actor.getSaleRoom().getId().equals(assignee.getSaleRoom().getId());
            if (!sameRoom || !("executive".equals(targetLevel) || "senior".equals(targetLevel))) {
                throw new IllegalArgumentException("Sales Manager chỉ được phân cho Executive/Senior trong phòng mình");
            }
            return;
        }
        if ("director".equals(actorLevel)
                && ("executive".equals(targetLevel) || "senior".equals(targetLevel) || "manager".equals(targetLevel))) return;
        throw new IllegalArgumentException("Cấp bậc của bạn không được phân Data cho nhân viên này");
    }

    @Override
    @Transactional
    public MarketingLeadDTO accept(Long leadId, Long actorId, boolean taskStage) {
        AssignmentRefType refType = taskStage ? AssignmentRefType.TASK : AssignmentRefType.MARKETING_LEAD;
        boolean alreadyAccepted = assignmentDomainService.findCurrent(refType, leadId)
                .map(current -> current.getStatus() == AssignmentStatus.ACCEPTED)
                .orElse(false);
        Assignment assignment = assignmentDomainService.accept(refType, leadId, actorId);
        MarketingLead lead = marketingLeadDomainService.markAccepted(leadId, taskStage);

        String assigneeName = assignment.getAssignee().getFullName();
        List<SendNotificationCommand> notifications = new ArrayList<>();
        if (!alreadyAccepted && assignment.getAssignedBy() != null) {
            notifications.add(notification(true, true, actorId, assignment.getAssignedBy().getId())
                    .setType(taskStage ? NotificationType.TASK_ACCEPTED : NotificationType.LEAD_ACCEPTED)
                    .setTitle("Nhân viên đã nhận việc")
                    .setBody("%s đã nhận %s - %s.".formatted(assigneeName, lead.getCode(), lead.getFullName()))
                    .setRefType(REF_TYPE_LEAD)
                    .setRefId(leadId)
                    .setLink((taskStage ? LINK_TASKS : LINK_MARKETING) + "?highlightId=" + leadId));
        }

        // Chặng 2 nhận xong thì sinh đơn hàng cho khách (1 khách hàng - N đơn).
        if (taskStage && lead.getOrderCreatedAt() == null) {
            CustomerOrder order = customerOrderDomainService.createFromLead(lead, assignment.getAssignee().getId());
            marketingLeadDomainService.markOrderCreated(leadId, order.getCustomer());
            notifications.add(notification(true, true, actorId, assignment.getAssignee().getId())
                    .setType(NotificationType.ORDER_CREATED)
                    .setTitle("Đã tạo đơn hàng " + order.getOrderCode())
                    .setBody("Đơn hàng cho khách %s được tạo tự động sau khi bạn nhận nhiệm vụ."
                            .formatted(order.getCustomer().getFullName()))
                    .setRefType("ORDER")
                    .setRefId(order.getId())
                    .setLink(LINK_ORDERS));
        }

        notificationAppService.sendAll(notifications);
        return marketingLeadAppService.getById(leadId, actorId);
    }

    @Override
    @Transactional
    public MarketingLeadDTO saveCareProgress(Long leadId, SaveCareProgressCommand command, Long actorId) {
        assignedDataScope.requireLead(actorId, leadId);
        String careProgressNote = resolveCareProgressNoteForActor(actorId, command.getCareProgressNote(), null);
        marketingLeadDomainService.applyCareProgress(
                leadId,
                command.getCareProgress(),
                careProgressNote,
                command.getHasIssue(),
                command.getIssueNote(),
                actorId);

        return marketingLeadAppService.getById(leadId, actorId);
    }

    @Override
    @Transactional
    public MarketingLeadDTO updateCareLog(Long leadId, Long logId, SaveCareProgressCommand command, Long actorId) {
        assignedDataScope.requireLead(actorId, leadId);
        CustomerCareLog current = marketingLeadDomainService.findCareLogs(leadId).stream()
                .filter(item -> item.getId().equals(logId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy tiến trình chăm sóc"));
        boolean becameSignedContract = !CareProgressRules.isAgreedToUseService(current.getCareProgress())
                && CareProgressRules.isAgreedToUseService(command.getCareProgress());
        marketingLeadDomainService.updateCareLog(
                leadId,
                logId,
                command.getCareProgress(),
                resolveCareProgressNoteForActor(actorId, command.getCareProgressNote(), current.getCareProgressNote()),
                actorId);
        return marketingLeadAppService.getById(leadId, actorId);
    }

    @Override
    @Transactional
    public MarketingLeadDTO deleteCareLog(Long leadId, Long logId, Long actorId) {
        assignedDataScope.requireLead(actorId, leadId);
        marketingLeadDomainService.deleteCareLog(leadId, logId);
        return marketingLeadAppService.getById(leadId, actorId);
    }

    private static SendNotificationCommand notification(NotifyManagerCommand command, Long actorId, Long recipientId) {
        return notification(
                command == null ? null : command.getNotifyMail(),
                command == null ? null : command.getNotifySystem(),
                actorId,
                recipientId);
    }

    private static SendNotificationCommand notification(Boolean notifyMail, Boolean notifySystem,
                                                        Long actorId, Long recipientId) {
        return new SendNotificationCommand()
                .setRecipientId(recipientId)
                .setActorId(actorId)
                .setSendEmail(!Boolean.FALSE.equals(notifyMail))
                .setSendRealtime(!Boolean.FALSE.equals(notifySystem));
    }

    private String resolveCareProgressNoteForActor(Long actorId, String requestedNote, String existingNote) {
        if (!assignedDataScope.isMarketingUser(actorId)) {
            return requestedNote;
        }
        if (existingNote != null && !existingNote.isBlank()) {
            return existingNote;
        }
        if (requestedNote != null && !requestedNote.isBlank()) {
            return requestedNote.trim();
        }
        return MARKETING_CARE_NOTE_PLACEHOLDER;
    }

    private static String phoneSuffix(MarketingLead lead) {
        return lead.getPhone() == null || lead.getPhone().isBlank() ? "" : " (" + lead.getPhone() + ")";
    }
}
