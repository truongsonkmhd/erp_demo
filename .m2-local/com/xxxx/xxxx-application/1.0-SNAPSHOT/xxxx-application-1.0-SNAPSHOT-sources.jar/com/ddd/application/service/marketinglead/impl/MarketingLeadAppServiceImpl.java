package com.xxxx.ddd.application.service.marketinglead.impl;

import com.xxxx.ddd.application.model.AssignmentDTO;
import com.xxxx.ddd.application.model.CustomerCareLogDTO;
import com.xxxx.ddd.application.model.MarketingLeadDTO;
import com.xxxx.ddd.application.model.MarketingLeadPageDTO;
import com.xxxx.ddd.application.model.MarketingLeadStatsDTO;
import com.xxxx.ddd.application.model.command.SaveMarketingLeadCommand;
import com.xxxx.ddd.application.model.command.SendNotificationCommand;
import com.xxxx.ddd.application.service.marketinglead.MarketingLeadAppService;
import com.xxxx.ddd.application.service.notification.NotificationAppService;
import com.xxxx.ddd.application.service.notification.NotificationRecipientResolver;
import com.xxxx.ddd.application.service.visibility.AssignedDataScope;
import com.xxxx.ddd.application.service.workflow.WorkflowDtoMapper;
import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;
import com.xxxx.ddd.domain.model.workflow.CampaignNamesJson;
import com.xxxx.ddd.domain.model.workflow.LeadStage;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadPage;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadSearchCriteria;
import com.xxxx.ddd.domain.model.workflow.NotificationType;
import com.xxxx.ddd.domain.respository.MarketingLeadStatsAggregate;
import com.xxxx.ddd.domain.service.AssignmentDomainService;
import com.xxxx.ddd.domain.service.MarketingLeadDomainService;
import com.xxxx.ddd.domain.respository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class MarketingLeadAppServiceImpl implements MarketingLeadAppService {

    private static final DateTimeFormatter YEAR_MONTH = DateTimeFormatter.ofPattern("yyyy-MM");

    @Autowired
    private MarketingLeadDomainService marketingLeadDomainService;

    @Autowired
    private AssignmentDomainService assignmentDomainService;

    @Autowired
    private WorkflowDtoMapper mapper;

    @Autowired
    private AssignedDataScope assignedDataScope;

    @Autowired private UserRepository userRepository;
    @Autowired private NotificationAppService notificationAppService;
    @Autowired private NotificationRecipientResolver notificationRecipientResolver;

    @Override
    @Transactional(readOnly = true)
    public MarketingLeadPageDTO search(
            String stages,
            String name,
            String phone,
            String category,
            String source,
            String careProgress,
            String assignee,
            Boolean customerCreated,
            String campaignName,
            String fromDate,
            String toDate,
            String fromMonth,
            String toMonth,
            boolean pendingForMe,
            boolean dashboard,
            int pageNo,
            int pageSize,
            String sortBy,
            String sortDir,
            Long actorId
    ) {
        Long requestedAssigneeId = parseAssigneeId(assignee);
        if (requestedAssigneeId != null) requestedAssigneeId = assignedDataScope.requireLeadAssigneeFilter(actorId, requestedAssigneeId);
        MarketingLeadSearchCriteria criteria = baseCriteria(actorId)
                .setStages(parseStages(stages))
                .setName(blankToNull(name))
                .setPhone(blankToNull(phone))
                .setCategory(blankToNull(category))
                .setSource(blankToNull(source))
                .setCareProgress(blankToNull(careProgress))
                .setUnassigned("__UNASSIGNED__".equalsIgnoreCase(blankToNull(assignee)))
                .setCustomerCreated(customerCreated)
                .setCampaignName(normalizeCampaignNameFilter(campaignName))
                .setCreatedFrom(resolveCreatedFrom(fromDate, fromMonth))
                .setCreatedTo(resolveCreatedTo(toDate, toMonth))
                .setPageNo(pageNo)
                .setPageSize(pageSize)
                .setSortBy(normalizeSortBy(sortBy))
                .setSortDir(normalizeSortDir(sortDir));
        if (requestedAssigneeId != null) {
            criteria.setAssignedAssigneeId(requestedAssigneeId);
        }
        if (dashboard) {
            criteria.setSaleRoomId(assignedDataScope.dashboardSaleRoomId(actorId));
        }
        if (pendingForMe) {
            if (actorId == null) {
                return emptyPage(pageNo, pageSize);
            }
            criteria.setPendingAssigneeId(actorId);
            // Inbox: khÃ´ng Ã¡p creator-only / assignee-or-creator (Ä‘Ã£ lá»c báº±ng pendingAssigneeId)
            criteria.setCreatedById(null);
            criteria.setMarketingNaturalScopeActorId(null);
            criteria.setAssigneeOrCreatorId(null);
            criteria.setAssignedAssigneeId(null);
        }

        MarketingLeadPage page = marketingLeadDomainService.search(criteria);
        List<MarketingLead> leads = page.items();
        List<Long> ids = leads.stream().map(MarketingLead::getId).toList();
        Map<Long, Assignment> marketingAssignments =
                assignmentDomainService.findCurrentByRefIds(AssignmentRefType.MARKETING_LEAD, ids);
        Map<Long, Assignment> taskAssignments =
                assignmentDomainService.findCurrentByRefIds(AssignmentRefType.TASK, ids);

        MarketingLeadPageDTO dto = new MarketingLeadPageDTO();
        dto.setPageNo(page.pageNo());
        dto.setPageSize(page.pageSize());
        dto.setTotalElements(page.totalElements());
        dto.setTotalPages(page.totalPages());
        dto.setItems(leads.stream()
                .map(lead -> mapper.toLeadDTO(
                        lead,
                        marketingAssignments.get(lead.getId()),
                        taskAssignments.get(lead.getId())))
                .toList());
        return dto;
    }

    private static Long parseAssigneeId(String value) {
        String normalized = blankToNull(value);
        if (normalized == null || "__UNASSIGNED__".equalsIgnoreCase(normalized)) return null;
        try {
            return Long.valueOf(normalized);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Nhân viên được phân không hợp lệ");
        }
    }

    @Override
    @Transactional(readOnly = true)
    public MarketingLeadStatsDTO stats(String fromDate, String toDate, String fromMonth, String toMonth, boolean dashboard, Long dashboardUserId, Long actorId) {
        LocalDateTime createdFrom = resolveCreatedFrom(fromDate, fromMonth);
        LocalDateTime createdTo = resolveCreatedTo(toDate, toMonth);
        MarketingLeadSearchCriteria criteria = baseCriteria(actorId)
                .setCreatedFrom(createdFrom)
                .setCreatedTo(createdTo)
                .setPageNo(1)
                .setPageSize(1);
        User dashboardActor = actorId == null ? null : userRepository.findByIdWithAuth(actorId).orElse(null);
        boolean saleDirector = dashboard && dashboardActor != null
                && dashboardActor.getRole() != null && dashboardActor.getRole().isSale()
                && "director".equalsIgnoreCase(dashboardActor.getLevelCode());
        boolean allocationOverview = dashboard && dashboardActor != null
                && (saleDirector || (dashboardActor.getRole() != null && dashboardActor.getRole().isAdmin()));
        if (dashboard) {
            criteria.setSaleRoomId(assignedDataScope.dashboardSaleRoomId(actorId));
            Long scopedUserId = assignedDataScope.requireDashboardUser(actorId, dashboardUserId);
            // Dashboard Sales chỉ tính Data đang được phân tại chặng Data cho nhân viên.
            // Không cộng Data do họ từng tạo hoặc nhiệm vụ ở chặng TASK.
            if (scopedUserId != null) criteria.setAssignedAssigneeId(scopedUserId);
            else if (allocationOverview) criteria.setAssignedOnly(true);
        }
        MarketingLeadStatsAggregate aggregate = marketingLeadDomainService.stats(criteria);
        long unassignedTotal = 0;
        if (allocationOverview) {
            MarketingLeadSearchCriteria unassignedCriteria = new MarketingLeadSearchCriteria()
                    .setCreatedFrom(createdFrom)
                    .setCreatedTo(createdTo)
                    .setUnassigned(true)
                    .setPageNo(1)
                    .setPageSize(1);
            unassignedTotal = marketingLeadDomainService.stats(unassignedCriteria).total();
        }
        MarketingLeadStatsDTO dto = new MarketingLeadStatsDTO();
        dto.setTotal(aggregate.total());
        dto.setWithCareProgress(aggregate.withCareProgress());
        dto.setWithoutCareProgress(Math.max(0, aggregate.total() - aggregate.withCareProgress()));
        dto.setWrongInsight(aggregate.wrongInsight());
        dto.setCustomerCreated(aggregate.customerCreated());
        dto.setMarketingSourceTotal(aggregate.marketingSourceTotal());
        dto.setAssignedTotal(aggregate.total());
        dto.setUnassignedTotal(unassignedTotal);
        dto.setSalesDirectorView(saleDirector);
        dto.setAllocationOverview(allocationOverview);
        dto.setByStage(aggregate.byStage() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(aggregate.byStage()));
        dto.setByCareProgress(aggregate.byCareProgress() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(aggregate.byCareProgress()));
        return dto;
    }

    @Override
    @Transactional(readOnly = true)
    public MarketingLeadDTO lookup(String query, String code, String phone, Long actorId) {
        MarketingLeadSearchCriteria criteria = baseCriteria(actorId)
                .setQuery(blankToNull(query))
                .setCode(blankToNull(code))
                .setPhone(blankToNull(phone))
                .setPageNo(1)
                .setPageSize(1);
        if (!hasText(criteria.getQuery()) && !hasText(criteria.getCode()) && !hasText(criteria.getPhone())) {
            throw new IllegalArgumentException("Cáº§n mÃ£, SÄT hoáº·c tá»« khÃ³a Ä‘á»ƒ tÃ¬m lead");
        }
        MarketingLead lead = marketingLeadDomainService.lookup(criteria)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy lead phù hợp"));
        return toDTO(lead);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MarketingLeadDTO> findAll(String stages, Long actorId) {
        MarketingLeadPageDTO page = search(stages, null, null, null, null, null, null, null, null, null, null, null, null, false, false, 1, 100, null, null, actorId);
        // Keep limited fallback for internal callers; prefer search/stats/lookup.
        List<MarketingLeadDTO> all = new ArrayList<>(page.getItems());
        int totalPages = Math.max(page.getTotalPages(), 1);
        for (int p = 2; p <= totalPages && p <= 50; p++) {
            MarketingLeadPageDTO next = search(stages, null, null, null, null, null, null, null, null, null, null, null, null, false, false, p, 100, null, null, actorId);
            all.addAll(next.getItems());
        }
        return all;
    }

    @Override
    @Transactional(readOnly = true)
    public MarketingLeadDTO getById(Long id, Long actorId) {
        assignedDataScope.requireLead(actorId, id);
        return toDTO(marketingLeadDomainService.getById(id));
    }

    @Override
    @Transactional
    public MarketingLeadDTO create(SaveMarketingLeadCommand command, Long actorId) {
        String campaignNames = command.getCampaignNames();
        if (campaignNames == null || campaignNames.isBlank()) {
            campaignNames = CampaignNamesJson.defaultManualJson();
        }
        MarketingLead lead = new MarketingLead()
                .setFullName(command.getFullName())
                .setPhone(command.getPhone())
                .setEmail(command.getEmail())
                .setCategory(command.getCategory())
                .setLeadSource(command.getLeadSource())
                .setLeadSourceNote(command.getLeadSourceNote())
                .setCampaignNames(campaignNames)
                .setInitialNeed(command.getInitialNeed())
                .setNote(command.getNote());
        MarketingLead saved = marketingLeadDomainService.create(lead, actorId);
        User actor = actorId == null ? null : userRepository.findByIdWithAuth(actorId).orElse(null);
        String role = actor == null ? "" : actor.getRoleCode();
        String level = actor == null ? "" : actor.getLevelCode();
        if ("sale".equalsIgnoreCase(role)
                && ("executive".equalsIgnoreCase(level) || "senior".equalsIgnoreCase(level)
                    || "manager".equalsIgnoreCase(level) || "director".equalsIgnoreCase(level))) {
            assignmentDomainService.assign(AssignmentRefType.MARKETING_LEAD, saved.getId(), actorId, actorId,
                    "Tự nhận khi tạo Data");
            assignmentDomainService.accept(AssignmentRefType.MARKETING_LEAD, saved.getId(), actorId);
            marketingLeadDomainService.markAccepted(saved.getId(), false);
        } else if ("marketing".equalsIgnoreCase(role)
                || ("cskh".equalsIgnoreCase(role) && "manager".equalsIgnoreCase(level))) {
            marketingLeadDomainService.markManagerNotified(saved.getId());
            notificationAppService.sendAll(notificationRecipientResolver.findSalesDirectors().stream()
                    .map(director -> new SendNotificationCommand()
                            .setRecipientId(director.getId()).setActorId(actorId)
                            .setSendEmail(true).setSendRealtime(true)
                            .setType(NotificationType.LEAD_READY_FOR_ASSIGN)
                            .setTitle("Data Marketing mới cần phân bổ")
                            .setBody("%s - %s cần phân cho Sales Manager để phân việc.".formatted(saved.getCode(), saved.getFullName()))
                            .setRefType("MARKETING_LEAD").setRefId(saved.getId())
                            .setLink("/data?highlightId=" + saved.getId()))
                    .toList());
        }
        return toDTO(saved);
    }

    @Override
    @Transactional
    public MarketingLeadDTO update(Long id, SaveMarketingLeadCommand command, Long actorId) {
        assignedDataScope.requireLead(actorId, id);
        MarketingLead patch = new MarketingLead()
                .setFullName(command.getFullName())
                .setPhone(command.getPhone())
                .setEmail(command.getEmail())
                .setCategory(command.getCategory())
                .setLeadSource(command.getLeadSource())
                .setLeadSourceNote(command.getLeadSourceNote())
                .setCampaignNames(command.getCampaignNames())
                .setInitialNeed(command.getInitialNeed())
                .setNote(command.getNote());
        return toDTO(marketingLeadDomainService.update(id, patch));
    }

    @Override
    @Transactional
    public void delete(Long id, Long actorId) {
        assignedDataScope.requireLead(actorId, id);
        marketingLeadDomainService.delete(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CustomerCareLogDTO> findCareLogs(Long leadId, Long actorId) {
        assignedDataScope.requireLead(actorId, leadId);
        return marketingLeadDomainService.findCareLogs(leadId).stream().map(mapper::toCareLogDTO).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> listCampaignNames(Long actorId) {
        return marketingLeadDomainService.listCampaignNameOptions(baseCriteria(actorId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AssignmentDTO> findAssignmentHistory(Long leadId, String refType, Long actorId) {
        assignedDataScope.requireLead(actorId, leadId);
        AssignmentRefType type = parseRefType(refType);
        return assignmentDomainService.findHistory(type, leadId).stream().map(mapper::toAssignmentDTO).toList();
    }

    private MarketingLeadSearchCriteria baseCriteria(Long actorId) {
        MarketingLeadSearchCriteria criteria = new MarketingLeadSearchCriteria();
        Long managerRoomId = assignedDataScope.managerLeadSaleRoomId(actorId);
        if (managerRoomId != null) {
            criteria.setSaleRoomId(managerRoomId).setAssignedSaleRoomOnly(true);
        } else if (assignedDataScope.shouldRestrictMarketingOwnedLeads(actorId)) {
            criteria.setMarketingNaturalScopeActorId(actorId);
        } else if (assignedDataScope.shouldRestrictLeads(actorId)) {
            criteria.setAssignedAssigneeId(actorId);
        }
        return criteria;
    }

    private MarketingLeadDTO toDTO(MarketingLead lead) {
        return mapper.toLeadDTO(
                lead,
                assignmentDomainService.findCurrent(AssignmentRefType.MARKETING_LEAD, lead.getId()).orElse(null),
                assignmentDomainService.findCurrent(AssignmentRefType.TASK, lead.getId()).orElse(null));
    }

    private static MarketingLeadPageDTO emptyPage(int pageNo, int pageSize) {
        MarketingLeadPageDTO dto = new MarketingLeadPageDTO();
        dto.setPageNo(Math.max(pageNo, 1));
        dto.setPageSize(pageSize <= 0 ? 10 : Math.min(pageSize, 100));
        dto.setTotalElements(0);
        dto.setTotalPages(0);
        dto.setItems(List.of());
        return dto;
    }

    private static List<LeadStage> parseStages(String stages) {
        if (stages == null || stages.isBlank()) {
            return List.of();
        }
        List<LeadStage> parsed = new ArrayList<>();
        for (String token : stages.split(",")) {
            String value = token.trim();
            if (value.isEmpty()) {
                continue;
            }
            try {
                parsed.add(LeadStage.valueOf(value.toUpperCase()));
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Cháº·ng khÃ´ng há»£p lá»‡: " + value);
            }
        }
        return parsed;
    }

    static AssignmentRefType parseRefType(String refType) {
        if (refType == null || refType.isBlank()) {
            return AssignmentRefType.MARKETING_LEAD;
        }
        try {
            return AssignmentRefType.valueOf(refType.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Loáº¡i phÃ¢n viá»‡c khÃ´ng há»£p lá»‡: " + refType);
        }
    }

    private static LocalDateTime parseMonthStart(String yearMonth) {
        if (!hasText(yearMonth)) {
            return null;
        }
        try {
            YearMonth ym = YearMonth.parse(yearMonth.trim(), YEAR_MONTH);
            return ym.atDay(1).atStartOfDay();
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("fromMonth pháº£i dáº¡ng yyyy-MM");
        }
    }

    private static LocalDateTime parseMonthEnd(String yearMonth) {
        if (!hasText(yearMonth)) {
            return null;
        }
        try {
            YearMonth ym = YearMonth.parse(yearMonth.trim(), YEAR_MONTH);
            LocalDate last = ym.atEndOfMonth();
            return LocalDateTime.of(last, LocalTime.MAX);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("toMonth pháº£i dáº¡ng yyyy-MM");
        }
    }

    private static LocalDateTime parseDateStart(String date) {
        if (!hasText(date)) {
            return null;
        }
        try {
            return LocalDate.parse(date.trim()).atStartOfDay();
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("fromDate pháº£i dáº¡ng yyyy-MM-dd");
        }
    }

    private static LocalDateTime parseDateEnd(String date) {
        if (!hasText(date)) {
            return null;
        }
        try {
            return LocalDate.parse(date.trim()).atTime(LocalTime.MAX);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("toDate pháº£i dáº¡ng yyyy-MM-dd");
        }
    }

    private static LocalDateTime resolveCreatedFrom(String fromDate, String fromMonth) {
        LocalDateTime parsed = parseDateStart(fromDate);
        return parsed != null ? parsed : parseMonthStart(fromMonth);
    }

    private static LocalDateTime resolveCreatedTo(String toDate, String toMonth) {
        LocalDateTime parsed = parseDateEnd(toDate);
        return parsed != null ? parsed : parseMonthEnd(toMonth);
    }

    private static String blankToNull(String value) {
        return hasText(value) ? value.trim() : null;
    }

    private static String normalizeCampaignNameFilter(String value) {
        if (!hasText(value)) {
            return null;
        }
        String trimmed = value.trim();
        if ("__OTHER__".equals(trimmed)) {
            return trimmed;
        }
        return trimmed;
    }

    private static String normalizeSortBy(String sortBy) {
        if (!hasText(sortBy)) {
            return null;
        }
        List<String> values = new ArrayList<>();
        for (String part : sortBy.split(",")) {
            String value = part.trim();
            if (!hasText(value)) {
                continue;
            }
            if (!"fullName".equalsIgnoreCase(value) && !"createdAt".equalsIgnoreCase(value)) {
                throw new IllegalArgumentException("sortBy không hợp lệ: " + sortBy);
            }
            if (values.stream().noneMatch(existing -> existing.equalsIgnoreCase(value))) {
                values.add(value);
            }
        }
        return values.isEmpty() ? null : String.join(",", values);
    }
    private static String normalizeSortDir(String sortDir) {
        if (!hasText(sortDir)) {
            return "desc";
        }
        List<String> values = new ArrayList<>();
        for (String part : sortDir.split(",")) {
            String value = part.trim().toLowerCase();
            if (!hasText(value)) {
                continue;
            }
            if (!"asc".equals(value) && !"desc".equals(value)) {
                throw new IllegalArgumentException("sortDir phải là asc hoặc desc");
            }
            values.add(value);
        }
        return values.isEmpty() ? "desc" : String.join(",", values);
    }
    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
