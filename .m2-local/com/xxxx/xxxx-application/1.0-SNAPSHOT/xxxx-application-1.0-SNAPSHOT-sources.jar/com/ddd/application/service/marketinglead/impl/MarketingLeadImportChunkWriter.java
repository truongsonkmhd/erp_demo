package com.xxxx.ddd.application.service.marketinglead.impl;

import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.workflow.LeadPhoneRef;
import com.xxxx.ddd.domain.service.MarketingLeadDomainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/** Commits sheet-import chunks in separate transactions when batch is large. */
@Service
public class MarketingLeadImportChunkWriter {

    @Autowired
    private MarketingLeadDomainService marketingLeadDomainService;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void persistChunk(List<MarketingLead> creates, List<LeadPhoneRef> updates, Long actorId) {
        if (creates != null && !creates.isEmpty()) {
            marketingLeadDomainService.batchCreate(creates, actorId);
        }
        if (updates != null && !updates.isEmpty()) {
            marketingLeadDomainService.batchUpdateCampaignNames(updates);
        }
    }
}
