package com.xxxx.ddd.application.service.notification;

import com.xxxx.ddd.application.model.NotificationDTO;
import com.xxxx.ddd.application.model.NotificationInboxDTO;
import com.xxxx.ddd.application.model.command.SendNotificationCommand;

import java.util.List;

public interface NotificationAppService {

    NotificationInboxDTO findInbox(Long recipientId, boolean unreadOnly, int limit, Long beforeId);

    NotificationDTO markRead(Long recipientId, Long notificationId);

    long markAllRead(Long recipientId);

    /** Ghi thông báo, đẩy websocket và xếp lịch gửi mail. Không ném exception ra ngoài. */
    void send(SendNotificationCommand command);

    void sendAll(List<SendNotificationCommand> commands);
}
