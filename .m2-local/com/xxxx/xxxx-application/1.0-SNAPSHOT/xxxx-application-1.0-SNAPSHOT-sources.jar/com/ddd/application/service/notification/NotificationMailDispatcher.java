package com.xxxx.ddd.application.service.notification;

import com.xxxx.ddd.application.port.MailMessage;
import com.xxxx.ddd.application.port.MailSenderPort;
import com.xxxx.ddd.domain.model.entity.Notification;
import com.xxxx.ddd.domain.model.workflow.NotificationEmailStatus;
import com.xxxx.ddd.domain.respository.NotificationRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * Gửi mail ngoài transaction nghiệp vụ: lỗi mail không được làm rollback việc phân việc.
 */
@Component
@Slf4j
public class NotificationMailDispatcher {

    @Autowired
    private MailSenderPort mailSenderPort;

    @Autowired
    private NotificationRepository notificationRepository;

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void dispatch(Long notificationId, String to, String subject, String htmlBody) {
        Notification notification = notificationRepository.findById(notificationId).orElse(null);
        if (notification == null) {
            return;
        }
        boolean sent;
        try {
            sent = mailSenderPort.send(new MailMessage(to, subject, htmlBody));
        } catch (Exception e) {
            log.error("Gửi mail thông báo {} thất bại", notificationId, e);
            sent = false;
        }
        notification.setEmailStatus(sent ? NotificationEmailStatus.SENT : NotificationEmailStatus.FAILED);
        notification.setEmailSentAt(sent ? LocalDateTime.now() : null);
        notificationRepository.save(notification);
    }
}
