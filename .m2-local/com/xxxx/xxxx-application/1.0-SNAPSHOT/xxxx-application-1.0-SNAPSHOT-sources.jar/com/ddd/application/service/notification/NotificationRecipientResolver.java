package com.xxxx.ddd.application.service.notification;

import com.xxxx.ddd.domain.model.entity.Permission;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Xác định người nhận thông báo theo quyền. Dùng lại logic quyền hiệu lực của User
 * (đã tính cả cấp bậc và trường hợp admin) thay vì viết lại truy vấn RBAC.
 */
@Component
public class NotificationRecipientResolver {

    @Autowired
    private UserRepository userRepository;

    /** Người có quyền receive_notify_manager_for_assign nhận thông báo "Thông báo quản lý". */
    @Transactional(readOnly = true)
    public List<User> findByPermission(String permissionCode) {
        if (permissionCode == null || permissionCode.isBlank()) {
            return List.of();
        }
        return userRepository.findAllActiveWithAuth().stream()
                .filter(user -> hasPermission(user, permissionCode))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<User> findCustomerCareManagers() {
        return userRepository.findAllActiveWithAuth().stream()
                .filter(user -> {
                    String role = user.getRoleCode();
                    String level = user.getLevelCode();
                    return role != null && "cskh".equalsIgnoreCase(role.trim())
                            && level != null && "manager".equalsIgnoreCase(level.trim());
                })
                .toList();
    }

    /** Sale Director nhận Data mới do Marketing tạo để phân xuống Sales Manager. */
    @Transactional(readOnly = true)
    public List<User> findSalesDirectors() {
        return userRepository.findAllActiveWithAuth().stream()
                .filter(user -> "sale".equalsIgnoreCase(user.getRoleCode())
                        && "director".equalsIgnoreCase(user.getLevelCode()))
                .toList();
    }

    private static boolean hasPermission(User user, String permissionCode) {
        for (Permission permission : user.getEffectivePermissions()) {
            if (permissionCode.equalsIgnoreCase(permission.getCode())) {
                return true;
            }
        }
        return false;
    }
}
