package com.xxxx.ddd.application.service.notification.impl;

import com.xxxx.ddd.application.model.NotificationDTO;
import com.xxxx.ddd.application.model.NotificationInboxDTO;
import com.xxxx.ddd.application.model.command.SendNotificationCommand;
import com.xxxx.ddd.application.port.RealtimeNotificationPort;
import com.xxxx.ddd.application.service.notification.NotificationAppService;
import com.xxxx.ddd.application.service.notification.NotificationMailDispatcher;
import com.xxxx.ddd.domain.model.entity.Notification;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.model.workflow.NotificationEmailStatus;
import com.xxxx.ddd.domain.respository.NotificationRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@Slf4j
public class NotificationAppServiceImpl implements NotificationAppService {

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
    private static final int MAX_PAGE = 40;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RealtimeNotificationPort realtimeNotificationPort;

    @Autowired
    private NotificationMailDispatcher mailDispatcher;

    @Override
    @Transactional(readOnly = true)
    public NotificationInboxDTO findInbox(Long recipientId, boolean unreadOnly, int limit, Long beforeId) {
        int pageSize = limit <= 0 ? 15 : Math.min(limit, MAX_PAGE);
        List<Notification> page = notificationRepository.findInboxPage(recipientId, unreadOnly, beforeId, pageSize + 1)
                .stream()
                .filter(notification -> !isSuppressed(notification))
                .toList();
        boolean hasMore = page.size() > pageSize;
        if (hasMore) {
            page = page.subList(0, pageSize);
        }
        NotificationInboxDTO inbox = new NotificationInboxDTO();
        inbox.setItems(page.stream().map(NotificationAppServiceImpl::toDTO).toList());
        inbox.setUnreadCount(notificationRepository.findUnread(recipientId).stream()
                .filter(notification -> !isSuppressed(notification))
                .count());
        inbox.setHasMore(hasMore);
        return inbox;
    }

    @Override
    @Transactional
    public NotificationDTO markRead(Long recipientId, Long notificationId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new IllegalArgumentException("Thông báo không tồn tại"));
        if (!notification.getRecipient().getId().equals(recipientId)) {
            throw new IllegalArgumentException("Không thể đọc thông báo của người khác");
        }
        if (!Boolean.TRUE.equals(notification.getIsRead())) {
            notification.setIsRead(true);
            notification.setReadAt(LocalDateTime.now());
            notificationRepository.save(notification);
        }
        return toDTO(notification);
    }

    @Override
    @Transactional
    public long markAllRead(Long recipientId) {
        List<Notification> unread = notificationRepository.findUnread(recipientId);
        LocalDateTime now = LocalDateTime.now();
        for (Notification notification : unread) {
            notification.setIsRead(true);
            notification.setReadAt(now);
            notificationRepository.save(notification);
        }
        return unread.size();
    }

    @Override
    @Transactional
    public void send(SendNotificationCommand command) {
        if (command.getRecipientId() == null) {
            return;
        }
        User recipient = userRepository.findById(command.getRecipientId()).orElse(null);
        if (recipient == null) {
            log.warn("Bỏ qua thông báo: người nhận {} không tồn tại", command.getRecipientId());
            return;
        }

        boolean wantEmail = !Boolean.FALSE.equals(command.getSendEmail())
                && recipient.getEmail() != null
                && !recipient.getEmail().isBlank();

        Notification notification = notificationRepository.save(new Notification()
                .setRecipient(recipient)
                .setActor(command.getActorId() == null ? null : userRepository.findById(command.getActorId()).orElse(null))
                .setType(command.getType())
                .setTitle(command.getTitle())
                .setBody(command.getBody())
                .setRefType(command.getRefType())
                .setRefId(command.getRefId())
                .setLink(command.getLink())
                .setIsRead(false)
                .setEmailStatus(wantEmail ? NotificationEmailStatus.PENDING : NotificationEmailStatus.SKIPPED)
                .setCreatedAt(LocalDateTime.now()));

        boolean wantRealtime = !Boolean.FALSE.equals(command.getSendRealtime());
        String emailBody = wantEmail ? buildEmailBody(recipient, notification) : null;
        // Chỉ phát tín hiệu sau khi commit: thread async phải đọc được bản ghi,
        // và transaction rollback thì không được để lại thông báo "ma".
        afterCommit(() -> {
            if (wantRealtime) {
                pushRealtime(recipient, notification);
            }
            if (wantEmail) {
                mailDispatcher.dispatch(
                        notification.getId(),
                        recipient.getEmail(),
                        notification.getTitle(),
                        emailBody);
            }
        });
    }

    @Override
    public void sendAll(List<SendNotificationCommand> commands) {
        if (commands == null) {
            return;
        }
        commands.forEach(this::send);
    }

    private static void afterCommit(Runnable action) {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            action.run();
            return;
        }
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                action.run();
            }
        });
    }

    private void pushRealtime(User recipient, Notification notification) {
        try {
            realtimeNotificationPort.sendToUser(recipient.getUsername(), toDTO(notification));
        } catch (Exception e) {
            log.warn("Không đẩy được thông báo realtime tới {}: {}", recipient.getUsername(), e.getMessage());
        }
    }

    private static String buildEmailBody(User recipient, Notification notification) {
        String body = notification.getBody() == null ? "" : notification.getBody();
        return """
                <div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#1f2937">
                  <p>Xin chào %s,</p>
                  <h3 style="color:#0265DC;margin:12px 0">%s</h3>
                  <p style="white-space:pre-line">%s</p>
                  <p style="color:#6b7280;font-size:12px;margin-top:20px">
                    Email tự động từ hệ thống Hoàng Minh Logistics.
                  </p>
                </div>
                """.formatted(recipient.getFullName(), notification.getTitle(), body);
    }

    private static NotificationDTO toDTO(Notification notification) {
        NotificationDTO dto = new NotificationDTO();
        dto.setId(notification.getId());
        dto.setType(notification.getType() == null ? null : notification.getType().name());
        // Chuẩn hóa cả các bản ghi CUSTOMER_CREATED cũ đã lưu với chuỗi sai encoding.
        dto.setTitle(notification.getType() == com.xxxx.ddd.domain.model.workflow.NotificationType.CUSTOMER_CREATED
                ? "Khách hàng mới cần phân CSKH"
                : notification.getTitle());
        dto.setBody(notification.getBody());
        dto.setRefType(notification.getRefType());
        dto.setRefId(notification.getRefId());
        dto.setLink(notification.getLink());
        dto.setIsRead(notification.getIsRead());
        dto.setReadAt(format(notification.getReadAt()));
        if (notification.getActor() != null) {
            dto.setActorId(notification.getActor().getId());
            dto.setActorName(notification.getActor().getFullName());
        }
        dto.setEmailStatus(notification.getEmailStatus() == null ? null : notification.getEmailStatus().name());
        dto.setCreatedAt(format(notification.getCreatedAt()));
        return dto;
    }

    private static boolean isSuppressed(Notification notification) {
        return notification != null
                && "Khách hàng đã ký hợp đồng, bắt đầu hỗ trợ".equals(notification.getTitle());
    }

    private static String format(LocalDateTime value) {
        return value == null ? null : value.atOffset(ZoneOffset.UTC).format(ISO);
    }
}
