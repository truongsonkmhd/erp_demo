package com.xxxx.ddd.application.service.notification.mail;

import com.xxxx.ddd.application.port.MailMessage;
import com.xxxx.ddd.application.port.MailSenderPort;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Chế độ dev: chưa có SMTP thì ghi log để vẫn kiểm tra được luồng thông báo.
 * Bật gửi thật bằng APP_MAIL_ENABLED=true.
 */
@Component
@Slf4j
@ConditionalOnProperty(prefix = "app.mail", name = "enabled", havingValue = "false", matchIfMissing = true)
public class LoggingMailSender implements MailSenderPort {

    @Override
    public boolean send(MailMessage message) {
        log.info("[MAIL-DEV] to={} subject={}\n{}", message.to(), message.subject(), message.htmlBody());
        return true;
    }

    @Override
    public boolean isRealDelivery() {
        return false;
    }
}
