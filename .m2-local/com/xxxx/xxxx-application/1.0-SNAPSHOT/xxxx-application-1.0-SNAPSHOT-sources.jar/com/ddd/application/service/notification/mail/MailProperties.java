package com.xxxx.ddd.application.service.notification.mail;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "app.mail")
public class MailProperties {

    /** false = chế độ dev, chỉ ghi log thay vì gửi thật. */
    private boolean enabled = false;

    private String from = "no-reply@hoangminh.local";
}
