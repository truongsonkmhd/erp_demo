package com.xxxx.ddd.application.service.notification.mail;

import com.xxxx.ddd.application.port.MailMessage;
import com.xxxx.ddd.application.port.MailSenderPort;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

@Component
@Slf4j
@ConditionalOnProperty(prefix = "app.mail", name = "enabled", havingValue = "true")
public class SmtpMailSender implements MailSenderPort {

    private final JavaMailSender javaMailSender;
    private final MailProperties mailProperties;

    public SmtpMailSender(JavaMailSender javaMailSender, MailProperties mailProperties) {
        this.javaMailSender = javaMailSender;
        this.mailProperties = mailProperties;
    }

    @Override
    public boolean send(MailMessage message) {
        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, StandardCharsets.UTF_8.name());
            helper.setFrom(mailProperties.getFrom());
            helper.setTo(message.to());
            helper.setSubject(message.subject());
            helper.setText(message.htmlBody(), true);
            javaMailSender.send(mimeMessage);
            return true;
        } catch (Exception e) {
            log.error("SMTP gửi mail tới {} thất bại: {}", message.to(), e.getMessage());
            return false;
        }
    }

    @Override
    public boolean isRealDelivery() {
        return true;
    }
}
