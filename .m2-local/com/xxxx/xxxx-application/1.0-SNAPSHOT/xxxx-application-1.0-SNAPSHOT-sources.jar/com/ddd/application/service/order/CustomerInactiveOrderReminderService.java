package com.xxxx.ddd.application.service.order;

import com.xxxx.ddd.application.model.CareReminderSettingsDTO;
import com.xxxx.ddd.application.model.command.SendNotificationCommand;
import com.xxxx.ddd.application.service.marketinglead.CareReminderSettingsService;
import com.xxxx.ddd.application.service.notification.NotificationAppService;
import com.xxxx.ddd.domain.model.workflow.NotificationType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@Slf4j
public class CustomerInactiveOrderReminderService {
    private final JdbcTemplate jdbcTemplate;
    private final CareReminderSettingsService settingsService;
    private final NotificationAppService notificationAppService;

    public CustomerInactiveOrderReminderService(JdbcTemplate jdbcTemplate,
                                                CareReminderSettingsService settingsService,
                                                NotificationAppService notificationAppService) {
        this.jdbcTemplate = jdbcTemplate;
        this.settingsService = settingsService;
        this.notificationAppService = notificationAppService;
    }

    @Scheduled(fixedDelay = 60000, initialDelay = 60000)
    public void sendDueReminders() {
        try {
            CareReminderSettingsDTO settings = settingsService.get();
            int[] thresholds = {settings.customerInactiveFirstDays(), settings.customerInactiveSecondDays(),
                    settings.customerInactiveThirdDays()};
            List<CustomerOrderAge> customers = jdbcTemplate.query("""
                    SELECT c.id, c.code, c.full_name, c.customer_care_staff_id, MIN(o.created_at)
                    FROM tbl_customer c
                    JOIN tbl_order o ON o.customer_id = c.id AND (o.is_deleted = 0 OR o.is_deleted IS NULL)
                    WHERE c.customer_care_staff_id IS NOT NULL
                    GROUP BY c.id, c.code, c.full_name, c.customer_care_staff_id
                    """, (rs, rowNum) -> new CustomerOrderAge(rs.getLong(1), rs.getString(2), rs.getString(3),
                    rs.getLong(4), rs.getTimestamp(5).toLocalDateTime()));
            for (CustomerOrderAge customer : customers) {
                long ageDays = ChronoUnit.DAYS.between(customer.firstOrderAt(), LocalDateTime.now());
                int dueThreshold = 0;
                for (int threshold : thresholds) if (ageDays >= threshold) dueThreshold = threshold;
                if (dueThreshold == 0 || wasSent(customer.id(), dueThreshold)) continue;
                send(customer, dueThreshold);
            }
        } catch (Exception error) {
            log.error("Customer inactive-order reminder scan failed", error);
        }
    }

    private boolean wasSent(Long customerId, int days) {
        Integer count = jdbcTemplate.queryForObject("""
                SELECT COUNT(*) FROM tbl_notification WHERE ref_type = ? AND ref_id = ?
                  AND type = 'CUSTOMER_INACTIVE_ORDER'
                """, Integer.class, refType(days), customerId);
        return count != null && count > 0;
    }

    private void send(CustomerOrderAge customer, int days) {
        String display = customer.code() == null || customer.code().isBlank()
                ? customer.name() : customer.code() + " - " + customer.name();
        notificationAppService.send(new SendNotificationCommand()
                .setRecipientId(customer.recipientId())
                .setType(NotificationType.CUSTOMER_INACTIVE_ORDER)
                .setTitle("Khách hàng lâu không đặt hàng")
                .setBody("Khách hàng " + display + " đã đạt mốc " + days
                        + " ngày kể từ đơn hàng đầu tiên. Vui lòng liên hệ chăm sóc khách hàng.")
                .setRefType(refType(days)).setRefId(customer.id())
                .setLink("/customers?highlightId=" + customer.id())
                .setSendEmail(false));
    }

    private static String refType(int days) {
        return "CUSTOMER_INACTIVE_ORDER_" + days;
    }

    private record CustomerOrderAge(Long id, String code, String name, Long recipientId,
                                    LocalDateTime firstOrderAt) {}
}
