package com.xxxx.ddd.application.service.order;

import com.xxxx.ddd.application.model.CustomerDTO;
import com.xxxx.ddd.application.model.CustomerPageDTO;
import com.xxxx.ddd.application.model.OrderDTO;
import com.xxxx.ddd.application.model.OrderPageDTO;
import com.xxxx.ddd.application.model.AssignmentDTO;
import com.xxxx.ddd.application.model.command.SaveCustomerCommand;
import com.xxxx.ddd.application.model.command.SaveOrderCommand;

import java.util.List;

public interface OrderAppService {

    List<OrderDTO> findAll(Long actorId);

    OrderPageDTO searchOrders(String query, String customerCode, String orderCode, String batchCode,
                              String customerName, String phone, String category, String productName,
                              String salesName, String customerCareName, String contractType,
                              String fromDate, String toDate, String fromMonth, String toMonth,
                              int pageNo, int pageSize, Long actorId);

    OrderDTO getById(Long id, Long actorId);

    OrderDTO create(SaveOrderCommand command, Long actorId);

    OrderDTO update(Long id, SaveOrderCommand command, Long actorId);

    OrderDTO updateWarehouse(Long id, SaveOrderCommand command, Long actorId);

    OrderDTO updateWarehouseDeliveryAddress(Long id, String address, Long actorId);

    OrderDTO requestEditApproval(Long id, Long actorId);

    OrderDTO approveEdit(Long id, Long actorId);

    void delete(Long id, Long actorId);

    void deleteWarehouse(Long id, Long actorId);

    List<CustomerDTO> findCustomers(String phone, Long actorId);

    CustomerDTO getCustomerById(Long id, Long actorId);

    CustomerPageDTO searchCustomers(String code, String name, String phone, String province, String ward,
                                    String category, Long createdById, Long customerCareStaffId,
                                    String fromDate, String toDate, String fromMonth, String toMonth,
                                    int pageNo, int pageSize, Long actorId);

    CustomerDTO createCustomer(SaveCustomerCommand command, Long actorId);

    CustomerDTO updateCustomer(Long id, SaveCustomerCommand command, Long actorId);

    void deleteCustomer(Long id, Long actorId);

    CustomerDTO assignCustomerCareStaff(Long customerId, Long staffId, String note,
                                        Boolean notifyMail, Boolean notifySystem, Long actorId);

    List<AssignmentDTO> findCustomerCareAssignmentHistory(Long customerId, Long actorId);

    List<OrderDTO> findByCustomerId(Long customerId, Long actorId);
}
