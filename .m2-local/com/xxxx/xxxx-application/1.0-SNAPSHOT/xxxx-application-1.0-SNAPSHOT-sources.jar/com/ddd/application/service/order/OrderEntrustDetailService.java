package com.xxxx.ddd.application.service.order;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xxxx.ddd.domain.model.entity.ImportEntrustOrderDetail;
import com.xxxx.ddd.domain.model.entity.TransportEntrustOrderDetail;
import com.xxxx.ddd.domain.respository.ImportEntrustOrderDetailRepository;
import com.xxxx.ddd.domain.respository.TransportEntrustOrderDetailRepository;
import org.springframework.stereotype.Service;
import org.springframework.jdbc.core.JdbcTemplate;
import jakarta.annotation.PostConstruct;
import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.math.BigDecimal;

@Service
public class OrderEntrustDetailService {
    public static final String IMPORT = "IMPORT_ENTRUST";
    public static final String TRANSPORT = "TRANSPORT_ENTRUST";

    private final ObjectMapper objectMapper;
    private final ImportEntrustOrderDetailRepository importRepository;
    private final TransportEntrustOrderDetailRepository transportRepository;
    private final JdbcTemplate jdbcTemplate;

    public OrderEntrustDetailService(ObjectMapper objectMapper,
                                     ImportEntrustOrderDetailRepository importRepository,
                                     TransportEntrustOrderDetailRepository transportRepository,
                                     JdbcTemplate jdbcTemplate) {
        this.objectMapper = objectMapper;
        this.importRepository = importRepository;
        this.transportRepository = transportRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    @PostConstruct
    public void ensureTransportDetailColumns() {
        addColumnIfMissing("vehicle_code", "VARCHAR(50) NULL AFTER transport_mode");
        addColumnIfMissing("supplier_code", "VARCHAR(50) NULL AFTER vehicle_code");
        addColumnIfMissing("warehouse_received_date", "DATE NULL AFTER supplier_code");
        addColumnIfMissing("route_status", "VARCHAR(40) NOT NULL DEFAULT 'LOADED' AFTER warehouse_received_date");
        addColumnIfMissing("delivery_address", "VARCHAR(1000) NULL AFTER cost_surcharge_vnd");
        addColumnIfMissing("delivery_province", "VARCHAR(255) NULL AFTER delivery_address");
        addColumnIfMissing("delivery_ward", "VARCHAR(255) NULL AFTER delivery_province");
        addColumnIfMissing("delivery_detail_address", "VARCHAR(500) NULL AFTER delivery_ward");
        addColumnIfMissing("utvc_debt_vnd", "DECIMAL(20,2) NULL AFTER total_revenue_vnd");
        addColumnIfMissing("revenue_destinations_json", "TEXT NULL AFTER utvc_debt_vnd");
        addColumnIfMissing("wallet_credit_vnd", "DECIMAL(20,2) NOT NULL DEFAULT 0 AFTER revenue_destinations_json");
        addCustomerColumnIfMissing("wallet_balance_vnd", "DECIMAL(20,2) NOT NULL DEFAULT 0 AFTER china_vietnam_rate_cbm");
        addOrderColumnIfMissing("paid_at", "DATE NULL AFTER total_payment_amount_vnd");
        addOrderColumnIfMissing("sales_owner_id", "BIGINT NULL AFTER assignee_id");
    }

    private void addColumnIfMissing(String columnName, String definition) {
        Integer count = jdbcTemplate.queryForObject("""
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = 'tbl_order_transport_entrust_detail'
              AND column_name = ?
            """, Integer.class, columnName);
        if (count == null || count == 0) {
            jdbcTemplate.execute("ALTER TABLE tbl_order_transport_entrust_detail ADD COLUMN "
                    + columnName + " " + definition);
        }
    }

    private void addCustomerColumnIfMissing(String columnName, String definition) {
        Integer count = jdbcTemplate.queryForObject("""
            SELECT COUNT(*) FROM information_schema.columns
            WHERE table_schema = DATABASE() AND table_name = 'tbl_customer' AND column_name = ?
            """, Integer.class, columnName);
        if (count == null || count == 0) {
            jdbcTemplate.execute("ALTER TABLE tbl_customer ADD COLUMN " + columnName + " " + definition);
        }
    }

    private void addOrderColumnIfMissing(String columnName, String definition) {
        Integer count = jdbcTemplate.queryForObject("""
            SELECT COUNT(*) FROM information_schema.columns
            WHERE table_schema = DATABASE() AND table_name = 'tbl_order' AND column_name = ?
            """, Integer.class, columnName);
        if (count == null || count == 0) {
            jdbcTemplate.execute("ALTER TABLE tbl_order ADD COLUMN " + columnName + " " + definition);
        }
    }

    public void save(Long orderId, String contractType, String overlayJson) {
        if (orderId == null) return;
        ObjectNode source = readObject(overlayJson);
        source.remove("advancePaymentVnd");
        try {
            validateNonNegativeValues(source);
            if (TRANSPORT.equalsIgnoreCase(contractType)) {
                Optional<TransportEntrustOrderDetail> previousDetail = transportRepository.findByOrderId(orderId);
                BigDecimal previousCredit = previousDetail
                        .map(TransportEntrustOrderDetail::getWalletCreditVnd).orElse(BigDecimal.ZERO);
                TransportEntrustOrderDetail detail = objectMapper.treeToValue(source, TransportEntrustOrderDetail.class);
                detail.setOrderId(orderId);
                if (detail.getRouteStatus() == null || detail.getRouteStatus().isBlank()) {
                    detail.setRouteStatus(previousDetail.map(TransportEntrustOrderDetail::getRouteStatus)
                            .filter(status -> !status.isBlank()).orElse("LOADED"));
                }
                BigDecimal allocated = validateAndTotalDestinations(source, detail.getTotalRevenueVnd());
                detail.setRevenueDestinationsJson(source.has("revenueDestinations")
                        ? source.get("revenueDestinations").toString() : null);
                BigDecimal walletCredit = allocated.subtract(zero(detail.getTotalRevenueVnd()));
                detail.setWalletCreditVnd(walletCredit);
                detail.setUtvcDebtVnd(calculateUtvcDebt(detail));
                applyWalletDelta(orderId, walletCredit.subtract(zero(previousCredit)));
                transportRepository.save(detail);
                importRepository.findByOrderId(orderId).ifPresent(ignored -> importRepository.deleteByOrderId(orderId));
            } else if (IMPORT.equalsIgnoreCase(contractType)) {
                releaseWalletCredit(orderId);
                ImportEntrustOrderDetail detail = objectMapper.treeToValue(source, ImportEntrustOrderDetail.class);
                detail.setOrderId(orderId);
                importRepository.save(detail);
                transportRepository.findByOrderId(orderId).ifPresent(ignored -> transportRepository.deleteByOrderId(orderId));
            }
        } catch (Exception exception) {
            Throwable cause = exception.getCause() != null ? exception.getCause() : exception;
            String detail = cause.getMessage();
            throw new IllegalArgumentException("Dữ liệu chi tiết đơn hàng không hợp lệ" + (detail == null || detail.isBlank() ? "" : ": " + detail), exception);
        }
    }

    private static void validateNonNegativeValues(ObjectNode source) {
        source.fields().forEachRemaining(entry -> {
            String field = entry.getKey();
            JsonNode value = entry.getValue();
            if (value.isNumber() && value.decimalValue().signum() < 0
                    && !Set.of("utvcDebtVnd", "costProfitVnd", "floorProfitVnd",
                            "totalMonthlyProfitVnd", "profitFrom2MonthsVnd", "profitFrom3MonthsVnd",
                            "profitFrom4MonthsVnd", "profitFrom5MonthsVnd").contains(field)) {
                throw new IllegalArgumentException(field + " không được âm");
            }
            if ("revenueDestinations".equals(field) && value.isArray()) {
                value.forEach(destination -> {
                    JsonNode amount = destination.path("amountVnd");
                    if (amount.isNumber() && amount.decimalValue().signum() < 0) {
                        throw new IllegalArgumentException("Số tiền nguồn thanh toán không được âm");
                    }
                });
            }
        });
    }

    public void releaseWalletCredit(Long orderId) {
        if (orderId == null) return;
        BigDecimal credit = transportRepository.findByOrderId(orderId)
                .map(TransportEntrustOrderDetail::getWalletCreditVnd).orElse(BigDecimal.ZERO);
        if (credit.signum() > 0) applyWalletDelta(orderId, credit.negate());
    }

    private BigDecimal validateAndTotalDestinations(ObjectNode source, BigDecimal revenue) {
        BigDecimal normalizedRevenue = zero(revenue);
        if (normalizedRevenue.signum() < 0) {
            throw new IllegalArgumentException("Tổng doanh thu UTVC không được âm");
        }
        JsonNode destinations = source.get("revenueDestinations");
        if (destinations == null || !destinations.isArray() || destinations.isEmpty()) {
            if (normalizedRevenue.signum() > 0) throw new IllegalArgumentException("Phải chọn ít nhất một nguồn tiền");
            return BigDecimal.ZERO;
        }
        Set<String> types = new HashSet<>();
        BigDecimal allocated = BigDecimal.ZERO;
        for (JsonNode destination : destinations) {
            String type = destination.path("type").asText("").trim();
            if (!Set.of("ADVANCE", "COMPANY_ACCOUNT", "PERSONAL_ACCOUNT").contains(type) || !types.add(type)) {
                throw new IllegalArgumentException("Nguồn tiền không hợp lệ hoặc bị trùng");
            }
            if (!"ADVANCE".equals(type) && destination.path("bank").asText("").trim().isEmpty()) {
                throw new IllegalArgumentException("Tài khoản đích phải chọn ngân hàng");
            }
            BigDecimal amount;
            try { amount = new BigDecimal(destination.path("amountVnd").asText()); }
            catch (Exception exception) { throw new IllegalArgumentException("Số tiền nguồn không hợp lệ"); }
            if (amount.signum() <= 0) throw new IllegalArgumentException("Số tiền từng nguồn phải lớn hơn 0");
            allocated = allocated.add(amount);
        }
        if (allocated.compareTo(normalizedRevenue) < 0) {
            throw new IllegalArgumentException("Tổng nguồn tiền không được nhỏ hơn Tổng doanh thu UTVC");
        }
        return allocated;
    }

    private void applyWalletDelta(Long orderId, BigDecimal delta) {
        if (delta == null || delta.signum() == 0) return;
        Long customerId = jdbcTemplate.queryForObject(
                "SELECT customer_id FROM tbl_order WHERE id = ?", Long.class, orderId);
        if (customerId == null) throw new IllegalArgumentException("Đơn hàng chưa gắn khách hàng");
        BigDecimal balance = jdbcTemplate.queryForObject(
                "SELECT wallet_balance_vnd FROM tbl_customer WHERE id = ? FOR UPDATE", BigDecimal.class, customerId);
        BigDecimal nextBalance = zero(balance).add(delta);
        if (nextBalance.signum() < 0) {
            throw new IllegalStateException("Số dư ví khách hàng không nhất quán; thao tác đã được hủy");
        }
        int updated = jdbcTemplate.update(
                "UPDATE tbl_customer SET wallet_balance_vnd = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                nextBalance, customerId);
        if (updated != 1) throw new IllegalStateException("Không thể cập nhật ví khách hàng");
    }

    /** Ghép dữ liệu chuẩn hóa vào payload hiện tại để frontend chuyển đổi không gián đoạn. */
    public String hydrate(Long orderId, String contractType, String overlayJson) {
        ObjectNode target = readObject(overlayJson);
        target.remove("advancePaymentVnd");
        target.put("entrustOrderType", contractType);
        if (TRANSPORT.equalsIgnoreCase(contractType)) {
            transportRepository.findByOrderId(orderId).ifPresent(detail -> merge(target, detail));
        } else if (IMPORT.equalsIgnoreCase(contractType)) {
            importRepository.findByOrderId(orderId).ifPresent(detail -> merge(target, detail));
        }
        try {
            return objectMapper.writeValueAsString(target);
        } catch (Exception exception) {
            return overlayJson;
        }
    }

    /** Hai truy vấn theo batch cho cả trang, thay vì một truy vấn chi tiết cho từng dòng. */
    public Map<Long, String> hydratePage(List<CustomerOrder> orders) {
        if (orders == null || orders.isEmpty()) return Map.of();
        List<Long> ids = orders.stream().map(CustomerOrder::getId).filter(Objects::nonNull).toList();
        Map<Long, ImportEntrustOrderDetail> imports = importRepository.findAllByOrderId(ids).stream()
                .collect(Collectors.toMap(ImportEntrustOrderDetail::getOrderId, Function.identity()));
        Map<Long, TransportEntrustOrderDetail> transports = transportRepository.findAllByOrderId(ids).stream()
                .collect(Collectors.toMap(TransportEntrustOrderDetail::getOrderId, Function.identity()));
        Map<Long, String> result = new HashMap<>();
        for (CustomerOrder order : orders) {
            ObjectNode target = readObject(order.getSaleOverlayJson());
            target.remove("advancePaymentVnd");
            target.put("entrustOrderType", order.getContractType());
            if (TRANSPORT.equalsIgnoreCase(order.getContractType()) && transports.containsKey(order.getId())) {
                merge(target, transports.get(order.getId()));
            } else if (IMPORT.equalsIgnoreCase(order.getContractType()) && imports.containsKey(order.getId())) {
                merge(target, imports.get(order.getId()));
            }
            try { result.put(order.getId(), objectMapper.writeValueAsString(target)); }
            catch (Exception ignored) { result.put(order.getId(), order.getSaleOverlayJson()); }
        }
        return result;
    }

    private ObjectNode readObject(String json) {
        if (json != null && !json.isBlank()) {
            try {
                JsonNode parsed = objectMapper.readTree(json);
                if (parsed instanceof ObjectNode object) return object.deepCopy();
            } catch (Exception ignored) { }
        }
        return objectMapper.createObjectNode();
    }

    private static BigDecimal calculateUtvcDebt(TransportEntrustOrderDetail detail) {
        String unit = detail.getCalculationUnit();
        BigDecimal amount = "CBM".equals(unit) ? zero(detail.getVolumeCbm())
                : (unit != null && (unit.startsWith("TRUCK_") || "CONT_40".equals(unit)))
                    ? BigDecimal.ONE : zero(detail.getWeightKg());
        return zero(detail.getSellingSurchargeVnd())
                .add(zero(detail.getOutputVatVnd()))
                .add(zero(detail.getOutputImportTaxVnd()))
                .add(zero(detail.getTotalRevenueNorthSouthVnd()))
                .add(zero(detail.getSellingChinaVietnamRateVnd()).multiply(amount))
                .subtract(zero(detail.getTotalRevenueVnd()));
    }

    private static BigDecimal zero(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    private void merge(ObjectNode target, Object detail) {
        ObjectNode normalized = objectMapper.valueToTree(detail);
        normalized.remove("orderId");
        if (detail instanceof TransportEntrustOrderDetail transport) {
            normalized.remove("revenueDestinationsJson");
            String destinationsJson = transport.getRevenueDestinationsJson();
            if (destinationsJson != null && !destinationsJson.isBlank()) {
                try { target.set("revenueDestinations", objectMapper.readTree(destinationsJson)); }
                catch (Exception ignored) { }
            }
        }
        target.setAll(normalized);
    }
}
