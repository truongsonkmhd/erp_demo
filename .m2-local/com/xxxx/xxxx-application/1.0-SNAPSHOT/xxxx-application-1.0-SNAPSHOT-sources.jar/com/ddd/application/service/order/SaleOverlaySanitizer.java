package com.xxxx.ddd.application.service.order;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.stereotype.Component;

/** Removes retired fields from the flexible sales-order payload. */
@Component
public class SaleOverlaySanitizer {

    private final ObjectMapper objectMapper;

    public SaleOverlaySanitizer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public String sanitize(String json) {
        if (json == null || json.isBlank()) {
            return json;
        }
        try {
            JsonNode root = objectMapper.readTree(json);
            if (root instanceof ObjectNode object) {
                object.remove("customerClassification");
                return objectMapper.writeValueAsString(object);
            }
        } catch (Exception ignored) {
            // Preserve legacy payloads that are not valid JSON instead of losing order data.
        }
        return json;
    }
}
