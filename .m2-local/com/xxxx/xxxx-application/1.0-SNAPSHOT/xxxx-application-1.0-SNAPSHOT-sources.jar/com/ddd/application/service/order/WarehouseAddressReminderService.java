package com.xxxx.ddd.application.service.order;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xxxx.ddd.application.model.CareReminderSettingsDTO;
import com.xxxx.ddd.application.model.command.SendNotificationCommand;
import com.xxxx.ddd.application.service.marketinglead.CareReminderSettingsService;
import com.xxxx.ddd.application.service.notification.NotificationAppService;
import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import com.xxxx.ddd.domain.model.workflow.NotificationType;
import com.xxxx.ddd.domain.respository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class WarehouseAddressReminderService {
    private static final String REF_TYPE = "WAREHOUSE_ADDRESS";
    private static final String DEBT_REF_TYPE = "WAREHOUSE_DEBT";
    private final ObjectMapper objectMapper;
    private final JdbcTemplate jdbcTemplate;
    private final NotificationAppService notificationAppService;
    private final CareReminderSettingsService settingsService;
    private final UserRepository userRepository;

    public WarehouseAddressReminderService(ObjectMapper objectMapper, JdbcTemplate jdbcTemplate,
                                           NotificationAppService notificationAppService,
                                           CareReminderSettingsService settingsService, UserRepository userRepository) {
        this.objectMapper = objectMapper;
        this.jdbcTemplate = jdbcTemplate;
        this.notificationAppService = notificationAppService;
        this.settingsService = settingsService;
        this.userRepository = userRepository;
    }

    /** Owner is fixed at creation; a new LOADED cycle starts a fresh reminder clock. */
    public String prepareOverlay(String incoming, String previous, Long actorId, boolean creating) {
        try {
            JsonNode root = objectMapper.readTree(incoming == null || incoming.isBlank() ? "{}" : incoming);
            if (!(root instanceof ObjectNode next)) return incoming;
            JsonNode prior = previous == null || previous.isBlank() ? null : objectMapper.readTree(previous);
            if (creating) {
                if (actorId != null) {
                    next.put("warehouseOwnerId", actorId);
                    userRepository.findById(actorId).ifPresent(user -> next.put("warehouseOwnerName", user.getFullName()));
                }
            } else if (prior != null && prior.hasNonNull("warehouseOwnerId")) {
                next.set("warehouseOwnerId", prior.get("warehouseOwnerId"));
                if (prior.hasNonNull("warehouseOwnerName")) next.set("warehouseOwnerName", prior.get("warehouseOwnerName"));
            }
            boolean pending = "LOADED".equalsIgnoreCase(next.path("routeStatus").asText())
                    && address(next).isBlank();
            boolean wasPending = prior != null && "LOADED".equalsIgnoreCase(prior.path("routeStatus").asText())
                    && address(prior).isBlank();
            if (pending) {
                if (wasPending && prior.hasNonNull("warehouseAddressPendingSince")) {
                    next.set("warehouseAddressPendingSince", prior.get("warehouseAddressPendingSince"));
                } else {
                    next.put("warehouseAddressPendingSince", LocalDateTime.now().toString());
                }
            } else {
                next.remove("warehouseAddressPendingSince");
            }
            boolean delivered = "DELIVERED".equalsIgnoreCase(next.path("routeStatus").asText());
            boolean wasDelivered = prior != null
                    && "DELIVERED".equalsIgnoreCase(prior.path("routeStatus").asText());
            if (delivered) {
                if (wasDelivered && prior.hasNonNull("warehouseDebtPendingSince")) {
                    next.set("warehouseDebtPendingSince", prior.get("warehouseDebtPendingSince"));
                } else {
                    next.put("warehouseDebtPendingSince", LocalDateTime.now().toString());
                }
            } else {
                next.remove("warehouseDebtPendingSince");
            }
            return objectMapper.writeValueAsString(next);
        } catch (Exception error) {
            log.warn("Cannot prepare warehouse reminder overlay", error);
            return incoming;
        }
    }

    public void notifyIfDue(CustomerOrder order) {
        if (order == null || order.getId() == null || order.getCustomer() == null
                || order.getCustomer().getCustomerCareStaff() == null) return;
        if (!"TRANSPORT_ENTRUST".equalsIgnoreCase(order.getContractType())) return;
        check(order.getId(), order.getOrderCode(), order.getSaleOverlayJson(),
                order.getCustomer().getCustomerCareStaff().getId());
        DebtOrder debt = findDebtOrder(order.getId());
        if (debt != null) checkDebt(debt);
    }

    public String withDeliveryAddress(String overlay, String address) {
        try {
            JsonNode root = objectMapper.readTree(overlay == null || overlay.isBlank() ? "{}" : overlay);
            if (!(root instanceof ObjectNode next)) throw new IllegalArgumentException("Thông tin Kho vận không hợp lệ");
            next.put("deliveryAddress", address.trim());
            next.put("shippingAddress", address.trim());
            next.remove("warehouseAddressPendingSince");
            return objectMapper.writeValueAsString(next);
        } catch (IllegalArgumentException error) {
            throw error;
        } catch (Exception error) {
            throw new IllegalArgumentException("Thông tin Kho vận không hợp lệ", error);
        }
    }

    @Scheduled(fixedDelay = 60000, initialDelay = 60000)
    public void sendDueReminders() {
        try {
            List<PendingOrder> orders = jdbcTemplate.query("""
                    SELECT o.id, o.order_code, o.sale_overlay_json, c.customer_care_staff_id
                    FROM tbl_order o JOIN tbl_customer c ON c.id = o.customer_id
                    WHERE o.contract_type = 'TRANSPORT_ENTRUST' AND o.is_deleted = 0
                      AND c.customer_care_staff_id IS NOT NULL
                    """, (rs, rowNum) -> new PendingOrder(rs.getLong(1), rs.getString(2),
                    rs.getString(3), rs.getLong(4)));
            for (PendingOrder order : orders) {
                try { check(order.id(), order.code(), order.overlay(), order.recipientId()); }
                catch (Exception error) { log.warn("Warehouse address reminder failed for order {}", order.id(), error); }
            }
            List<DebtOrder> debtOrders = jdbcTemplate.query("""
                    SELECT o.id, o.order_code, o.sale_overlay_json, c.customer_care_staff_id,
                           d.utvc_debt_vnd, o.updated_at
                    FROM tbl_order o
                    JOIN tbl_customer c ON c.id = o.customer_id
                    JOIN tbl_order_transport_entrust_detail d ON d.order_id = o.id
                    WHERE o.contract_type = 'TRANSPORT_ENTRUST' AND o.is_deleted = 0
                      AND c.customer_care_staff_id IS NOT NULL
                      AND d.route_status = 'DELIVERED' AND COALESCE(d.utvc_debt_vnd, 0) > 0
                    """, (rs, rowNum) -> new DebtOrder(rs.getLong(1), rs.getString(2),
                    rs.getString(3), rs.getLong(4), rs.getBigDecimal(5), rs.getTimestamp(6)));
            for (DebtOrder order : debtOrders) {
                try { checkDebt(order); }
                catch (Exception error) { log.warn("Warehouse debt reminder failed for order {}", order.id(), error); }
            }
        } catch (Exception error) {
            log.error("Warehouse address reminder scan failed", error);
        }
    }

    private void check(Long orderId, String code, String overlay, Long recipientId) {
        try {
            JsonNode root = objectMapper.readTree(overlay == null || overlay.isBlank() ? "{}" : overlay);
            if (!"LOADED".equalsIgnoreCase(root.path("routeStatus").asText()) || !address(root).isBlank()) return;
            String startedText = root.path("warehouseAddressPendingSince").asText("");
            if (startedText.isBlank()) return;
            LocalDateTime startedAt = LocalDateTime.parse(startedText);
            ReminderHistory history = jdbcTemplate.queryForObject("""
                    SELECT COUNT(*), MAX(created_at) FROM tbl_notification
                    WHERE ref_type = ? AND ref_id = ? AND recipient_id = ? AND created_at >= ?
                      AND type IN ('WAREHOUSE_ADDRESS_REQUIRED', 'WAREHOUSE_ADDRESS_REMINDER')
                    """, (rs, rowNum) -> new ReminderHistory(rs.getLong(1), rs.getTimestamp(2)),
                    REF_TYPE, orderId, recipientId, Timestamp.valueOf(startedAt));
            long count = history == null ? 0 : history.count();
            if (count > 0) {
                CareReminderSettingsDTO settings = settingsService.get();
                int minutes = count == 1 ? settings.warehouseAddressInitialMinutes()
                        : settings.warehouseAddressRepeatMinutes();
                Timestamp last = history.lastSentAt();
                if (last == null || LocalDateTime.now().isBefore(last.toLocalDateTime().plusMinutes(minutes))) return;
            }
            notificationAppService.send(new SendNotificationCommand()
                    .setRecipientId(recipientId)
                    .setType(count == 0 ? NotificationType.WAREHOUSE_ADDRESS_REQUIRED
                            : NotificationType.WAREHOUSE_ADDRESS_REMINDER)
                    .setTitle(count == 0 ? "Kho vận đã xếp xe: cần điền địa chỉ giao hàng"
                            : "Nhắc điền địa chỉ giao hàng Kho vận")
                    .setBody("Mã UTVC " + (code == null ? orderId : code)
                            + " chưa có địa chỉ giao hàng. Vui lòng cập nhật tại tab Kho vận.")
                    .setRefType(REF_TYPE).setRefId(orderId).setLink("/warehouse-transport")
                    .setSendEmail(false));
        } catch (Exception error) {
            log.warn("Cannot check warehouse address for order {}", orderId, error);
        }
    }

    private static String address(JsonNode root) {
        String delivery = root.path("deliveryAddress").asText("").trim();
        return delivery.isBlank() ? root.path("shippingAddress").asText("").trim() : delivery;
    }

    private DebtOrder findDebtOrder(Long orderId) {
        List<DebtOrder> rows = jdbcTemplate.query("""
                SELECT o.id, o.order_code, o.sale_overlay_json, c.customer_care_staff_id,
                       d.utvc_debt_vnd, o.updated_at
                FROM tbl_order o
                JOIN tbl_customer c ON c.id = o.customer_id
                JOIN tbl_order_transport_entrust_detail d ON d.order_id = o.id
                WHERE o.id = ? AND o.contract_type = 'TRANSPORT_ENTRUST' AND o.is_deleted = 0
                  AND c.customer_care_staff_id IS NOT NULL
                  AND d.route_status = 'DELIVERED' AND COALESCE(d.utvc_debt_vnd, 0) > 0
                """, (rs, rowNum) -> new DebtOrder(rs.getLong(1), rs.getString(2),
                rs.getString(3), rs.getLong(4), rs.getBigDecimal(5), rs.getTimestamp(6)), orderId);
        return rows.isEmpty() ? null : rows.getFirst();
    }

    private void checkDebt(DebtOrder order) {
        try {
            JsonNode root = objectMapper.readTree(order.overlay() == null || order.overlay().isBlank()
                    ? "{}" : order.overlay());
            String startedText = root.path("warehouseDebtPendingSince").asText("");
            LocalDateTime startedAt = startedText.isBlank()
                    ? (order.updatedAt() == null ? LocalDateTime.now() : order.updatedAt().toLocalDateTime())
                    : LocalDateTime.parse(startedText);
            ReminderHistory history = jdbcTemplate.queryForObject("""
                    SELECT COUNT(*), MAX(created_at) FROM tbl_notification
                    WHERE ref_type = ? AND ref_id = ? AND recipient_id = ? AND created_at >= ?
                      AND type IN ('WAREHOUSE_DEBT_REQUIRED', 'WAREHOUSE_DEBT_REMINDER')
                    """, (rs, rowNum) -> new ReminderHistory(rs.getLong(1), rs.getTimestamp(2)),
                    DEBT_REF_TYPE, order.id(), order.recipientId(), Timestamp.valueOf(startedAt));
            CareReminderSettingsDTO settings = settingsService.get();
            long count = history == null ? 0 : history.count();
            LocalDateTime dueAt = count == 0
                    ? startedAt.plusMinutes(settings.warehouseDebtInitialMinutes())
                    : history.lastSentAt().toLocalDateTime().plusMinutes(settings.warehouseDebtRepeatMinutes());
            if (LocalDateTime.now().isBefore(dueAt)) return;
            notificationAppService.send(new SendNotificationCommand()
                    .setRecipientId(order.recipientId())
                    .setType(count == 0 ? NotificationType.WAREHOUSE_DEBT_REQUIRED
                            : NotificationType.WAREHOUSE_DEBT_REMINDER)
                    .setTitle(count == 0 ? "Đơn UTVC đã giao: cần thu hồi công nợ"
                            : "Nhắc thu hồi công nợ UTVC")
                    .setBody("Mã UTVC " + (order.code() == null ? order.id() : order.code())
                            + " còn công nợ " + formatMoney(order.debt())
                            + " VNĐ. Vui lòng kiểm tra và thu hồi công nợ.")
                    .setRefType(DEBT_REF_TYPE).setRefId(order.id())
                    .setLink("/projects-sale?highlightId=" + order.id())
                    .setSendEmail(false));
        } catch (Exception error) {
            log.warn("Cannot check warehouse debt for order {}", order.id(), error);
        }
    }

    private static String formatMoney(BigDecimal value) {
        return value == null ? "0" : String.format(java.util.Locale.forLanguageTag("vi-VN"), "%,.0f", value);
    }

    private record PendingOrder(Long id, String code, String overlay, Long recipientId) {}
    private record DebtOrder(Long id, String code, String overlay, Long recipientId, BigDecimal debt,
                             Timestamp updatedAt) {}
    private record ReminderHistory(long count, Timestamp lastSentAt) {}
}
