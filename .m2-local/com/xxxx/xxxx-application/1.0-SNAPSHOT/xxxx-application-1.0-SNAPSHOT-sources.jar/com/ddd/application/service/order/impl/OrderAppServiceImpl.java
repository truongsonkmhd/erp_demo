package com.xxxx.ddd.application.service.order.impl;

import com.xxxx.ddd.application.model.CustomerDTO;
import com.xxxx.ddd.application.model.CustomerPageDTO;
import com.xxxx.ddd.application.model.OrderDTO;
import com.xxxx.ddd.application.model.OrderPageDTO;
import com.xxxx.ddd.application.model.AssignmentDTO;
import com.xxxx.ddd.application.model.command.SendNotificationCommand;
import com.xxxx.ddd.application.model.command.SaveCustomerCommand;
import com.xxxx.ddd.application.model.command.SaveOrderCommand;
import com.xxxx.ddd.application.service.notification.NotificationAppService;
import com.xxxx.ddd.application.service.notification.NotificationRecipientResolver;
import com.xxxx.ddd.application.service.order.OrderAppService;
import com.xxxx.ddd.application.service.order.SaleOverlaySanitizer;
import com.xxxx.ddd.application.service.order.OrderEntrustDetailService;
import com.xxxx.ddd.application.service.order.WarehouseAddressReminderService;
import com.xxxx.ddd.application.service.visibility.AssignedDataScope;
import com.xxxx.ddd.application.service.workflow.WorkflowDtoMapper;
import com.xxxx.ddd.domain.model.entity.Customer;
import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.model.workflow.NotificationType;
import com.xxxx.ddd.domain.model.workflow.CareProgressRules;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;
import com.xxxx.ddd.domain.model.query.OrderSearchCriteria;
import com.xxxx.ddd.domain.model.query.OrderSearchResult;
import com.xxxx.ddd.domain.service.AssignmentDomainService;
import com.xxxx.ddd.domain.service.CustomerDomainService;
import com.xxxx.ddd.domain.service.CustomerOrderDomainService;
import com.xxxx.ddd.domain.service.MarketingLeadDomainService;
import com.xxxx.ddd.domain.respository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;

@Service
@Slf4j
public class OrderAppServiceImpl implements OrderAppService {

    @Autowired
    private CustomerOrderDomainService customerOrderDomainService;

    @Autowired
    private CustomerDomainService customerDomainService;

    @Autowired
    private MarketingLeadDomainService marketingLeadDomainService;

    @Autowired
    private NotificationAppService notificationAppService;

    @Autowired
    private NotificationRecipientResolver notificationRecipientResolver;

    @Autowired
    private WorkflowDtoMapper mapper;

    @Autowired
    private AssignedDataScope assignedDataScope;

    @Autowired
    private AssignmentDomainService assignmentDomainService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SaleOverlaySanitizer saleOverlaySanitizer;

    @Autowired
    private OrderEntrustDetailService orderEntrustDetailService;

    @Autowired
    private WarehouseAddressReminderService warehouseAddressReminderService;

    @Override
    @Transactional(readOnly = true)
    public List<OrderDTO> findAll(Long actorId) {
        return assignedDataScope.filterOrders(actorId, customerOrderDomainService.findAll()).stream()
                .map(mapper::toOrderDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public OrderPageDTO searchOrders(String query, String customerCode, String orderCode, String batchCode,
                                     String customerName, String phone, String category, String productName,
                                     String salesName, String customerCareName, String contractType,
                                     String fromDate, String toDate, String fromMonth, String toMonth,
                                     int pageNo, int pageSize, Long actorId) {
        OrderSearchCriteria criteria = new OrderSearchCriteria();
        criteria.setQuery(query);
        criteria.setCustomerCode(customerCode);
        criteria.setOrderCode(orderCode);
        criteria.setBatchCode(batchCode);
        criteria.setCustomerName(customerName);
        criteria.setPhone(phone);
        criteria.setCategory(category);
        criteria.setProductName(productName);
        criteria.setSalesName(salesName);
        criteria.setCustomerCareName(customerCareName);
        criteria.setContractType(contractType);
        criteria.setCreatedFrom(resolveFrom(fromDate, fromMonth));
        criteria.setCreatedToExclusive(resolveToExclusive(toDate, toMonth));
        criteria.setPageNo(pageNo);
        criteria.setPageSize(pageSize);
        if (assignedDataScope.shouldRestrictOrders(actorId)) {
            if (assignedDataScope.isRestrictedCustomerCareStaff(actorId)) {
                criteria.setCustomerCareStaffId(actorId);
            } else {
                criteria.setCustomerIds(assignedDataScope.assignedCustomerIds(actorId));
            }
        }
        OrderSearchResult result = customerOrderDomainService.search(criteria);
        Map<Long, String> overlays = orderEntrustDetailService.hydratePage(result.getItems());
        OrderPageDTO dto = new OrderPageDTO();
        dto.setItems(result.getItems().stream()
                .map(order -> mapper.toOrderListDTO(order, overlays.get(order.getId())))
                .toList());
        fillPage(dto, result.getTotalElements(), pageNo, pageSize);
        return dto;
    }

    @Override
    @Transactional(readOnly = true)
    public OrderDTO getById(Long id, Long actorId) {
        CustomerOrder order = customerOrderDomainService.getById(id);
        assignedDataScope.requireOrder(actorId, order);
        return mapper.toOrderDTO(order);
    }

    @Override
    @Transactional
    public OrderDTO create(SaveOrderCommand command, Long actorId) {
        if (command == null || command.getCustomerId() == null) {
            throw new IllegalArgumentException("Khách hàng không hợp lệ");
        }
        String contractType = requireContractType(command.getContractType());
        Customer customer = customerDomainService.getById(command.getCustomerId());
        MarketingLead sourceLead = marketingLeadDomainService.findByStages(List.of()).stream()
                .filter(lead -> lead.getCustomer() != null
                        && command.getCustomerId().equals(lead.getCustomer().getId()))
                .max(java.util.Comparator.comparing(MarketingLead::getId))
                .orElse(null);
        User saleOwner = resolveSaleOwner(sourceLead, customer, actorId);
        String overlay = "TRANSPORT_ENTRUST".equals(contractType)
                ? warehouseAddressReminderService.prepareOverlay(command.getSaleOverlayJson(), null, actorId, true)
                : command.getSaleOverlayJson();
        CustomerOrder patch = new CustomerOrder()
                .setLeadId(sourceLead == null ? null : sourceLead.getId())
                .setAssignee(customer.getCustomerCareStaff())
                .setSalesOwner(saleOwner)
                .setOrderCode(command.getOrderCode())
                .setBatchCode(command.getBatchCode())
                .setServiceType(command.getServiceType())
                .setContractType(contractType)
                .setProductName(command.getProductName())
                .setCategory(command.getCategory())
                .setQuantity(command.getQuantity())
                .setUnitPriceRmb(command.getUnitPriceRmb())
                .setTotalPaymentAmountVnd(command.getTotalPaymentAmountVnd())
                .setPaidAt(command.getPaidAt())
                .setSaleOverlayJson(saleOverlaySanitizer.sanitize(overlay))
                .setNotes(command.getNotes());
        CustomerOrder saved = customerOrderDomainService.createManual(command.getCustomerId(), patch, actorId);
        orderEntrustDetailService.save(saved.getId(), contractType, command.getSaleOverlayJson());
        warehouseAddressReminderService.notifyIfDue(saved);
        return mapper.toOrderDTO(saved);
    }

    @Override
    @Transactional
    public OrderDTO update(Long id, SaveOrderCommand command, Long actorId) {
        return updateInternal(id, command, actorId, false);
    }

    @Override
    @Transactional
    public OrderDTO updateWarehouse(Long id, SaveOrderCommand command, Long actorId) {
        return updateInternal(id, command, actorId, true);
    }

    private OrderDTO updateInternal(Long id, SaveOrderCommand command, Long actorId, boolean warehouseOnly) {
        CustomerOrder current = customerOrderDomainService.getById(id);
        if (warehouseOnly && (!"TRANSPORT_ENTRUST".equalsIgnoreCase(current.getContractType())
                || !"TRANSPORT_ENTRUST".equalsIgnoreCase(command.getContractType()))) {
            throw new IllegalArgumentException("Chỉ được sửa bản ghi Kho vận");
        }
        assignedDataScope.requireOrder(actorId, current);
        User actor = requireUser(actorId);
        boolean executive = !warehouseOnly && isLevel(actor, "executive");
        if (executive && !("APPROVED".equals(current.getEditApprovalStatus())
                && actorId.equals(current.getEditRequestedBy()))) {
            throw new IllegalArgumentException("Bạn cần gửi yêu cầu và được Manager phê duyệt trước khi sửa đơn hàng");
        }
        String contractType = requireContractType(command.getContractType());
        String overlay = "TRANSPORT_ENTRUST".equals(contractType)
                ? warehouseAddressReminderService.prepareOverlay(command.getSaleOverlayJson(), current.getSaleOverlayJson(), actorId, false)
                : command.getSaleOverlayJson();
        CustomerOrder patch = new CustomerOrder()
                .setOrderCode(command.getOrderCode())
                .setBatchCode(command.getBatchCode())
                .setServiceType(command.getServiceType())
                .setContractType(contractType)
                .setProductName(command.getProductName())
                .setCategory(command.getCategory())
                .setQuantity(command.getQuantity())
                .setUnitPriceRmb(command.getUnitPriceRmb())
                .setTotalPaymentAmountVnd(command.getTotalPaymentAmountVnd())
                .setPaidAt(command.getPaidAt())
                .setSaleOverlayJson(saleOverlaySanitizer.sanitize(overlay))
                .setNotes(command.getNotes());
        CustomerOrder saved = customerOrderDomainService.update(id, patch);
        orderEntrustDetailService.save(saved.getId(), contractType, command.getSaleOverlayJson());
        warehouseAddressReminderService.notifyIfDue(saved);
        if (executive) {
            saved.setEditApprovalStatus("NONE")
                    .setEditRequestedBy(null)
                    .setEditApprovedBy(null)
                    .setEditRequestedAt(null)
                    .setEditApprovedAt(null);
            saved = customerOrderDomainService.save(saved);
        }
        return mapper.toOrderDTO(saved);
    }

    @Override
    @Transactional
    public OrderDTO updateWarehouseDeliveryAddress(Long id, String address, Long actorId) {
        CustomerOrder order = customerOrderDomainService.getById(id);
        assignedDataScope.requireOrder(actorId, order);
        if (!"TRANSPORT_ENTRUST".equalsIgnoreCase(order.getContractType())) {
            throw new IllegalArgumentException("Bản ghi không thuộc Kho vận");
        }
        User actor = requireUser(actorId);
        Long careStaffId = order.getCustomer().getCustomerCareStaff() == null
                ? null : order.getCustomer().getCustomerCareStaff().getId();
        boolean admin = actor.getRole() != null && actor.getRole().isAdmin();
        if (!admin && !actorId.equals(careStaffId)) {
            throw new IllegalArgumentException("Bạn không phải nhân viên CSKH phụ trách khách hàng này");
        }
        if (address == null || address.isBlank()) {
            throw new IllegalArgumentException("Vui lòng nhập địa chỉ giao hàng");
        }
        String overlay = warehouseAddressReminderService.withDeliveryAddress(order.getSaleOverlayJson(), address);
        order.setSaleOverlayJson(saleOverlaySanitizer.sanitize(overlay));
        CustomerOrder saved = customerOrderDomainService.save(order);
        orderEntrustDetailService.save(saved.getId(), saved.getContractType(), overlay);
        return mapper.toOrderDTO(saved);
    }

    /**
     * Đơn tạo từ hồ sơ khách hàng phải giữ chủ sở hữu Sale của Data nguồn để
     * doanh thu trên Dashboard được cộng đúng nhân viên/phòng. Người bấm tạo đơn
     * (thường là CSKH/Admin) chỉ được dùng làm phương án cuối khi không có Data nguồn.
     */
    private User resolveSaleOwner(MarketingLead sourceLead, Customer customer, Long actorId) {
        // Luồng tạo đơn từ trang Khách hàng: Sale tạo hồ sơ khách hàng là chủ
        // doanh thu. Chỉ tra ngược Data nguồn khi hồ sơ không do Sale tạo.
        if (customer != null && isSaleUser(customer.getCreatedBy())) return customer.getCreatedBy();
        if (sourceLead != null) {
            User assignedSale = assignmentDomainService
                    .findCurrent(AssignmentRefType.MARKETING_LEAD, sourceLead.getId())
                    .map(assignment -> assignment.getAssignee())
                    .filter(OrderAppServiceImpl::isSaleUser)
                    .orElse(null);
            if (assignedSale != null) return assignedSale;
            if (isSaleUser(sourceLead.getCreatedBy())) return sourceLead.getCreatedBy();
        }
        if (actorId == null) return null;
        return userRepository.findById(actorId).filter(OrderAppServiceImpl::isSaleUser).orElse(null);
    }

    private static boolean isSaleUser(User user) {
        return user != null && user.getRole() != null && user.getRole().isSale();
    }

    @Override
    @Transactional
    public OrderDTO requestEditApproval(Long id, Long actorId) {
        CustomerOrder order = customerOrderDomainService.getById(id);
        assignedDataScope.requireOrder(actorId, order);
        User actor = requireUser(actorId);
        if (!isLevel(actor, "executive")) {
            throw new IllegalArgumentException("Chỉ nhân viên Executive cần gửi yêu cầu phê duyệt sửa đơn");
        }
        if (order.getAssignee() != null && !actorId.equals(order.getAssignee().getId())) {
            throw new IllegalArgumentException("Bạn không phải nhân viên phụ trách đơn hàng này");
        }
        if ("PENDING".equals(order.getEditApprovalStatus())) {
            throw new IllegalArgumentException("Yêu cầu sửa đơn đang chờ Manager phê duyệt");
        }
        if ("APPROVED".equals(order.getEditApprovalStatus()) && actorId.equals(order.getEditRequestedBy())) {
            return mapper.toOrderDTO(order);
        }
        order.setEditApprovalStatus("PENDING")
                .setEditRequestedBy(actorId)
                .setEditApprovedBy(null)
                .setEditRequestedAt(LocalDateTime.now())
                .setEditApprovedAt(null);
        CustomerOrder saved = customerOrderDomainService.save(order);
        List<User> managers = managersFor(actor);
        if (managers.isEmpty()) {
            throw new IllegalArgumentException("Không tìm thấy Manager phù hợp để phê duyệt");
        }
        notificationAppService.sendAll(managers.stream().map(manager -> new SendNotificationCommand()
                .setRecipientId(manager.getId()).setActorId(actorId)
                .setType(NotificationType.ORDER_EDIT_REQUESTED)
                .setTitle("Yêu cầu phê duyệt sửa đơn hàng")
                .setBody(actor.getFullName() + " yêu cầu sửa đơn " + safeOrderCode(saved))
                .setRefType("ORDER").setRefId(saved.getId())
                .setLink("/projects-cskh?highlightId=" + saved.getId())
                .setSendEmail(false).setSendRealtime(true)).toList());
        return mapper.toOrderDTO(saved);
    }

    @Override
    @Transactional
    public OrderDTO approveEdit(Long id, Long actorId) {
        CustomerOrder order = customerOrderDomainService.getById(id);
        User manager = requireUser(actorId);
        if (!isLevel(manager, "manager") && !"admin".equalsIgnoreCase(manager.getRoleCode())) {
            throw new IllegalArgumentException("Chỉ Manager được phê duyệt yêu cầu sửa đơn");
        }
        if (!"PENDING".equals(order.getEditApprovalStatus()) || order.getEditRequestedBy() == null) {
            throw new IllegalArgumentException("Đơn hàng không có yêu cầu sửa đang chờ phê duyệt");
        }
        User requester = requireUser(order.getEditRequestedBy());
        if (!"admin".equalsIgnoreCase(manager.getRoleCode()) && !sameTeam(manager, requester)) {
            throw new IllegalArgumentException("Bạn chỉ được phê duyệt nhân viên trong phòng của mình");
        }
        order.setEditApprovalStatus("APPROVED")
                .setEditApprovedBy(actorId)
                .setEditApprovedAt(LocalDateTime.now());
        CustomerOrder saved = customerOrderDomainService.save(order);
        notificationAppService.send(new SendNotificationCommand()
                .setRecipientId(requester.getId()).setActorId(actorId)
                .setType(NotificationType.ORDER_EDIT_APPROVED)
                .setTitle("Yêu cầu sửa đơn đã được phê duyệt")
                .setBody("Bạn đã được phép sửa đơn " + safeOrderCode(saved) + " một lần")
                .setRefType("ORDER").setRefId(saved.getId())
                .setLink("/projects-cskh?highlightId=" + saved.getId())
                .setSendEmail(false).setSendRealtime(true));
        return mapper.toOrderDTO(saved);
    }

    private User requireUser(Long id) {
        return userRepository.findByIdWithAuth(id)
                .orElseThrow(() -> new IllegalArgumentException("Người dùng không tồn tại"));
    }

    private List<User> managersFor(User requester) {
        return userRepository.findAllActiveWithAuth().stream()
                .filter(user -> isLevel(user, "manager"))
                .filter(user -> sameTeam(user, requester))
                .toList();
    }

    private static boolean sameTeam(User manager, User requester) {
        if (manager.getRoleCode() == null || requester.getRoleCode() == null
                || !manager.getRoleCode().equalsIgnoreCase(requester.getRoleCode())) return false;
        Long managerRoom = manager.getSaleRoom() == null ? null : manager.getSaleRoom().getId();
        Long requesterRoom = requester.getSaleRoom() == null ? null : requester.getSaleRoom().getId();
        return managerRoom == null ? requesterRoom == null : managerRoom.equals(requesterRoom);
    }

    private static boolean isLevel(User user, String level) {
        return user != null && user.getLevelCode() != null && level.equalsIgnoreCase(user.getLevelCode().trim());
    }

    private static String safeOrderCode(CustomerOrder order) {
        return order.getOrderCode() == null || order.getOrderCode().isBlank() ? "#" + order.getId() : order.getOrderCode();
    }

    @Override
    @Transactional
    public void delete(Long id, Long actorId) {
        assignedDataScope.requireOrder(actorId, customerOrderDomainService.getById(id));
        orderEntrustDetailService.releaseWalletCredit(id);
        customerOrderDomainService.delete(id);
    }

    @Override
    @Transactional
    public void deleteWarehouse(Long id, Long actorId) {
        CustomerOrder order = customerOrderDomainService.getById(id);
        if (!"TRANSPORT_ENTRUST".equalsIgnoreCase(order.getContractType())) {
            throw new IllegalArgumentException("Chỉ được xóa bản ghi Kho vận");
        }
        delete(id, actorId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CustomerDTO> findCustomers(String phone, Long actorId) {
        List<CustomerOrder> allOrders = customerOrderDomainService.findAll();
        List<CustomerOrder> visibleOrders = assignedDataScope.filterOrders(actorId, allOrders);
        Map<Long, Long> orderCountByCustomer = visibleOrders.stream()
                .filter(order -> order.getCustomer() != null)
                .collect(Collectors.groupingBy(order -> order.getCustomer().getId(), Collectors.counting()));
        List<Customer> customers = phone == null || phone.isBlank()
                ? customerDomainService.findAll()
                : customerDomainService.findByPhone(phone).stream().toList();
        Set<Long> allowedCustomers = assignedDataScope.scopedCustomerIdsForOrders(actorId, allOrders);
        if (allowedCustomers != null) {
            boolean includeDirectCareAssignments = assignedDataScope.isRestrictedCustomerCareStaff(actorId);
            customers = customers.stream()
                    .filter(customer -> allowedCustomers.contains(customer.getId())
                            || AssignedDataScope.isCustomerCreator(actorId, customer)
                            || (includeDirectCareAssignments
                            && AssignedDataScope.isDirectCustomerCareAssignee(actorId, customer)))
                    .toList();
        }
        return customers.stream()
                .map(customer -> mapper.toCustomerDTO(
                        customer,
                        orderCountByCustomer.getOrDefault(customer.getId(), 0L).intValue()))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public CustomerDTO getCustomerById(Long id, Long actorId) {
        return findCustomers(null, actorId).stream()
                .filter(customer -> customer.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Khách hàng không tồn tại"));
    }

    @Override
    @Transactional(readOnly = true)
    public CustomerPageDTO searchCustomers(String code, String name, String phone, String province, String ward,
                                           String category, Long createdById, Long customerCareStaffId,
                                           String fromDate, String toDate, String fromMonth, String toMonth,
                                           int pageNo, int pageSize, Long actorId) {
        List<CustomerDTO> filtered = findCustomers(null, actorId).stream()
                .filter(customer -> contains(customer.getCode(), code))
                .filter(customer -> contains(customer.getFullName(), name))
                .filter(customer -> contains(customer.getPhone(), phone))
                .filter(customer -> contains(customer.getProvince(), province))
                .filter(customer -> contains(customer.getWard(), ward))
                .filter(customer -> contains(customer.getCategory(), category))
                .filter(customer -> createdById == null || createdById.equals(customer.getCreatedById()))
                .filter(customer -> customerCareStaffId == null
                        || customerCareStaffId.equals(customer.getCustomerCareStaffId()))
                .filter(customer -> inDateRange(customer.getCreatedAt(), fromDate, toDate, fromMonth, toMonth))
                .toList();
        CustomerPageDTO dto = new CustomerPageDTO();
        dto.setItems(pageSlice(filtered, pageNo, pageSize));
        fillPage(dto, filtered.size(), pageNo, pageSize);
        return dto;
    }

    @Override
    @Transactional
    public CustomerDTO createCustomer(SaveCustomerCommand command, Long actorId) {
        validateCustomerTaxCode(command);
        if (command.getLeadId() != null) {
            assignedDataScope.requireLead(actorId, command.getLeadId());
            String careProgress = marketingLeadDomainService.getById(command.getLeadId()).getCareProgress();
            if (!CareProgressRules.isAgreedToUseService(careProgress)) {
                throw new IllegalArgumentException(
                        "Chỉ được tạo khách hàng khi tiến trình chăm sóc là L4: Ký hợp đồng");
            }
        }
        Customer saved = customerDomainService.createOrResolve(new Customer()
                .setCode(command.getCode())
                .setFullName(command.getFullName())
                .setCompanyName(command.getCompanyName())
                .setPhone(command.getPhone())
                .setEmail(command.getEmail())
                .setCategory(command.getCategory())
                .setTaxCode(command.getTaxCode())
                .setBusinessType(command.getBusinessType())
                .setChinaVietnamRateKg(command.getChinaVietnamRateKg())
                .setChinaVietnamRateCbm(command.getChinaVietnamRateCbm())
                .setLeadSource(command.getLeadSource())
                .setAddress(command.getAddress())
                .setProvince(command.getProvince())
                .setWard(command.getWard())
                .setDetailAddress(command.getDetailAddress())
                .setNote(command.getNote()), actorId);
        if (command.getLeadId() != null) {
            marketingLeadDomainService.linkCustomer(command.getLeadId(), saved);
            if (command.getCustomerCareStaffId() != null) {
                assignmentDomainService.assign(AssignmentRefType.CUSTOMER, saved.getId(),
                        command.getCustomerCareStaffId(), actorId, "Phân CSKH khi tạo từ Data");
                saved = customerDomainService.assignCustomerCareStaff(saved.getId(), command.getCustomerCareStaffId());
            } else {
                notifyCustomerCareManagers(saved, actorId);
            }
        } else if (isCustomerCareUser(actorId)) {
            assignmentDomainService.assign(AssignmentRefType.CUSTOMER, saved.getId(), actorId, actorId,
                    "Tự nhận khi tạo khách hàng trực tiếp");
            saved = customerDomainService.assignCustomerCareStaff(saved.getId(), actorId);
        } else {
            notifyCustomerCareManagers(saved, actorId);
        }
        long orderCount = customerOrderDomainService.findByCustomerId(saved.getId()).size();
        return mapper.toCustomerDTO(saved, (int) orderCount);
    }

    @Override
    @Transactional
    public CustomerDTO updateCustomer(Long id, SaveCustomerCommand command, Long actorId) {
        validateCustomerTaxCode(command);
        Customer saved = customerDomainService.update(id, customerDraft(command));
        if (command.getCustomerCareStaffId() != null) {
            saved = customerDomainService.assignCustomerCareStaff(id, command.getCustomerCareStaffId());
        }
        long orderCount = customerOrderDomainService.findByCustomerId(saved.getId()).size();
        return mapper.toCustomerDTO(saved, (int) orderCount);
    }

    @Override
    @Transactional
    public void deleteCustomer(Long id, Long actorId) {
        marketingLeadDomainService.unlinkCustomer(id);
        customerDomainService.delete(id);
    }

    private static void validateCustomerTaxCode(SaveCustomerCommand command) {
        String taxCode = command.getTaxCode() == null ? "" : command.getTaxCode().trim();
        if (taxCode.isEmpty()) return;
        String businessType = command.getBusinessType() == null ? "" : command.getBusinessType().trim();
        if (businessType.isEmpty()) {
            throw new IllegalArgumentException("Vui lòng chọn Loại hình trước khi nhập mã số thuế");
        }
        if (businessType.equalsIgnoreCase("Hộ Kinh doanh")
                || businessType.equalsIgnoreCase("Cá nhân kinh doanh")) {
            if (!taxCode.matches("\\d{12}")) {
                throw new IllegalArgumentException("Mã số thuế Hộ/Cá nhân kinh doanh phải gồm đúng 12 chữ số");
            }
        } else if (!taxCode.matches("\\d{10}")) {
            throw new IllegalArgumentException("Mã số thuế công ty/doanh nghiệp phải gồm đúng 10 chữ số");
        }
    }

    private static Customer customerDraft(SaveCustomerCommand command) {
        return new Customer()
                .setCode(command.getCode())
                .setFullName(command.getFullName())
                .setCompanyName(command.getCompanyName())
                .setPhone(command.getPhone())
                .setEmail(command.getEmail())
                .setCategory(command.getCategory())
                .setTaxCode(command.getTaxCode())
                .setBusinessType(command.getBusinessType())
                .setChinaVietnamRateKg(command.getChinaVietnamRateKg())
                .setChinaVietnamRateCbm(command.getChinaVietnamRateCbm())
                .setLeadSource(command.getLeadSource())
                .setAddress(command.getAddress())
                .setProvince(command.getProvince())
                .setWard(command.getWard())
                .setDetailAddress(command.getDetailAddress())
                .setNote(command.getNote());
    }

    @Override
    @Transactional
    public CustomerDTO assignCustomerCareStaff(Long customerId, Long staffId, String note,
                                               Boolean notifyMail, Boolean notifySystem, Long actorId) {
        getCustomerById(customerId, actorId);
        if (staffId != null) {
            assignmentDomainService.assign(AssignmentRefType.CUSTOMER, customerId, staffId, actorId, note);
        }
        Customer saved = customerDomainService.assignCustomerCareStaff(customerId, staffId);
        if (staffId != null) {
            try {
                notificationAppService.send(new SendNotificationCommand()
                        .setRecipientId(staffId)
                        .setActorId(actorId)
                        .setType(NotificationType.TASK_ASSIGNED)
                        .setTitle("Bạn được phân phụ trách khách hàng")
                        .setBody((saved.getFullName() == null ? "" : saved.getFullName())
                                + " - " + (saved.getPhone() == null ? "" : saved.getPhone()))
                        .setRefType("CUSTOMER")
                        .setRefId(saved.getId())
                        .setLink("/customers")
                        .setSendEmail(!Boolean.FALSE.equals(notifyMail))
                        .setSendRealtime(!Boolean.FALSE.equals(notifySystem)));
            } catch (Exception e) {
                log.error("Send customer care assignment notification error, customerId={}, staffId={}",
                        customerId, staffId, e);
            }
        }
        long orderCount = customerOrderDomainService.findByCustomerId(saved.getId()).size();
        return mapper.toCustomerDTO(saved, (int) orderCount);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AssignmentDTO> findCustomerCareAssignmentHistory(Long customerId, Long actorId) {
        getCustomerById(customerId, actorId);
        return assignmentDomainService.findHistory(AssignmentRefType.CUSTOMER, customerId).stream()
                .map(mapper::toAssignmentDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderDTO> findByCustomerId(Long customerId, Long actorId) {
        Customer customer = customerDomainService.getById(customerId);
        List<CustomerOrder> orders = assignedDataScope.filterOrders(
                actorId, customerOrderDomainService.findByCustomerId(customer.getId()));
        if (assignedDataScope.shouldRestrictOrders(actorId)) {
            Set<Long> allowedCustomers = assignedDataScope.scopedCustomerIdsForOrders(
                    actorId, customerOrderDomainService.findAll());
            if (allowedCustomers != null && !allowedCustomers.contains(customer.getId())) {
                throw new IllegalArgumentException("Khách hàng không tồn tại");
            }
        }
        Map<Long, String> overlays = orderEntrustDetailService.hydratePage(orders);
        return orders.stream()
                .map(order -> mapper.toOrderListDTO(
                        order, overlays.getOrDefault(order.getId(), order.getSaleOverlayJson())))
                .toList();
    }

    private static boolean matchesAny(OrderDTO order, String query) {
        String q = normalize(query);
        if (q == null) return true;
        return contains(order.getCustomerCode(), q)
                || contains(order.getOrderCode(), q)
                || contains(order.getBatchCode(), q)
                || contains(order.getCustomerName(), q)
                || contains(order.getCustomerPhone(), q)
                || contains(order.getProductName(), q)
                || contains(order.getCategory(), q)
                || contains(order.getServiceType(), q)
                || contains(order.getSalaryCustomerKind(), q);
    }

    private void notifyCustomerCareManagers(Customer customer, Long actorId) {
        List<User> managers = notificationRecipientResolver.findCustomerCareManagers();
        if (managers == null || managers.isEmpty()) {
            return;
        }
        notificationAppService.sendAll(managers.stream()
                .map(manager -> new SendNotificationCommand()
                        .setRecipientId(manager.getId())
                        .setActorId(actorId)
                        .setType(NotificationType.CUSTOMER_CREATED)
                        .setTitle("Khách hàng mới cần phân CSKH")
                        .setBody((customer.getFullName() == null ? "" : customer.getFullName())
                                + " - " + (customer.getPhone() == null ? "" : customer.getPhone())
                                + " đang chờ phân nhân viên CSKH")
                        .setRefType("CUSTOMER")
                        .setRefId(customer.getId())
                        .setLink("/customers?highlightId=" + customer.getId())
                        .setSendEmail(false)
                        .setSendRealtime(true))
                .toList());
    }

    private boolean isCustomerCareUser(Long userId) {
        if (userId == null) return false;
        return userRepository.findByIdWithAuth(userId)
                .map(User::getRoleCode)
                .map(String::trim)
                .map("cskh"::equalsIgnoreCase)
                .orElse(false);
    }

    private static boolean contains(String value, String query) {
        String q = normalize(query);
        if (q == null) return true;
        return value != null && value.toLowerCase().contains(q);
    }

    private static String normalize(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim().toLowerCase();
    }

    private static boolean inDateRange(String createdAt, String fromDate, String toDate, String fromMonth, String toMonth) {
        if (createdAt == null || createdAt.isBlank()) return true;
        String itemDate = createdAt.length() >= 10 ? createdAt.substring(0, 10) : createdAt;
        String itemMonth = createdAt.length() >= 7 ? createdAt.substring(0, 7) : createdAt;
        if (hasText(fromDate) && itemDate.compareTo(fromDate.trim()) < 0) return false;
        if (hasText(toDate) && itemDate.compareTo(toDate.trim()) > 0) return false;
        if (hasText(fromMonth) && itemMonth.compareTo(fromMonth.trim()) < 0) return false;
        return !hasText(toMonth) || itemMonth.compareTo(toMonth.trim()) <= 0;
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private static java.time.LocalDateTime resolveFrom(String fromDate, String fromMonth) {
        try {
            if (hasText(fromDate)) return LocalDate.parse(fromDate.trim()).atStartOfDay();
            if (hasText(fromMonth)) return YearMonth.parse(fromMonth.trim()).atDay(1).atStartOfDay();
        } catch (Exception ignored) { }
        return null;
    }

    private static java.time.LocalDateTime resolveToExclusive(String toDate, String toMonth) {
        try {
            if (hasText(toDate)) return LocalDate.parse(toDate.trim()).plusDays(1).atStartOfDay();
            if (hasText(toMonth)) return YearMonth.parse(toMonth.trim()).plusMonths(1).atDay(1).atStartOfDay();
        } catch (Exception ignored) { }
        return null;
    }

    private static String requireContractType(String value) {
        String normalized = value == null ? "" : value.trim().toUpperCase();
        if (!"IMPORT_ENTRUST".equals(normalized) && !"TRANSPORT_ENTRUST".equals(normalized)) {
            throw new IllegalArgumentException("Loại hợp đồng không hợp lệ");
        }
        return normalized;
    }

    private static <T> List<T> pageSlice(List<T> items, int pageNo, int pageSize) {
        int safeSize = Math.min(Math.max(pageSize, 1), 100);
        int safePage = Math.max(pageNo, 1);
        int from = Math.min((safePage - 1) * safeSize, items.size());
        int to = Math.min(from + safeSize, items.size());
        return items.subList(from, to);
    }

    private static void fillPage(CustomerPageDTO dto, long total, int pageNo, int pageSize) {
        int safeSize = Math.min(Math.max(pageSize, 1), 100);
        dto.setPageNo(Math.max(pageNo, 1));
        dto.setPageSize(safeSize);
        dto.setTotalElements(total);
        dto.setTotalPages((int) Math.max(1, Math.ceil(total / (double) safeSize)));
    }

    private static void fillPage(OrderPageDTO dto, long total, int pageNo, int pageSize) {
        int safeSize = Math.min(Math.max(pageSize, 1), 100);
        dto.setPageNo(Math.max(pageNo, 1));
        dto.setPageSize(safeSize);
        dto.setTotalElements(total);
        dto.setTotalPages((int) Math.max(1, Math.ceil(total / (double) safeSize)));
    }
}
