package com.xxxx.ddd.application.service.salary;

import com.xxxx.ddd.application.model.SalaryPeriodDTO;
import com.xxxx.ddd.application.model.command.SaveSalaryCommand;

public interface SalaryAppService {

    SalaryPeriodDTO getOrPreview(String period, Long actorId, Long saleRoomId);

    SalaryPeriodDTO getMyPreview(String period, Long actorId);

    SalaryPeriodDTO save(String period, SaveSalaryCommand command, Long actorId, Long saleRoomId);

    SalaryPeriodDTO lock(String period, Long actorId, Long saleRoomId);

    SalaryPeriodDTO unlock(String period, Long actorId, Long saleRoomId);
}
