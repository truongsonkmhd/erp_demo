package com.xxxx.ddd.application.service.salary;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;
import java.util.Set;

/**
 * Port of pts-frontend.com/src/constants/salary.ts commission formulas.
 */
public final class SalaryCommissionRules {

    public static final String SCHEME_SALES = "sales";
    public static final String SCHEME_SENIOR = "senior";
    public static final String SCHEME_MANAGER = "manager";
    public static final String SCHEME_DIRECTOR = "director";
    /** Hoa hồng Marketing: 2% × LNP đơn mới từ lead do user tạo (không tính lương). */
    public static final String SCHEME_MARKETING = "marketing";

    private static final Set<String> DEPT_SCHEMES = Set.of(SCHEME_MANAGER, SCHEME_DIRECTOR);

    private SalaryCommissionRules() {
    }

    public static boolean usesDepartmentProfit(String scheme) {
        return scheme != null && DEPT_SCHEMES.contains(normalizeScheme(scheme));
    }

    public static String normalizeScheme(String scheme) {
        if (scheme == null || scheme.isBlank()) {
            return SCHEME_SALES;
        }
        return scheme.trim().toLowerCase(Locale.ROOT);
    }

    /** Map cấp bậc Sale → cơ chế thưởng (không cho sửa tay trên UI). */
    public static String schemeFromLevelCode(String levelCode) {
        if (levelCode == null || levelCode.isBlank()) {
            return SCHEME_SALES;
        }
        return switch (levelCode.trim().toLowerCase(Locale.ROOT)) {
            case "senior" -> SCHEME_SENIOR;
            case "manager" -> SCHEME_MANAGER;
            case "director" -> SCHEME_DIRECTOR;
            default -> SCHEME_SALES;
        };
    }

    /** Math.round(baseSalary * (kpiPercent/100) * coefficient) */
    public static BigDecimal calcBasePayout(BigDecimal baseSalary, BigDecimal kpiPercent, BigDecimal coefficient) {
        BigDecimal base = nz(baseSalary);
        BigDecimal rate = nz(kpiPercent).max(BigDecimal.ZERO).divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP);
        BigDecimal coef = nz(coefficient);
        return roundMoney(base.multiply(rate).multiply(coef));
    }

    /**
     * a = KPI, b = actual.
     * &lt; 100%: c × a × (b/a) = c × b
     * ≥ 100%: c × (a + a × (b/a)) = c × (a + b)
     */
    public static BigDecimal commissionPart(BigDecimal rate, BigDecimal kpi, BigDecimal actual) {
        BigDecimal a = nz(kpi);
        if (a.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        BigDecimal b = nz(actual);
        BigDecimal c = nz(rate);
        BigDecimal pct = b.divide(a, 10, RoundingMode.HALF_UP);
        if (pct.compareTo(BigDecimal.ONE) < 0) {
            return c.multiply(a).multiply(pct);
        }
        return c.multiply(a.add(a.multiply(pct)));
    }

    public static BigDecimal calcCommission(
            String scheme,
            BigDecimal newProfit,
            BigDecimal newKpi,
            BigDecimal oldProfit,
            BigDecimal oldKpi,
            BigDecimal deptProfit,
            BigDecimal deptNewProfit,
            BigDecimal deptOldProfit) {
        String s = normalizeScheme(scheme);
        if (SCHEME_MARKETING.equals(s)) {
            // 2% × lợi nhuận Net đơn hàng mới (data Marketing tạo)
            return roundMoney(BigDecimal.valueOf(0.02).multiply(nz(newProfit)));
        }
        if (SCHEME_DIRECTOR.equals(s)) {
            // Sheet: 2% × LNP toàn phòng
            return roundMoney(BigDecimal.valueOf(0.02).multiply(nz(deptProfit)));
        }
        if (SCHEME_MANAGER.equals(s)) {
            // Sheet: 3% LNP đơn mới + 2% LNP đơn cũ (toàn phòng) — không nhân theo % đạt KPI.
            return roundMoney(
                    BigDecimal.valueOf(0.03).multiply(nz(deptNewProfit))
                            .add(BigDecimal.valueOf(0.02).multiply(nz(deptOldProfit))));
        }
        if (SCHEME_SENIOR.equals(s)) {
            return roundMoney(
                    commissionPart(BigDecimal.valueOf(0.22), newKpi, newProfit)
                            .add(commissionPart(BigDecimal.valueOf(0.08), oldKpi, oldProfit)));
        }
        return roundMoney(
                commissionPart(BigDecimal.valueOf(0.2), newKpi, newProfit)
                        .add(commissionPart(BigDecimal.valueOf(0.07), oldKpi, oldProfit)));
    }

    public static BigDecimal roundMoney(BigDecimal value) {
        if (value == null) {
            return BigDecimal.ZERO;
        }
        return value.setScale(0, RoundingMode.HALF_UP);
    }

    public static BigDecimal nz(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }
}
