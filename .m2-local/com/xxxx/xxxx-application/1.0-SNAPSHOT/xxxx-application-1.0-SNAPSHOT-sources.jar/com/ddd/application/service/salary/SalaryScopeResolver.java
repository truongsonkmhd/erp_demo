package com.xxxx.ddd.application.service.salary;

import com.xxxx.ddd.domain.model.entity.Permission;
import com.xxxx.ddd.domain.model.entity.SaleRoom;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.SaleRoomRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Phạm vi xem/tính lương & KPI: chỉ role Sale; leader phòng hoặc view_all_salary_rooms.
 */
@Component
public class SalaryScopeResolver {

    public static final String PERMISSION_VIEW_ALL = "view_all_salary_rooms";

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SaleRoomRepository saleRoomRepository;

    public record Scope(
            boolean canViewAllRooms,
            Long scopedSaleRoomId,
            String scopedSaleRoomName,
            String emptyReason,
            Set<Long> allowedUserIds,
            List<User> users
    ) {
        public boolean allows(Long userId) {
            return userId != null && allowedUserIds.contains(userId);
        }
    }

    /**
     * Phạm vi xem lương/hoa hồng tạm tính cá nhân — Sale hoặc Marketing.
     */
    public Scope resolveSelf(Long actorId) {
        if (actorId == null) {
            return empty("Chưa xác định người dùng", false, null, null);
        }
        User actor = userRepository.findByIdWithAuth(actorId).orElse(null);
        if (actor == null) {
            return empty("Người dùng không tồn tại", false, null, null);
        }
        if (!isSale(actor) && !isMarketing(actor)) {
            return empty("Chỉ nhân viên Sale hoặc Marketing mới xem được lương/hoa hồng tạm tính", false, null, null);
        }
        SaleRoom room = actor.getSaleRoom();
        return new Scope(
                false,
                room != null ? room.getId() : null,
                room != null ? room.getName() : null,
                null,
                Set.of(actorId),
                List.of(actor)
        );
    }

    public Scope resolve(Long actorId, Long requestedSaleRoomId) {
        if (actorId == null) {
            return empty("Chưa xác định người dùng", false, null, null);
        }
        User actor = userRepository.findByIdWithAuth(actorId).orElse(null);
        if (actor == null) {
            return empty("Người dùng không tồn tại", false, null, null);
        }

        boolean canViewAll = isAdmin(actor)
                || isAccounting(actor)
                || hasPermission(actor, PERMISSION_VIEW_ALL);
        if (canViewAll) {
            Long filterRoomId = requestedSaleRoomId;
            SaleRoom filterRoom = null;
            if (filterRoomId != null) {
                filterRoom = saleRoomRepository.findByIdActive(filterRoomId).orElse(null);
                if (filterRoom == null) {
                    return empty("Phòng ban không tồn tại", true, filterRoomId, null);
                }
            }
            List<User> users = filterRoomId == null
                    ? findActiveSaleUsers()
                    : findActiveSaleUsersInRoom(filterRoomId);
            return new Scope(
                    true,
                    filterRoom != null ? filterRoom.getId() : null,
                    filterRoom != null ? filterRoom.getName() : null,
                    users.isEmpty() ? "Không có nhân viên Sale trong phạm vi" : null,
                    toIds(users),
                    users
            );
        }

        SaleRoom led = saleRoomRepository.findByLeaderId(actorId).orElse(null);
        if (led == null) {
            return empty(
                    "Chỉ Leader phòng mới xem được lương phòng mình. Bạn không phải Leader của phòng nào.",
                    false,
                    null,
                    null
            );
        }
        List<User> users = findActiveSaleUsersInRoom(led.getId());
        return new Scope(
                false,
                led.getId(),
                led.getName(),
                users.isEmpty() ? "Phòng chưa có nhân viên Sale" : null,
                toIds(users),
                users
        );
    }

    private List<User> findActiveSaleUsers() {
        return userRepository.findAllActiveWithAuth().stream()
                .filter(SalaryScopeResolver::isSale)
                .filter(u -> u.getSaleRoom() != null && u.getSaleRoom().getId() != null)
                .collect(Collectors.toList());
    }

    private List<User> findActiveSaleUsersInRoom(Long roomId) {
        return userRepository.findBySaleRoomId(roomId).stream()
                .filter(u -> u.getActive() == null || Boolean.TRUE.equals(u.getActive()))
                .filter(SalaryScopeResolver::isSale)
                .collect(Collectors.toList());
    }

    private static Scope empty(String reason, boolean canViewAll, Long roomId, String roomName) {
        return new Scope(canViewAll, roomId, roomName, reason, Set.of(), List.of());
    }

    private static Set<Long> toIds(List<User> users) {
        return users.stream()
                .map(User::getId)
                .filter(Objects::nonNull)
                .collect(Collectors.toUnmodifiableSet());
    }

    public static boolean isSale(User user) {
        String code = user != null ? user.getRoleCode() : null;
        return code != null && "sale".equalsIgnoreCase(code.trim());
    }

    public static boolean isMarketing(User user) {
        String code = user != null ? user.getRoleCode() : null;
        return code != null && "marketing".equalsIgnoreCase(code.trim());
    }

    private static boolean isAccounting(User user) {
        String code = user.getRoleCode();
        return code != null && "accounting".equalsIgnoreCase(code.trim());
    }

    private static boolean isAdmin(User user) {
        return user.getRole() != null && user.getRole().isAdmin();
    }

    private static boolean hasPermission(User user, String code) {
        if (code == null || code.isBlank()) {
            return false;
        }
        String wanted = code.trim().toLowerCase(Locale.ROOT);
        Set<Permission> permissions = user.getEffectivePermissions();
        if (permissions == null || permissions.isEmpty()) {
            return false;
        }
        for (Permission permission : permissions) {
            if (permission != null && permission.getCode() != null
                    && wanted.equals(permission.getCode().trim().toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return false;
    }
}
