package com.xxxx.ddd.application.service.salary.impl;

import com.xxxx.ddd.application.model.SalaryLineDTO;
import com.xxxx.ddd.application.model.SalaryOrderDTO;
import com.xxxx.ddd.application.model.SalaryPeriodDTO;
import com.xxxx.ddd.application.model.command.SaveSalaryCommand;
import com.xxxx.ddd.application.service.salary.SalaryAppService;
import com.xxxx.ddd.application.service.salary.SalaryCommissionRules;
import com.xxxx.ddd.application.service.salary.SalaryScopeResolver;
import com.xxxx.ddd.domain.model.entity.*;
import com.xxxx.ddd.domain.model.workflow.SalaryCustomerKindRules;
import com.xxxx.ddd.domain.respository.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SalaryAppServiceImpl implements SalaryAppService {

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private static final DateTimeFormatter PERIOD_FMT = DateTimeFormatter.ofPattern("yyyy-MM");

    @Autowired
    private SalaryPeriodRepository salaryPeriodRepository;

    @Autowired
    private SalaryLineRepository salaryLineRepository;

    @Autowired
    private SalaryOrderRepository salaryOrderRepository;

    @Autowired
    private CustomerOrderRepository customerOrderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LeadKpiPeriodRepository leadKpiPeriodRepository;

    @Autowired
    private LeadKpiEmployeeRepository leadKpiEmployeeRepository;

    @Autowired
    private SalaryScopeResolver salaryScopeResolver;

    @Autowired
    private MarketingLeadRepository marketingLeadRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    @Transactional(readOnly = true)
    public SalaryPeriodDTO getOrPreview(String period, Long actorId, Long saleRoomId) {
        String normalized = normalizePeriod(period);
        SalaryScopeResolver.Scope scope = salaryScopeResolver.resolve(actorId, saleRoomId);
        return buildPeriodForScope(normalized, scope);
    }

    @Override
    @Transactional(readOnly = true)
    public SalaryPeriodDTO getMyPreview(String period, Long actorId) {
        String normalized = normalizePeriod(period);
        SalaryScopeResolver.Scope scope = salaryScopeResolver.resolveSelf(actorId);
        if (scope.users().isEmpty()) {
            throw new IllegalArgumentException(
                    scope.emptyReason() != null ? scope.emptyReason() : "Không xem được lương tạm tính");
        }
        return buildPeriodForScope(normalized, scope);
    }

    private SalaryPeriodDTO buildPeriodForScope(String normalized, SalaryScopeResolver.Scope scope) {
        boolean marketingPreview = scope.users().stream().allMatch(SalaryScopeResolver::isMarketing)
                && !scope.users().isEmpty();

        Optional<SalaryPeriod> existing = salaryPeriodRepository.findByPeriod(normalized);
        // Marketing chỉ xem hoa hồng tạm tính theo đơn — không dùng dòng lương Sale đã khóa.
        if (existing.isPresent() && existing.get().isLocked() && !marketingPreview) {
            List<SalaryLine> scopedLines = salaryLineRepository.findByPeriodId(existing.get().getId()).stream()
                    .filter(line -> line.getUser() != null && scope.allows(line.getUser().getId()))
                    .toList();
            return toPeriodDTO(existing.get(), scopedLines, true, false, scope);
        }

        List<CustomerOrder> periodEligible = customerOrderRepository.findSalaryEligibleByPeriod(normalized);
        List<CustomerOrder> eligible = marketingPreview
                ? periodEligible
                : filterEligible(periodEligible, scope);
        ProfitBuckets dept = sumDept(eligible);
        Map<Long, ProfitBuckets> byAssignee = sumByAssignee(eligible);
        Map<Long, ProfitBuckets> byMarketingCreator = marketingPreview
                ? sumByMarketingLeadCreator(periodEligible)
                : Map.of();
        Map<Long, LeadKpiEmployee> kpiByUser = loadKpiByUser(normalized);

        SalaryPeriodDTO dto = new SalaryPeriodDTO();
        dto.setPeriod(normalized);
        dto.setStatus(SalaryPeriod.STATUS_DRAFT);
        dto.setPreview(true);
        applyScopeMeta(dto, scope);
        dto.setDeptNewActualVnd(dept.newVnd);
        dto.setDeptOldActualVnd(dept.oldVnd);
        dto.setDeptProfitVnd(dept.total());
        if (existing.isPresent()) {
            SalaryPeriod periodEntity = existing.get();
            dto.setId(periodEntity.getId());
            dto.setDeptProfitOverrideVnd(null);
            dto.setCreatedAt(format(periodEntity.getCreatedAt()));
            dto.setUpdatedAt(format(periodEntity.getUpdatedAt()));
        }

        BigDecimal deptProfitForCalc = dept.total();

        List<SalaryLineDTO> lineDtos = new ArrayList<>();
        for (User user : scope.users()) {
            if (SalaryScopeResolver.isMarketing(user)) {
                lineDtos.add(buildMarketingLine(user, byMarketingCreator.getOrDefault(user.getId(), new ProfitBuckets())));
                continue;
            }

            LeadKpiEmployee kpi = kpiByUser.get(user.getId());
            BigDecimal kpiPercent = kpiPercentOf(kpi);
            BigDecimal coefficient = coefficientOf(kpi);
            BigDecimal baseSalary = user.getBaseSalary() != null ? user.getBaseSalary() : BigDecimal.ZERO;
            ProfitBuckets personal = byAssignee.getOrDefault(user.getId(), new ProfitBuckets());

            String scheme = SalaryCommissionRules.schemeFromLevelCode(user.getLevelCode());
            BigDecimal newActual = SalaryCommissionRules.usesDepartmentProfit(scheme) ? dept.newVnd : personal.newVnd;
            BigDecimal oldActual = SalaryCommissionRules.usesDepartmentProfit(scheme) ? dept.oldVnd : personal.oldVnd;

            BigDecimal payout = SalaryCommissionRules.calcBasePayout(baseSalary, kpiPercent, coefficient);
            BigDecimal commission = SalaryCommissionRules.calcCommission(
                    scheme,
                    newActual, BigDecimal.ZERO,
                    oldActual, BigDecimal.ZERO,
                    deptProfitForCalc, dept.newVnd, dept.oldVnd);

            SalaryLineDTO line = new SalaryLineDTO();
            line.setUserId(user.getId());
            line.setUserName(user.getFullName());
            applyUserRoom(line, user);
            line.setScheme(scheme);
            line.setBaseSalary(baseSalary);
            line.setKpiPercent(kpiPercent);
            line.setCoefficient(coefficient);
            line.setNewKpiVnd(BigDecimal.ZERO);
            line.setOldKpiVnd(BigDecimal.ZERO);
            line.setNewActualVnd(newActual);
            line.setOldActualVnd(oldActual);
            line.setActualIsOverride(false);
            line.setPayoutVnd(payout);
            line.setCommissionVnd(commission);
            line.setTotalVnd(payout.add(commission));
            lineDtos.add(line);
        }
        Map<Long, SalaryLine> savedByUser = Map.of();
        if (existing.isPresent() && !marketingPreview) {
            savedByUser = salaryLineRepository.findByPeriodId(existing.get().getId()).stream()
                    .filter(line -> line.getUser() != null && line.getUser().getId() != null)
                    .collect(Collectors.toMap(line -> line.getUser().getId(), line -> line, (a, b) -> a));
        }

        for (SalaryLineDTO line : lineDtos) {
            if (SalaryCommissionRules.SCHEME_MARKETING.equals(
                    SalaryCommissionRules.normalizeScheme(line.getScheme()))) {
                continue;
            }
            SalaryLine saved = savedByUser.get(line.getUserId());
            if (saved != null) {
                line.setNewKpiVnd(SalaryCommissionRules.nz(saved.getNewKpiVnd()));
                line.setOldKpiVnd(SalaryCommissionRules.nz(saved.getOldKpiVnd()));
                if (Boolean.TRUE.equals(saved.getActualIsOverride())) {
                    line.setActualIsOverride(true);
                    line.setNewActualVnd(saved.getNewActualVnd());
                    line.setOldActualVnd(saved.getOldActualVnd());
                }
                BigDecimal payout = SalaryCommissionRules.calcBasePayout(
                        line.getBaseSalary(), line.getKpiPercent(), line.getCoefficient());
                BigDecimal commission = SalaryCommissionRules.calcCommission(
                        line.getScheme(),
                        line.getNewActualVnd(), line.getNewKpiVnd(),
                        line.getOldActualVnd(), line.getOldKpiVnd(),
                        deptProfitForCalc, dept.newVnd, dept.oldVnd);
                line.setPayoutVnd(payout);
                line.setCommissionVnd(commission);
                line.setTotalVnd(payout.add(commission));
            }
        }

        dto.setLines(lineDtos);
        return dto;
    }

    private SalaryLineDTO buildMarketingLine(User user, ProfitBuckets fromLeads) {
        BigDecimal newActual = fromLeads.newVnd;
        BigDecimal commission = SalaryCommissionRules.calcCommission(
                SalaryCommissionRules.SCHEME_MARKETING,
                newActual, BigDecimal.ZERO,
                BigDecimal.ZERO, BigDecimal.ZERO,
                BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);

        SalaryLineDTO line = new SalaryLineDTO();
        line.setUserId(user.getId());
        line.setUserName(user.getFullName());
        applyUserRoom(line, user);
        line.setScheme(SalaryCommissionRules.SCHEME_MARKETING);
        line.setBaseSalary(BigDecimal.ZERO);
        line.setKpiPercent(BigDecimal.ZERO);
        line.setCoefficient(BigDecimal.ONE);
        line.setNewKpiVnd(BigDecimal.ZERO);
        line.setOldKpiVnd(BigDecimal.ZERO);
        line.setNewActualVnd(newActual);
        line.setOldActualVnd(BigDecimal.ZERO);
        line.setActualIsOverride(false);
        line.setPayoutVnd(BigDecimal.ZERO);
        line.setCommissionVnd(commission);
        line.setTotalVnd(commission);
        return line;
    }

    @Override
    @Transactional
    public SalaryPeriodDTO save(String period, SaveSalaryCommand command, Long actorId, Long saleRoomId) {
        String normalized = normalizePeriod(period);
        SalaryScopeResolver.Scope scope = salaryScopeResolver.resolve(actorId, saleRoomId);
        if (command == null || command.getLines() == null || command.getLines().isEmpty()) {
            throw new IllegalArgumentException("Danh sách dòng lương không được trống");
        }
        for (SaveSalaryCommand.LineInput input : command.getLines()) {
            if (input.getUserId() == null || !scope.allows(input.getUserId())) {
                throw new IllegalArgumentException("Không được lưu dòng lương ngoài phạm vi phòng của bạn");
            }
        }

        LocalDateTime now = LocalDateTime.now();
        SalaryPeriod periodEntity = salaryPeriodRepository.findByPeriod(normalized).orElse(null);
        if (periodEntity != null && periodEntity.isLocked()) {
            throw new IllegalArgumentException("Kỳ lương đã khóa, không thể chỉnh sửa");
        }
        if (periodEntity == null) {
            periodEntity = new SalaryPeriod()
                    .setPeriod(normalized)
                    .setStatus(SalaryPeriod.STATUS_DRAFT)
                    .setCreatedAt(now);
        }
        periodEntity.setDeptProfitOverrideVnd(null);
        periodEntity.setStatus(SalaryPeriod.STATUS_DRAFT);
        periodEntity.setUpdatedAt(now);
        periodEntity = salaryPeriodRepository.save(periodEntity);

        // Replace only in-scope lines; keep other rooms' lines when see-all filter or leader scope
        List<SalaryLine> existingLines = salaryLineRepository.findByPeriodId(periodEntity.getId());
        List<SalaryLine> toRemove = existingLines.stream()
                .filter(line -> line.getUser() != null && scope.allows(line.getUser().getId()))
                .toList();
        if (!toRemove.isEmpty()) {
            List<Long> lineIds = toRemove.stream().map(SalaryLine::getId).toList();
            salaryOrderRepository.deleteBySalaryLineIdIn(lineIds);
            for (SalaryLine line : toRemove) {
                salaryLineRepository.delete(line);
            }
            entityManager.flush();
        }

        List<CustomerOrder> eligible = filterEligible(
                customerOrderRepository.findSalaryEligibleByPeriod(normalized), scope);
        ProfitBuckets dept = sumDept(eligible);
        Map<Long, ProfitBuckets> byAssignee = sumByAssignee(eligible);
        Map<Long, List<CustomerOrder>> ordersByAssignee = groupOrdersByAssignee(eligible);
        Map<Long, LeadKpiEmployee> kpiByUser = loadKpiByUser(normalized);

        BigDecimal deptProfitForCalc = dept.total();

        for (SaveSalaryCommand.LineInput input : command.getLines()) {
            User user = userRepository.findById(input.getUserId())
                    .orElseThrow(() -> new IllegalArgumentException("Nhân viên không tồn tại: " + input.getUserId()));

            LeadKpiEmployee kpi = kpiByUser.get(user.getId());
            // Nguồn sự thật: cấp bậc → scheme, hồ sơ → lương CB, KPI dẫn cùng kỳ → % / hệ số
            String scheme = SalaryCommissionRules.schemeFromLevelCode(user.getLevelCode());
            boolean override = false;

            BigDecimal baseSalary = user.getBaseSalary() != null ? user.getBaseSalary() : BigDecimal.ZERO;
            BigDecimal kpiPercent = kpiPercentOf(kpi);
            BigDecimal coefficient = coefficientOf(kpi);

            BigDecimal newKpi = SalaryCommissionRules.nz(input.getNewKpiVnd());
            BigDecimal oldKpi = SalaryCommissionRules.nz(input.getOldKpiVnd());

            ProfitBuckets personal = byAssignee.getOrDefault(user.getId(), new ProfitBuckets());
            BigDecimal newActual;
            BigDecimal oldActual;
            if (SalaryCommissionRules.usesDepartmentProfit(scheme)) {
                newActual = dept.newVnd;
                oldActual = dept.oldVnd;
            } else {
                newActual = personal.newVnd;
                oldActual = personal.oldVnd;
            }

            BigDecimal payout = SalaryCommissionRules.calcBasePayout(baseSalary, kpiPercent, coefficient);
            BigDecimal commission = SalaryCommissionRules.calcCommission(
                    scheme,
                    newActual, newKpi,
                    oldActual, oldKpi,
                    deptProfitForCalc, dept.newVnd, dept.oldVnd);

            SalaryLine line = new SalaryLine()
                    .setPeriod(periodEntity)
                    .setUser(user)
                    .setScheme(scheme)
                    .setBaseSalary(baseSalary)
                    .setKpiPercent(kpiPercent)
                    .setCoefficient(coefficient)
                    .setNewKpiVnd(newKpi)
                    .setOldKpiVnd(oldKpi)
                    .setNewActualVnd(newActual)
                    .setOldActualVnd(oldActual)
                    .setActualIsOverride(override)
                    .setPayoutVnd(payout)
                    .setCommissionVnd(commission)
                    .setTotalVnd(payout.add(commission))
                    .setCreatedAt(now)
                    .setUpdatedAt(now);
            line = salaryLineRepository.save(line);

            if (!override) {
                List<CustomerOrder> userOrders = ordersByAssignee.getOrDefault(user.getId(), List.of());
                for (CustomerOrder order : userOrders) {
                    SalaryOrder so = new SalaryOrder()
                            .setSalaryLine(line)
                            .setOrder(order)
                            .setCustomer(order.getCustomer())
                            .setCustomerKind(resolveKind(order))
                            .setNetProfitVnd(SalaryCommissionRules.nz(order.getNetProfitVnd()))
                            .setHandedOverAt(order.getDocumentHandedOverAt())
                            .setAssignee(order.getAssignee())
                            .setCreatedAt(now);
                    salaryOrderRepository.save(so);
                }
            }
        }

        List<SalaryLine> lines = salaryLineRepository.findByPeriodId(periodEntity.getId()).stream()
                .filter(line -> line.getUser() != null && scope.allows(line.getUser().getId()))
                .toList();
        return toPeriodDTO(periodEntity, lines, true, false, scope);
    }

    @Override
    @Transactional
    public SalaryPeriodDTO lock(String period, Long actorId, Long saleRoomId) {
        String normalized = normalizePeriod(period);
        SalaryScopeResolver.Scope scope = salaryScopeResolver.resolve(actorId, saleRoomId);
        SalaryPeriod periodEntity = salaryPeriodRepository.findByPeriod(normalized)
                .orElseThrow(() -> new IllegalArgumentException("Kỳ lương chưa được lưu"));
        List<SalaryLine> lines = salaryLineRepository.findByPeriodId(periodEntity.getId()).stream()
                .filter(line -> line.getUser() != null && scope.allows(line.getUser().getId()))
                .toList();
        if (lines.isEmpty()) {
            throw new IllegalArgumentException("Kỳ lương chưa có dòng lương trong phạm vi để khóa");
        }
        if (periodEntity.isLocked()) {
            return toPeriodDTO(periodEntity, lines, true, false, scope);
        }

        // Chốt snapshot KPI dẫn + lương CB + scheme trước khi khóa
        Map<Long, LeadKpiEmployee> kpiByUser = loadKpiByUser(normalized);
        List<CustomerOrder> eligible = filterEligible(
                customerOrderRepository.findSalaryEligibleByPeriod(normalized), scope);
        ProfitBuckets dept = sumDept(eligible);
        BigDecimal deptProfitForCalc = dept.total();
        for (SalaryLine line : lines) {
            if (line.getUser() == null) {
                continue;
            }
            User user = line.getUser();
            LeadKpiEmployee kpi = kpiByUser.get(user.getId());
            String scheme = SalaryCommissionRules.schemeFromLevelCode(user.getLevelCode());
            BigDecimal baseSalary = user.getBaseSalary() != null ? user.getBaseSalary() : BigDecimal.ZERO;
            BigDecimal kpiPercent = kpiPercentOf(kpi);
            BigDecimal coefficient = coefficientOf(kpi);
            BigDecimal newActual = SalaryCommissionRules.usesDepartmentProfit(scheme) ? dept.newVnd
                    : SalaryCommissionRules.nz(line.getNewActualVnd());
            BigDecimal oldActual = SalaryCommissionRules.usesDepartmentProfit(scheme) ? dept.oldVnd
                    : SalaryCommissionRules.nz(line.getOldActualVnd());
            if (!Boolean.TRUE.equals(line.getActualIsOverride())
                    && !SalaryCommissionRules.usesDepartmentProfit(scheme)) {
                ProfitBuckets personal = sumByAssignee(eligible).getOrDefault(user.getId(), new ProfitBuckets());
                newActual = personal.newVnd;
                oldActual = personal.oldVnd;
            }
            BigDecimal payout = SalaryCommissionRules.calcBasePayout(baseSalary, kpiPercent, coefficient);
            BigDecimal commission = SalaryCommissionRules.calcCommission(
                    scheme,
                    newActual, SalaryCommissionRules.nz(line.getNewKpiVnd()),
                    oldActual, SalaryCommissionRules.nz(line.getOldKpiVnd()),
                    deptProfitForCalc, dept.newVnd, dept.oldVnd);
            line.setScheme(scheme)
                    .setBaseSalary(baseSalary)
                    .setKpiPercent(kpiPercent)
                    .setCoefficient(coefficient)
                    .setNewActualVnd(newActual)
                    .setOldActualVnd(oldActual)
                    .setPayoutVnd(payout)
                    .setCommissionVnd(commission)
                    .setTotalVnd(payout.add(commission))
                    .setUpdatedAt(LocalDateTime.now());
            salaryLineRepository.save(line);
        }

        User locker = actorId == null ? null : userRepository.findById(actorId).orElse(null);
        periodEntity.setStatus(SalaryPeriod.STATUS_LOCKED);
        periodEntity.setLockedAt(LocalDateTime.now());
        periodEntity.setLockedBy(locker);
        periodEntity.setUpdatedAt(LocalDateTime.now());
        periodEntity = salaryPeriodRepository.save(periodEntity);
        lines = salaryLineRepository.findByPeriodId(periodEntity.getId()).stream()
                .filter(line -> line.getUser() != null && scope.allows(line.getUser().getId()))
                .toList();
        return toPeriodDTO(periodEntity, lines, true, false, scope);
    }

    @Override
    @Transactional
    public SalaryPeriodDTO unlock(String period, Long actorId, Long saleRoomId) {
        String normalized = normalizePeriod(period);
        SalaryPeriod periodEntity = salaryPeriodRepository.findByPeriod(normalized)
                .orElseThrow(() -> new IllegalArgumentException("Kỳ lương chưa được lưu"));
        if (!periodEntity.isLocked()) {
            return getOrPreview(normalized, actorId, saleRoomId);
        }
        periodEntity.setStatus(SalaryPeriod.STATUS_DRAFT);
        periodEntity.setLockedAt(null);
        periodEntity.setLockedBy(null);
        periodEntity.setUpdatedAt(LocalDateTime.now());
        salaryPeriodRepository.save(periodEntity);
        return getOrPreview(normalized, actorId, saleRoomId);
    }

    private SalaryPeriodDTO toPeriodDTO(
            SalaryPeriod period,
            List<SalaryLine> lines,
            boolean includeOrders,
            boolean preview,
            SalaryScopeResolver.Scope scope
    ) {
        List<CustomerOrder> eligible = filterEligible(
                customerOrderRepository.findSalaryEligibleByPeriod(period.getPeriod()), scope);
        ProfitBuckets dept = sumDept(eligible);

        SalaryPeriodDTO dto = new SalaryPeriodDTO();
        dto.setId(period.getId());
        dto.setPeriod(period.getPeriod());
        dto.setStatus(period.getStatus());
        dto.setDeptProfitOverrideVnd(null);
        dto.setDeptNewActualVnd(dept.newVnd);
        dto.setDeptOldActualVnd(dept.oldVnd);
        dto.setDeptProfitVnd(dept.total());
        dto.setLockedAt(format(period.getLockedAt()));
        if (period.getLockedBy() != null) {
            dto.setLockedById(period.getLockedBy().getId());
            dto.setLockedByName(period.getLockedBy().getFullName());
        }
        dto.setPreview(preview);
        applyScopeMeta(dto, scope);
        dto.setCreatedAt(format(period.getCreatedAt()));
        dto.setUpdatedAt(format(period.getUpdatedAt()));

        Map<Long, LeadKpiEmployee> kpiByUser = period.isLocked()
                ? Map.of()
                : loadKpiByUser(period.getPeriod());
        BigDecimal deptProfitForCalc = dto.getDeptProfitVnd() != null ? dto.getDeptProfitVnd() : dept.total();

        List<SalaryLineDTO> lineDtos = new ArrayList<>();
        for (SalaryLine line : lines) {
            SalaryLineDTO lineDto = toLineDTO(line);
            if (!period.isLocked() && line.getUser() != null) {
                applyLiveSources(lineDto, line.getUser(), kpiByUser.get(line.getUser().getId()), dept, deptProfitForCalc);
            }
            if (includeOrders && line.getId() != null) {
                lineDto.setOrders(salaryOrderRepository.findByLineId(line.getId()).stream()
                        .map(this::toOrderDTO)
                        .toList());
            }
            lineDtos.add(lineDto);
        }
        dto.setLines(lineDtos);
        return dto;
    }

    /** Khi chưa khóa: luôn lấy %KPI/hệ số từ KPI dẫn, lương CB + cơ chế từ hồ sơ/cấp bậc. */
    private void applyLiveSources(
            SalaryLineDTO dto,
            User user,
            LeadKpiEmployee kpi,
            ProfitBuckets dept,
            BigDecimal deptProfitForCalc
    ) {
        BigDecimal kpiPercent = kpiPercentOf(kpi);
        BigDecimal coefficient = coefficientOf(kpi);
        BigDecimal baseSalary = user.getBaseSalary() != null ? user.getBaseSalary() : BigDecimal.ZERO;
        String scheme = SalaryCommissionRules.schemeFromLevelCode(user.getLevelCode());

        dto.setKpiPercent(kpiPercent);
        dto.setCoefficient(coefficient);
        dto.setBaseSalary(baseSalary);
        dto.setScheme(scheme);

        boolean deptScheme = SalaryCommissionRules.usesDepartmentProfit(scheme);
        if (!Boolean.TRUE.equals(dto.getActualIsOverride())) {
            if (deptScheme) {
                dto.setNewActualVnd(dept.newVnd);
                dto.setOldActualVnd(dept.oldVnd);
            }
        }

        BigDecimal newActual = SalaryCommissionRules.nz(dto.getNewActualVnd());
        BigDecimal oldActual = SalaryCommissionRules.nz(dto.getOldActualVnd());
        BigDecimal newKpi = SalaryCommissionRules.nz(dto.getNewKpiVnd());
        BigDecimal oldKpi = SalaryCommissionRules.nz(dto.getOldKpiVnd());
        BigDecimal payout = SalaryCommissionRules.calcBasePayout(baseSalary, kpiPercent, coefficient);
        BigDecimal commission = SalaryCommissionRules.calcCommission(
                scheme,
                newActual, newKpi,
                oldActual, oldKpi,
                deptProfitForCalc, dept.newVnd, dept.oldVnd);
        dto.setPayoutVnd(payout);
        dto.setCommissionVnd(commission);
        dto.setTotalVnd(payout.add(commission));
    }

    private static BigDecimal kpiPercentOf(LeadKpiEmployee kpi) {
        return kpi != null && kpi.getTotalPercent() != null ? kpi.getTotalPercent() : BigDecimal.ZERO;
    }

    private static BigDecimal coefficientOf(LeadKpiEmployee kpi) {
        return kpi != null && kpi.getCoefficient() != null ? kpi.getCoefficient() : BigDecimal.ONE;
    }

    private static void applyScopeMeta(SalaryPeriodDTO dto, SalaryScopeResolver.Scope scope) {
        dto.setCanViewAllRooms(scope.canViewAllRooms());
        dto.setScopedSaleRoomId(scope.scopedSaleRoomId());
        dto.setScopedSaleRoomName(scope.scopedSaleRoomName());
        dto.setScopeMessage(scope.emptyReason());
    }

    private static List<CustomerOrder> filterEligible(List<CustomerOrder> orders, SalaryScopeResolver.Scope scope) {
        if (scope.allowedUserIds().isEmpty()) {
            return List.of();
        }
        return orders.stream()
                .filter(order -> order.getAssignee() != null
                        && scope.allows(order.getAssignee().getId()))
                .toList();
    }

    private SalaryLineDTO toLineDTO(SalaryLine line) {
        SalaryLineDTO dto = new SalaryLineDTO();
        dto.setId(line.getId());
        if (line.getUser() != null) {
            dto.setUserId(line.getUser().getId());
            dto.setUserName(line.getUser().getFullName());
            applyUserRoom(dto, line.getUser());
        }
        dto.setScheme(line.getScheme());
        dto.setBaseSalary(line.getBaseSalary());
        dto.setKpiPercent(line.getKpiPercent());
        dto.setCoefficient(line.getCoefficient());
        dto.setNewKpiVnd(line.getNewKpiVnd());
        dto.setOldKpiVnd(line.getOldKpiVnd());
        dto.setNewActualVnd(line.getNewActualVnd());
        dto.setOldActualVnd(line.getOldActualVnd());
        dto.setActualIsOverride(line.getActualIsOverride());
        dto.setPayoutVnd(line.getPayoutVnd());
        dto.setCommissionVnd(line.getCommissionVnd());
        dto.setTotalVnd(line.getTotalVnd());
        dto.setCreatedAt(format(line.getCreatedAt()));
        dto.setUpdatedAt(format(line.getUpdatedAt()));
        return dto;
    }

    private static void applyUserRoom(SalaryLineDTO dto, User user) {
        if (user.getSaleRoom() != null) {
            dto.setSaleRoomId(user.getSaleRoom().getId());
            dto.setSaleRoomName(user.getSaleRoom().getName());
        }
    }

    private SalaryOrderDTO toOrderDTO(SalaryOrder so) {
        SalaryOrderDTO dto = new SalaryOrderDTO();
        dto.setId(so.getId());
        if (so.getOrder() != null) {
            dto.setOrderId(so.getOrder().getId());
            dto.setOrderCode(so.getOrder().getOrderCode());
        }
        if (so.getCustomer() != null) {
            dto.setCustomerId(so.getCustomer().getId());
            dto.setCustomerName(so.getCustomer().getFullName());
        }
        dto.setCustomerKind(so.getCustomerKind());
        dto.setNetProfitVnd(so.getNetProfitVnd());
        dto.setHandedOverAt(format(so.getHandedOverAt()));
        if (so.getAssignee() != null) {
            dto.setAssigneeId(so.getAssignee().getId());
            dto.setAssigneeName(so.getAssignee().getFullName());
        }
        dto.setCreatedAt(format(so.getCreatedAt()));
        return dto;
    }

    private Map<Long, LeadKpiEmployee> loadKpiByUser(String period) {
        return leadKpiPeriodRepository.findByPeriod(period)
                .map(p -> leadKpiEmployeeRepository.findByPeriodId(p.getId()).stream()
                        .filter(e -> e.getUser() != null && e.getUser().getId() != null)
                        .collect(Collectors.toMap(e -> e.getUser().getId(), e -> e, (a, b) -> a)))
                .orElseGet(Map::of);
    }

    private static ProfitBuckets sumDept(List<CustomerOrder> orders) {
        ProfitBuckets buckets = new ProfitBuckets();
        for (CustomerOrder order : orders) {
            buckets.add(resolveKind(order), SalaryCommissionRules.nz(order.getNetProfitVnd()));
        }
        return buckets;
    }

    private static Map<Long, ProfitBuckets> sumByAssignee(List<CustomerOrder> orders) {
        Map<Long, ProfitBuckets> map = new HashMap<>();
        for (CustomerOrder order : orders) {
            if (order.getAssignee() == null || order.getAssignee().getId() == null) {
                continue;
            }
            map.computeIfAbsent(order.getAssignee().getId(), id -> new ProfitBuckets())
                    .add(resolveKind(order), SalaryCommissionRules.nz(order.getNetProfitVnd()));
        }
        return map;
    }

    /**
     * Lợi nhuận đơn mới gắn với Marketing: order.leadId → lead.createdBy (chỉ NEW).
     */
    private Map<Long, ProfitBuckets> sumByMarketingLeadCreator(List<CustomerOrder> orders) {
        Set<Long> leadIds = orders.stream()
                .map(CustomerOrder::getLeadId)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        if (leadIds.isEmpty()) {
            return Map.of();
        }
        Map<Long, MarketingLead> leadsById = marketingLeadRepository.findByIds(leadIds).stream()
                .filter(lead -> lead.getId() != null)
                .collect(Collectors.toMap(MarketingLead::getId, lead -> lead, (a, b) -> a));

        Map<Long, ProfitBuckets> map = new HashMap<>();
        for (CustomerOrder order : orders) {
            if (order.getLeadId() == null) {
                continue;
            }
            if (!SalaryCustomerKindRules.NEW.equalsIgnoreCase(resolveKind(order))) {
                continue;
            }
            MarketingLead lead = leadsById.get(order.getLeadId());
            if (lead == null || lead.getCreatedBy() == null || lead.getCreatedBy().getId() == null) {
                continue;
            }
            map.computeIfAbsent(lead.getCreatedBy().getId(), id -> new ProfitBuckets())
                    .add(SalaryCustomerKindRules.NEW, SalaryCommissionRules.nz(order.getNetProfitVnd()));
        }
        return map;
    }

    private static Map<Long, List<CustomerOrder>> groupOrdersByAssignee(List<CustomerOrder> orders) {
        Map<Long, List<CustomerOrder>> map = new HashMap<>();
        for (CustomerOrder order : orders) {
            if (order.getAssignee() == null || order.getAssignee().getId() == null) {
                continue;
            }
            map.computeIfAbsent(order.getAssignee().getId(), id -> new ArrayList<>()).add(order);
        }
        return map;
    }

    private static String resolveKind(CustomerOrder order) {
        String kind = order.getSalaryCustomerKind();
        if (kind == null || kind.isBlank()) {
            return SalaryCustomerKindRules.NEW;
        }
        return kind.trim().toUpperCase(Locale.ROOT);
    }

    private static String normalizePeriod(String period) {
        if (period == null || period.isBlank()) {
            return LocalDateTime.now().format(PERIOD_FMT);
        }
        String trimmed = period.trim();
        if (!trimmed.matches("\\d{4}-\\d{2}")) {
            throw new IllegalArgumentException("Kỳ lương phải có dạng YYYY-MM");
        }
        return trimmed;
    }

    private static String format(LocalDateTime value) {
        return value == null ? null : value.format(ISO);
    }

    private static final class ProfitBuckets {
        BigDecimal newVnd = BigDecimal.ZERO;
        BigDecimal oldVnd = BigDecimal.ZERO;

        void add(String kind, BigDecimal amount) {
            if (SalaryCustomerKindRules.OLD.equalsIgnoreCase(kind)) {
                oldVnd = oldVnd.add(amount);
            } else {
                newVnd = newVnd.add(amount);
            }
        }

        BigDecimal total() {
            return newVnd.add(oldVnd);
        }
    }
}
