package com.xxxx.ddd.application.service.saleroom;

import com.xxxx.ddd.application.model.SaleRoomDTO;
import com.xxxx.ddd.application.model.command.SaveSaleRoomCommand;

import java.util.List;

public interface SaleRoomAppService {
    List<SaleRoomDTO> findAll(Long actorId);

    SaleRoomDTO getById(Long id, Long actorId);

    SaleRoomDTO create(SaveSaleRoomCommand command, Long actorId);

    SaleRoomDTO update(Long id, SaveSaleRoomCommand command, Long actorId);

    void delete(Long id, Long actorId);
}
