package com.xxxx.ddd.application.service.saleroom.impl;

import com.xxxx.ddd.application.model.SaleRoomDTO;
import com.xxxx.ddd.application.model.command.SaveSaleRoomCommand;
import com.xxxx.ddd.application.service.saleroom.SaleRoomAppService;
import com.xxxx.ddd.domain.model.entity.SaleRoom;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.SaleRoomDomainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Service
public class SaleRoomAppServiceImpl implements SaleRoomAppService {

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    @Autowired
    private SaleRoomDomainService saleRoomDomainService;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public List<SaleRoomDTO> findAll(Long actorId) {
        User actor = requireActor(actorId);
        Long scopedRoomId = isSaleManager(actor) ? requireOwnRoomId(actor) : null;
        return saleRoomDomainService.findAll().stream()
                .filter(room -> scopedRoomId == null || scopedRoomId.equals(room.getId()))
                .map(this::toDTO).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public SaleRoomDTO getById(Long id, Long actorId) {
        requireRoomAccess(requireActor(actorId), id);
        return toDTO(saleRoomDomainService.getById(id));
    }

    @Override
    @Transactional
    public SaleRoomDTO create(SaveSaleRoomCommand command, Long actorId) {
        requireGlobalManager(requireActor(actorId));
        SaleRoom room = new SaleRoom()
                .setCode(command.getCode())
                .setName(command.getName())
                .setDescription(command.getDescription())
                .setActive(command.getActive());
        SaleRoom saved = saleRoomDomainService.create(
                room,
                command.getLeaderId(),
                command.getMemberIds() == null ? new HashSet<>() : new HashSet<>(command.getMemberIds()));
        return toDTO(saved);
    }

    @Override
    @Transactional
    public SaleRoomDTO update(Long id, SaveSaleRoomCommand command, Long actorId) {
        User actor = requireActor(actorId);
        if (isSaleManager(actor)) {
            requireRoomAccess(actor, id);
            validateManagerUpdate(actor, id, command);
        } else {
            requireGlobalManager(actor);
        }
        SaleRoom patch = new SaleRoom()
                .setCode(command.getCode())
                .setName(command.getName())
                .setDescription(command.getDescription())
                .setActive(command.getActive());
        SaleRoom updated = saleRoomDomainService.update(
                id,
                patch,
                command.getLeaderId(),
                command.getMemberIds() == null ? null : new HashSet<>(command.getMemberIds()));
        return toDTO(updated);
    }

    @Override
    @Transactional
    public void delete(Long id, Long actorId) {
        requireGlobalManager(requireActor(actorId));
        saleRoomDomainService.delete(id);
    }

    private User requireActor(Long actorId) {
        return userRepository.findByIdWithAuth(actorId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy người dùng"));
    }

    private static boolean isSaleManager(User actor) {
        return "sale".equalsIgnoreCase(actor.getRoleCode())
                && "manager".equalsIgnoreCase(actor.getLevelCode());
    }

    private static boolean isGlobalManager(User actor) {
        return actor.getRole() != null && actor.getRole().isAdmin()
                || "sale".equalsIgnoreCase(actor.getRoleCode())
                    && "director".equalsIgnoreCase(actor.getLevelCode())
                || actor.getEffectivePermissions().stream()
                    .anyMatch(permission -> "grant_role".equalsIgnoreCase(permission.getCode()));
    }

    private static void requireGlobalManager(User actor) {
        if (isSaleManager(actor) || !isGlobalManager(actor)) {
            throw new IllegalArgumentException("Chỉ Admin hoặc Sale Director được tạo/xóa phòng Sale");
        }
    }

    private static Long requireOwnRoomId(User actor) {
        if (actor.getSaleRoom() == null) {
            throw new IllegalArgumentException("Sale Manager chưa được gán phòng Sale");
        }
        return actor.getSaleRoom().getId();
    }

    private static void requireRoomAccess(User actor, Long roomId) {
        if (isSaleManager(actor) && !Objects.equals(requireOwnRoomId(actor), roomId)) {
            throw new IllegalArgumentException("Bạn chỉ được quản lý phòng Sale của mình");
        }
    }

    private void validateManagerUpdate(User actor, Long roomId, SaveSaleRoomCommand command) {
        SaleRoom room = saleRoomDomainService.getById(roomId);
        Long currentLeaderId = room.getLeader() == null ? null : room.getLeader().getId();
        if (!Objects.equals(command.getLeaderId(), currentLeaderId)) {
            throw new IllegalArgumentException("Sale Manager không được thay đổi trưởng phòng");
        }
        List<Long> memberIds = command.getMemberIds();
        if (memberIds == null) return;
        if (!memberIds.contains(actor.getId())
                || currentLeaderId != null && !memberIds.contains(currentLeaderId)) {
            throw new IllegalArgumentException("Không được gỡ Sale Manager hoặc trưởng phòng khỏi phòng của mình");
        }
        for (Long memberId : memberIds) {
            User member = userRepository.findByIdWithAuth(memberId)
                    .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy nhân viên " + memberId));
            Long existingRoomId = member.getSaleRoom() == null ? null : member.getSaleRoom().getId();
            if (existingRoomId != null && !roomId.equals(existingRoomId)) {
                throw new IllegalArgumentException("Không được chuyển nhân viên từ phòng Sale khác");
            }
            if (member.getRole() == null || !member.getRole().isSale()) {
                throw new IllegalArgumentException("Chỉ nhân viên Sale được vào phòng Sale");
            }
        }
    }

    private SaleRoomDTO toDTO(SaleRoom room) {
        SaleRoomDTO dto = new SaleRoomDTO();
        dto.setId(room.getId());
        dto.setCode(room.getCode());
        dto.setName(room.getName());
        dto.setDescription(room.getDescription());
        if (room.getLeader() != null) {
            dto.setLeaderId(room.getLeader().getId());
            dto.setLeaderName(room.getLeader().getFullName());
        }
        dto.setMemberIds(userRepository.findBySaleRoomId(room.getId()).stream().map(User::getId).toList());
        dto.setActive(room.getActive());
        dto.setCreatedAt(format(room.getCreatedAt()));
        dto.setUpdatedAt(format(room.getUpdatedAt()));
        return dto;
    }

    private static String format(LocalDateTime value) {
        return value == null ? null : value.format(ISO);
    }
}
