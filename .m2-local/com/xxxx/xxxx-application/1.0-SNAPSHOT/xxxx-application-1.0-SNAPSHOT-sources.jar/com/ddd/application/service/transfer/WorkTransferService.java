package com.xxxx.ddd.application.service.transfer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.xxxx.ddd.application.model.command.SendNotificationCommand;
import com.xxxx.ddd.application.service.notification.NotificationAppService;
import com.xxxx.ddd.domain.model.entity.*;
import com.xxxx.ddd.domain.model.workflow.*;
import com.xxxx.ddd.domain.respository.*;
import com.xxxx.ddd.domain.service.AssignmentDomainService;
import com.xxxx.ddd.domain.service.MarketingLeadDomainService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class WorkTransferService {
    private final UserRepository users;
    private final AssignmentRepository assignments;
    private final AssignmentDomainService assignmentService;
    private final MarketingLeadDomainService leadDomainService;
    private final MarketingLeadRepository leads;
    private final CustomerRepository customers;
    private final CustomerOrderRepository orders;
    private final NotificationAppService notifications;
    private final ObjectMapper objectMapper;
    private final EntityManager entityManager;

    public record Selection(AssignmentRefType type, Long id) {}
    public record Group(Long recipientId, List<Selection> selections) {}
    public record Request(Long sourceId, List<Group> groups, List<PreviewItem> expected,
                          boolean confirmActiveSource) {}
    public record InventoryItem(AssignmentRefType type, Long id, String code, String name,
                                Long customerId, String fingerprint) {}
    public record Inventory(Long sourceId, String sourceName, String sourceRole, boolean active,
                            List<InventoryItem> items) {}
    public record Source(Long id, String name, String role, String level, Long roomId,
                         boolean active, boolean deleted) {}
    public record PreviewItem(AssignmentRefType type, Long id, Long recipientId,
                              String fingerprint, boolean linked) {}
    public record Preview(List<PreviewItem> items, Map<AssignmentRefType, Long> counts) {}

    @Transactional(readOnly = true)
    public List<Source> sources(Long actorId) {
        User actor = requireUser(actorId);
        if (!isAdmin(actor) && !Set.of("manager", "director").contains(normalize(actor.getLevelCode()))) {
            throw new IllegalArgumentException("Chỉ Manager/Director hoặc Admin được bàn giao");
        }
        return entityManager.createQuery("SELECT u FROM User u LEFT JOIN FETCH u.role LEFT JOIN FETCH u.saleRoom ORDER BY u.fullName", User.class)
                .getResultList().stream()
                .filter(user -> Set.of("sale", "cskh").contains(normalize(user.getRoleCode())))
                .filter(user -> !isManagerSelf(actor, user))
                .filter(user -> {
                    try { checkScope(actor, user); checkTransferPermission(actor, user.getRoleCode()); return true; }
                    catch (IllegalArgumentException ignored) { return false; }
                })
                .map(user -> new Source(user.getId(), user.getFullName(), user.getRoleCode(),
                        user.getLevelCode(), roomId(user), Boolean.TRUE.equals(user.getActive()) && !Boolean.TRUE.equals(user.getIsDeleted()),
                        Boolean.TRUE.equals(user.getIsDeleted())))
                .toList();
    }

    @Transactional(readOnly = true)
    public Inventory inventory(Long sourceId, Long actorId) {
        User source = requireSource(sourceId);
        User actor = requireUser(actorId);
        if (isManagerSelf(actor, source)) {
            throw new IllegalArgumentException("Manager không thể bàn giao công việc của chính mình");
        }
        checkScope(actor, source);
        checkTransferPermission(actor, source.getRoleCode());
        String role = source.getRoleCode();
        List<InventoryItem> result = new ArrayList<>();
        if ("sale".equalsIgnoreCase(role)) {
            for (Assignment a : assignments.findCurrentByAssignee(AssignmentRefType.MARKETING_LEAD, sourceId)) {
                leads.findByIdActive(a.getRefId()).ifPresent(lead -> result.add(new InventoryItem(
                        AssignmentRefType.MARKETING_LEAD, lead.getId(), lead.getCode(), lead.getFullName(),
                        lead.getCustomer() == null ? null : lead.getCustomer().getId(), fingerprint(a))));
            }
        } else if ("cskh".equalsIgnoreCase(role)) {
            // Việc chăm sóc CSKH bắt đầu từ phân công CUSTOMER, không phải TASK của luồng Data.
            for (Customer customer : customers.findAllActive()) {
                if (sameUser(customer.getCustomerCareStaff(), sourceId)) {
                    result.add(new InventoryItem(AssignmentRefType.CUSTOMER, customer.getId(),
                            customer.getCode(), customer.getFullName(), customer.getId(),
                            customerFingerprint(customer)));
                }
            }
        } else {
            throw new IllegalArgumentException("Chỉ hỗ trợ bàn giao Sales hoặc CSKH");
        }
        result.sort(Comparator.comparing((InventoryItem i) -> i.type().ordinal()).thenComparing(InventoryItem::id));
        return new Inventory(sourceId, source.getFullName(), role,
                Boolean.TRUE.equals(source.getActive()) && !Boolean.TRUE.equals(source.getIsDeleted()), result);
    }

    @Transactional(readOnly = true)
    public Preview preview(Request request, Long actorId) {
        return buildPreview(request, actorId);
    }

    @Transactional
    public Preview commit(Request request, Long actorId) {
        if (request.expected() == null || request.expected().isEmpty()) {
            throw new IllegalArgumentException("Cần xem trước trước khi xác nhận bàn giao");
        }
        // Khoá các bản ghi nghiệp vụ theo thứ tự cố định trước khi so khớp ảnh chụp.
        List<Selection> keys = request.expected().stream().map(i -> new Selection(i.type(), i.id()))
                .distinct().sorted(Comparator.comparing((Selection s) -> s.type().ordinal()).thenComparing(Selection::id))
                .toList();
        for (Selection key : keys) {
            Class<?> entityType = switch (key.type()) {
                case MARKETING_LEAD, TASK -> MarketingLead.class;
                case CUSTOMER -> Customer.class;
                case ORDER -> CustomerOrder.class;
            };
            Object entity = entityManager.find(entityType, key.id(), LockModeType.PESSIMISTIC_WRITE);
            if (entity == null) throw new IllegalArgumentException("Hồ sơ đã bị xóa; vui lòng xem trước lại");
        }
        Preview fresh = buildPreview(request, actorId);
        if (!fresh.items().equals(request.expected())) {
            throw new IllegalArgumentException("Phân việc đã thay đổi; vui lòng xem trước lại trước khi lưu");
        }
        User source = requireSource(request.sourceId());
        if (Boolean.TRUE.equals(source.getActive()) && !Boolean.TRUE.equals(source.getIsDeleted())
                && !request.confirmActiveSource()) {
            throw new IllegalArgumentException("Tài khoản nguồn còn hoạt động; cần xác nhận bàn giao");
        }
        for (PreviewItem item : fresh.items()) {
            String note = "Bàn giao hàng loạt từ " + source.getFullName();
            switch (item.type()) {
                case MARKETING_LEAD, TASK -> {
                    assignmentService.assign(item.type(), item.id(), item.recipientId(), actorId, note);
                    assignmentService.accept(item.type(), item.id(), item.recipientId());
                    leadDomainService.markAccepted(item.id(), item.type() == AssignmentRefType.TASK);
                }
                case CUSTOMER -> {
                    assignWithHistory(AssignmentRefType.CUSTOMER, item.id(), item.recipientId(), actorId, source, note);
                    Customer customer = customers.findByIdActive(item.id()).orElseThrow();
                    customer.setCustomerCareStaff(requireUser(item.recipientId()));
                    customers.save(customer);
                }
                case ORDER -> {
                    assignWithHistory(AssignmentRefType.ORDER, item.id(), item.recipientId(), actorId, source, note);
                    CustomerOrder order = orders.findByIdActive(item.id()).orElseThrow();
                    order.setAssignee(requireUser(item.recipientId()));
                    orders.save(order);
                }
            }
        }
        Map<Long, Long> byRecipient = fresh.items().stream().collect(Collectors.groupingBy(
                PreviewItem::recipientId, Collectors.counting()));
        List<SendNotificationCommand> messages = new ArrayList<>();
        for (Map.Entry<Long, Long> recipient : byRecipient.entrySet()) {
            boolean saleTransfer = "sale".equalsIgnoreCase(source.getRoleCode());
            Long highlightedId = fresh.items().stream()
                    .filter(item -> item.recipientId().equals(recipient.getKey())
                            && (saleTransfer
                            ? item.type() == AssignmentRefType.MARKETING_LEAD || item.type() == AssignmentRefType.TASK
                            : item.type() == AssignmentRefType.CUSTOMER))
                    .map(PreviewItem::id).findFirst().orElse(null);
            String link = (saleTransfer ? "/data" : "/customers") + "?transfer=1"
                    + (highlightedId == null ? "" : "&highlightId=" + highlightedId);
            messages.add(new SendNotificationCommand().setRecipientId(recipient.getKey()).setActorId(actorId)
                    .setType(NotificationType.TASK_ASSIGNED).setTitle("Bạn được bàn giao công việc")
                    .setBody("Bạn nhận " + recipient.getValue() + " hồ sơ từ " + source.getFullName())
                    .setLink(link)
                    .setSendEmail(false).setSendRealtime(true));
        }
        // NotificationAppService ghi cùng transaction và tự hoãn realtime đến sau commit.
        notifications.sendAll(messages);
        return fresh;
    }

    private Preview buildPreview(Request request, Long actorId) {
        if (request == null || request.sourceId() == null || request.groups() == null || request.groups().isEmpty()) {
            throw new IllegalArgumentException("Chưa chọn nhân viên nguồn hoặc nhóm bàn giao");
        }
        Inventory inventory = inventory(request.sourceId(), actorId);
        User actor = requireUser(actorId);
        User source = requireSource(request.sourceId());
        Map<Selection, InventoryItem> available = inventory.items().stream().collect(Collectors.toMap(
                i -> new Selection(i.type(), i.id()), i -> i));
        Map<Long, List<InventoryItem>> openOrdersByCustomer = new HashMap<>();
        if ("cskh".equalsIgnoreCase(source.getRoleCode())) {
            for (CustomerOrder order : orders.findAllActive()) {
                if (!sameUser(order.getAssignee(), source.getId()) || !openOrder(order)) continue;
                Long customerId = order.getCustomer().getId();
                openOrdersByCustomer.computeIfAbsent(customerId, ignored -> new ArrayList<>()).add(
                        new InventoryItem(AssignmentRefType.ORDER, order.getId(), order.getOrderCode(),
                                order.getCustomer().getFullName(), customerId, orderFingerprint(order)));
            }
        }
        Map<Selection, PreviewItem> mapped = new LinkedHashMap<>();
        for (Group group : request.groups()) {
            if (group == null || group.recipientId() == null || group.selections() == null || group.selections().isEmpty()) {
                throw new IllegalArgumentException("Mỗi nhóm cần người nhận và ít nhất một hồ sơ");
            }
            User recipient = requireUser(group.recipientId());
            if (recipient.getId().equals(source.getId()) || Boolean.FALSE.equals(recipient.getActive())
                    || Boolean.TRUE.equals(recipient.getIsDeleted())) {
                throw new IllegalArgumentException("Người nhận không hợp lệ hoặc đã bị khóa");
            }
            if (!Objects.equals(source.getRoleCode(), recipient.getRoleCode())) {
                throw new IllegalArgumentException("Người nhận phải cùng bộ phận Sales/CSKH với nhân viên nguồn");
            }
            checkScope(actor, recipient);
            if (!isAdmin(actor) && "manager".equalsIgnoreCase(actor.getLevelCode())
                    && "sale".equalsIgnoreCase(source.getRoleCode())
                    && !Set.of("executive", "senior").contains(normalize(recipient.getLevelCode()))) {
                throw new IllegalArgumentException("Sales Manager chỉ giao cho Executive/Senior trong phòng mình");
            }
            for (Selection selected : group.selections()) {
                InventoryItem base = available.get(selected);
                if (base == null) throw new IllegalArgumentException("Hồ sơ không còn thuộc nhân viên nguồn: " + selected);
                add(mapped, base, recipient.getId(), false);
                if (selected.type() == AssignmentRefType.CUSTOMER) {
                    // Chỉ chọn khách hàng; đơn còn mở đang do CSKH cũ phụ trách tự đi cùng.
                    for (InventoryItem linked : openOrdersByCustomer.getOrDefault(base.id(), List.of())) {
                        add(mapped, linked, recipient.getId(), true);
                    }
                }
            }
        }
        List<PreviewItem> items = mapped.values().stream().sorted(Comparator
                .comparing((PreviewItem i) -> i.type().ordinal()).thenComparing(PreviewItem::id)).toList();
        Map<AssignmentRefType, Long> counts = items.stream().collect(Collectors.groupingBy(
                PreviewItem::type, () -> new EnumMap<>(AssignmentRefType.class), Collectors.counting()));
        return new Preview(items, counts);
    }

    private static void add(Map<Selection, PreviewItem> mapped, InventoryItem item, Long recipientId, boolean linked) {
        Selection key = new Selection(item.type(), item.id());
        PreviewItem previous = mapped.putIfAbsent(key,
                new PreviewItem(item.type(), item.id(), recipientId, item.fingerprint(), linked));
        if (previous != null && !previous.recipientId().equals(recipientId)) {
            throw new IllegalArgumentException("Một hồ sơ đang được chọn cho hai người nhận khác nhau");
        }
    }

    private void assignWithHistory(AssignmentRefType type, Long id, Long recipientId,
                                   Long actorId, User source, String note) {
        Assignment prior = assignments.findCurrent(type, id).orElse(null);
        Assignment assigned = assignmentService.assign(type, id, recipientId, actorId, note);
        assignmentService.accept(type, id, recipientId);
        if (prior == null || !sameUser(prior.getAssignee(), source.getId())) {
            assignments.save(new Assignment().setRefType(type).setRefId(id).setAssignee(source)
                    .setAssignedBy(requireUser(actorId)).setStatus(AssignmentStatus.REASSIGNED)
                    .setNote("Người phụ trách trước bàn giao hàng loạt")
                    .setAssignedAt(LocalDateTime.now()).setSupersededById(assigned.getId()));
        }
    }

    private User requireUser(Long id) {
        return users.findByIdWithAuth(id).orElseThrow(() -> new IllegalArgumentException("Không tìm thấy tài khoản"));
    }

    private User requireSource(Long id) {
        return users.findById(id).orElseThrow(() -> new IllegalArgumentException("Không tìm thấy tài khoản nguồn"));
    }

    private static void checkScope(User actor, User target) {
        if (isAdmin(actor)) return;
        if (!Objects.equals(actor.getRoleCode(), target.getRoleCode()) && !isSaleDirector(actor)) {
            throw new IllegalArgumentException("Không có quyền bàn giao ngoài bộ phận");
        }
        String level = normalize(actor.getLevelCode());
        if (!level.equals("manager") && !level.equals("director")) {
            throw new IllegalArgumentException("Chỉ Manager/Director hoặc Admin được bàn giao");
        }
        if (level.equals("manager") && !Objects.equals(roomId(actor), roomId(target))) {
            throw new IllegalArgumentException("Manager chỉ bàn giao trong phòng mình");
        }
    }

    private static void checkTransferPermission(User actor, String role) {
        if (isAdmin(actor)) return;
        String required = isSaleDirector(actor) || "sale".equalsIgnoreCase(role)
                ? "bulk_transfer_sale" : "bulk_transfer_cskh";
        boolean permitted = actor.getEffectivePermissions().stream()
                .anyMatch(permission -> required.equalsIgnoreCase(permission.getCode()));
        if (!permitted) throw new IllegalArgumentException("Tài khoản không có quyền phân việc cho bộ phận này");
    }

    private static boolean isAdmin(User user) { return user.getRole() != null && user.getRole().isAdmin(); }
    private static boolean isSaleDirector(User user) {
        return "sale".equals(normalize(user.getRoleCode()))
                && "director".equals(normalize(user.getLevelCode()));
    }
    private static boolean isManagerSelf(User actor, User target) {
        return !isAdmin(actor) && "manager".equals(normalize(actor.getLevelCode()))
                && Objects.equals(actor.getId(), target.getId());
    }
    private static Long roomId(User user) { return user.getSaleRoom() == null ? null : user.getSaleRoom().getId(); }
    private static String normalize(String value) { return value == null ? "" : value.trim().toLowerCase(Locale.ROOT); }
    private static boolean sameUser(User user, Long id) { return user != null && id.equals(user.getId()); }
    private static String fingerprint(Assignment assignment) { return "A:" + assignment.getId(); }
    private static String customerFingerprint(Customer customer) {
        return "C:" + (customer.getCustomerCareStaff() == null ? 0 : customer.getCustomerCareStaff().getId())
                + ":" + (customer.getUpdatedAt() == null ? "" : customer.getUpdatedAt());
    }
    private static String orderFingerprint(CustomerOrder order) {
        return "O:" + (order.getAssignee() == null ? 0 : order.getAssignee().getId())
                + ":" + (order.getUpdatedAt() == null ? "" : order.getUpdatedAt());
    }
    private boolean openOrder(CustomerOrder order) {
        if (order.getDocumentHandedOverAt() == null || order.getPaidAt() == null) return true;
        String json = order.getSaleOverlayJson();
        if (json == null || json.isBlank()) return false;
        try {
            JsonNode debt = objectMapper.readTree(json).path("utvcDebtVnd");
            return !debt.isMissingNode() && new BigDecimal(debt.asText("0").replace(",", "")).signum() > 0;
        } catch (Exception ignored) {
            // Dữ liệu công nợ không đọc được: giữ hồ sơ trong danh sách để không bỏ sót việc còn mở.
            return true;
        }
    }
}
