package com.xxxx.ddd.application.service.user.impl;

import com.xxxx.ddd.application.mapper.AuthMapper;
import com.xxxx.ddd.application.model.UserDTO;
import com.xxxx.ddd.application.model.UserPageDTO;
import com.xxxx.ddd.application.model.command.ChangePasswordCommand;
import com.xxxx.ddd.application.model.command.CreateUserCommand;
import com.xxxx.ddd.application.model.command.UpdateUserCommand;
import com.xxxx.ddd.application.service.user.UserAppService;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.service.UserDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Slf4j
public class UserAppServiceImpl implements UserAppService {

    public static final String DEFAULT_PASSWORD = "123456";

    @Autowired
    private UserDomainService userDomainService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    @Transactional(readOnly = true)
    public UserPageDTO search(String keyword, int pageNo, int pageSize) {
        int page = pageNo <= 0 ? 1 : pageNo;
        int size = pageSize <= 0 ? 10 : pageSize;
        List<UserDTO> users = userDomainService.search(keyword, page, size).stream()
                .map(AuthMapper::toUserDTO)
                .toList();
        long total = userDomainService.countSearch(keyword);
        UserPageDTO pageDTO = new UserPageDTO();
        pageDTO.setUsers(users);
        pageDTO.setPageNo(page);
        pageDTO.setPageSize(size);
        pageDTO.setTotalElements(total);
        pageDTO.setTotalPages((int) Math.ceil(total / (double) size));
        return pageDTO;
    }

    @Override
    @Transactional(readOnly = true)
    public UserDTO getById(Long id) {
        return AuthMapper.toUserDTO(userDomainService.getById(id));
    }

    @Override
    @Transactional
    public UserDTO create(CreateUserCommand command) {
        String username = command.getUsername();
        if (username != null && username.isBlank()) {
            username = null;
        }
        User user = new User()
                .setFullName(command.getFullName())
                .setUsername(username)
                .setEmail(command.getEmail())
                .setPhone(command.getPhone())
                .setPassword(passwordEncoder.encode(command.getPassword()))
                .setBaseSalary(command.getBaseSalary())
                .setActive(command.getActive() == null || command.getActive());
        User saved = userDomainService.createUser(user, command.getRoleCode(), command.getLevelId(), command.getSaleRoomId());
        return AuthMapper.toUserDTO(saved);
    }

    @Override
    @Transactional
    public UserDTO update(Long id, UpdateUserCommand command) {
        User patch = new User()
                .setFullName(command.getFullName())
                .setUsername(command.getUsername())
                .setEmail(command.getEmail())
                .setPhone(command.getPhone())
                .setBaseSalary(command.getBaseSalary())
                .setActive(command.getActive());
        User updated = userDomainService.updateUser(id, patch, command.getRoleCode(), command.getLevelId(), command.getSaleRoomId());
        return AuthMapper.toUserDTO(updated);
    }

    @Override
    @Transactional
    public UserDTO markLeftCompany(Long actorId, Long employeeId) {
        User actor = userDomainService.getById(actorId);
        User employee = userDomainService.getById(employeeId);
        if (actorId.equals(employeeId)) {
            throw new IllegalArgumentException("Không thể tắt tài khoản của chính mình");
        }
        String actorRole = actor.getRoleCode();
        boolean admin = "admin".equalsIgnoreCase(actorRole);
        boolean director = "sale".equalsIgnoreCase(actorRole) && "director".equalsIgnoreCase(actor.getLevelCode());
        boolean manager = "sale".equalsIgnoreCase(actorRole) && "manager".equalsIgnoreCase(actor.getLevelCode());
        if (!admin && !director && !manager) {
            throw new IllegalArgumentException("Bạn không có quyền cập nhật nhân sự này");
        }
        if (!admin && !"sale".equalsIgnoreCase(employee.getRoleCode())) {
            throw new IllegalArgumentException("Chỉ được cập nhật nhân sự Sale");
        }
        if (manager) {
            if (actor.getSaleRoom() == null || employee.getSaleRoom() == null
                    || !actor.getSaleRoom().getId().equals(employee.getSaleRoom().getId())
                    || "manager".equalsIgnoreCase(employee.getLevelCode())
                    || "director".equalsIgnoreCase(employee.getLevelCode())) {
                throw new IllegalArgumentException("Chỉ được cập nhật nhân viên thuộc phòng mình");
            }
        }
        if (!Boolean.TRUE.equals(employee.getActive())) {
            return AuthMapper.toUserDTO(employee);
        }
        return AuthMapper.toUserDTO(userDomainService.updateUser(employeeId, new User().setActive(false), null, null,
                employee.getSaleRoom() == null ? null : employee.getSaleRoom().getId()));
    }

    @Override
    @Transactional
    public UserDTO updateOwnProfile(Long id, String fullName, String email, String phone) {
        return AuthMapper.toUserDTO(userDomainService.updateOwnProfile(id, fullName, email, phone));
    }

    @Override
    @Transactional
    public void changeOwnPassword(Long id, String currentPassword, String newPassword, String confirmPassword) {
        if (currentPassword == null || currentPassword.isBlank()) {
            throw new IllegalArgumentException("Vui lòng nhập mật khẩu hiện tại");
        }
        if (newPassword == null || newPassword.length() < 6) {
            throw new IllegalArgumentException("Mật khẩu mới phải có ít nhất 6 ký tự");
        }
        if (!newPassword.equals(confirmPassword)) {
            throw new IllegalArgumentException("Xác nhận mật khẩu không khớp");
        }
        User user = userDomainService.getById(id);
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            throw new IllegalArgumentException("Mật khẩu hiện tại không đúng");
        }
        if (passwordEncoder.matches(newPassword, user.getPassword())) {
            throw new IllegalArgumentException("Mật khẩu mới phải khác mật khẩu hiện tại");
        }
        userDomainService.changePassword(id, passwordEncoder.encode(newPassword));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        userDomainService.deactivate(id);
    }

    @Override
    @Transactional
    public void changePassword(ChangePasswordCommand command) {
        if (command.getId() == null) {
            throw new IllegalArgumentException("User id is required");
        }
        if (command.getPassword() == null || command.getPassword().isBlank()) {
            throw new IllegalArgumentException("Password is required");
        }
        if (!command.getPassword().equals(command.getConfirmPassword())) {
            throw new IllegalArgumentException("Password confirmation does not match");
        }
        userDomainService.changePassword(command.getId(), passwordEncoder.encode(command.getPassword()));
    }

    @Override
    @Transactional
    public void resetPassword(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("User id is required");
        }
        userDomainService.getById(id);
        userDomainService.changePassword(id, passwordEncoder.encode(DEFAULT_PASSWORD));
    }
}
