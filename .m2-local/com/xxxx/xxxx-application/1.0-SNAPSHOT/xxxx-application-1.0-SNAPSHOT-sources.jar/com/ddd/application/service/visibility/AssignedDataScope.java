package com.xxxx.ddd.application.service.visibility;

import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.entity.Customer;
import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.entity.Permission;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;
import com.xxxx.ddd.domain.model.workflow.CampaignNamesJson;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.AssignmentDomainService;
import com.xxxx.ddd.domain.service.MarketingLeadDomainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Phạm vi dữ liệu:
 * - Sale Executive / Senior: lead đã giao cho mình hoặc do mình tạo (trừ khi có quyền tổng quan / phân việc).
 * - Marketing (executive/senior): lead tự nhiên do mình tạo; lead Sheets/chiến dịch khác xem chung; Manager/Director xem tất cả.
 * - CSKH (executive/senior): chỉ đơn hàng của khách hàng đang được phân cho mình; Manager / Director CSKH xem tất cả.
 * - Admin và role khác: xem toàn bộ (theo quyền API hiện có).
 */
@Component
public class AssignedDataScope {

    public static final String ASSIGN_TASK_FOR_SALE = "assign_task_for_sale";
    public static final String VIEW_GENERAL_MARKETING = "view_general_data_of_marketing";
    public static final String VIEW_GENERAL_BUSINESS = "view_general_business_results";

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MarketingLeadDomainService marketingLeadDomainService;

    @Autowired
    private AssignmentDomainService assignmentDomainService;

    public boolean shouldRestrictLeads(Long actorId) {
        User actor = actor(actorId);
        if (!isRestrictedSaleStaff(actor)) {
            return false;
        }
        return !hasPermission(actor, ASSIGN_TASK_FOR_SALE)
                && !hasPermission(actor, VIEW_GENERAL_MARKETING);
    }

    /** Marketing non-manager và CSKH Manager chỉ thấy data tự nhiên của mình; data Sheets/chiến dịch khác xem chung. */
    public boolean shouldRestrictMarketingOwnedLeads(Long actorId) {
        User actor = actor(actorId);
        if (actor == null || actor.getRole() == null || actor.getRole().isAdmin()) {
            return false;
        }
        return (isMarketing(actor) && !isManagerOrDirector(actor)) || isCustomerCareManager(actor);
    }

    public boolean isMarketingUser(Long actorId) {
        return isMarketing(actor(actorId));
    }

    public boolean isCustomerCareManager(Long actorId) {
        return isCustomerCareManager(actor(actorId));
    }

    /** Manager chỉ xem Dashboard của phòng mình; admin/director tiếp tục xem toàn bộ. */
    public Long dashboardSaleRoomId(Long actorId) {
        User actor = actor(actorId);
        if (actor == null || actor.getRole() == null || actor.getRole().isAdmin() || !actor.getRole().isSale()
                || actor.getLevelCode() == null || !"manager".equalsIgnoreCase(actor.getLevelCode().trim())) {
            return null;
        }
        // Manager chưa được gán phòng không được rơi về phạm vi toàn hệ thống.
        return actor.getSaleRoom() == null || actor.getSaleRoom().getId() == null ? -1L : actor.getSaleRoom().getId();
    }

    /** Kiểm tra nhân viên được chọn trên Dashboard có nằm trong phạm vi của actor hay không. */
    public Long requireDashboardUser(Long actorId, Long targetUserId) {
        if (targetUserId == null) return null;
        User actor = actor(actorId);
        User target = actor(targetUserId);
        if (actor == null || target == null) throw new IllegalArgumentException("Không tìm thấy nhân viên");
        if (actor.getRole() != null && actor.getRole().isAdmin()) return targetUserId;
        boolean saleManager = actor.getRole() != null && actor.getRole().isSale()
                && "manager".equalsIgnoreCase(actor.getLevelCode());
        boolean sameRoom = saleManager && actor.getSaleRoom() != null && target.getSaleRoom() != null
                && actor.getSaleRoom().getId().equals(target.getSaleRoom().getId());
        if (!sameRoom && !actor.getId().equals(targetUserId)) {
            throw new IllegalArgumentException("Bạn chỉ được xem KPI thực đạt của nhân viên trong phòng mình");
        }
        return targetUserId;
    }

    /** Kiểm soát bộ lọc Sales: Manager chỉ lọc thành viên phòng, Director lọc toàn bộ Sale. */
    public Long requireLeadAssigneeFilter(Long actorId, Long targetUserId) {
        if (targetUserId == null) return null;
        User actor = actor(actorId);
        User target = actor(targetUserId);
        if (actor == null || target == null) throw new IllegalArgumentException("Không tìm thấy nhân viên Sales");
        if (actor.getId().equals(targetUserId)) return targetUserId;
        if (actor.getRole() != null && actor.getRole().isAdmin()) return targetUserId;
        if (actor.getRole() == null || !actor.getRole().isSale()) return targetUserId;
        String level = actor.getLevelCode() == null ? "" : actor.getLevelCode().trim().toLowerCase(Locale.ROOT);
        if ("director".equals(level)) {
            if (target.getRole() == null || !target.getRole().isSale()) {
                throw new IllegalArgumentException("Sales Director chỉ được tìm theo nhân viên Sale");
            }
            return targetUserId;
        }
        if ("manager".equals(level)) {
            boolean sameRoom = actor.getSaleRoom() != null && target.getSaleRoom() != null
                    && actor.getSaleRoom().getId().equals(target.getSaleRoom().getId());
            if (!sameRoom || target.getRole() == null || !target.getRole().isSale()) {
                throw new IllegalArgumentException("Sales Manager chỉ được tìm nhân viên trong phòng mình");
            }
            return targetUserId;
        }
        throw new IllegalArgumentException("Cấp bậc của bạn không được tìm kiếm theo Sales");
    }

    public boolean shouldRestrictOrders(Long actorId) {
        User actor = actor(actorId);
        if (isRestrictedCskhStaff(actor)) {
            return true;
        }
        if (!isRestrictedSaleStaff(actor)) {
            return false;
        }
        return !hasPermission(actor, ASSIGN_TASK_FOR_SALE)
                && !hasPermission(actor, VIEW_GENERAL_BUSINESS);
    }

    public boolean canViewLead(Long actorId, MarketingLead lead, Assignment marketingAssignment, Assignment taskAssignment) {
        User actor = actor(actorId);
        if (isSaleManager(actor)) {
            return isAssignmentInManagerRoom(actor, marketingAssignment);
        }
        if (shouldRestrictMarketingOwnedLeads(actorId)) {
            return !isManualNaturalOnlyLead(lead) || isCreator(lead, actorId);
        }
        if (!shouldRestrictLeads(actorId)) {
            return true;
        }
        return isAssignee(marketingAssignment, actorId);
    }

    public boolean canViewLead(Long actorId, Assignment marketingAssignment, Assignment taskAssignment) {
        User actor = actor(actorId);
        if (isSaleManager(actor)) {
            return isAssignmentInManagerRoom(actor, marketingAssignment);
        }
        if (shouldRestrictMarketingOwnedLeads(actorId)) {
            return false;
        }
        if (!shouldRestrictLeads(actorId)) {
            return true;
        }
        return isAssignee(marketingAssignment, actorId);
    }

    public boolean canViewLead(Long actorId, Long leadId) {
        MarketingLead lead = marketingLeadDomainService.getById(leadId);
        if (shouldRestrictMarketingOwnedLeads(actorId)) {
            return !isManualNaturalOnlyLead(lead) || isCreator(lead, actorId);
        }
        if (!shouldRestrictLeads(actorId)) {
            return true;
        }
        Assignment marketing = assignmentDomainService.findCurrent(AssignmentRefType.MARKETING_LEAD, leadId).orElse(null);
        Assignment task = assignmentDomainService.findCurrent(AssignmentRefType.TASK, leadId).orElse(null);
        return canViewLead(actorId, lead, marketing, task);
    }

    public void requireLead(Long actorId, Long leadId) {
        if (!canViewLead(actorId, leadId)) {
            throw new IllegalArgumentException("Dữ liệu marketing không tồn tại");
        }
    }

    public boolean canViewOrder(Long actorId, CustomerOrder order) {
        if (!shouldRestrictOrders(actorId)) {
            return true;
        }
        if (isRestrictedCskhStaff(actor(actorId))) {
            return isDirectCustomerCareAssignee(actorId, order == null ? null : order.getCustomer());
        }
        return visibleOrder(actorId, order, assignedCustomerIds(actorId));
    }

    public List<CustomerOrder> filterOrders(Long actorId, List<CustomerOrder> orders) {
        if (orders == null || orders.isEmpty() || !shouldRestrictOrders(actorId)) {
            return orders == null ? List.of() : orders;
        }
        if (isRestrictedCskhStaff(actor(actorId))) {
            return orders.stream()
                    .filter(order -> isDirectCustomerCareAssignee(actorId, order.getCustomer()))
                    .toList();
        }
        Set<Long> customerIds = assignedCustomerIds(actorId);
        return orders.stream().filter(order -> visibleOrder(actorId, order, customerIds)).toList();
    }

    public void requireOrder(Long actorId, CustomerOrder order) {
        if (!canViewOrder(actorId, order)) {
            throw new IllegalArgumentException("Đơn hàng không tồn tại");
        }
    }

    /**
     * Id khách hàng trong phạm vi xem đơn của actor.
     * CSKH non-manager: KH của các đơn được giao; Sale restricted: KH từ lead được giao.
     */
    public Set<Long> scopedCustomerIdsForOrders(Long actorId, List<CustomerOrder> allOrders) {
        if (!shouldRestrictOrders(actorId)) {
            return null;
        }
        if (isRestrictedCskhStaff(actor(actorId))) {
            return filterOrders(actorId, allOrders).stream()
                    .filter(order -> order.getCustomer() != null && order.getCustomer().getId() != null)
                    .map(order -> order.getCustomer().getId())
                    .collect(Collectors.toCollection(HashSet::new));
        }
        return assignedCustomerIds(actorId);
    }

    /**
     * CSKH executive/senior can also see a customer assigned directly through
     * customer.customerCareStaff, even when that customer has no assigned order yet.
     */
    public boolean isRestrictedCustomerCareStaff(Long actorId) {
        return isRestrictedCskhStaff(actor(actorId));
    }

    public static boolean isDirectCustomerCareAssignee(Long actorId, Customer customer) {
        return actorId != null
                && customer != null
                && customer.getCustomerCareStaff() != null
                && actorId.equals(customer.getCustomerCareStaff().getId());
    }

    /** Người tạo trực tiếp hồ sơ khách hàng luôn được xem lại hồ sơ đó. */
    public static boolean isCustomerCreator(Long actorId, Customer customer) {
        return actorId != null
                && customer != null
                && customer.getCreatedBy() != null
                && actorId.equals(customer.getCreatedBy().getId());
    }

    public Set<Long> assignedCustomerIds(Long actorId) {
        Set<Long> ids = new HashSet<>();
        if (actorId == null) {
            return ids;
        }
        List<MarketingLead> leads = marketingLeadDomainService.findByStages(List.of());
        if (leads.isEmpty()) {
            return ids;
        }
        List<Long> leadIds = leads.stream().map(MarketingLead::getId).toList();
        Map<Long, Assignment> marketing = assignmentDomainService.findCurrentByRefIds(AssignmentRefType.MARKETING_LEAD, leadIds);
        Map<Long, Assignment> tasks = assignmentDomainService.findCurrentByRefIds(AssignmentRefType.TASK, leadIds);
        for (MarketingLead lead : leads) {
            if (!canViewLead(actorId, lead, marketing.get(lead.getId()), tasks.get(lead.getId()))) {
                continue;
            }
            if (lead.getCustomer() != null && lead.getCustomer().getId() != null) {
                ids.add(lead.getCustomer().getId());
            }
        }
        return ids;
    }

    private static boolean visibleOrder(Long actorId, CustomerOrder order, Set<Long> customerIds) {
        if (isOrderAssignee(order, actorId)) {
            return true;
        }
        return order.getCustomer() != null && customerIds.contains(order.getCustomer().getId());
    }

    private static boolean isOrderAssignee(CustomerOrder order, Long actorId) {
        return actorId != null
                && order != null
                && order.getAssignee() != null
                && actorId.equals(order.getAssignee().getId());
    }

    public static boolean isAssignee(Assignment assignment, Long actorId) {
        return actorId != null
                && assignment != null
                && assignment.getAssignee() != null
                && actorId.equals(assignment.getAssignee().getId());
    }

    private static boolean isCreator(MarketingLead lead, Long actorId) {
        return actorId != null
                && lead != null
                && lead.getCreatedBy() != null
                && actorId.equals(lead.getCreatedBy().getId());
    }

    private static boolean isManualNaturalOnlyLead(MarketingLead lead) {
        return lead != null && CampaignNamesJson.isManualNaturalOnly(lead.getCampaignNames());
    }

    private static boolean isRestrictedSaleStaff(User actor) {
        if (actor == null || actor.getRole() == null || actor.getRole().isAdmin()) {
            return false;
        }
        if (!actor.getRole().isSale()) {
            return false;
        }
        return !isManagerOrDirector(actor);
    }

    public Long managerLeadSaleRoomId(Long actorId) {
        User actor = actor(actorId);
        if (!isSaleManager(actor)) return null;
        return actor.getSaleRoom() == null || actor.getSaleRoom().getId() == null ? -1L : actor.getSaleRoom().getId();
    }

    private static boolean isSaleManager(User actor) {
        return actor != null && actor.getRole() != null && !actor.getRole().isAdmin()
                && actor.getRole().isSale() && "manager".equalsIgnoreCase(actor.getLevelCode());
    }

    private static boolean isCustomerCareManager(User actor) {
        return actor != null && actor.getRole() != null && !actor.getRole().isAdmin()
                && "cskh".equalsIgnoreCase(actor.getRoleCode())
                && "manager".equalsIgnoreCase(actor.getLevelCode());
    }

    private static boolean isAssignmentInManagerRoom(User manager, Assignment assignment) {
        return manager.getSaleRoom() != null && manager.getSaleRoom().getId() != null
                && assignment != null && assignment.getAssignee() != null
                && assignment.getAssignee().getSaleRoom() != null
                && manager.getSaleRoom().getId().equals(assignment.getAssignee().getSaleRoom().getId());
    }

    private static boolean isRestrictedCskhStaff(User actor) {
        if (actor == null || actor.getRole() == null || actor.getRole().isAdmin()) {
            return false;
        }
        if (!isCskh(actor)) {
            return false;
        }
        return !isManagerOrDirector(actor);
    }

    private static boolean isMarketing(User actor) {
        String code = actor.getRoleCode();
        return code != null && "marketing".equalsIgnoreCase(code.trim());
    }

    private static boolean isCskh(User actor) {
        String code = actor.getRoleCode();
        return code != null && "cskh".equalsIgnoreCase(code.trim());
    }

    private static boolean isManagerOrDirector(User actor) {
        String level = actor.getLevelCode();
        if (level == null || level.isBlank()) {
            return false;
        }
        String normalized = level.trim().toLowerCase(Locale.ROOT);
        return "manager".equals(normalized) || "director".equals(normalized);
    }

    private User actor(Long actorId) {
        if (actorId == null) {
            return null;
        }
        return userRepository.findByIdWithAuth(actorId).orElse(null);
    }

    private static boolean hasPermission(User user, String code) {
        if (code == null || code.isBlank() || user == null) {
            return false;
        }
        String wanted = code.trim().toLowerCase(Locale.ROOT);
        Set<Permission> permissions = user.getEffectivePermissions();
        if (permissions == null || permissions.isEmpty()) {
            return false;
        }
        for (Permission permission : permissions) {
            if (permission != null && permission.getCode() != null
                    && wanted.equals(permission.getCode().trim().toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return false;
    }
}
