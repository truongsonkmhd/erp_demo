package com.xxxx.ddd.application.service.workflow;

import com.xxxx.ddd.application.model.AssignmentDTO;
import com.xxxx.ddd.application.model.CustomerCareLogDTO;
import com.xxxx.ddd.application.model.CustomerDTO;
import com.xxxx.ddd.application.model.MarketingLeadDTO;
import com.xxxx.ddd.application.model.OrderDTO;
import com.xxxx.ddd.application.service.order.SaleOverlaySanitizer;
import com.xxxx.ddd.application.service.order.OrderEntrustDetailService;
import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.entity.Customer;
import com.xxxx.ddd.domain.model.entity.CustomerCareLog;
import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

/**
 * Chuyển entity của luồng marketing sang DTO. Dùng chung cho các app service.
 */
@Component
public class WorkflowDtoMapper {

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_OFFSET_DATE_TIME;

    private final SaleOverlaySanitizer saleOverlaySanitizer;
    private final OrderEntrustDetailService orderEntrustDetailService;
    private final ObjectMapper objectMapper;

    public WorkflowDtoMapper(SaleOverlaySanitizer saleOverlaySanitizer,
                             OrderEntrustDetailService orderEntrustDetailService,
                             ObjectMapper objectMapper) {
        this.saleOverlaySanitizer = saleOverlaySanitizer;
        this.orderEntrustDetailService = orderEntrustDetailService;
        this.objectMapper = objectMapper;
    }

    public MarketingLeadDTO toLeadDTO(MarketingLead lead, Assignment marketingAssignment, Assignment taskAssignment) {
        MarketingLeadDTO dto = new MarketingLeadDTO();
        dto.setId(lead.getId());
        dto.setCode(lead.getCode());
        if (lead.getCustomer() != null && !Boolean.TRUE.equals(lead.getCustomer().getIsDeleted())) {
            dto.setCustomerId(lead.getCustomer().getId());
            dto.setCustomerCode(lead.getCustomer().getCode());
        }
        dto.setFullName(lead.getFullName());
        dto.setPhone(lead.getPhone());
        dto.setEmail(lead.getEmail() != null && !lead.getEmail().isBlank()
                ? lead.getEmail()
                : lead.getCustomer() != null ? lead.getCustomer().getEmail() : null);
        dto.setCategory(lead.getCategory());
        dto.setLeadSource(lead.getLeadSource());
        dto.setLeadSourceNote(lead.getLeadSourceNote());
        dto.setCampaignNames(lead.getCampaignNames());
        dto.setInitialNeed(lead.getInitialNeed());
        dto.setNote(lead.getNote());
        dto.setStage(name(lead.getStage()));
        dto.setMarketingStatus(name(lead.getMarketingStatus()));
        dto.setTaskStatus(name(lead.getTaskStatus()));
        dto.setManagerNotifiedAt(format(lead.getManagerNotifiedAt()));
        dto.setCareProgress(lead.getCareProgress());
        dto.setCareProgressNote(lead.getCareProgressNote());
        dto.setCareL4At(format(lead.getCareL4At()));
        dto.setOrderCreatedAt(format(lead.getOrderCreatedAt()));
        if (lead.getCreatedBy() != null) {
            dto.setCreatedById(lead.getCreatedBy().getId());
            dto.setCreatedByName(lead.getCreatedBy().getFullName());
        }
        dto.setCreatedAt(format(lead.getCreatedAt()));
        dto.setUpdatedAt(format(lead.getUpdatedAt()));
        dto.setMarketingAssignment(toAssignmentDTO(marketingAssignment));
        dto.setTaskAssignment(toAssignmentDTO(taskAssignment));
        return dto;
    }

    public AssignmentDTO toAssignmentDTO(Assignment assignment) {
        if (assignment == null) {
            return null;
        }
        AssignmentDTO dto = new AssignmentDTO();
        dto.setId(assignment.getId());
        dto.setRefType(name(assignment.getRefType()));
        dto.setRefId(assignment.getRefId());
        if (assignment.getAssignee() != null) {
            dto.setAssigneeId(assignment.getAssignee().getId());
            dto.setAssigneeName(assignment.getAssignee().getFullName());
            dto.setAssigneeEmail(assignment.getAssignee().getEmail());
        }
        if (assignment.getAssignedBy() != null) {
            dto.setAssignedById(assignment.getAssignedBy().getId());
            dto.setAssignedByName(assignment.getAssignedBy().getFullName());
        }
        dto.setStatus(name(assignment.getStatus()));
        dto.setNote(assignment.getNote());
        dto.setAssignedAt(format(assignment.getAssignedAt()));
        dto.setAcceptedAt(format(assignment.getAcceptedAt()));
        dto.setSupersededById(assignment.getSupersededById());
        return dto;
    }

    public CustomerCareLogDTO toCareLogDTO(CustomerCareLog log) {
        CustomerCareLogDTO dto = new CustomerCareLogDTO();
        dto.setId(log.getId());
        dto.setLeadId(log.getLeadId());
        dto.setCareProgress(log.getCareProgress());
        dto.setCareProgressNote(log.getCareProgressNote());
        dto.setDataEvaluation(log.getDataEvaluation());
        dto.setHasIssue(log.getHasIssue());
        dto.setIssueNote(log.getIssueNote());
        if (log.getChangedBy() != null) {
            dto.setChangedById(log.getChangedBy().getId());
            dto.setChangedByName(log.getChangedBy().getFullName());
        }
        dto.setCreatedAt(format(log.getCreatedAt()));
        return dto;
    }

    public CustomerDTO toCustomerDTO(Customer customer, int orderCount) {
        AddressParts parsed = AddressParts.parse(customer.getAddress());
        CustomerDTO dto = new CustomerDTO();
        dto.setId(customer.getId());
        dto.setCode(customer.getCode());
        dto.setFullName(customer.getFullName());
        dto.setCompanyName(customer.getCompanyName());
        dto.setPhone(customer.getPhone());
        dto.setEmail(customer.getEmail());
        dto.setCategory(customer.getCategory());
        dto.setTaxCode(customer.getTaxCode());
        dto.setBusinessType(customer.getBusinessType());
        dto.setChinaVietnamRateKg(customer.getChinaVietnamRateKg());
        dto.setChinaVietnamRateCbm(customer.getChinaVietnamRateCbm());
        dto.setWalletBalanceVnd(customer.getWalletBalanceVnd());
        dto.setLeadSource(customer.getLeadSource());
        dto.setAddress(customer.getAddress());
        dto.setProvince(firstNonBlank(customer.getProvince(), parsed.province()));
        dto.setWard(firstNonBlank(customer.getWard(), parsed.ward()));
        dto.setDetailAddress(firstNonBlank(customer.getDetailAddress(), parsed.detailAddress()));
        dto.setNote(customer.getNote());
        if (customer.getCreatedBy() != null) {
            dto.setCreatedById(customer.getCreatedBy().getId());
            dto.setCreatedByName(customer.getCreatedBy().getFullName());
        }
        if (customer.getCustomerCareStaff() != null) {
            dto.setCustomerCareStaffId(customer.getCustomerCareStaff().getId());
            dto.setCustomerCareStaffName(customer.getCustomerCareStaff().getFullName());
        }
        dto.setOrderCount(orderCount);
        dto.setCreatedAt(format(customer.getCreatedAt()));
        dto.setUpdatedAt(format(customer.getUpdatedAt()));
        return dto;
    }

    public OrderDTO toOrderDTO(CustomerOrder order) {
        return toOrderDTO(order, orderEntrustDetailService.hydrate(
                order.getId(), order.getContractType(), order.getSaleOverlayJson()));
    }

    public OrderDTO toOrderDTO(CustomerOrder order, String hydratedOverlayJson) {
        OrderDTO dto = new OrderDTO();
        dto.setId(order.getId());
        dto.setInternalCode(order.getInternalCode());
        dto.setOrderCode(order.getOrderCode());
        if (order.getCustomer() != null) {
            dto.setCustomerId(order.getCustomer().getId());
            dto.setCustomerCode(order.getCustomer().getCode());
            dto.setCustomerName(order.getCustomer().getFullName());
            dto.setCustomerPhone(order.getCustomer().getPhone());
            if (order.getCustomer().getCustomerCareStaff() != null) {
                dto.setCustomerCareStaffId(order.getCustomer().getCustomerCareStaff().getId());
                dto.setCustomerCareStaffName(order.getCustomer().getCustomerCareStaff().getFullName());
            }
        }
        dto.setLeadId(order.getLeadId());
        dto.setBatchCode(order.getBatchCode());
        dto.setServiceType(order.getServiceType());
        dto.setContractType(order.getContractType());
        dto.setProductName(order.getProductName());
        dto.setCategory(order.getCategory());
        dto.setQuantity(order.getQuantity());
        dto.setUnitPriceRmb(order.getUnitPriceRmb());
        dto.setTotalPaymentAmountVnd(order.getTotalPaymentAmountVnd());
        dto.setPaidAt(order.getPaidAt() == null ? null : order.getPaidAt().toString());
        dto.setSalaryCustomerKind(order.getSalaryCustomerKind());
        if (order.getAssignee() != null) {
            dto.setAssigneeId(order.getAssignee().getId());
            dto.setAssigneeName(order.getAssignee().getFullName());
        }
        if (order.getSalesOwner() != null) {
            dto.setSalesOwnerId(order.getSalesOwner().getId());
            dto.setSalesOwnerName(order.getSalesOwner().getFullName());
        }
        dto.setNotes(order.getNotes());
        dto.setSaleOverlayJson(saleOverlaySanitizer.sanitize(hydratedOverlayJson));
        dto.setSource(name(order.getSource()));
        dto.setEditApprovalStatus(order.getEditApprovalStatus());
        dto.setEditRequestedBy(order.getEditRequestedBy());
        dto.setEditApprovedBy(order.getEditApprovedBy());
        dto.setEditRequestedAt(format(order.getEditRequestedAt()));
        dto.setEditApprovedAt(format(order.getEditApprovedAt()));
        dto.setCreatedAt(format(order.getCreatedAt()));
        dto.setUpdatedAt(format(order.getUpdatedAt()));
        return dto;
    }

    /** Payload gọn cho bảng danh sách; không trả JSON chi tiết. */
    public OrderDTO toOrderListDTO(CustomerOrder order, String hydratedOverlayJson) {
        OrderDTO dto = toOrderDTO(order, null);
        dto.setSaleOverlayJson(null);
        if (hydratedOverlayJson == null || hydratedOverlayJson.isBlank()) return dto;
        try {
            JsonNode node = objectMapper.readTree(hydratedOverlayJson);
            dto.setTransportMode(text(node, "transportMode"));
            dto.setCalculationUnit(text(node, "calculationUnit"));
            dto.setWeightKg(decimal(node, "weightKg"));
            dto.setVolumeCbm(decimal(node, "volumeCbm"));
            dto.setTotalGoodsRmb(decimal(node, "totalGoodsRmb"));
            dto.setImportServiceFeeVnd(decimal(node, "importServiceFeeVnd"));
            dto.setTotalRevenueVnd(decimal(node, "totalRevenueVnd"));
            dto.setRemainingPaymentVnd(decimal(node, "remainingPaymentVnd"));
            dto.setSellingChinaVietnamRateVnd(decimal(node, "sellingChinaVietnamRateVnd"));
            dto.setTotalRevenueNorthSouthVnd(decimal(node, "totalRevenueNorthSouthVnd"));
            dto.setOutputVatVnd(decimal(node, "outputVatVnd"));
            dto.setStatementAmountVnd(decimal(node, "statementAmountVnd"));
            dto.setUtvcDebtVnd(decimal(node, "utvcDebtVnd"));
            dto.setCostProfitVnd(decimal(node, "costProfitVnd"));
            dto.setFloorProfitVnd(decimal(node, "floorProfitVnd"));
        } catch (Exception ignored) { }
        return dto;
    }

    private static String text(JsonNode node, String field) {
        JsonNode value = node.get(field);
        return value == null || value.isNull() ? null : value.asText();
    }

    private static java.math.BigDecimal decimal(JsonNode node, String field) {
        JsonNode value = node.get(field);
        if (value == null || value.isNull() || value.asText().isBlank()) return null;
        try { return value.decimalValue(); } catch (Exception ignored) { return null; }
    }

    private static String name(Enum<?> value) {
        return value == null ? null : value.name();
    }

    private static String format(LocalDateTime value) {
        // Các cột LocalDateTime được lưu theo UTC. Luôn trả offset để trình duyệt
        // có thể chuyển chính xác sang múi giờ của người dùng (Việt Nam: UTC+7).
        return value == null ? null : value.atOffset(ZoneOffset.UTC).format(ISO);
    }

    private static String firstNonBlank(String primary, String fallback) {
        return primary == null || primary.isBlank() ? fallback : primary.trim();
    }

    private record AddressParts(String detailAddress, String ward, String province) {
        static AddressParts parse(String address) {
            if (address == null || address.isBlank()) {
                return new AddressParts(null, null, null);
            }
            String[] parts = java.util.Arrays.stream(address.split(","))
                    .map(String::trim)
                    .filter(part -> !part.isEmpty())
                    .toArray(String[]::new);
            if (parts.length >= 3) {
                return new AddressParts(
                        String.join(", ", java.util.Arrays.copyOf(parts, parts.length - 2)),
                        parts[parts.length - 2],
                        parts[parts.length - 1]);
            }
            if (parts.length == 2) {
                return new AddressParts(null, parts[0], parts[1]);
            }
            return new AddressParts(parts[0], null, null);
        }
    }
}
