package com.xxxx.ddd.controller.config;

public final class CorsOrigins {

    public static final String[] PATTERNS = {
            "http://localhost:*",
            "http://127.0.0.1:*",
            "http://192.168.*:*",
            "http://10.*:*",
            "https://*.trycloudflare.com",
            "https://*"
    };

    private CorsOrigins() {
    }
}
