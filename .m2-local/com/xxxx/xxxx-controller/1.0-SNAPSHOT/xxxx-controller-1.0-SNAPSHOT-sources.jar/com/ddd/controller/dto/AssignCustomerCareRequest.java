package com.xxxx.ddd.controller.dto;

import lombok.Data;

@Data
public class AssignCustomerCareRequest {
    private Long staffId;
    private String note;
    private Boolean notifyMail = true;
    private Boolean notifySystem = true;
}
