package com.xxxx.ddd.controller.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AssignLeadRequest {

    @NotNull(message = "Chưa chọn nhân viên nhận việc")
    private Long assigneeId;

    private String note;
    private Boolean notifyMail = true;
    private Boolean notifySystem = true;
}
