package com.xxxx.ddd.controller.dto;

import lombok.Data;

@Data
public class NotifyManagerRequest {
    private String message;
    private Boolean notifyMail = true;
    private Boolean notifySystem = true;
}
