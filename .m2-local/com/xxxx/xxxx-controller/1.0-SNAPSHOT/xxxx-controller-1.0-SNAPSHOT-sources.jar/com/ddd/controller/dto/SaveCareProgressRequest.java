package com.xxxx.ddd.controller.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class SaveCareProgressRequest {

    @NotBlank(message = "Chưa chọn tiến trình chăm sóc")
    private String careProgress;

    private String careProgressNote;
    private Boolean hasIssue;
    private String issueNote;
}
