package com.xxxx.ddd.controller.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class SaveCustomerRequest {

    private Long leadId;
    private String code;

    @NotBlank(message = "Tên khách hàng không được để trống")
    private String fullName;

    private String companyName;

    @NotBlank(message = "Số điện thoại khách hàng không được để trống")
    @Pattern(regexp = "^0\\d{9}$", message = "Số điện thoại phải gồm 10 chữ số và bắt đầu bằng 0")
    private String phone;

    @Email(message = "Email không đúng định dạng")
    private String email;
    private String category;
    private String taxCode;
    private String businessType;
    @NotNull(message = "Đơn giá cước Trung - Việt (VNĐ/KG) không được để trống")
    @DecimalMin(value = "0", inclusive = false, message = "Đơn giá cước Trung - Việt (VNĐ/KG) phải lớn hơn 0")
    private java.math.BigDecimal chinaVietnamRateKg;

    @NotNull(message = "Đơn giá cước Trung - Việt (VNĐ/CBM) không được để trống")
    @DecimalMin(value = "0", inclusive = false, message = "Đơn giá cước Trung - Việt (VNĐ/CBM) phải lớn hơn 0")
    private java.math.BigDecimal chinaVietnamRateCbm;
    private Long customerCareStaffId;
    private String leadSource;
    private String address;
    private String province;
    private String ward;
    private String detailAddress;
    private String note;
}
