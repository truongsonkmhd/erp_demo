package com.xxxx.ddd.controller.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class SaveDashboardKpiRequest {
    private BigDecimal totalData;
    private BigDecimal overallData;
    private BigDecimal wrongInsight;
    private BigDecimal levelL0;
    private BigDecimal levelL1;
    private BigDecimal levelL2;
    private BigDecimal levelL3;
    private BigDecimal levelL5;
    private BigDecimal newCustomers;
    private BigDecimal newProfitVnd;
    private BigDecimal conversionTimeDays;
}
