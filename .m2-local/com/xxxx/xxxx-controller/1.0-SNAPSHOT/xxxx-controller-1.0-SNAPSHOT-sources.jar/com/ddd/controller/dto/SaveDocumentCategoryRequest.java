package com.xxxx.ddd.controller.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class SaveDocumentCategoryRequest {
    @NotBlank
    private String name;
    private Integer sortOrder;
    private Boolean active;
    private Boolean editable;
    private Boolean sharedMenu;
}
