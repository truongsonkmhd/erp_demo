package com.xxxx.ddd.controller.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Data
public class SaveLeadKpiRequest {

    private List<Employee> employees = new ArrayList<>();

    @Data
    public static class Employee {
        private Long userId;
        private String comment;
        private Map<String, BigDecimal> actuals = new LinkedHashMap<>();
    }
}
