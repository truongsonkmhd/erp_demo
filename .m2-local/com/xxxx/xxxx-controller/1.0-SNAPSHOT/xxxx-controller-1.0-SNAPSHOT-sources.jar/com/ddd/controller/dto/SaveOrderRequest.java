package com.xxxx.ddd.controller.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class SaveOrderRequest {
    private Long customerId;
    private String orderCode;
    private String batchCode;
    private String serviceType;
    private String contractType;
    private String productName;
    private String category;
    private BigDecimal quantity;
    private BigDecimal unitPriceRmb;
    private BigDecimal totalPaymentAmountVnd;
    private LocalDate paidAt;
    private String notes;
    private String saleOverlayJson;
}
