package com.xxxx.ddd.controller.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

@Data
public class SaveSaleRoomRequest {
    private String code;
    @NotBlank
    private String name;
    private String description;
    private Long leaderId;
    private List<Long> memberIds;
    private Boolean active;
}
