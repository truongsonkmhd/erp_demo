package com.xxxx.ddd.controller.dto;

import lombok.Data;

import java.util.List;

@Data
public class UpdateLevelPermissionsRequest {
    private List<String> permissionIds;
}
