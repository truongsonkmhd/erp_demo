package com.xxxx.ddd.controller.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class UpdateUserRequest {
    private String fullName;
    private String username;
    private String email;
    private String phone;
    private String roleCode;
    private String levelId;
    private Long saleRoomId;
    private BigDecimal baseSalary;
    private Boolean active;
}
