package com.xxxx.ddd.controller.exception;

import org.springframework.web.multipart.MultipartFile;

public final class DocumentUploadLimits {

    public static final long MAX_FILE_BYTES = 50L * 1024 * 1024;
    public static final String TOO_LARGE_MESSAGE = "Dung lượng tệp tối đa 50MB.";

    private DocumentUploadLimits() {
    }

    public static boolean exceedsLimit(MultipartFile file) {
        return file != null && !file.isEmpty() && file.getSize() > MAX_FILE_BYTES;
    }
}
