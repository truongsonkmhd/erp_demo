package com.xxxx.ddd.controller.exception;

import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;

@Slf4j
@RestControllerAdvice
public class MultipartUploadExceptionHandler {

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<ResultMessage<Void>> handleMaxUpload(MaxUploadSizeExceededException ex) {
        log.warn("Upload rejected: {}", ex.getMessage());
        return tooLarge();
    }

    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<ResultMessage<Void>> handleMultipart(MultipartException ex) {
        if (isSizeExceeded(ex)) {
            log.warn("Upload rejected: {}", ex.getMessage());
            return tooLarge();
        }
        log.error("Multipart error", ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ResultUtil.error(400, "Không thể tải tệp lên"));
    }

    private static ResponseEntity<ResultMessage<Void>> tooLarge() {
        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE)
                .body(ResultUtil.error(413, DocumentUploadLimits.TOO_LARGE_MESSAGE));
    }

    private static boolean isSizeExceeded(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof MaxUploadSizeExceededException) {
                return true;
            }
            String name = current.getClass().getName();
            if (name.contains("SizeLimitExceeded") || name.contains("FileSizeLimitExceeded")) {
                return true;
            }
            current = current.getCause();
        }
        return false;
    }
}
