package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.CareReminderSettingsDTO;
import com.xxxx.ddd.application.service.marketinglead.CareReminderSettingsService;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;

@RestController
@RequestMapping("/api/care-reminder-settings")
public class CareReminderSettingsController {
    private final CareReminderSettingsService service;
    private final CurrentUserResolver currentUserResolver;

    public CareReminderSettingsController(CareReminderSettingsService service, CurrentUserResolver currentUserResolver) {
        this.service = service;
        this.currentUserResolver = currentUserResolver;
    }

    @GetMapping
    public ResultMessage<CareReminderSettingsDTO> get() {
        return ResultUtil.data(service.get());
    }

    @PutMapping
    public ResultMessage<CareReminderSettingsDTO> save(@RequestBody SaveBody body, Authentication authentication) {
        return ResultUtil.data(service.save(body.intervalMinutes(), body.l0IntervalMinutes(), body.l11IntervalMinutes(),
                body.l21IntervalMinutes(), body.l22IntervalMinutes(), body.unassignedCustomerInitialMinutes(),
                body.unassignedCustomerRepeatMinutes(),
                body.unassignedLeadInitialMinutes(), body.unassignedLeadRepeatMinutes(),
                body.warehouseAddressInitialMinutes(), body.warehouseAddressRepeatMinutes(),
                body.warehouseDebtInitialMinutes(), body.warehouseDebtRepeatMinutes(),
                body.customerInactiveFirstDays(), body.customerInactiveSecondDays(), body.customerInactiveThirdDays(),
                body.utvcNorthSouthCostRateVnd(), currentUserResolver.requireUserId(authentication)));
    }

    public record SaveBody(int intervalMinutes, int l0IntervalMinutes, int l11IntervalMinutes,
                           int l21IntervalMinutes, int l22IntervalMinutes, int unassignedCustomerInitialMinutes,
                           int unassignedCustomerRepeatMinutes,
                           int unassignedLeadInitialMinutes, int unassignedLeadRepeatMinutes,
                           int warehouseAddressInitialMinutes, int warehouseAddressRepeatMinutes,
                           int warehouseDebtInitialMinutes, int warehouseDebtRepeatMinutes,
                           int customerInactiveFirstDays, int customerInactiveSecondDays,
                           int customerInactiveThirdDays,
                           BigDecimal utvcNorthSouthCostRateVnd) {
    }
}
