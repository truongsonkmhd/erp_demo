package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.CompanyDocumentDTO;
import com.xxxx.ddd.application.model.DocumentFilePayload;
import com.xxxx.ddd.application.model.OnlyOfficeEditorConfigDTO;
import com.xxxx.ddd.application.service.document.CompanyDocumentAppService;
import com.xxxx.ddd.application.service.document.onlyoffice.OnlyOfficeDocumentAppService;
import com.xxxx.ddd.controller.exception.DocumentUploadLimits;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.List;

@RestController
@RequestMapping("/api/documents")
@Slf4j
public class CompanyDocumentController {

    @Autowired
    private CompanyDocumentAppService companyDocumentAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @Autowired
    private OnlyOfficeDocumentAppService onlyOfficeDocumentAppService;

    @GetMapping
    public ResultMessage<List<CompanyDocumentDTO>> findAll(
            @RequestParam(required = false) Long categoryId,
            Authentication authentication
    ) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(companyDocumentAppService.findVisible(categoryId, userId));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (Exception e) {
            log.error("List documents error", e);
            return ResultUtil.error(500, "Failed to list documents");
        }
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResultMessage<CompanyDocumentDTO> create(
            @RequestParam Long categoryId,
            @RequestParam String name,
            @RequestParam("file") MultipartFile file,
            Authentication authentication
    ) {
        try {
            if (file == null || file.isEmpty()) {
                return ResultUtil.error(400, "File is required");
            }
            if (DocumentUploadLimits.exceedsLimit(file)) {
                return ResultUtil.error(413, DocumentUploadLimits.TOO_LARGE_MESSAGE);
            }
            Long userId = currentUserResolver.requireUserId(authentication);
            boolean canManageShared = currentUserResolver.canUpdateSharedDocument(authentication);
            return ResultUtil.data(companyDocumentAppService.create(
                    categoryId,
                    name,
                    file.getOriginalFilename(),
                    file.getContentType(),
                    file.getSize(),
                    file.getInputStream(),
                    userId,
                    canManageShared
            ));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Create document error", e);
            return ResultUtil.error(500, "Failed to create document");
        }
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResultMessage<CompanyDocumentDTO> update(
            @PathVariable Long id,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String name,
            @RequestParam(value = "file", required = false) MultipartFile file,
            Authentication authentication
    ) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            boolean canManageShared = currentUserResolver.canUpdateSharedDocument(authentication);
            boolean hasFile = file != null && !file.isEmpty();
            if (DocumentUploadLimits.exceedsLimit(file)) {
                return ResultUtil.error(413, DocumentUploadLimits.TOO_LARGE_MESSAGE);
            }
            return ResultUtil.data(companyDocumentAppService.update(
                    id,
                    categoryId,
                    name,
                    hasFile ? file.getOriginalFilename() : null,
                    hasFile ? file.getContentType() : null,
                    hasFile ? file.getSize() : null,
                    hasFile ? file.getInputStream() : null,
                    userId,
                    canManageShared
            ));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update document error", e);
            return ResultUtil.error(500, "Failed to update document");
        }
    }

    @PostMapping("/{id}/move")
    public ResultMessage<CompanyDocumentDTO> move(
            @PathVariable Long id,
            @RequestParam Long categoryId,
            Authentication authentication
    ) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            boolean canManageShared = currentUserResolver.canUpdateSharedDocument(authentication);
            return ResultUtil.data(companyDocumentAppService.move(id, categoryId, userId, canManageShared));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Move document error", e);
            return ResultUtil.error(500, "Failed to move document");
        }
    }

    @PostMapping("/{id}/copy")
    public ResultMessage<CompanyDocumentDTO> copy(
            @PathVariable Long id,
            @RequestParam Long categoryId,
            @RequestParam(required = false) String name,
            Authentication authentication
    ) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            boolean canManageShared = currentUserResolver.canUpdateSharedDocument(authentication);
            return ResultUtil.data(companyDocumentAppService.copy(id, categoryId, name, userId, canManageShared));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Copy document error", e);
            return ResultUtil.error(500, "Failed to copy document");
        }
    }

    @DeleteMapping("/{id}")
    public ResultMessage<Long> delete(@PathVariable Long id, Authentication authentication) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            boolean canManageShared = currentUserResolver.canDeleteSharedDocument(authentication);
            companyDocumentAppService.delete(id, userId, canManageShared);
            return ResultUtil.data(id);
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Delete document error", e);
            return ResultUtil.error(500, "Failed to delete document");
        }
    }

    @GetMapping("/{id}/editor-config")
    public ResultMessage<OnlyOfficeEditorConfigDTO> editorConfig(
            @PathVariable Long id,
            @RequestParam(defaultValue = "view") String mode,
            Authentication authentication
    ) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            boolean canEditOnline = currentUserResolver.canEditDocumentOnline(authentication);
            String userName = currentUserResolver.displayName(authentication);
            return ResultUtil.data(onlyOfficeDocumentAppService.buildEditorConfig(
                    id, userId, userName, mode, canEditOnline));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("OnlyOffice editor config error", e);
            return ResultUtil.error(500, "Failed to build editor config");
        }
    }

    @GetMapping("/{id}/file")
    public ResponseEntity<Resource> download(
            @PathVariable Long id,
            @RequestParam(required = false) String ooToken,
            Authentication authentication
    ) {
        try {
            DocumentFilePayload payload;
            if (ooToken != null && !ooToken.isBlank()) {
                log.info("OnlyOffice file download documentId={} via ooToken", id);
                payload = companyDocumentAppService.getFileWithOoToken(id, ooToken);
            } else {
                Long userId = currentUserResolver.requireUserId(authentication);
                payload = companyDocumentAppService.getFile(id, userId);
            }
            ContentDisposition disposition = ContentDisposition.attachment()
                    .filename(payload.fileName() == null ? "file" : payload.fileName(), StandardCharsets.UTF_8)
                    .build();
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, disposition.toString())
                    .contentType(MediaType.parseMediaType(payload.contentType()))
                    .contentLength(payload.fileSize())
                    .body(payload.resource());
        } catch (IllegalStateException e) {
            log.warn("Document download unauthorized documentId={} hasOoToken={} message={}",
                    id, ooToken != null && !ooToken.isBlank(), e.getMessage());
            return ResponseEntity.status(401).build();
        } catch (IllegalArgumentException e) {
            log.warn("Document download rejected documentId={} hasOoToken={} message={}",
                    id, ooToken != null && !ooToken.isBlank(), e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
}
