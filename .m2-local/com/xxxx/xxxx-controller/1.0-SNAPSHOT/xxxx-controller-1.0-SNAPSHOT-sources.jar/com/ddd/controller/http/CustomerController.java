package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.CustomerDTO;
import com.xxxx.ddd.application.model.CustomerPageDTO;
import com.xxxx.ddd.application.model.OrderDTO;
import com.xxxx.ddd.application.model.AssignmentDTO;
import com.xxxx.ddd.application.model.command.SaveCustomerCommand;
import com.xxxx.ddd.application.service.order.OrderAppService;
import com.xxxx.ddd.controller.dto.AssignCustomerCareRequest;
import com.xxxx.ddd.controller.dto.SaveCustomerRequest;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
@Slf4j
public class CustomerController {

    @Autowired
    private OrderAppService orderAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @GetMapping
    public ResultMessage<List<CustomerDTO>> findAll(@RequestParam(required = false) String phone,
                                                    Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.findCustomers(phone, currentUserResolver.userId(authentication)));
        } catch (Exception e) {
            log.error("List customers error", e);
            return ResultUtil.error(500, "Không tải được danh sách khách hàng");
        }
    }

    @GetMapping("/search")
    public ResultMessage<CustomerPageDTO> search(@RequestParam(required = false) String code,
                                                 @RequestParam(required = false) String name,
                                                 @RequestParam(required = false) String phone,
                                                 @RequestParam(required = false) String province,
                                                 @RequestParam(required = false) String ward,
                                                 @RequestParam(required = false) String category,
                                                 @RequestParam(required = false) Long createdById,
                                                 @RequestParam(required = false) Long customerCareStaffId,
                                                 @RequestParam(required = false) String fromDate,
                                                 @RequestParam(required = false) String toDate,
                                                 @RequestParam(required = false) String fromMonth,
                                                 @RequestParam(required = false) String toMonth,
                                                 @RequestParam(defaultValue = "1") int pageNo,
                                                 @RequestParam(defaultValue = "10") int pageSize,
                                                 Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.searchCustomers(
                    code, name, phone, province, ward, category, createdById, customerCareStaffId,
                    fromDate, toDate, fromMonth, toMonth,
                    pageNo, pageSize, currentUserResolver.userId(authentication)));
        } catch (Exception e) {
            log.error("Search customers error", e);
            return ResultUtil.error(500, "Không tải được danh sách khách hàng");
        }
    }

    @GetMapping("/{id:\\d+}")
    public ResultMessage<CustomerDTO> getById(@PathVariable Long id, Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.getCustomerById(
                    id, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(404, e.getMessage());
        }
    }

    @PostMapping
    public ResultMessage<CustomerDTO> create(@Valid @RequestBody SaveCustomerRequest request,
                                             Authentication authentication) {
        try {
            Long actorId = currentUserResolver.userId(authentication);
            return ResultUtil.data(orderAppService.createCustomer(toCommand(request), actorId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Create customer error", e);
            return ResultUtil.error(500, "Không lưu được hồ sơ khách hàng");
        }
    }

    @PutMapping("/{id:\\d+}")
    public ResultMessage<CustomerDTO> update(@PathVariable Long id,
                                             @Valid @RequestBody SaveCustomerRequest request,
                                             Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.updateCustomer(
                    id, toCommand(request), currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update customer error", e);
            return ResultUtil.error(500, "Không cập nhật được khách hàng");
        }
    }

    @DeleteMapping("/{id:\\d+}")
    public ResultMessage<Long> delete(@PathVariable Long id, Authentication authentication) {
        try {
            orderAppService.deleteCustomer(id, currentUserResolver.userId(authentication));
            return ResultUtil.data(id);
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(404, e.getMessage());
        } catch (Exception e) {
            log.error("Delete customer error", e);
            return ResultUtil.error(500, "Không xóa được khách hàng");
        }
    }

    @PostMapping("/{id:\\d+}/assign-care")
    public ResultMessage<CustomerDTO> assignCustomerCare(@PathVariable Long id,
                                                         @RequestBody(required = false) AssignCustomerCareRequest request,
                                                         Authentication authentication) {
        try {
            Long staffId = request == null ? null : request.getStaffId();
            return ResultUtil.data(orderAppService.assignCustomerCareStaff(
                    id,
                    staffId,
                    request == null ? null : request.getNote(),
                    request == null ? true : request.getNotifyMail(),
                    request == null ? true : request.getNotifySystem(),
                    currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Assign customer care staff error", e);
            return ResultUtil.error(500, "Không phân được nhân viên CSKH");
        }
    }

    @GetMapping("/{id:\\d+}/assignments")
    public ResultMessage<List<AssignmentDTO>> assignmentHistory(@PathVariable Long id,
                                                                 Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.findCustomerCareAssignmentHistory(
                    id, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(404, e.getMessage());
        } catch (Exception e) {
            log.error("List customer care assignment history error", e);
            return ResultUtil.error(500, "Không tải được lịch sử điều chuyển CSKH");
        }
    }

    @GetMapping("/{id}/orders")
    public ResultMessage<List<OrderDTO>> findOrders(@PathVariable Long id, Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.findByCustomerId(id, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(404, e.getMessage());
        } catch (Exception e) {
            log.error("List customer orders error", e);
            return ResultUtil.error(500, "Không tải được đơn hàng của khách");
        }
    }

    private static SaveCustomerCommand toCommand(SaveCustomerRequest request) {
        SaveCustomerCommand command = new SaveCustomerCommand();
        command.setLeadId(request.getLeadId());
        command.setCode(request.getCode());
        command.setFullName(request.getFullName());
        command.setCompanyName(request.getCompanyName());
        command.setPhone(request.getPhone());
        command.setEmail(request.getEmail());
        command.setCategory(request.getCategory());
        command.setTaxCode(request.getTaxCode());
        command.setBusinessType(request.getBusinessType());
        command.setChinaVietnamRateKg(request.getChinaVietnamRateKg());
        command.setChinaVietnamRateCbm(request.getChinaVietnamRateCbm());
        command.setCustomerCareStaffId(request.getCustomerCareStaffId());
        command.setLeadSource(request.getLeadSource());
        command.setAddress(request.getAddress());
        command.setProvince(request.getProvince());
        command.setWard(request.getWard());
        command.setDetailAddress(request.getDetailAddress());
        command.setNote(request.getNote());
        return command;
    }
}
