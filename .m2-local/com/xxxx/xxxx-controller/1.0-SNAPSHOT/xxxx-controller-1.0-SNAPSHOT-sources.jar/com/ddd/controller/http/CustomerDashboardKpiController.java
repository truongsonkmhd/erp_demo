package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.CustomerDashboardKpiDTO;
import com.xxxx.ddd.application.service.dashboard.CustomerDashboardKpiAppService;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api/customer-dashboard-kpis")
@Slf4j
public class CustomerDashboardKpiController {
    @Autowired private CustomerDashboardKpiAppService service;
    @Autowired private CurrentUserResolver currentUserResolver;

    @GetMapping
    public ResultMessage<CustomerDashboardKpiDTO> get(@RequestParam(required = false) String month, Authentication authentication) {
        try { return ResultUtil.data(service.get(currentUserResolver.requireUserId(authentication), month)); }
        catch (IllegalArgumentException e) { return ResultUtil.error(400, e.getMessage()); }
        catch (Exception e) { log.error("Get customer dashboard KPI error", e); return ResultUtil.error(500, "Không tải được KPI khách hàng"); }
    }

    @PutMapping("/{userId}")
    public ResultMessage<CustomerDashboardKpiDTO> save(@PathVariable Long userId, @RequestParam(required = false) String month,
                                                        @RequestBody Map<String, BigDecimal> values, Authentication authentication) {
        try { return ResultUtil.data(service.save(currentUserResolver.requireUserId(authentication), userId, month, values)); }
        catch (IllegalArgumentException e) { return ResultUtil.error(400, e.getMessage()); }
        catch (Exception e) { log.error("Save customer dashboard KPI error", e); return ResultUtil.error(500, "Không lưu được KPI khách hàng"); }
    }
}
