package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.DashboardKpiDTO;
import com.xxxx.ddd.application.model.command.SaveDashboardKpiCommand;
import com.xxxx.ddd.application.service.dashboard.DashboardKpiAppService;
import com.xxxx.ddd.controller.dto.SaveDashboardKpiRequest;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard-kpis")
@Slf4j
public class DashboardKpiController {
    @Autowired private DashboardKpiAppService service;
    @Autowired private CurrentUserResolver currentUserResolver;

    @GetMapping
    public ResultMessage<DashboardKpiDTO> get(@RequestParam(required = false) String month, Authentication authentication) {
        try { return ResultUtil.data(service.get(currentUserResolver.requireUserId(authentication), month)); }
        catch (IllegalArgumentException e) { return ResultUtil.error(400, e.getMessage()); }
        catch (Exception e) { log.error("Get dashboard KPI error", e); return ResultUtil.error(500, "Không tải được KPI"); }
    }

    @PutMapping("/{userId}")
    public ResultMessage<DashboardKpiDTO> save(@PathVariable Long userId, @RequestParam(required = false) String month, @RequestBody SaveDashboardKpiRequest request,
                                               Authentication authentication) {
        try { return ResultUtil.data(service.save(currentUserResolver.requireUserId(authentication), userId, month, toCommand(request))); }
        catch (IllegalArgumentException e) { return ResultUtil.error(400, e.getMessage()); }
        catch (Exception e) { log.error("Save dashboard KPI error", e); return ResultUtil.error(500, "Không lưu được KPI"); }
    }

    @PutMapping("/rooms/{saleRoomId}")
    public ResultMessage<DashboardKpiDTO> saveRoom(@PathVariable Long saleRoomId, @RequestParam(required = false) String month,
                                                   @RequestBody SaveDashboardKpiRequest request, Authentication authentication) {
        try { return ResultUtil.data(service.saveRoom(currentUserResolver.requireUserId(authentication), saleRoomId, month, toCommand(request))); }
        catch (IllegalArgumentException e) { return ResultUtil.error(400, e.getMessage()); }
        catch (Exception e) { log.error("Save dashboard room KPI error", e); return ResultUtil.error(500, "Không lưu được KPI phòng"); }
    }

    private static SaveDashboardKpiCommand toCommand(SaveDashboardKpiRequest r) {
        if (r == null) return null;
        SaveDashboardKpiCommand c = new SaveDashboardKpiCommand();
        c.setTotalData(r.getTotalData()); c.setOverallData(r.getOverallData()); c.setWrongInsight(r.getWrongInsight());
        c.setLevelL0(r.getLevelL0()); c.setLevelL1(r.getLevelL1()); c.setLevelL2(r.getLevelL2());
        c.setLevelL3(r.getLevelL3()); c.setLevelL5(r.getLevelL5());
        c.setNewCustomers(r.getNewCustomers()); c.setNewProfitVnd(r.getNewProfitVnd()); c.setConversionTimeDays(r.getConversionTimeDays());
        return c;
    }
}
