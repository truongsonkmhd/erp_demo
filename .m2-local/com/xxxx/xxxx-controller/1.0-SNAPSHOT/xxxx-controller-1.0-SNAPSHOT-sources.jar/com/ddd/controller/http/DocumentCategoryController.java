package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.DocumentCategoryDTO;
import com.xxxx.ddd.application.model.command.SaveDocumentCategoryCommand;
import com.xxxx.ddd.application.service.document.DocumentCategoryAppService;
import com.xxxx.ddd.controller.dto.SaveDocumentCategoryRequest;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/document-categories")
@Slf4j
public class DocumentCategoryController {

    @Autowired
    private DocumentCategoryAppService documentCategoryAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @GetMapping
    public ResultMessage<List<DocumentCategoryDTO>> findAll(Authentication authentication) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(documentCategoryAppService.findVisible(userId));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (Exception e) {
            log.error("List document categories error", e);
            return ResultUtil.error(500, "Failed to list document categories");
        }
    }

    @PostMapping
    public ResultMessage<DocumentCategoryDTO> create(
            @Valid @RequestBody SaveDocumentCategoryRequest request,
            Authentication authentication
    ) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            boolean canManageShared = currentUserResolver.canManageDocumentMenu(authentication);
            return ResultUtil.data(documentCategoryAppService.create(toCommand(request), userId, canManageShared));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Create document category error", e);
            return ResultUtil.error(500, "Failed to create document category");
        }
    }

    @PutMapping("/{id}")
    public ResultMessage<DocumentCategoryDTO> update(
            @PathVariable Long id,
            @Valid @RequestBody SaveDocumentCategoryRequest request,
            Authentication authentication
    ) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            boolean canManageShared = currentUserResolver.canManageDocumentMenu(authentication);
            return ResultUtil.data(documentCategoryAppService.update(id, toCommand(request), userId, canManageShared));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update document category error", e);
            return ResultUtil.error(500, "Failed to update document category");
        }
    }

    @DeleteMapping("/{id}")
    public ResultMessage<Long> delete(@PathVariable Long id, Authentication authentication) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            boolean canDeleteShared = currentUserResolver.canDeleteDocumentMenu(authentication);
            documentCategoryAppService.delete(id, userId, canDeleteShared);
            return ResultUtil.data(id);
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Delete document category error", e);
            return ResultUtil.error(500, "Failed to delete document category");
        }
    }

    private static SaveDocumentCategoryCommand toCommand(SaveDocumentCategoryRequest request) {
        SaveDocumentCategoryCommand command = new SaveDocumentCategoryCommand();
        command.setName(request.getName());
        command.setSortOrder(request.getSortOrder());
        command.setActive(request.getActive());
        command.setEditable(request.getEditable());
        command.setSharedMenu(request.getSharedMenu());
        return command;
    }
}
