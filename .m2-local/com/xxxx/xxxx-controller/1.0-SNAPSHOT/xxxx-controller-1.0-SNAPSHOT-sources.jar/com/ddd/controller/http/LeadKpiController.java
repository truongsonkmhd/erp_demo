package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.LeadKpiPeriodDTO;
import com.xxxx.ddd.application.model.command.SaveLeadKpiCommand;
import com.xxxx.ddd.application.service.leadkpi.LeadKpiAppService;
import com.xxxx.ddd.controller.dto.SaveLeadKpiRequest;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/lead-kpi")
@Slf4j
public class LeadKpiController {

    @Autowired
    private LeadKpiAppService leadKpiAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @GetMapping
    public ResultMessage<LeadKpiPeriodDTO> getByPeriod(
            @RequestParam String period,
            @RequestParam(required = false) Long saleRoomId,
            Authentication authentication) {
        try {
            Long actorId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(leadKpiAppService.getByPeriod(period, actorId, saleRoomId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Get lead KPI error", e);
            return ResultUtil.error(500, "Không tải được KPI dẫn");
        }
    }

    @PutMapping("/{period}")
    public ResultMessage<LeadKpiPeriodDTO> savePeriod(@PathVariable String period,
                                                      @RequestBody SaveLeadKpiRequest request,
                                                      @RequestParam(required = false) Long saleRoomId,
                                                      Authentication authentication) {
        try {
            Long actorId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(leadKpiAppService.savePeriod(period, toCommand(request), actorId, saleRoomId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Save lead KPI error", e);
            return ResultUtil.error(500, "Không lưu được KPI dẫn");
        }
    }

    private static SaveLeadKpiCommand toCommand(SaveLeadKpiRequest request) {
        SaveLeadKpiCommand command = new SaveLeadKpiCommand();
        if (request == null || request.getEmployees() == null) {
            return command;
        }
        for (SaveLeadKpiRequest.Employee item : request.getEmployees()) {
            SaveLeadKpiCommand.Employee employee = new SaveLeadKpiCommand.Employee();
            employee.setUserId(item.getUserId());
            employee.setComment(item.getComment());
            employee.setActuals(item.getActuals());
            command.getEmployees().add(employee);
        }
        return command;
    }
}
