package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.AssignmentDTO;
import com.xxxx.ddd.application.model.CustomerCareLogDTO;
import com.xxxx.ddd.application.model.MarketingLeadDTO;
import com.xxxx.ddd.application.model.MarketingLeadPageDTO;
import com.xxxx.ddd.application.model.MarketingLeadStatsDTO;
import com.xxxx.ddd.application.model.command.AssignLeadCommand;
import com.xxxx.ddd.application.model.command.NotifyManagerCommand;
import com.xxxx.ddd.application.model.command.SaveCareProgressCommand;
import com.xxxx.ddd.application.model.command.SaveMarketingLeadCommand;
import com.xxxx.ddd.application.service.marketinglead.LeadWorkflowAppService;
import com.xxxx.ddd.application.service.marketinglead.MarketingLeadAppService;
import com.xxxx.ddd.controller.dto.AssignLeadRequest;
import com.xxxx.ddd.controller.dto.NotifyManagerRequest;
import com.xxxx.ddd.controller.dto.SaveCareProgressRequest;
import com.xxxx.ddd.controller.dto.SaveMarketingLeadRequest;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/marketing-leads")
@Slf4j
public class MarketingLeadController {

    @Autowired
    private MarketingLeadAppService marketingLeadAppService;

    @Autowired
    private LeadWorkflowAppService leadWorkflowAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @GetMapping
    public ResultMessage<MarketingLeadPageDTO> search(
            @RequestParam(required = false) String stage,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String phone,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String source,
            @RequestParam(required = false) String careProgress,
            @RequestParam(required = false) String assignee,
            @RequestParam(required = false) Boolean customerCreated,
            @RequestParam(required = false) String campaignName,
            @RequestParam(required = false) String fromDate,
            @RequestParam(required = false) String toDate,
            @RequestParam(required = false) String fromMonth,
            @RequestParam(required = false) String toMonth,
            @RequestParam(required = false, defaultValue = "false") boolean pendingForMe,
            @RequestParam(required = false, defaultValue = "false") boolean dashboard,
            @RequestParam(required = false, defaultValue = "1") int pageNo,
            @RequestParam(required = false, defaultValue = "10") int pageSize,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String sortDir,
            Authentication authentication) {
        try {
            Long actorId = currentUserResolver.userId(authentication);
            return ResultUtil.data(marketingLeadAppService.search(
                    stage, name, phone, category, source, careProgress, assignee, customerCreated, campaignName, fromDate, toDate, fromMonth, toMonth, pendingForMe, dashboard, pageNo, pageSize, sortBy, sortDir, actorId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("List marketing leads error", e);
            return ResultUtil.error(500, "Không tải được dữ liệu marketing");
        }
    }

    @GetMapping("/stats")
    public ResultMessage<MarketingLeadStatsDTO> stats(
            @RequestParam(required = false) String fromDate,
            @RequestParam(required = false) String toDate,
            @RequestParam(required = false) String fromMonth,
            @RequestParam(required = false) String toMonth,
            @RequestParam(required = false, defaultValue = "false") boolean dashboard,
            @RequestParam(required = false) Long dashboardUserId,
            Authentication authentication) {
        try {
            return ResultUtil.data(marketingLeadAppService.stats(
                    fromDate, toDate, fromMonth, toMonth, dashboard, dashboardUserId, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Marketing lead stats error", e);
            return ResultUtil.error(500, "Không tải được thống kê marketing");
        }
    }

    @GetMapping("/campaign-names")
    public ResultMessage<List<String>> listCampaignNames(Authentication authentication) {
        try {
            return ResultUtil.data(marketingLeadAppService.listCampaignNames(currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("List campaign names error", e);
            return ResultUtil.error(500, "Không tải được danh sách chiến dịch");
        }
    }

    @GetMapping("/lookup")
    public ResultMessage<MarketingLeadDTO> lookup(
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String code,
            @RequestParam(required = false) String phone,
            Authentication authentication) {
        try {
            return ResultUtil.data(marketingLeadAppService.lookup(
                    q, code, phone, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(404, e.getMessage());
        } catch (Exception e) {
            log.error("Lookup marketing lead error", e);
            return ResultUtil.error(500, "Không tìm được dữ liệu marketing");
        }
    }

    @GetMapping("/{id:\\d+}")
    public ResultMessage<MarketingLeadDTO> getById(@PathVariable Long id, Authentication authentication) {
        try {
            return ResultUtil.data(marketingLeadAppService.getById(id, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(404, e.getMessage());
        } catch (Exception e) {
            log.error("Get marketing lead error", e);
            return ResultUtil.error(500, "Không tải được dữ liệu marketing");
        }
    }

    @PostMapping
    public ResultMessage<MarketingLeadDTO> create(@Valid @RequestBody SaveMarketingLeadRequest request,
                                                  Authentication authentication) {
        try {
            Long actorId = currentUserResolver.userId(authentication);
            return ResultUtil.data(marketingLeadAppService.create(toCommand(request), actorId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Create marketing lead error", e);
            return ResultUtil.error(500, "Không tạo được dữ liệu marketing");
        }
    }

    @PutMapping("/{id:\\d+}")
    public ResultMessage<MarketingLeadDTO> update(@PathVariable Long id,
                                                  @Valid @RequestBody SaveMarketingLeadRequest request,
                                                  Authentication authentication) {
        try {
            return ResultUtil.data(marketingLeadAppService.update(id, toCommand(request), currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update marketing lead error", e);
            return ResultUtil.error(500, "Không cập nhật được dữ liệu marketing");
        }
    }

    @DeleteMapping("/{id:\\d+}")
    public ResultMessage<Long> delete(@PathVariable Long id, Authentication authentication) {
        try {
            marketingLeadAppService.delete(id, currentUserResolver.userId(authentication));
            return ResultUtil.data(id);
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Delete marketing lead error", e);
            return ResultUtil.error(500, "Không xoá được dữ liệu marketing");
        }
    }

    @PostMapping("/{id:\\d+}/notify-manager")
    public ResultMessage<MarketingLeadDTO> notifyManager(@PathVariable Long id,
                                                        @RequestBody(required = false) NotifyManagerRequest request,
                                                        Authentication authentication) {
        try {
            Long actorId = currentUserResolver.userId(authentication);
            return ResultUtil.data(leadWorkflowAppService.notifyManager(id, toCommand(request), actorId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Notify manager error", e);
            return ResultUtil.error(500, "Không gửi được thông báo cho quản lý");
        }
    }

    @PostMapping("/{id:\\d+}/request-order")
    public ResultMessage<MarketingLeadDTO> requestCreateOrder(@PathVariable Long id,
                                                              @RequestBody(required = false) NotifyManagerRequest request,
                                                              Authentication authentication) {
        try {
            Long actorId = currentUserResolver.userId(authentication);
            return ResultUtil.data(leadWorkflowAppService.requestCreateOrder(id, toCommand(request), actorId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Request create order error", e);
            return ResultUtil.error(500, "Không gửi được yêu cầu tạo đơn hàng");
        }
    }

    @PostMapping("/{id:\\d+}/assign")
    public ResultMessage<MarketingLeadDTO> assign(@PathVariable Long id,
                                                  @Valid @RequestBody AssignLeadRequest request,
                                                  Authentication authentication) {
        try {
            Long actorId = currentUserResolver.userId(authentication);
            return ResultUtil.data(leadWorkflowAppService.assign(id, toCommand(request), actorId, false));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Assign marketing lead error", e);
            return ResultUtil.error(500, "Không phân việc được");
        }
    }

    @PostMapping("/{id:\\d+}/accept")
    public ResultMessage<MarketingLeadDTO> accept(@PathVariable Long id, Authentication authentication) {
        try {
            Long actorId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(leadWorkflowAppService.accept(id, actorId, false));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, "Unauthorized");
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Accept marketing lead error", e);
            return ResultUtil.error(500, "Không nhận được việc");
        }
    }

    @PostMapping("/{id:\\d+}/care-progress")
    public ResultMessage<MarketingLeadDTO> saveCareProgress(@PathVariable Long id,
                                                           @Valid @RequestBody SaveCareProgressRequest request,
                                                           Authentication authentication) {
        try {
            Long actorId = currentUserResolver.userId(authentication);
            return ResultUtil.data(leadWorkflowAppService.saveCareProgress(id, toCommand(request), actorId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Save care progress error", e);
            return ResultUtil.error(500, "Không lưu được tiến trình chăm sóc");
        }
    }

    @PutMapping("/{id:\\d+}/care-logs/{logId}")
    public ResultMessage<MarketingLeadDTO> updateCareLog(@PathVariable Long id,
                                                         @PathVariable Long logId,
                                                         @Valid @RequestBody SaveCareProgressRequest request,
                                                         Authentication authentication) {
        try {
            Long actorId = currentUserResolver.userId(authentication);
            return ResultUtil.data(leadWorkflowAppService.updateCareLog(id, logId, toCommand(request), actorId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update care log error", e);
            return ResultUtil.error(500, "Không cập nhật được tiến trình chăm sóc");
        }
    }

    @DeleteMapping("/{id:\\d+}/care-logs/{logId}")
    public ResultMessage<MarketingLeadDTO> deleteCareLog(@PathVariable Long id,
                                                         @PathVariable Long logId,
                                                         Authentication authentication) {
        try {
            return ResultUtil.data(leadWorkflowAppService.deleteCareLog(id, logId, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Delete care log error", e);
            return ResultUtil.error(500, "Không xoá được tiến trình chăm sóc");
        }
    }

    @GetMapping("/{id:\\d+}/care-logs")
    public ResultMessage<List<CustomerCareLogDTO>> findCareLogs(@PathVariable Long id,
                                                                Authentication authentication) {
        try {
            return ResultUtil.data(marketingLeadAppService.findCareLogs(id, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("List care logs error", e);
            return ResultUtil.error(500, "Không tải được tiến trình chăm sóc");
        }
    }

    @GetMapping("/{id:\\d+}/assignments")
    public ResultMessage<List<AssignmentDTO>> findAssignments(@PathVariable Long id,
                                                              @RequestParam(required = false) String refType,
                                                              Authentication authentication) {
        try {
            return ResultUtil.data(marketingLeadAppService.findAssignmentHistory(id, refType, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("List assignments error", e);
            return ResultUtil.error(500, "Không tải được lịch sử phân việc");
        }
    }

    private static SaveMarketingLeadCommand toCommand(SaveMarketingLeadRequest request) {
        SaveMarketingLeadCommand command = new SaveMarketingLeadCommand();
        command.setFullName(request.getFullName());
        command.setPhone(request.getPhone());
        command.setEmail(request.getEmail());
        command.setCategory(request.getCategory());
        command.setLeadSource(request.getLeadSource());
        command.setLeadSourceNote(request.getLeadSourceNote());
        command.setCampaignNames(request.getCampaignNames());
        command.setInitialNeed(request.getInitialNeed());
        command.setNote(request.getNote());
        return command;
    }

    private static NotifyManagerCommand toCommand(NotifyManagerRequest request) {
        NotifyManagerCommand command = new NotifyManagerCommand();
        if (request != null) {
            command.setMessage(request.getMessage());
            command.setNotifyMail(request.getNotifyMail());
            command.setNotifySystem(request.getNotifySystem());
        }
        return command;
    }

    static AssignLeadCommand toCommand(AssignLeadRequest request) {
        AssignLeadCommand command = new AssignLeadCommand();
        command.setAssigneeId(request.getAssigneeId());
        command.setNote(request.getNote());
        command.setNotifyMail(request.getNotifyMail());
        command.setNotifySystem(request.getNotifySystem());
        return command;
    }

    private static SaveCareProgressCommand toCommand(SaveCareProgressRequest request) {
        SaveCareProgressCommand command = new SaveCareProgressCommand();
        command.setCareProgress(request.getCareProgress());
        command.setCareProgressNote(request.getCareProgressNote());
        command.setHasIssue(request.getHasIssue());
        command.setIssueNote(request.getIssueNote());
        return command;
    }
}
