package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.NotificationDTO;
import com.xxxx.ddd.application.model.NotificationInboxDTO;
import com.xxxx.ddd.application.service.notification.NotificationAppService;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
@Slf4j
public class NotificationController {

    @Autowired
    private NotificationAppService notificationAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @GetMapping
    public ResultMessage<NotificationInboxDTO> findInbox(@RequestParam(defaultValue = "false") boolean unreadOnly,
                                                        @RequestParam(defaultValue = "15") int limit,
                                                        @RequestParam(required = false) Long beforeId,
                                                        Authentication authentication) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(notificationAppService.findInbox(userId, unreadOnly, limit, beforeId));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, "Unauthorized");
        } catch (Exception e) {
            log.error("List notifications error", e);
            return ResultUtil.error(500, "Không tải được thông báo");
        }
    }

    @PatchMapping("/{id}/read")
    public ResultMessage<NotificationDTO> markRead(@PathVariable Long id, Authentication authentication) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(notificationAppService.markRead(userId, id));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, "Unauthorized");
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Mark notification read error", e);
            return ResultUtil.error(500, "Không cập nhật được thông báo");
        }
    }

    @PatchMapping("/read-all")
    public ResultMessage<Long> markAllRead(Authentication authentication) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(notificationAppService.markAllRead(userId));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, "Unauthorized");
        } catch (Exception e) {
            log.error("Mark all notifications read error", e);
            return ResultUtil.error(500, "Không cập nhật được thông báo");
        }
    }
}
