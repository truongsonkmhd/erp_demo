package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.service.document.onlyoffice.OnlyOfficeDocumentAppService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/onlyoffice")
@Slf4j
public class OnlyOfficeCallbackController {

    @Autowired
    private OnlyOfficeDocumentAppService onlyOfficeDocumentAppService;

    @PostMapping("/callback/{id}")
    public Map<String, Object> callback(
            @PathVariable Long id,
            @RequestParam String ooToken,
            @RequestBody Map<String, Object> body
    ) {
        try {
            return onlyOfficeDocumentAppService.handleCallback(id, ooToken, body);
        } catch (IllegalArgumentException e) {
            log.warn("OnlyOffice callback rejected for document {}: {}", id, e.getMessage());
            return Map.of("error", 1);
        } catch (Exception e) {
            log.error("OnlyOffice callback error for document {}", id, e);
            return Map.of("error", 1);
        }
    }
}
