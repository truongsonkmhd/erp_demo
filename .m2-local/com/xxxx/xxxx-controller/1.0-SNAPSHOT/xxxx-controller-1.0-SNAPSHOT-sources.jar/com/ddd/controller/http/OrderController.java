package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.OrderDTO;
import com.xxxx.ddd.application.model.OrderPageDTO;
import com.xxxx.ddd.application.model.command.SaveOrderCommand;
import com.xxxx.ddd.application.service.order.OrderAppService;
import com.xxxx.ddd.controller.dto.SaveOrderRequest;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import com.xxxx.ddd.controller.security.CurrentUserResolver;

import java.util.List;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/orders")
@Slf4j
public class OrderController {

    @Autowired
    private OrderAppService orderAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @GetMapping
    public ResultMessage<List<OrderDTO>> findAll(Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.findAll(currentUserResolver.userId(authentication)));
        } catch (Exception e) {
            log.error("List orders error", e);
            return ResultUtil.error(500, "Không tải được danh sách đơn hàng");
        }
    }

    @GetMapping("/search")
    public ResultMessage<OrderPageDTO> search(@RequestParam(required = false) String query,
                                              @RequestParam(required = false) String customerCode,
                                              @RequestParam(required = false) String orderCode,
                                              @RequestParam(required = false) String batchCode,
                                              @RequestParam(required = false) String customerName,
                                              @RequestParam(required = false) String phone,
                                              @RequestParam(required = false) String category,
                                              @RequestParam(required = false) String productName,
                                              @RequestParam(required = false) String salesName,
                                              @RequestParam(required = false) String customerCareName,
                                              @RequestParam(required = false) String contractType,
                                              @RequestParam(required = false) String fromDate,
                                              @RequestParam(required = false) String toDate,
                                              @RequestParam(required = false) String fromMonth,
                                              @RequestParam(required = false) String toMonth,
                                              @RequestParam(defaultValue = "1") int pageNo,
                                              @RequestParam(defaultValue = "10") int pageSize,
                                              Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.searchOrders(
                    query, customerCode, orderCode, batchCode, customerName, phone, category, productName,
                    salesName, customerCareName, contractType,
                    fromDate, toDate, fromMonth, toMonth, pageNo, pageSize,
                    currentUserResolver.userId(authentication)));
        } catch (Exception e) {
            log.error("Search orders error", e);
            return ResultUtil.error(500, "Không tải được danh sách đơn hàng");
        }
    }

    @GetMapping("/export")
    public void export(@RequestParam(required = false) String query,
                       @RequestParam(required = false) String customerCode,
                       @RequestParam(required = false) String orderCode,
                       @RequestParam(required = false) String batchCode,
                       @RequestParam(required = false) String customerName,
                       @RequestParam(required = false) String phone,
                       @RequestParam(required = false) String category,
                       @RequestParam(required = false) String productName,
                       @RequestParam(required = false) String salesName,
                       @RequestParam(required = false) String customerCareName,
                       @RequestParam String contractType,
                       @RequestParam(required = false) String fromDate,
                       @RequestParam(required = false) String toDate,
                       @RequestParam(required = false) String fromMonth,
                       @RequestParam(required = false) String toMonth,
                       Authentication authentication,
                       HttpServletResponse response) throws java.io.IOException {
        String dateStr = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd_MM_yyyy"));
        String fileName = ("TRANSPORT_ENTRUST".equals(contractType) ? "don-hang-utvc" : "don-hang-utnk") + "_" + dateStr + ".xlsx";
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename*=UTF-8''" + URLEncoder.encode(fileName, StandardCharsets.UTF_8));
        Long actorId = currentUserResolver.userId(authentication);
        try (SXSSFWorkbook workbook = new SXSSFWorkbook(100)) {
            workbook.setCompressTempFiles(true);
            Sheet sheet = workbook.createSheet("TRANSPORT_ENTRUST".equals(contractType) ? "UTVC" : "UTNK");
            String[] headers = "TRANSPORT_ENTRUST".equals(contractType)
                    ? new String[]{"STT", "Mã UTVC", "Tên hàng hóa", "Đơn vị", "Số cân (kg)", "Số khối (cbm)", "Đơn giá bán Trung - Việt", "Doanh thu Bắc - Nam", "VAT xuất ra", "Tổng doanh thu UTVC", "Tiền sao kê UTVC", "Lợi nhuận cost", "Lợi nhuận sàn"}
                    : new String[]{"STT", "Mã UTNK", "Tên hàng hóa", "Tổng tiền hàng (RMB)", "Phí dịch vụ", "Tổng doanh thu", "Tiền sao kê UTNK", "Lợi nhuận sàn UTNK"};
            Row header = sheet.createRow(0);
            for (int i = 0; i < headers.length; i++) header.createCell(i).setCellValue(headers[i]);
            int excelRow = 1;
            int page = 1;
            while (true) {
                OrderPageDTO data = orderAppService.searchOrders(query, customerCode, orderCode, batchCode,
                        customerName, phone, category, productName, salesName, customerCareName, contractType,
                        fromDate, toDate, fromMonth, toMonth,
                        page, 100, actorId);
                for (OrderDTO item : data.getItems()) {
                    Row row = sheet.createRow(excelRow);
                    row.createCell(0).setCellValue(excelRow++);
                    row.createCell(1).setCellValue(value(item.getOrderCode()));
                    row.createCell(2).setCellValue(value(item.getProductName()));
                    if ("TRANSPORT_ENTRUST".equals(contractType)) {
                        row.createCell(3).setCellValue(value(item.getCalculationUnit()));
                        number(row, 4, item.getWeightKg()); number(row, 5, item.getVolumeCbm());
                        number(row, 6, item.getSellingChinaVietnamRateVnd()); number(row, 7, item.getTotalRevenueNorthSouthVnd());
                        number(row, 8, item.getOutputVatVnd()); number(row, 9, item.getTotalRevenueVnd());
                        number(row, 10, item.getStatementAmountVnd()); number(row, 11, item.getCostProfitVnd());
                        number(row, 12, item.getFloorProfitVnd());
                    } else {
                        number(row, 3, item.getTotalGoodsRmb()); number(row, 4, item.getImportServiceFeeVnd());
                        number(row, 5, item.getTotalRevenueVnd()); number(row, 6, item.getRemainingPaymentVnd());
                        number(row, 7, item.getFloorProfitVnd());
                    }
                }
                if (page >= data.getTotalPages() || data.getItems().isEmpty()) break;
                page++;
            }
            workbook.write(response.getOutputStream());
            response.flushBuffer();
        }
    }

    private static String value(String value) { return value == null ? "" : value; }
    private static void number(Row row, int cell, java.math.BigDecimal value) {
        row.createCell(cell).setCellValue(value == null ? 0D : value.doubleValue());
    }

    @GetMapping("/{id}")
    public ResultMessage<OrderDTO> getById(@PathVariable Long id, Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.getById(id, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(404, e.getMessage());
        } catch (Exception e) {
            log.error("Get order error", e);
            return ResultUtil.error(500, "Không tải được đơn hàng");
        }
    }

    @PostMapping
    public ResultMessage<OrderDTO> create(@RequestBody SaveOrderRequest request, Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.create(toCommand(request), currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (DataIntegrityViolationException e) {
            if (isDuplicateOrderCode(e)) {
                return ResultUtil.error(409, "Mã UTVC/Mã đặt hàng đã tồn tại, vui lòng nhập mã khác");
            }
            log.error("Create order data integrity error", e);
            return ResultUtil.error(500, "Không tạo được đơn hàng");
        } catch (Exception e) {
            log.error("Create order error", e);
            return ResultUtil.error(500, "Không tạo được đơn hàng");
        }
    }

    @PatchMapping("/{id}/warehouse-address")
    public ResultMessage<OrderDTO> updateWarehouseAddress(@PathVariable Long id,
            @RequestBody WarehouseAddressRequest request, Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.updateWarehouseDeliveryAddress(
                    id, request.deliveryAddress(), currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update warehouse address error", e);
            return ResultUtil.error(500, "Không cập nhật được địa chỉ giao hàng");
        }
    }

    public record WarehouseAddressRequest(String deliveryAddress) {}

    @PutMapping("/{id}/warehouse")
    public ResultMessage<OrderDTO> updateWarehouse(@PathVariable Long id,
            @RequestBody SaveOrderRequest request, Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.updateWarehouse(id, toCommand(request),
                    currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update warehouse error", e);
            return ResultUtil.error(500, "Không cập nhật được Kho vận");
        }
    }

    @DeleteMapping("/{id}/warehouse")
    public ResultMessage<Long> deleteWarehouse(@PathVariable Long id, Authentication authentication) {
        try {
            orderAppService.deleteWarehouse(id, currentUserResolver.userId(authentication));
            return ResultUtil.data(id);
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Delete warehouse error", e);
            return ResultUtil.error(500, "Không xoá được Kho vận");
        }
    }

    @PutMapping("/{id}")
    public ResultMessage<OrderDTO> update(@PathVariable Long id, @RequestBody SaveOrderRequest request,
                                          Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.update(id, toCommand(request), currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update order error", e);
            return ResultUtil.error(500, "Không cập nhật được đơn hàng");
        }
    }

    private static boolean isDuplicateOrderCode(DataIntegrityViolationException error) {
        Throwable cause = error.getMostSpecificCause();
        String message = cause == null ? "" : cause.getMessage();
        return message != null && message.contains("uk_order_code");
    }

    @PostMapping("/{id}/edit-approval/request")
    public ResultMessage<OrderDTO> requestEditApproval(@PathVariable Long id, Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.requestEditApproval(id, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Request order edit approval error", e);
            return ResultUtil.error(500, "Không gửi được yêu cầu phê duyệt sửa đơn");
        }
    }

    @PostMapping("/{id}/edit-approval/approve")
    public ResultMessage<OrderDTO> approveEdit(@PathVariable Long id, Authentication authentication) {
        try {
            return ResultUtil.data(orderAppService.approveEdit(id, currentUserResolver.userId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Approve order edit error", e);
            return ResultUtil.error(500, "Không phê duyệt được yêu cầu sửa đơn");
        }
    }

    @DeleteMapping("/{id}")
    public ResultMessage<Long> delete(@PathVariable Long id, Authentication authentication) {
        try {
            orderAppService.delete(id, currentUserResolver.userId(authentication));
            return ResultUtil.data(id);
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Delete order error", e);
            return ResultUtil.error(500, "Không xoá được đơn hàng");
        }
    }

    private static SaveOrderCommand toCommand(SaveOrderRequest request) {
        SaveOrderCommand command = new SaveOrderCommand();
        if (request == null) {
            return command;
        }
        command.setCustomerId(request.getCustomerId());
        command.setOrderCode(request.getOrderCode());
        command.setBatchCode(request.getBatchCode());
        command.setServiceType(request.getServiceType());
        command.setContractType(request.getContractType());
        command.setProductName(request.getProductName());
        command.setCategory(request.getCategory());
        command.setQuantity(request.getQuantity());
        command.setUnitPriceRmb(request.getUnitPriceRmb());
        command.setTotalPaymentAmountVnd(request.getTotalPaymentAmountVnd());
        command.setPaidAt(request.getPaidAt());
        command.setNotes(request.getNotes());
        command.setSaleOverlayJson(request.getSaleOverlayJson());
        return command;
    }
}
