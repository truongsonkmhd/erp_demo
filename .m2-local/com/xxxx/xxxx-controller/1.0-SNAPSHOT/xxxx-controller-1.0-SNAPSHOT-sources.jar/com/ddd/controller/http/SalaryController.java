package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.SalaryPeriodDTO;
import com.xxxx.ddd.application.model.command.SaveSalaryCommand;
import com.xxxx.ddd.application.service.salary.SalaryAppService;
import com.xxxx.ddd.controller.dto.SaveSalaryRequest;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/salary")
@Slf4j
public class SalaryController {

    @Autowired
    private SalaryAppService salaryAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @GetMapping("/me")
    public ResultMessage<SalaryPeriodDTO> getMyPreview(
            @RequestParam(required = false) String period,
            Authentication authentication) {
        try {
            Long actorId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(salaryAppService.getMyPreview(period, actorId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Get my salary preview error", e);
            return ResultUtil.error(500, "Không tải được lương tạm tính");
        }
    }

    @GetMapping
    public ResultMessage<SalaryPeriodDTO> getOrPreview(
            @RequestParam(required = false) String period,
            @RequestParam(required = false) Long saleRoomId,
            Authentication authentication) {
        try {
            Long actorId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(salaryAppService.getOrPreview(period, actorId, saleRoomId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Get salary period error", e);
            return ResultUtil.error(500, "Không tải được kỳ lương");
        }
    }

    @PutMapping("/{period}")
    public ResultMessage<SalaryPeriodDTO> save(@PathVariable String period,
                                               @RequestBody SaveSalaryRequest request,
                                               @RequestParam(required = false) Long saleRoomId,
                                               Authentication authentication) {
        try {
            Long actorId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(salaryAppService.save(period, toCommand(request), actorId, saleRoomId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Save salary period error", e);
            return ResultUtil.error(500, "Không lưu được kỳ lương");
        }
    }

    @PostMapping("/{period}/lock")
    public ResultMessage<SalaryPeriodDTO> lock(@PathVariable String period,
                                               @RequestParam(required = false) Long saleRoomId,
                                               Authentication authentication) {
        try {
            Long actorId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(salaryAppService.lock(period, actorId, saleRoomId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Lock salary period error", e);
            return ResultUtil.error(500, "Không khóa được kỳ lương");
        }
    }

    @PostMapping("/{period}/unlock")
    public ResultMessage<SalaryPeriodDTO> unlock(@PathVariable String period,
                                                 @RequestParam(required = false) Long saleRoomId,
                                                 Authentication authentication) {
        try {
            Long actorId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(salaryAppService.unlock(period, actorId, saleRoomId));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Unlock salary period error", e);
            return ResultUtil.error(500, "Không mở khóa được kỳ lương");
        }
    }

    private static SaveSalaryCommand toCommand(SaveSalaryRequest request) {
        SaveSalaryCommand command = new SaveSalaryCommand();
        if (request == null) {
            return command;
        }
        command.setDeptProfitOverrideVnd(request.getDeptProfitOverrideVnd());
        List<SaveSalaryCommand.LineInput> lines = new ArrayList<>();
        if (request.getLines() != null) {
            for (SaveSalaryRequest.LineInput item : request.getLines()) {
                SaveSalaryCommand.LineInput line = new SaveSalaryCommand.LineInput();
                line.setUserId(item.getUserId());
                line.setScheme(item.getScheme());
                line.setNewKpiVnd(item.getNewKpiVnd());
                line.setOldKpiVnd(item.getOldKpiVnd());
                line.setNewActualVnd(item.getNewActualVnd());
                line.setOldActualVnd(item.getOldActualVnd());
                line.setActualIsOverride(item.getActualIsOverride());
                line.setBaseSalary(item.getBaseSalary());
                line.setKpiPercent(item.getKpiPercent());
                line.setCoefficient(item.getCoefficient());
                lines.add(line);
            }
        }
        command.setLines(lines);
        return command;
    }
}
