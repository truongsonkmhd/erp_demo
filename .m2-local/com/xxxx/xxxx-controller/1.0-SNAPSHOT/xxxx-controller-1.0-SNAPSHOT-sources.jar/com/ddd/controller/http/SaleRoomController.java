package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.SaleRoomDTO;
import com.xxxx.ddd.application.model.command.SaveSaleRoomCommand;
import com.xxxx.ddd.application.service.saleroom.SaleRoomAppService;
import com.xxxx.ddd.controller.dto.SaveSaleRoomRequest;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.List;

@RestController
@RequestMapping("/api/sale-rooms")
@Slf4j
public class SaleRoomController {

    @Autowired
    private SaleRoomAppService saleRoomAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @GetMapping
    public ResultMessage<List<SaleRoomDTO>> findAll(Authentication authentication) {
        try {
            return ResultUtil.data(saleRoomAppService.findAll(currentUserResolver.requireUserId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("List sale rooms error", e);
            return ResultUtil.error(500, "Failed to list sale rooms");
        }
    }

    @GetMapping("/{id}")
    public ResultMessage<SaleRoomDTO> getById(@PathVariable Long id, Authentication authentication) {
        try {
            return ResultUtil.data(saleRoomAppService.getById(id, currentUserResolver.requireUserId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(404, e.getMessage());
        } catch (Exception e) {
            log.error("Get sale room error", e);
            return ResultUtil.error(500, "Failed to get sale room");
        }
    }

    @PostMapping
    public ResultMessage<SaleRoomDTO> create(@Valid @RequestBody SaveSaleRoomRequest request, Authentication authentication) {
        try {
            return ResultUtil.data(saleRoomAppService.create(toCommand(request), currentUserResolver.requireUserId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Create sale room error", e);
            return ResultUtil.error(500, "Failed to create sale room");
        }
    }

    @PutMapping("/{id}")
    public ResultMessage<SaleRoomDTO> update(@PathVariable Long id, @Valid @RequestBody SaveSaleRoomRequest request,
                                             Authentication authentication) {
        try {
            return ResultUtil.data(saleRoomAppService.update(id, toCommand(request), currentUserResolver.requireUserId(authentication)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update sale room error", e);
            return ResultUtil.error(500, "Failed to update sale room");
        }
    }

    @DeleteMapping("/{id}")
    public ResultMessage<Long> delete(@PathVariable Long id, Authentication authentication) {
        try {
            saleRoomAppService.delete(id, currentUserResolver.requireUserId(authentication));
            return ResultUtil.data(id);
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Delete sale room error", e);
            return ResultUtil.error(500, "Failed to delete sale room");
        }
    }

    private static SaveSaleRoomCommand toCommand(SaveSaleRoomRequest request) {
        SaveSaleRoomCommand command = new SaveSaleRoomCommand();
        command.setCode(request.getCode());
        command.setName(request.getName());
        command.setDescription(request.getDescription());
        command.setLeaderId(request.getLeaderId());
        command.setMemberIds(request.getMemberIds());
        command.setActive(request.getActive());
        return command;
    }
}
