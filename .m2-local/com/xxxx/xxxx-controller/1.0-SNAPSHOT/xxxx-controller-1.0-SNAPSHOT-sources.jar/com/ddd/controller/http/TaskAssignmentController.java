package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.MarketingLeadDTO;
import com.xxxx.ddd.application.service.marketinglead.LeadWorkflowAppService;
import com.xxxx.ddd.controller.dto.AssignLeadRequest;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Chặng giao nhiệm vụ (sau L4 hoặc sau khi bấm Tạo đơn hàng). Nhận việc ở chặng này sinh đơn hàng tự động.
 */
@RestController
@RequestMapping("/api/tasks")
@Slf4j
public class TaskAssignmentController {

    @Autowired
    private LeadWorkflowAppService leadWorkflowAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @PostMapping("/{leadId}/assign")
    public ResultMessage<MarketingLeadDTO> assign(@PathVariable Long leadId,
                                                  @Valid @RequestBody AssignLeadRequest request,
                                                  Authentication authentication) {
        try {
            Long actorId = currentUserResolver.userId(authentication);
            return ResultUtil.data(leadWorkflowAppService.assign(
                    leadId, MarketingLeadController.toCommand(request), actorId, true));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Assign task error", e);
            return ResultUtil.error(500, "Không giao nhiệm vụ được");
        }
    }

    @PostMapping("/{leadId}/accept")
    public ResultMessage<MarketingLeadDTO> accept(@PathVariable Long leadId, Authentication authentication) {
        try {
            Long actorId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(leadWorkflowAppService.accept(leadId, actorId, true));
        } catch (IllegalStateException e) {
            return ResultUtil.error(401, "Unauthorized");
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Accept task error", e);
            return ResultUtil.error(500, "Không nhận được nhiệm vụ");
        }
    }
}
