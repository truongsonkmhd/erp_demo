package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.model.UserDTO;
import com.xxxx.ddd.application.model.UserPageDTO;
import com.xxxx.ddd.application.service.user.UserAppService;
import com.xxxx.ddd.controller.dto.ChangePasswordRequest;
import com.xxxx.ddd.controller.dto.ChangeMyPasswordRequest;
import com.xxxx.ddd.controller.dto.CreateUserRequest;
import com.xxxx.ddd.controller.dto.UpdateUserRequest;
import com.xxxx.ddd.controller.dto.UpdateMyProfileRequest;
import com.xxxx.ddd.controller.mapper.AuthControllerMapper;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

@RestController
@RequestMapping("/api/users")
@Slf4j
public class UserController {

    @Autowired
    private UserAppService userAppService;

    @Autowired
    private CurrentUserResolver currentUserResolver;

    @PutMapping("/me/profile")
    public ResultMessage<UserDTO> updateMyProfile(Authentication authentication,
                                                   @Valid @RequestBody UpdateMyProfileRequest request) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            return ResultUtil.data(userAppService.updateOwnProfile(
                    userId, request.getFullName(), request.getEmail(), request.getPhone()));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update own profile error", e);
            return ResultUtil.error(500, "Không thể cập nhật thông tin cá nhân");
        }
    }

    @PatchMapping("/me/password")
    public ResultMessage<Long> changeMyPassword(Authentication authentication,
                                                 @Valid @RequestBody ChangeMyPasswordRequest request) {
        try {
            Long userId = currentUserResolver.requireUserId(authentication);
            userAppService.changeOwnPassword(userId, request.getCurrentPassword(),
                    request.getNewPassword(), request.getConfirmPassword());
            return ResultUtil.data(userId);
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Change own password error", e);
            return ResultUtil.error(500, "Không thể đổi mật khẩu");
        }
    }

    @GetMapping
    public ResultMessage<UserPageDTO> search(
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "1") int pageNo,
            @RequestParam(defaultValue = "10") int pageSize) {
        try {
            return ResultUtil.data(userAppService.search(keyword, pageNo, pageSize));
        } catch (Exception e) {
            log.error("Search users error", e);
            return ResultUtil.error(500, "Failed to search users");
        }
    }

    @GetMapping("/{id}")
    public ResultMessage<UserDTO> getById(@PathVariable Long id) {
        try {
            return ResultUtil.data(userAppService.getById(id));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(404, e.getMessage());
        } catch (Exception e) {
            log.error("Get user error", e);
            return ResultUtil.error(500, "Failed to get user");
        }
    }

    @PostMapping
    public ResultMessage<UserDTO> create(@Valid @RequestBody CreateUserRequest request) {
        try {
            return ResultUtil.data(userAppService.create(AuthControllerMapper.toCommand(request)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Create user error", e);
            return ResultUtil.error(500, "Failed to create user");
        }
    }

    @PutMapping("/{id}")
    public ResultMessage<UserDTO> update(@PathVariable Long id, @RequestBody UpdateUserRequest request) {
        try {
            return ResultUtil.data(userAppService.update(id, AuthControllerMapper.toCommand(request)));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Update user error", e);
            return ResultUtil.error(500, "Failed to update user");
        }
    }

    @PatchMapping("/{id}/leave-company")
    public ResultMessage<UserDTO> leaveCompany(@PathVariable Long id, Authentication authentication) {
        try {
            return ResultUtil.data(userAppService.markLeftCompany(currentUserResolver.requireUserId(authentication), id));
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Mark employee as left company error", e);
            return ResultUtil.error(500, "Không thể cập nhật trạng thái nhân viên");
        }
    }

    @DeleteMapping("/{id}")
    public ResultMessage<Long> delete(@PathVariable Long id) {
        try {
            userAppService.delete(id);
            return ResultUtil.data(id);
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Delete user error", e);
            return ResultUtil.error(500, "Failed to delete user");
        }
    }

    @PostMapping("/{id}/reset-password")
    public ResultMessage<Long> resetPassword(@PathVariable Long id) {
        try {
            userAppService.resetPassword(id);
            return ResultUtil.data(id);
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Reset password error", e);
            return ResultUtil.error(500, "Failed to reset password");
        }
    }

    @PatchMapping("/change-pwd")
    public ResultMessage<Long> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        try {
            userAppService.changePassword(AuthControllerMapper.toCommand(request));
            return ResultUtil.data(request.getId());
        } catch (IllegalArgumentException e) {
            return ResultUtil.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("Change password error", e);
            return ResultUtil.error(500, "Failed to change password");
        }
    }
}
