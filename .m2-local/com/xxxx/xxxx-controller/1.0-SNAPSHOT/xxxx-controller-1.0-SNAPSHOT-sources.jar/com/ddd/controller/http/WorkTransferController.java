package com.xxxx.ddd.controller.http;

import com.xxxx.ddd.application.service.transfer.WorkTransferService;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import com.xxxx.ddd.controller.security.CurrentUserResolver;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/work-transfers")
@RequiredArgsConstructor
public class WorkTransferController {
    private final WorkTransferService service;
    private final CurrentUserResolver currentUser;

    @GetMapping("/sources")
    public ResultMessage<?> sources(Authentication authentication) {
        try { return ResultUtil.data(service.sources(currentUser.requireUserId(authentication))); }
        catch (IllegalArgumentException e) { return ResultUtil.error(400, e.getMessage()); }
    }

    @GetMapping("/inventory")
    public ResultMessage<WorkTransferService.Inventory> inventory(@RequestParam Long sourceId,
                                                                   Authentication authentication) {
        try { return ResultUtil.data(service.inventory(sourceId, currentUser.requireUserId(authentication))); }
        catch (IllegalArgumentException e) { return ResultUtil.error(400, e.getMessage()); }
    }

    @PostMapping("/preview")
    public ResultMessage<WorkTransferService.Preview> preview(@RequestBody WorkTransferService.Request request,
                                                                Authentication authentication) {
        try { return ResultUtil.data(service.preview(request, currentUser.requireUserId(authentication))); }
        catch (IllegalArgumentException e) { return ResultUtil.error(400, e.getMessage()); }
    }

    @PostMapping
    public ResultMessage<WorkTransferService.Preview> commit(@RequestBody WorkTransferService.Request request,
                                                               Authentication authentication) {
        try { return ResultUtil.data(service.commit(request, currentUser.requireUserId(authentication))); }
        catch (IllegalArgumentException e) { return ResultUtil.error(400, e.getMessage()); }
    }
}
