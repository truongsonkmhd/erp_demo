package com.xxxx.ddd.controller.security;

public final class AuthoritiesConstants {
    public static final String ROLE_ADMIN = "ROLE_ADMIN";
    public static final String ROLE_CSKH_MANAGER = "ROLE_CSKH_MANAGER";
    public static final String ROLE_CSKH_DIRECTOR = "ROLE_CSKH_DIRECTOR";
    public static final String ROLE_SALE_MANAGER = "ROLE_SALE_MANAGER";
    public static final String ROLE_SALE_DIRECTOR = "ROLE_SALE_DIRECTOR";
    public static final String GRANT_ROLE = "grant_role";
    public static final String CREATE_ACCOUNT = "create_account";
    public static final String CREATE_TEAM_SALE = "create_team_sale";

    // Luồng marketing -> phân việc -> CSKH -> đơn hàng
    public static final String CUD_MARKETING_DATA = "cud_marketing_data";
    public static final String DELETE_MARKETING_LEAD = "delete_marketing_lead";
    public static final String NOTIFY_MANAGER_FOR_ASSIGN = "notify_manager_for_assign";
    /** Nhận email/thông báo khi Marketing bấm Thông báo quản lý. */
    public static final String RECEIVE_NOTIFY_MANAGER_FOR_ASSIGN = "receive_notify_manager_for_assign";
    public static final String ASSIGN_TASK_FOR_SALE = "assign_task_for_sale";
    public static final String BULK_TRANSFER_SALE = "bulk_transfer_sale";
    public static final String BULK_TRANSFER_CSKH = "bulk_transfer_cskh";
    /** Bấm "+ Phân việc" trên tab Giao nhiệm vụ (CSKH chờ giao). */
    public static final String ASSIGN_TASK_FOR_CUSTOMER_CARE = "assign_task_for_customer_care";
    public static final String UPDATE_CUSTOMER = "update_customer";
    public static final String DELETE_CUSTOMER = "delete_customer";
    public static final String IMPORT_EXCEL_CUSTOMERS = "import_excel_customers";
    public static final String ACCEPT_TASK_ASSIGNMENT = "accept_task_assignment";
    public static final String UPDATE_CUSTOMER_CARE = "update_customer_care";
    public static final String TAKE_CARE_CUSTOMER = "take_care_customer";
    public static final String RS_MANAGE_ORDERS = "rs_manage_orders";
    public static final String UPDATE_ORDER = "update_order";
    public static final String DELETE_ORDER = "delete_order";
    public static final String UPDATE_WAREHOUSE_TRANSPORT = "update_warehouse_transport";
    public static final String DELETE_WAREHOUSE_TRANSPORT = "delete_warehouse_transport";
    public static final String CREATE_ORDER = "create_order";
    public static final String ONE_CUSTOMER_MANY_ORDERS = "one_customer_many_orders";
    public static final String RS_ORDER = "rs_order";
    public static final String RS_MANAGE_MARKETING_DATA = "rs_manage_marketing_data";
    public static final String MENU_DOCUMENTS = "menu_documents";
    public static final String MANAGE_DOCUMENTS = "manage_documents";
    public static final String MANAGE_DOCUMENT_MENU = "create_update_delete_menu_document_fixed";
    public static final String DELETE_DOCUMENT_MENU = "delete_menu_document_fixed";
    public static final String MANAGER_UPDATE_DOCUMENT = "manager_update_document";
    public static final String MANAGER_DELETE_DOCUMENT = "manager_delete_document";
    public static final String DOWNLOAD_DOCUMENT = "download_document_fixed";
    public static final String VIEW_DOCUMENT_ONLINE = "view_document_only_office";
    public static final String UPDATE_DOCUMENT_ONLINE = "update_online_document_fixed";
    public static final String MENU_SALARY = "menu_salary";
    public static final String MANAGE_SALARY = "manage_salary";
    public static final String EDIT_DATA_DASHBOARD_KPI = "edit_data_dashboard_kpi";
    public static final String ROLE_ACCOUNTING = "ROLE_ACCOUNTING";
    /** Xem lương/KPI của tất cả phòng Sale (Admin / Senior hoặc gán động). */
    public static final String VIEW_ALL_SALARY_ROOMS = "view_all_salary_rooms";
    /** Xem trang báo cáo / theo dõi ads MKT. */
    /** Nhập ngân sách và quản lý camp trong báo cáo ads. */

    private AuthoritiesConstants() {
    }
}
