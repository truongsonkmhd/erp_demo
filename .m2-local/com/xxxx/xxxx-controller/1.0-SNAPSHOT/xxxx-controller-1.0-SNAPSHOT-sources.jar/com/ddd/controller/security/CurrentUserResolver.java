package com.xxxx.ddd.controller.security;

import com.xxxx.ddd.infrastructure.security.AuthUserDetails;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Lấy id/username của người đang đăng nhập từ Authentication mà JwtAuthenticationFilter đã set.
 */
@Component
public class CurrentUserResolver {

    public Long userId(Authentication authentication) {
        AuthUserDetails details = details(authentication);
        return details == null ? null : details.getUser().getId();
    }

    public Long requireUserId(Authentication authentication) {
        Long id = userId(authentication);
        if (id == null) {
            throw new IllegalStateException("Unauthorized");
        }
        return id;
    }

    public boolean canManageSharedDocuments(Authentication authentication) {
        return hasAnyAuthority(authentication, AuthoritiesConstants.MANAGE_DOCUMENTS);
    }

    public boolean canManageDocumentMenu(Authentication authentication) {
        return hasAnyAuthority(
                authentication,
                AuthoritiesConstants.MANAGE_DOCUMENT_MENU,
                AuthoritiesConstants.MANAGE_DOCUMENTS
        );
    }

    public boolean canDeleteDocumentMenu(Authentication authentication) {
        return hasAnyAuthority(
                authentication,
                AuthoritiesConstants.DELETE_DOCUMENT_MENU,
                AuthoritiesConstants.MANAGE_DOCUMENT_MENU,
                AuthoritiesConstants.MANAGE_DOCUMENTS
        );
    }

    public boolean canUpdateSharedDocument(Authentication authentication) {
        return hasAnyAuthority(
                authentication,
                AuthoritiesConstants.MANAGE_DOCUMENTS,
                AuthoritiesConstants.MANAGER_UPDATE_DOCUMENT
        );
    }

    public boolean canDeleteSharedDocument(Authentication authentication) {
        return hasAnyAuthority(
                authentication,
                AuthoritiesConstants.MANAGE_DOCUMENTS,
                AuthoritiesConstants.MANAGER_DELETE_DOCUMENT
        );
    }

    public boolean canDownloadDocument(Authentication authentication) {
        return hasAnyAuthority(
                authentication,
                AuthoritiesConstants.MANAGE_DOCUMENTS,
                AuthoritiesConstants.DOWNLOAD_DOCUMENT
        );
    }

    public boolean canViewDocumentOnline(Authentication authentication) {
        return hasAnyAuthority(
                authentication,
                AuthoritiesConstants.MANAGE_DOCUMENTS,
                AuthoritiesConstants.VIEW_DOCUMENT_ONLINE,
                AuthoritiesConstants.UPDATE_DOCUMENT_ONLINE
        );
    }

    public boolean canEditDocumentOnline(Authentication authentication) {
        return hasAnyAuthority(
                authentication,
                AuthoritiesConstants.MANAGE_DOCUMENTS,
                AuthoritiesConstants.UPDATE_DOCUMENT_ONLINE
        );
    }

    public boolean hasAnyAuthority(Authentication authentication, String... codes) {
        if (authentication == null || codes == null || codes.length == 0) {
            return false;
        }
        Set<String> wanted = Set.of(codes);
        return authentication.getAuthorities().stream().anyMatch(authority ->
                AuthoritiesConstants.ROLE_ADMIN.equals(authority.getAuthority())
                        || wanted.contains(authority.getAuthority()));
    }

    public String username(Authentication authentication) {
        return authentication == null ? null : authentication.getName();
    }

    public String displayName(Authentication authentication) {
        AuthUserDetails details = details(authentication);
        if (details == null) {
            return null;
        }
        String fullName = details.getUser().getFullName();
        if (fullName != null && !fullName.isBlank()) {
            return fullName;
        }
        return details.getUser().getUsername();
    }

    private AuthUserDetails details(Authentication authentication) {
        if (authentication == null || !(authentication.getPrincipal() instanceof AuthUserDetails details)) {
            return null;
        }
        return details;
    }
}
