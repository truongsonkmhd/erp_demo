package com.xxxx.ddd.controller.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xxxx.ddd.controller.model.enums.ResultUtil;
import com.xxxx.ddd.controller.model.vo.ResultMessage;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.nio.charset.StandardCharsets;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final ObjectMapper objectMapper;

    public SecurityConfiguration(JwtAuthenticationFilter jwtAuthenticationFilter, ObjectMapper objectMapper) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.objectMapper = objectMapper;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .cors(Customizer.withDefaults())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/authenticate/me").authenticated()
                        .requestMatchers(
                                "/api/authenticate",
                                "/api/authenticate/register",
                                "/api/authenticate/refresh-token",
                                "/api/authenticate/login-with-token",
                                "/api/authenticate/logout"
                        ).permitAll()
                        .requestMatchers(HttpMethod.PUT, "/api/users/me/profile").authenticated()
                        .requestMatchers(HttpMethod.PATCH, "/api/users/me/password").authenticated()
                        .requestMatchers(HttpMethod.GET, "/api/users", "/api/users/**").authenticated()
                        .requestMatchers(HttpMethod.PATCH, "/api/users/*/leave-company").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ROLE_SALE_DIRECTOR,
                                AuthoritiesConstants.ROLE_SALE_MANAGER)
                        .requestMatchers("/api/work-transfers", "/api/work-transfers/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.BULK_TRANSFER_SALE,
                                AuthoritiesConstants.BULK_TRANSFER_CSKH)
                        .requestMatchers(HttpMethod.POST, "/api/users").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.GRANT_ROLE,
                                AuthoritiesConstants.CREATE_ACCOUNT)
                        .requestMatchers("/api/users/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.GRANT_ROLE)
                        .requestMatchers("/api/roles/**", "/api/permissions/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.GRANT_ROLE)
                        .requestMatchers(HttpMethod.GET, "/api/sale-rooms", "/api/sale-rooms/**").authenticated()
                        .requestMatchers(HttpMethod.PUT, "/api/sale-rooms/*").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.GRANT_ROLE,
                                AuthoritiesConstants.CREATE_TEAM_SALE,
                                AuthoritiesConstants.ROLE_SALE_MANAGER,
                                AuthoritiesConstants.ROLE_SALE_DIRECTOR)
                        .requestMatchers("/api/sale-rooms", "/api/sale-rooms/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ROLE_SALE_DIRECTOR,
                                AuthoritiesConstants.GRANT_ROLE,
                                AuthoritiesConstants.CREATE_TEAM_SALE)
                        // Handshake WebSocket: xác thực JWT ở tầng STOMP CONNECT
                        .requestMatchers("/ws", "/ws/**").permitAll()
                        .requestMatchers("/api/notifications", "/api/notifications/**").authenticated()
                        .requestMatchers(HttpMethod.GET, "/api/care-reminder-settings").authenticated()
                        .requestMatchers(HttpMethod.PUT, "/api/care-reminder-settings").hasAuthority(
                                AuthoritiesConstants.ROLE_ADMIN)
                        .requestMatchers(HttpMethod.GET,
                                "/api/marketing-leads", "/api/marketing-leads/**",
                                "/api/orders", "/api/orders/**",
                                "/api/customers", "/api/customers/**").authenticated()
                        .requestMatchers(HttpMethod.POST, "/api/customers").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.IMPORT_EXCEL_CUSTOMERS,
                                AuthoritiesConstants.UPDATE_CUSTOMER_CARE,
                                AuthoritiesConstants.RS_MANAGE_ORDERS)
                        .requestMatchers(HttpMethod.POST, "/api/customers/*/assign-care").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ROLE_CSKH_MANAGER,
                                AuthoritiesConstants.ROLE_CSKH_DIRECTOR,
                                AuthoritiesConstants.ASSIGN_TASK_FOR_CUSTOMER_CARE)
                        .requestMatchers(HttpMethod.PUT, "/api/customers/*").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.UPDATE_CUSTOMER)
                        .requestMatchers(HttpMethod.DELETE, "/api/customers/*").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.DELETE_CUSTOMER)
                        .requestMatchers("/api/marketing-leads/*/notify-manager").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.NOTIFY_MANAGER_FOR_ASSIGN)
                        .requestMatchers("/api/marketing-leads/*/request-order").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.UPDATE_CUSTOMER_CARE,
                                AuthoritiesConstants.CREATE_ORDER,
                                AuthoritiesConstants.RS_MANAGE_ORDERS,
                                AuthoritiesConstants.RS_ORDER)
                        .requestMatchers("/api/marketing-leads/*/assign").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ASSIGN_TASK_FOR_SALE)
                        .requestMatchers("/api/tasks/*/assign").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ASSIGN_TASK_FOR_CUSTOMER_CARE)
                        .requestMatchers("/api/marketing-leads/*/accept", "/api/tasks/*/accept").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ACCEPT_TASK_ASSIGNMENT)
                        // Quyền nghiệp vụ được kiểm tra trong service: Executive gửi yêu cầu,
                        // Manager cùng phòng (hoặc Admin) phê duyệt.
                        .requestMatchers(HttpMethod.POST,
                                "/api/orders/*/edit-approval/request",
                                "/api/orders/*/edit-approval/approve").authenticated()
                        .requestMatchers("/api/marketing-leads/*/care-progress",
                                "/api/marketing-leads/*/care-logs/*").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.UPDATE_CUSTOMER_CARE,
                                AuthoritiesConstants.TAKE_CARE_CUSTOMER,
                                AuthoritiesConstants.CUD_MARKETING_DATA,
                                AuthoritiesConstants.RS_MANAGE_MARKETING_DATA)
                        .requestMatchers(HttpMethod.DELETE, "/api/marketing-leads", "/api/marketing-leads/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.DELETE_MARKETING_LEAD)
                        .requestMatchers(HttpMethod.POST, "/api/marketing-leads").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ROLE_SALE_MANAGER,
                                AuthoritiesConstants.ROLE_SALE_DIRECTOR,
                                AuthoritiesConstants.CUD_MARKETING_DATA)
                        .requestMatchers("/api/marketing-leads", "/api/marketing-leads/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.CUD_MARKETING_DATA)
                        .requestMatchers(HttpMethod.POST, "/api/orders").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.CREATE_ORDER,
                                AuthoritiesConstants.RS_MANAGE_ORDERS,
                                AuthoritiesConstants.ONE_CUSTOMER_MANY_ORDERS,
                                AuthoritiesConstants.RS_ORDER)
                        .requestMatchers(HttpMethod.PATCH, "/api/orders/*/warehouse-address").authenticated()
                        .requestMatchers(HttpMethod.PUT, "/api/orders/*/warehouse").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.UPDATE_WAREHOUSE_TRANSPORT)
                        .requestMatchers(HttpMethod.DELETE, "/api/orders/*/warehouse").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.DELETE_WAREHOUSE_TRANSPORT)
                        .requestMatchers(HttpMethod.PUT, "/api/orders", "/api/orders/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.RS_MANAGE_ORDERS,
                                AuthoritiesConstants.UPDATE_ORDER)
                        .requestMatchers(HttpMethod.DELETE, "/api/orders", "/api/orders/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.DELETE_ORDER)
                        .requestMatchers("/api/orders", "/api/orders/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.RS_MANAGE_ORDERS)
                        .requestMatchers(HttpMethod.GET, "/api/salary/me").authenticated()
                        .requestMatchers(HttpMethod.GET, "/api/dashboard-kpis").authenticated()
                        .requestMatchers(HttpMethod.PUT, "/api/dashboard-kpis/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.EDIT_DATA_DASHBOARD_KPI)
                        .requestMatchers(HttpMethod.GET, "/api/customer-dashboard-kpis").authenticated()
                        .requestMatchers(HttpMethod.PUT, "/api/customer-dashboard-kpis/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ROLE_CSKH_MANAGER,
                                AuthoritiesConstants.ROLE_CSKH_DIRECTOR)
                        .requestMatchers(HttpMethod.GET, "/api/lead-kpi", "/api/lead-kpi/**",
                                "/api/salary", "/api/salary/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ROLE_ACCOUNTING,
                                AuthoritiesConstants.MENU_SALARY,
                                AuthoritiesConstants.MANAGE_SALARY)
                        .requestMatchers("/api/lead-kpi", "/api/lead-kpi/**",
                                "/api/salary", "/api/salary/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.ROLE_ACCOUNTING,
                                AuthoritiesConstants.MANAGE_SALARY)
                        .requestMatchers(HttpMethod.POST, "/api/onlyoffice/callback/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/documents/*/file").permitAll()
                        .requestMatchers(HttpMethod.GET,
                                "/api/document-categories", "/api/document-categories/**",
                                "/api/documents", "/api/documents/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.MENU_DOCUMENTS,
                                AuthoritiesConstants.MANAGE_DOCUMENTS)
                        .requestMatchers("/api/document-categories", "/api/document-categories/**",
                                "/api/documents", "/api/documents/**").hasAnyAuthority(
                                AuthoritiesConstants.ROLE_ADMIN,
                                AuthoritiesConstants.MENU_DOCUMENTS,
                                AuthoritiesConstants.MANAGE_DOCUMENTS,
                                AuthoritiesConstants.MANAGE_DOCUMENT_MENU,
                                AuthoritiesConstants.DELETE_DOCUMENT_MENU,
                                AuthoritiesConstants.MANAGER_UPDATE_DOCUMENT,
                                AuthoritiesConstants.MANAGER_DELETE_DOCUMENT,
                                AuthoritiesConstants.DOWNLOAD_DOCUMENT,
                                AuthoritiesConstants.VIEW_DOCUMENT_ONLINE,
                                AuthoritiesConstants.UPDATE_DOCUMENT_ONLINE)
                        .requestMatchers("/actuator/health", "/actuator/health/**").permitAll()
                        .requestMatchers("/actuator/**").denyAll()
                        .anyRequest().permitAll()
                )
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(authenticationEntryPoint())
                        .accessDeniedHandler(accessDeniedHandler())
                )
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    private AuthenticationEntryPoint authenticationEntryPoint() {
        return (request, response, authException) ->
                write(response, HttpServletResponse.SC_UNAUTHORIZED, ResultUtil.error(401, "Unauthorized"));
    }

    private AccessDeniedHandler accessDeniedHandler() {
        return (request, response, accessDeniedException) ->
                write(response, HttpServletResponse.SC_FORBIDDEN, ResultUtil.error(403, "Forbidden"));
    }

    private void write(HttpServletResponse response, int status, ResultMessage<?> body) throws java.io.IOException {
        response.setStatus(status);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        objectMapper.writeValue(response.getWriter(), body);
    }
}
