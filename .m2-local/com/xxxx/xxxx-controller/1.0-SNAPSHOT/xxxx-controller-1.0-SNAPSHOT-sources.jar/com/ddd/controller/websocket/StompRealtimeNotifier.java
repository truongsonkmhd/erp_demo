package com.xxxx.ddd.controller.websocket;

import com.xxxx.ddd.application.port.RealtimeNotificationPort;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

/**
 * Adapter STOMP cho cổng thông báo realtime của tầng application.
 */
@Component
@Slf4j
public class StompRealtimeNotifier implements RealtimeNotificationPort {

    public static final String USER_QUEUE = "/queue/notifications";

    private final SimpMessagingTemplate messagingTemplate;

    public StompRealtimeNotifier(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @Override
    public void sendToUser(String username, Object payload) {
        if (username == null || username.isBlank()) {
            return;
        }
        messagingTemplate.convertAndSendToUser(username, USER_QUEUE, payload);
        log.debug("Đã đẩy thông báo realtime tới {}", username);
    }
}
