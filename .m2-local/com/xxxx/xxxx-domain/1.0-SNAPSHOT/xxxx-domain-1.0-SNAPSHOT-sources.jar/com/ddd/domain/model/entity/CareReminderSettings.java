package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.math.BigDecimal;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@Entity
@Table(name = "tbl_care_reminder_settings")
public class CareReminderSettings {
    public static final long SINGLETON_ID = 1L;

    @Id
    private Long id = SINGLETON_ID;

    @Column(name = "interval_minutes", nullable = false)
    private Integer intervalMinutes = 30;

    @Column(name = "l0_interval_minutes", nullable = false)
    private Integer l0IntervalMinutes = 30;

    @Column(name = "l11_interval_minutes", nullable = false)
    private Integer l11IntervalMinutes = 1440;

    @Column(name = "l21_interval_minutes", nullable = false)
    private Integer l21IntervalMinutes = 1440;

    @Column(name = "l22_interval_minutes", nullable = false)
    private Integer l22IntervalMinutes = 10080;

    @Column(name = "unassigned_customer_initial_minutes", nullable = false)
    private Integer unassignedCustomerInitialMinutes = 1440;

    @Column(name = "unassigned_customer_repeat_minutes", nullable = false)
    private Integer unassignedCustomerRepeatMinutes = 720;

    @Column(name = "unassigned_lead_initial_minutes", nullable = false)
    private Integer unassignedLeadInitialMinutes = 1440;

    @Column(name = "unassigned_lead_repeat_minutes", nullable = false)
    private Integer unassignedLeadRepeatMinutes = 720;

    @Column(name = "utvc_north_south_cost_rate_vnd", nullable = false, precision = 19, scale = 2)
    private BigDecimal utvcNorthSouthCostRateVnd = BigDecimal.ZERO;

    @Column(name = "warehouse_address_initial_minutes", nullable = false)
    private Integer warehouseAddressInitialMinutes = 1440;
    @Column(name = "warehouse_address_repeat_minutes", nullable = false)
    private Integer warehouseAddressRepeatMinutes = 180;
    @Column(name = "warehouse_debt_initial_minutes", nullable = false)
    private Integer warehouseDebtInitialMinutes = 10080;
    @Column(name = "warehouse_debt_repeat_minutes", nullable = false)
    private Integer warehouseDebtRepeatMinutes = 10080;

    @Column(name = "customer_inactive_first_days", nullable = false)
    private Integer customerInactiveFirstDays = 30;
    @Column(name = "customer_inactive_second_days", nullable = false)
    private Integer customerInactiveSecondDays = 60;
    @Column(name = "customer_inactive_third_days", nullable = false)
    private Integer customerInactiveThirdDays = 90;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
