package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.math.BigDecimal;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_customer")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String code;

    @Column(name = "full_name", nullable = false)
    private String fullName;

    @Column(name = "company_name", length = 255)
    private String companyName;

    @Column(length = 30)
    private String phone;

    private String email;

    private String category;

    @Column(name = "tax_code", length = 50)
    private String taxCode;

    @Column(name = "business_type", length = 50)
    private String businessType;

    @Column(name = "china_vietnam_rate_kg")
    private BigDecimal chinaVietnamRateKg;

    @Column(name = "china_vietnam_rate_cbm")
    private BigDecimal chinaVietnamRateCbm;

    @Column(name = "wallet_balance_vnd", nullable = false, precision = 20, scale = 2)
    private BigDecimal walletBalanceVnd = BigDecimal.ZERO;

    @Column(name = "lead_source")
    private String leadSource;

    @Column(length = 500)
    private String address;

    @Column(length = 255)
    private String province;

    @Column(length = 255)
    private String ward;

    @Column(name = "detail_address", length = 500)
    private String detailAddress;

    @Column(length = 1000)
    private String note;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User createdBy;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_care_staff_id")
    private User customerCareStaff;

    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
