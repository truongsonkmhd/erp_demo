package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_customer_care_log")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CustomerCareLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(name = "lead_id", nullable = false)
    private Long leadId;

    @Column(name = "care_progress", nullable = false)
    private String careProgress;

    @Column(name = "care_progress_note", length = 1000)
    private String careProgressNote;

    @Column(name = "data_evaluation", length = 64)
    private String dataEvaluation;

    @Column(name = "has_issue", nullable = false)
    private Boolean hasIssue = false;

    @Column(name = "issue_note", length = 1000)
    private String issueNote;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "changed_by")
    private User changedBy;

    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
