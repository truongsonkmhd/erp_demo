package com.xxxx.ddd.domain.model.entity;

import com.xxxx.ddd.domain.model.workflow.OrderSource;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalDate;

/**
 * Đơn hàng. Tên class không dùng "Order" vì đó là từ khoá JPQL.
 */
@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_order")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CustomerOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    /** Mã kỹ thuật bất biến dùng để nhận diện bản ghi, không phải mã UTNK/UTVC nghiệp vụ. */
    @Column(name = "internal_code", nullable = false, unique = true, updatable = false, length = 40)
    private String internalCode;

    @Column(name = "order_code", unique = true, length = 50)
    private String orderCode;

    @PrePersist
    void ensureInternalCode() {
        if (internalCode == null || internalCode.isBlank()) {
            internalCode = "ORD-" + java.util.UUID.randomUUID().toString().replace("-", "").toUpperCase(java.util.Locale.ROOT);
        }
    }

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Column(name = "lead_id")
    private Long leadId;

    @Column(name = "batch_code", length = 50)
    private String batchCode;

    @Column(name = "service_type")
    private String serviceType;

    @Column(name = "contract_type", length = 32)
    private String contractType;

    @Column(name = "product_name")
    private String productName;

    private String category;

    private BigDecimal quantity;

    @Column(name = "unit_price_rmb")
    private BigDecimal unitPriceRmb;

    @Column(name = "total_payment_amount_vnd")
    private BigDecimal totalPaymentAmountVnd;

    @Column(name = "paid_at")
    private LocalDate paidAt;

    @Column(name = "net_profit_vnd", nullable = false)
    private BigDecimal netProfitVnd = BigDecimal.ZERO;

    @Column(name = "order_status", length = 50)
    private String orderStatus;

    @Column(name = "shipment_status", length = 50)
    private String shipmentStatus;

    @Column(name = "freight_payment_status", length = 50)
    private String freightPaymentStatus;

    @Column(name = "document_status", length = 50)
    private String documentStatus;

    @Column(name = "document_handed_over_at")
    private LocalDateTime documentHandedOverAt;

    /** NEW / OLD — chốt lúc Đã bàn giao theo cửa sổ 30 ngày. */
    @Column(name = "salary_customer_kind", length = 10)
    private String salaryCustomerKind;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignee_id")
    private User assignee;

    /** Sale tạo hồ sơ khách hàng; dùng quy doanh thu và hiển thị Tên Sales. */
    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sales_owner_id")
    private User salesOwner;

    @Column(length = 1000)
    private String notes;

    /** Extended ProjectSale fields (weight, freight rates, FX…) from Sheets/Excel sync. */
    @Column(name = "sale_overlay_json", columnDefinition = "LONGTEXT")
    private String saleOverlayJson;

    @Column(name = "edit_approval_status", nullable = false, length = 20)
    private String editApprovalStatus = "NONE";

    @Column(name = "edit_requested_by")
    private Long editRequestedBy;

    @Column(name = "edit_approved_by")
    private Long editApprovedBy;

    @Column(name = "edit_requested_at")
    private LocalDateTime editRequestedAt;

    @Column(name = "edit_approved_at")
    private LocalDateTime editApprovedAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private OrderSource source = OrderSource.MANUAL;

    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
