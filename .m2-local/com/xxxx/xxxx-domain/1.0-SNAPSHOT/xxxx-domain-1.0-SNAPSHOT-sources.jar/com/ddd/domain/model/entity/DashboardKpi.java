package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_dashboard_kpi", uniqueConstraints = @UniqueConstraint(name = "uk_dashboard_kpi_user_month", columnNames = {"user_id", "period_month"}))
public class DashboardKpi {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "period_month", nullable = false, length = 7)
    private String periodMonth;

    @Column(name = "total_data", nullable = false)
    private BigDecimal totalData;
    @Column(name = "overall_data", nullable = false)
    private BigDecimal overallData;
    @Column(name = "wrong_insight", nullable = false)
    private BigDecimal wrongInsight;
    @Column(name = "level_l0", nullable = false)
    private BigDecimal levelL0;
    @Column(name = "level_l1", nullable = false)
    private BigDecimal levelL1;
    @Column(name = "level_l2", nullable = false)
    private BigDecimal levelL2;
    @Column(name = "level_l3", nullable = false)
    private BigDecimal levelL3;
    @Column(name = "level_l5", nullable = false)
    private BigDecimal levelL5;
    @Column(name = "correct_insight", nullable = false)
    private BigDecimal correctInsight;
    @Column(name = "new_customers", nullable = false)
    private BigDecimal newCustomers;
    @Column(name = "new_profit_vnd", nullable = false)
    private BigDecimal newProfitVnd;
    @Column(name = "conversion_time_days", nullable = false)
    private BigDecimal conversionTimeDays;
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updated_by")
    private User updatedBy;
}
