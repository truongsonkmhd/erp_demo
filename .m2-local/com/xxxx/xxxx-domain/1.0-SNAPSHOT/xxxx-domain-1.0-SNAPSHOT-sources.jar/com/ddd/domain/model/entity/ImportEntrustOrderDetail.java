package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;

@Getter @Setter @Accessors(chain = true) @NoArgsConstructor @AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity @Table(name = "tbl_order_import_entrust_detail")
public class ImportEntrustOrderDetail {
    @Id @Column(name = "order_id") private Long orderId;
    @Column(name = "total_cost_rmb", precision = 20, scale = 4) private BigDecimal totalCostRmb;
    @Column(name = "total_goods_rmb", precision = 20, scale = 4) private BigDecimal totalGoodsRmb;
    @Column(name = "cost_exchange_rate", precision = 20, scale = 4) private BigDecimal costExchangeRate;
    @Column(name = "floor_exchange_rate", precision = 20, scale = 4) private BigDecimal floorExchangeRate;
    @Column(name = "total_goods_cost_vnd", precision = 20, scale = 2) private BigDecimal totalGoodsCostVnd;
    @Column(name = "total_goods_selling_vnd", precision = 20, scale = 2) private BigDecimal totalGoodsSellingVnd;
    @Column(name = "import_service_fee_vnd", precision = 20, scale = 2) private BigDecimal importServiceFeeVnd;
    @Column(name = "total_revenue_vnd", precision = 20, scale = 2) private BigDecimal totalRevenueVnd;
    @Column(name = "remaining_payment_vnd", precision = 20, scale = 2) private BigDecimal remainingPaymentVnd;
    @Column(name = "cost_profit_vnd", precision = 20, scale = 2) private BigDecimal costProfitVnd;
    @Column(name = "floor_profit_vnd", precision = 20, scale = 2) private BigDecimal floorProfitVnd;
}
