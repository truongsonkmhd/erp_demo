package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_lead_kpi_employee")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class LeadKpiEmployee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "period_id")
    private LeadKpiPeriod period;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id")
    private User user;

    @Column(name = "comment", length = 2000)
    private String comment;

    @Column(name = "total_percent", nullable = false, precision = 8, scale = 2)
    private BigDecimal totalPercent = BigDecimal.ZERO;

    /** A / B / C */
    @Column(name = "grade", length = 1)
    private String grade;

    @Column(name = "coefficient", nullable = false, precision = 8, scale = 4)
    private BigDecimal coefficient = BigDecimal.ONE;

    @ToString.Exclude
    @OneToMany(mappedBy = "kpiEmployee", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LeadKpiScore> scores = new ArrayList<>();

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public LeadKpiEmployee addScore(LeadKpiScore score) {
        scores.add(score);
        score.setKpiEmployee(this);
        return this;
    }
}
