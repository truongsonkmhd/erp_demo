package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_lead_kpi_score")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class LeadKpiScore {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "kpi_employee_id")
    private LeadKpiEmployee kpiEmployee;

    /** attendance / deadline / self_data / telesale / quote / meeting / convert */
    @Column(name = "criterion_id", nullable = false, length = 30)
    private String criterionId;

    @Column(name = "actual_value", nullable = false, precision = 12, scale = 4)
    private BigDecimal actualValue = BigDecimal.ZERO;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
