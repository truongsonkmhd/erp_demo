package com.xxxx.ddd.domain.model.entity;

import com.xxxx.ddd.domain.model.workflow.LeadMarketingStatus;
import com.xxxx.ddd.domain.model.workflow.LeadStage;
import com.xxxx.ddd.domain.model.workflow.LeadTaskStatus;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_marketing_lead")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class MarketingLead {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String code;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Column(name = "full_name", nullable = false)
    private String fullName;

    @Column(length = 30)
    private String phone;

    private String email;

    private String category;

    @Column(name = "lead_source")
    private String leadSource;

    @Column(name = "lead_source_note", length = 1000)
    private String leadSourceNote;

    @Transient
    private String campaignNames;

    @Column(length = 1000)
    private String note;

    @Column(name = "initial_need", length = 1000)
    private String initialNeed;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private LeadStage stage = LeadStage.MARKETING;

    @Enumerated(EnumType.STRING)
    @Column(name = "marketing_status", nullable = false, length = 20)
    private LeadMarketingStatus marketingStatus = LeadMarketingStatus.DRAFT;

    @Enumerated(EnumType.STRING)
    @Column(name = "task_status", nullable = false, length = 20)
    private LeadTaskStatus taskStatus = LeadTaskStatus.NONE;

    @Column(name = "manager_notified_at")
    private LocalDateTime managerNotifiedAt;

    @Column(name = "care_progress")
    private String careProgress;

    @Column(name = "care_progress_note", length = 1000)
    private String careProgressNote;

    @Column(name = "data_insight_correct", nullable = false)
    private Boolean dataInsightCorrect = false;

    @Column(name = "data_insight_at")
    private LocalDateTime dataInsightAt;

    @Column(name = "care_l4_at")
    private LocalDateTime careL4At;

    @Column(name = "order_created_at")
    private LocalDateTime orderCreatedAt;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User createdBy;

    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
