package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.xxxx.ddd.domain.model.auth.FixedRoleLevel;

@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_role")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String code;

    @Column(nullable = false, length = 100)
    private String name;

    private String summary;

    @Column(name = "enabled_levels", length = 120)
    private String enabledLevels;

    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToMany
    @JoinTable(
            name = "tbl_role_permission",
            joinColumns = @JoinColumn(name = "role_id"),
            inverseJoinColumns = @JoinColumn(name = "permission_id")
    )
    private Set<Permission> permissions = new HashSet<>();

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "role", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<RoleLevelPermission> levelPermissions = new HashSet<>();

    public boolean isAdmin() {
        return code != null && "admin".equalsIgnoreCase(code.trim());
    }

    public boolean isSale() {
        return code != null && "sale".equalsIgnoreCase(code.trim());
    }

    public boolean hasNoLevels() {
        if (code == null || code.isBlank()) {
            return false;
        }
        String normalized = code.trim().toLowerCase();
        return "admin".equals(normalized);
    }

    public boolean hasOnlyOtherLevel() {
        if (code == null || code.isBlank()) {
            return false;
        }
        String normalized = code.trim().toLowerCase();
        return "warehouse".equals(normalized) || "accounting".equals(normalized);
    }

    public Set<Permission> permissionsForLevel(String levelCode) {
        if (levelPermissions == null || levelCode == null) {
            return Set.of();
        }
        return levelPermissions.stream()
                .filter(item -> levelCode.equals(item.getLevelCode()))
                .map(RoleLevelPermission::getPermission)
                .collect(Collectors.toCollection(HashSet::new));
    }

    public void replaceLevelPermissions(String levelCode, Set<Permission> permissions) {
        if (levelPermissions == null) {
            levelPermissions = new HashSet<>();
        }
        Set<Long> desiredPermissionIds = permissions == null
                ? Set.of()
                : permissions.stream()
                .map(Permission::getId)
                .filter(id -> id != null)
                .collect(Collectors.toSet());

        levelPermissions.removeIf(item ->
                levelCode.equals(item.getLevelCode())
                        && (item.getPermission() == null
                        || item.getPermission().getId() == null
                        || !desiredPermissionIds.contains(item.getPermission().getId())));

        Set<Long> existingPermissionIds = levelPermissions.stream()
                .filter(item -> levelCode.equals(item.getLevelCode()))
                .map(item -> item.getPermission() == null ? null : item.getPermission().getId())
                .filter(id -> id != null)
                .collect(Collectors.toSet());

        if (permissions == null) {
            return;
        }
        for (Permission permission : permissions) {
            if (permission.getId() != null && existingPermissionIds.contains(permission.getId())) {
                continue;
            }
            RoleLevelPermission link = new RoleLevelPermission()
                    .setRole(this)
                    .setLevelCode(levelCode)
                    .setPermission(permission);
            levelPermissions.add(link);
        }
    }

    public List<FixedRoleLevel> resolvedLevels() {
        if (hasNoLevels()) {
            return List.of();
        }
        if (hasOnlyOtherLevel()) {
            return List.of(FixedRoleLevel.OTHER);
        }
        List<FixedRoleLevel> selected = parseEnabledLevels();
        return selected.isEmpty() ? FixedRoleLevel.all() : selected;
    }

    public void applyEnabledLevels(Collection<String> levelCodes) {
        if (hasNoLevels()) {
            this.enabledLevels = "";
            return;
        }
        if (hasOnlyOtherLevel()) {
            this.enabledLevels = FixedRoleLevel.OTHER.getCode();
            pruneLevelPermissions(Set.of(FixedRoleLevel.OTHER.getCode()));
            return;
        }
        if (levelCodes == null) {
            return;
        }
        List<FixedRoleLevel> selected = levelCodes.stream()
                .map(FixedRoleLevel::fromCode)
                .flatMap(java.util.Optional::stream)
                .distinct()
                .sorted(Comparator.comparingInt(Enum::ordinal))
                .toList();
        if (selected.isEmpty()) {
            throw new IllegalArgumentException("Vai trò cần giữ ít nhất 1 cấp bậc");
        }
        this.enabledLevels = selected.stream()
                .map(FixedRoleLevel::getCode)
                .collect(Collectors.joining(","));
        pruneLevelPermissions(selected.stream().map(FixedRoleLevel::getCode).collect(Collectors.toSet()));
    }

    private List<FixedRoleLevel> parseEnabledLevels() {
        if (enabledLevels == null || enabledLevels.isBlank()) {
            return List.of();
        }
        return Arrays.stream(enabledLevels.split(","))
                .map(String::trim)
                .map(FixedRoleLevel::fromCode)
                .flatMap(java.util.Optional::stream)
                .distinct()
                .sorted(Comparator.comparingInt(Enum::ordinal))
                .toList();
    }

    private void pruneLevelPermissions(Set<String> keepCodes) {
        if (levelPermissions == null || keepCodes == null) {
            return;
        }
        levelPermissions.removeIf(item -> item.getLevelCode() == null || !keepCodes.contains(item.getLevelCode()));
    }
}
