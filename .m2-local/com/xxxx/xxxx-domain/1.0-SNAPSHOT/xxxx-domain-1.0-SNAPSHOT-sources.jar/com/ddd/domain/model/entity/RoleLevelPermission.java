package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(
        name = "tbl_role_level_permission",
        uniqueConstraints = @UniqueConstraint(
                name = "uk_role_level_permission",
                columnNames = {"role_id", "level_code", "permission_id"}
        )
)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class RoleLevelPermission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "role_id", nullable = false)
    private Role role;

    @EqualsAndHashCode.Include
    @Column(name = "level_code", nullable = false, length = 50)
    private String levelCode;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "permission_id", nullable = false)
    private Permission permission;

    @EqualsAndHashCode.Include
    public Long getPermissionId() {
        return permission == null ? null : permission.getId();
    }
}
