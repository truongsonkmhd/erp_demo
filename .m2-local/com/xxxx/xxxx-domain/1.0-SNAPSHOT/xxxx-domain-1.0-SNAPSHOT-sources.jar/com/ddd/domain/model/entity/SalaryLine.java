package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_salary_line")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class SalaryLine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "period_id")
    private SalaryPeriod period;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id")
    private User user;

    /** sales / senior / manager / director */
    @Column(nullable = false, length = 20)
    private String scheme = "sales";

    @Column(name = "base_salary", nullable = false)
    private BigDecimal baseSalary = BigDecimal.ZERO;

    @Column(name = "kpi_percent", nullable = false)
    private BigDecimal kpiPercent = BigDecimal.ZERO;

    @Column(nullable = false)
    private BigDecimal coefficient = BigDecimal.ONE;

    @Column(name = "new_kpi_vnd", nullable = false)
    private BigDecimal newKpiVnd = BigDecimal.ZERO;

    @Column(name = "old_kpi_vnd", nullable = false)
    private BigDecimal oldKpiVnd = BigDecimal.ZERO;

    @Column(name = "new_actual_vnd", nullable = false)
    private BigDecimal newActualVnd = BigDecimal.ZERO;

    @Column(name = "old_actual_vnd", nullable = false)
    private BigDecimal oldActualVnd = BigDecimal.ZERO;

    @Column(name = "actual_is_override", nullable = false)
    private Boolean actualIsOverride = false;

    @Column(name = "payout_vnd", nullable = false)
    private BigDecimal payoutVnd = BigDecimal.ZERO;

    @Column(name = "commission_vnd", nullable = false)
    private BigDecimal commissionVnd = BigDecimal.ZERO;

    @Column(name = "total_vnd", nullable = false)
    private BigDecimal totalVnd = BigDecimal.ZERO;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
