package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_salary_order")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class SalaryOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "salary_line_id")
    private SalaryLine salaryLine;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "order_id")
    private CustomerOrder order;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    /** NEW / OLD */
    @Column(name = "customer_kind", nullable = false, length = 10)
    private String customerKind;

    @Column(name = "net_profit_vnd", nullable = false)
    private BigDecimal netProfitVnd = BigDecimal.ZERO;

    @Column(name = "handed_over_at", nullable = false)
    private LocalDateTime handedOverAt;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignee_id")
    private User assignee;

    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
