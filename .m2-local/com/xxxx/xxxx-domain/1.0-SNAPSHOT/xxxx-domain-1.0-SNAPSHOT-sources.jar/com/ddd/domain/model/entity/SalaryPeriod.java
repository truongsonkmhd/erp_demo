package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_salary_period")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class SalaryPeriod {

    public static final String STATUS_DRAFT = "DRAFT";
    public static final String STATUS_LOCKED = "LOCKED";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    /** YYYY-MM */
    @Column(nullable = false, unique = true, length = 7)
    private String period;

    @Column(nullable = false, length = 20)
    private String status = STATUS_DRAFT;

    @Column(name = "dept_profit_override_vnd")
    private BigDecimal deptProfitOverrideVnd;

    @Column(name = "locked_at")
    private LocalDateTime lockedAt;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "locked_by")
    private User lockedBy;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public boolean isLocked() {
        return STATUS_LOCKED.equalsIgnoreCase(status);
    }
}
