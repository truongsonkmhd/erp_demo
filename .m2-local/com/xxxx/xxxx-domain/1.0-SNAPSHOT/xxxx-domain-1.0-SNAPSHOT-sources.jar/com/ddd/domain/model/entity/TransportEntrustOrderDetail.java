package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.time.LocalDate;

@Getter @Setter @Accessors(chain = true) @NoArgsConstructor @AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity @Table(name = "tbl_order_transport_entrust_detail")
public class TransportEntrustOrderDetail {
    @Id @Column(name = "order_id") private Long orderId;
    @Column(name = "transport_mode", length = 8) private String transportMode;
    @Column(name = "vehicle_code", length = 50) private String vehicleCode;
    @Column(name = "supplier_code", length = 50) private String supplierCode;
    @Column(name = "warehouse_received_date") private LocalDate warehouseReceivedDate;
    @Column(name = "route_status", length = 40) private String routeStatus;
    @Column(name = "calculation_unit", length = 20) private String calculationUnit;
    @Column(name = "weight_kg", precision = 20, scale = 4) private BigDecimal weightKg;
    @Column(name = "volume_cbm", precision = 20, scale = 4) private BigDecimal volumeCbm;
    @Column(name = "cost_china_vietnam_rate_vnd", precision = 20, scale = 2) private BigDecimal costChinaVietnamRateVnd;
    @Column(name = "floor_china_vietnam_rate_vnd", precision = 20, scale = 2) private BigDecimal floorChinaVietnamRateVnd;
    @Column(name = "selling_china_vietnam_rate_vnd", precision = 20, scale = 2) private BigDecimal sellingChinaVietnamRateVnd;
    @Column(name = "total_cost_china_vietnam_vnd", precision = 20, scale = 2) private BigDecimal totalCostChinaVietnamVnd;
    @Column(name = "total_floor_china_vietnam_vnd", precision = 20, scale = 2) private BigDecimal totalFloorChinaVietnamVnd;
    @Column(name = "total_selling_china_vietnam_vnd", precision = 20, scale = 2) private BigDecimal totalSellingChinaVietnamVnd;
    @Column(name = "cost_north_south_rate_vnd", precision = 20, scale = 2) private BigDecimal costNorthSouthRateVnd;
    @Column(name = "total_cost_north_south_vnd", precision = 20, scale = 2) private BigDecimal totalCostNorthSouthVnd;
    @Column(name = "cost_surcharge_vnd", precision = 20, scale = 2) private BigDecimal costSurchargeVnd;
    @Column(name = "delivery_address", length = 1000) private String deliveryAddress;
    @Column(name = "delivery_province", length = 255) private String deliveryProvince;
    @Column(name = "delivery_ward", length = 255) private String deliveryWard;
    @Column(name = "delivery_detail_address", length = 500) private String deliveryDetailAddress;
    @Column(name = "selling_north_south_rate_vnd", precision = 20, scale = 2) private BigDecimal sellingNorthSouthRateVnd;
    @Column(name = "total_revenue_north_south_vnd", precision = 20, scale = 2) private BigDecimal totalRevenueNorthSouthVnd;
    @Column(name = "input_import_tax_vnd", precision = 20, scale = 2) private BigDecimal inputImportTaxVnd;
    @Column(name = "input_vat_vnd", precision = 20, scale = 2) private BigDecimal inputVatVnd;
    @Column(name = "output_import_tax_vnd", precision = 20, scale = 2) private BigDecimal outputImportTaxVnd;
    @Column(name = "output_vat_vnd", precision = 20, scale = 2) private BigDecimal outputVatVnd;
    @Column(name = "selling_surcharge_vnd", precision = 20, scale = 2) private BigDecimal sellingSurchargeVnd;
    @Column(name = "total_revenue_vnd", precision = 20, scale = 2) private BigDecimal totalRevenueVnd;
    @Column(name = "utvc_debt_vnd", precision = 20, scale = 2) private BigDecimal utvcDebtVnd;
    @Column(name = "revenue_destinations_json", columnDefinition = "TEXT") private String revenueDestinationsJson;
    @Column(name = "wallet_credit_vnd", nullable = false, precision = 20, scale = 2) private BigDecimal walletCreditVnd = BigDecimal.ZERO;
    @Column(name = "other_revenue_vnd", precision = 20, scale = 2) private BigDecimal otherRevenueVnd;
    @Column(name = "other_revenue_note", length = 1000) private String otherRevenueNote;
    @Column(name = "statement_amount_vnd", precision = 20, scale = 2) private BigDecimal statementAmountVnd;
    @Column(name = "cost_profit_vnd", precision = 20, scale = 2) private BigDecimal costProfitVnd;
    @Column(name = "floor_profit_vnd", precision = 20, scale = 2) private BigDecimal floorProfitVnd;
}
