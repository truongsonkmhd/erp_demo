package com.xxxx.ddd.domain.model.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbl_user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String username;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(name = "full_name", nullable = false)
    private String fullName;

    private String phone;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "role_id")
    private Role role;

    @Column(name = "level_code", length = 50)
    private String levelCode;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sale_room_id")
    private SaleRoom saleRoom;

    @Column(name = "base_salary")
    private BigDecimal baseSalary;

    private Boolean active = true;

    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private Token token;

    /** In-memory catalog used so admin always has every permission without persisting a dirty Role. */
    @Transient
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private Set<Permission> catalogPermissions;

    public Set<Permission> getEffectivePermissions() {
        if (role == null) {
            return Collections.emptySet();
        }
        if (role.isAdmin()) {
            if (catalogPermissions != null && !catalogPermissions.isEmpty()) {
                return catalogPermissions;
            }
            return role.getPermissions() != null ? role.getPermissions() : Collections.emptySet();
        }
        if (role.hasNoLevels()) {
            return role.getPermissions() != null ? role.getPermissions() : Collections.emptySet();
        }
        Set<Permission> merged = new HashSet<>();
        if (role.getPermissions() != null) {
            merged.addAll(role.getPermissions());
        }
        if (levelCode != null && !levelCode.isBlank()) {
            merged.addAll(role.permissionsForLevel(levelCode));
        }
        if (role.hasOnlyOtherLevel()) {
            merged.addAll(role.permissionsForLevel("other"));
        }
        merged.removeIf(permission -> permission == null || permission.getCode() == null || permission.getCode().isBlank());
        return merged;
    }

    public String getRoleAuthority() {
        if (role == null || role.getCode() == null || role.getCode().isBlank()) {
            return "ROLE_USER";
        }
        return "ROLE_" + role.getCode().trim().toUpperCase();
    }

    public String getRoleCode() {
        return role == null ? null : role.getCode();
    }
}
