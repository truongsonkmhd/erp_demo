package com.xxxx.ddd.domain.model.query;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.Set;

@Data
public class OrderSearchCriteria {
    private String query;
    private String customerCode;
    private String orderCode;
    private String batchCode;
    private String customerName;
    private String phone;
    private String category;
    private String productName;
    private String salesName;
    private String customerCareName;
    private String contractType;
    private LocalDateTime createdFrom;
    private LocalDateTime createdToExclusive;
    private Long assigneeId;
    private Long customerCareStaffId;
    private Set<Long> customerIds;
    private int pageNo = 1;
    private int pageSize = 10;
}
