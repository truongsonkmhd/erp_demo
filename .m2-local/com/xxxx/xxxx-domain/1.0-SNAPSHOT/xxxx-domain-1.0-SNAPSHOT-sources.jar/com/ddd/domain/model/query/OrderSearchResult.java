package com.xxxx.ddd.domain.model.query;

import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import java.util.List;

@Getter
@AllArgsConstructor
public class OrderSearchResult {
    private final List<CustomerOrder> items;
    private final long totalElements;
}
