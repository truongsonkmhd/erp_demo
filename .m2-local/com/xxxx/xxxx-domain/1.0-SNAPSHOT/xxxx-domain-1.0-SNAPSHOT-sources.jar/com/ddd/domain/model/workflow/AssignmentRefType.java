package com.xxxx.ddd.domain.model.workflow;

/**
 * Chặng mà một bản ghi phân việc thuộc về.
 */
public enum AssignmentRefType {
    MARKETING_LEAD,
    TASK,
    CUSTOMER,
    ORDER
}
