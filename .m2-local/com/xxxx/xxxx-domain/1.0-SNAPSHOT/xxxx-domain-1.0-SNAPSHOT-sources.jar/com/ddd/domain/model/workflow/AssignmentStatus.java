package com.xxxx.ddd.domain.model.workflow;

/**
 * REASSIGNED giữ lại dấu vết khi quản lý đổi người trong lúc assign.
 */
public enum AssignmentStatus {
    PENDING,
    ACCEPTED,
    REASSIGNED,
    CANCELLED
}
