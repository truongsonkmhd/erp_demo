package com.xxxx.ddd.domain.model.workflow;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;

/** Helpers for MarketingLead.campaignNames stored as JSON array text. */
public final class CampaignNamesJson {

    /** Campaign name assigned when a lead is created manually (not via Sheets import). */
    public static final String MANUAL_DEFAULT_CAMPAIGN_NAME = "Tự nhiên";

    private CampaignNamesJson() {
    }

    public record CampaignEntry(String at, String name) {
    }

    public static String defaultManualJson() {
        return toJson(List.of(MANUAL_DEFAULT_CAMPAIGN_NAME));
    }

    public static List<CampaignEntry> parseEntries(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        String trimmed = json.trim();
        if (!trimmed.startsWith("[") || !trimmed.endsWith("]")) {
            return List.of(new CampaignEntry(null, trimmed));
        }
        String inner = trimmed.substring(1, trimmed.length() - 1).trim();
        if (inner.isEmpty()) {
            return List.of();
        }
        List<CampaignEntry> out = new ArrayList<>();
        for (String element : splitJsonArrayElements(inner)) {
            String value = element.trim();
            if (value.isEmpty()) {
                continue;
            }
            if (value.startsWith("{")) {
                CampaignEntry entry = parseObjectElement(value);
                if (entry != null) {
                    out.add(entry);
                }
                continue;
            }
            String name = unwrapJsonString(value);
            if (name != null && !name.isBlank()) {
                out.add(new CampaignEntry(null, name.trim()));
            }
        }
        return out;
    }

    public static List<String> parse(String json) {
        return parseEntries(json).stream().map(CampaignEntry::name).toList();
    }

    /** Latest non-manual campaign name for ads reporting attribution. */
    public static String latestCampaignName(String json) {
        List<CampaignEntry> sorted = sortEntries(parseEntries(json));
        for (int i = sorted.size() - 1; i >= 0; i--) {
            String name = sorted.get(i).name();
            if (name == null || name.isBlank()) {
                continue;
            }
            String trimmed = name.trim();
            if (MANUAL_DEFAULT_CAMPAIGN_NAME.equalsIgnoreCase(trimmed)) {
                continue;
            }
            return trimmed;
        }
        return null;
    }

    /**
     * Camp tiếp cận tại thời điểm lead được tạo (dùng cho báo cáo Ads).
     * Ưu tiên entry có {@code at <= leadCreatedAt} mới nhất; không có timestamp thì lấy entry đầu tiên (không phải Tự nhiên).
     */
    public static String campaignNameAt(LocalDateTime leadCreatedAt, String json) {
        List<CampaignEntry> entries = parseEntries(json);
        if (entries.isEmpty()) {
            return null;
        }
        if (leadCreatedAt == null) {
            return latestCampaignName(json);
        }

        boolean anyTimestamped = entries.stream().anyMatch(entry -> entry.at() != null && !entry.at().isBlank());
        if (anyTimestamped) {
            CampaignEntry matched = null;
            LocalDateTime matchedAt = null;
            for (CampaignEntry entry : sortEntries(entries)) {
                if (isManualNatural(entry.name())) {
                    continue;
                }
                LocalDateTime at = parseEntryAt(entry.at());
                if (at == null || at.isAfter(leadCreatedAt)) {
                    continue;
                }
                if (matchedAt == null || at.isAfter(matchedAt)) {
                    matched = entry;
                    matchedAt = at;
                }
            }
            if (matched != null) {
                return matched.name().trim();
            }
        }

        for (CampaignEntry entry : entries) {
            if (!isManualNatural(entry.name())) {
                return entry.name().trim();
            }
        }
        return latestCampaignName(json);
    }

    /** Lead nhập tay (nút data tự nhiên): chỉ có đúng một chiến dịch {@link #MANUAL_DEFAULT_CAMPAIGN_NAME}. */
    public static boolean isManualNaturalOnly(String json) {
        if (json == null || json.isBlank()) {
            return false;
        }
        List<CampaignEntry> entries = parseEntries(json);
        return entries.size() == 1
                && entries.get(0).at() == null
                && MANUAL_DEFAULT_CAMPAIGN_NAME.equalsIgnoreCase(entries.get(0).name().trim());
    }

    public static String toJson(List<String> names) {
        if (names == null || names.isEmpty()) {
            return "[]";
        }
        LinkedHashSet<String> unique = new LinkedHashSet<>();
        for (String name : names) {
            if (name != null && !name.isBlank()) {
                unique.add(name.trim());
            }
        }
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (String name : unique) {
            if (!first) {
                sb.append(',');
            }
            first = false;
            sb.append('"').append(escape(name)).append('"');
        }
        sb.append(']');
        return sb.toString();
    }

    public static String toJsonEntries(List<CampaignEntry> entries) {
        if (entries == null || entries.isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (CampaignEntry entry : sortEntries(entries)) {
            if (entry == null || entry.name() == null || entry.name().isBlank()) {
                continue;
            }
            if (!first) {
                sb.append(',');
            }
            first = false;
            if (entry.at() != null && !entry.at().isBlank()) {
                sb.append("{\"at\":\"").append(escape(entry.at())).append("\",\"name\":\"")
                        .append(escape(entry.name().trim())).append("\"}");
            } else {
                sb.append('"').append(escape(entry.name().trim())).append('"');
            }
        }
        sb.append(']');
        return sb.toString();
    }

    /** Append one campaign if missing; returns same string when unchanged. */
    public static String append(String existingJson, String campaignName) {
        if (campaignName == null || campaignName.isBlank()) {
            return existingJson == null || existingJson.isBlank() ? "[]" : existingJson;
        }
        List<CampaignEntry> current = new ArrayList<>(parseEntries(existingJson));
        String next = campaignName.trim();
        if (current.stream().anyMatch(item -> item.at() == null && item.name().equalsIgnoreCase(next))) {
            return existingJson == null || existingJson.isBlank() ? toJsonEntries(current) : existingJson;
        }
        current.add(new CampaignEntry(null, next));
        return toJsonEntries(current);
    }

    /**
     * External data import: append {@code at + campaignName}, sorted by time ascending.
     * Duplicate = same timestamp and same campaign name.
     */
    public static String appendWithTime(String existingJson, String campaignName, LocalDateTime at) {
        if (campaignName == null || campaignName.isBlank()) {
            return existingJson == null || existingJson.isBlank() ? "[]" : existingJson;
        }
        List<CampaignEntry> entries = new ArrayList<>(parseEntries(existingJson));
        String name = campaignName.trim();
        String atIso = at == null ? null : at.withNano(0).toString();
        boolean duplicate = entries.stream().anyMatch(item ->
                name.equalsIgnoreCase(item.name())
                        && (atIso == null ? item.at() == null : atIso.equals(item.at())));
        if (duplicate) {
            return existingJson == null || existingJson.isBlank() ? "[]" : existingJson;
        }
        entries.add(new CampaignEntry(atIso, name));
        return toJsonEntries(entries);
    }

    private static List<CampaignEntry> sortEntries(List<CampaignEntry> entries) {
        return entries.stream()
                .sorted(Comparator.comparing(CampaignEntry::at, Comparator.nullsLast(String::compareTo)))
                .toList();
    }

    private static CampaignEntry parseObjectElement(String objectJson) {
        String name = extractJsonStringField(objectJson, "name");
        if (name == null || name.isBlank()) {
            return null;
        }
        return new CampaignEntry(blankToNull(extractJsonStringField(objectJson, "at")), name.trim());
    }

    private static String extractJsonStringField(String objectJson, String fieldName) {
        String needle = "\"" + fieldName + "\"";
        int pos = objectJson.indexOf(needle);
        if (pos < 0) {
            return null;
        }
        int colon = objectJson.indexOf(':', pos + needle.length());
        if (colon < 0) {
            return null;
        }
        int i = colon + 1;
        while (i < objectJson.length() && Character.isWhitespace(objectJson.charAt(i))) {
            i++;
        }
        if (i >= objectJson.length() || objectJson.charAt(i) != '"') {
            return null;
        }
        i++;
        StringBuilder sb = new StringBuilder();
        boolean escape = false;
        while (i < objectJson.length()) {
            char c = objectJson.charAt(i);
            if (escape) {
                sb.append(c);
                escape = false;
            } else if (c == '\\') {
                escape = true;
            } else if (c == '"') {
                return sb.toString();
            } else {
                sb.append(c);
            }
            i++;
        }
        return null;
    }

    private static String unwrapJsonString(String raw) {
        String trimmed = raw.trim();
        if (trimmed.length() >= 2 && trimmed.startsWith("\"") && trimmed.endsWith("\"")) {
            return unescape(trimmed.substring(1, trimmed.length() - 1));
        }
        return trimmed;
    }

    private static List<String> splitJsonArrayElements(String inner) {
        List<String> elements = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        int depth = 0;
        boolean inQuotes = false;
        boolean escape = false;
        for (int i = 0; i < inner.length(); i++) {
            char c = inner.charAt(i);
            if (escape) {
                current.append(c);
                escape = false;
                continue;
            }
            if (c == '\\' && inQuotes) {
                escape = true;
                current.append(c);
                continue;
            }
            if (c == '"') {
                inQuotes = !inQuotes;
                current.append(c);
                continue;
            }
            if (!inQuotes) {
                if (c == '{' || c == '[') {
                    depth++;
                } else if (c == '}' || c == ']') {
                    depth--;
                } else if (c == ',' && depth == 0) {
                    elements.add(current.toString().trim());
                    current.setLength(0);
                    continue;
                }
            }
            current.append(c);
        }
        if (!current.isEmpty()) {
            elements.add(current.toString().trim());
        }
        return elements;
    }

    private static String blankToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }

    private static String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String unescape(String value) {
        return value.replace("\\\"", "\"").replace("\\\\", "\\");
    }

    private static boolean isManualNatural(String name) {
        return name != null && MANUAL_DEFAULT_CAMPAIGN_NAME.equalsIgnoreCase(name.trim());
    }

    private static LocalDateTime parseEntryAt(String at) {
        if (at == null || at.isBlank()) {
            return null;
        }
        String trimmed = at.trim();
        try {
            return LocalDateTime.parse(trimmed);
        } catch (DateTimeParseException ignored) {
            try {
                return LocalDate.parse(trimmed).atStartOfDay();
            } catch (DateTimeParseException ignoredAgain) {
                return null;
            }
        }
    }
}
