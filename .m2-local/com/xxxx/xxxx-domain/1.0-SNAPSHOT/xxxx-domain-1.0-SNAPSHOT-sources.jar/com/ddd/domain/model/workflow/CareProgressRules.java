package com.xxxx.ddd.domain.model.workflow;

/**
 * Quy ước nhãn tiến trình CSKH. Nhãn đầy đủ do frontend quản lý (CARE_PROGRESS_OPTIONS),
 * backend nhận biết mốc L4 (Ký hợp đồng) để bắt đầu bước hỗ trợ/giao nhiệm vụ.
 * L5 vẫn được chấp nhận để tương thích với dữ liệu đã lưu trước khi đổi mã.
 */
public final class CareProgressRules {

    private static final String SIGNED_CONTRACT_PREFIX = "L4";
    private static final String LEGACY_SIGNED_CONTRACT_PREFIX = "L5";

    private CareProgressRules() {
    }

    /** L4: Khách hàng đã ký hợp đồng. */
    public static boolean isAgreedToUseService(String careProgress) {
        if (careProgress == null) {
            return false;
        }
        String normalized = careProgress.trim().toUpperCase();
        return normalized.startsWith(SIGNED_CONTRACT_PREFIX)
                || normalized.startsWith(LEGACY_SIGNED_CONTRACT_PREFIX);
    }
}
