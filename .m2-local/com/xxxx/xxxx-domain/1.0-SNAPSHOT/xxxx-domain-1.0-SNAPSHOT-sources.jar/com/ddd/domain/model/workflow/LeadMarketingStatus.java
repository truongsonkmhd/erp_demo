package com.xxxx.ddd.domain.model.workflow;

/**
 * Trạng thái phân việc ở chặng marketing.
 */
public enum LeadMarketingStatus {
    DRAFT,
    NOTIFIED_MANAGER,
    ASSIGNED,
    ACCEPTED
}
