package com.xxxx.ddd.domain.model.workflow;

/**
 * Lightweight projection for sheet import phone dedupe (id + phone + campaign_names only).
 */
public record LeadPhoneRef(Long id, String phone, String campaignNames) {
}
