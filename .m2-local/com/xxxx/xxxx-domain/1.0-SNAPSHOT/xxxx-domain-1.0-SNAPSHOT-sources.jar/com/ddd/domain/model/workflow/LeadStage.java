package com.xxxx.ddd.domain.model.workflow;

/**
 * Chặng hiện tại của một lead marketing trong pipeline.
 */
public enum LeadStage {
    MARKETING,
    CARE,
    TASK,
    ORDER_CREATED
}
