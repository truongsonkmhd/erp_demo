package com.xxxx.ddd.domain.model.workflow;

/**
 * Trạng thái phân việc ở chặng giao nhiệm vụ (sau khi CSKH đạt L4).
 */
public enum LeadTaskStatus {
    NONE,
    PENDING,
    ASSIGNED,
    ACCEPTED,
    DONE
}
