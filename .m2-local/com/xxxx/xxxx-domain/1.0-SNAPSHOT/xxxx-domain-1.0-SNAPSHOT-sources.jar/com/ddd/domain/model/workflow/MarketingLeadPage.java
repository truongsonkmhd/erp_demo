package com.xxxx.ddd.domain.model.workflow;

import com.xxxx.ddd.domain.model.entity.MarketingLead;

import java.util.List;

public record MarketingLeadPage(
        List<MarketingLead> items,
        long totalElements,
        int pageNo,
        int pageSize
) {
    public int totalPages() {
        if (pageSize <= 0) return 0;
        return (int) Math.ceil((double) totalElements / (double) pageSize);
    }
}
