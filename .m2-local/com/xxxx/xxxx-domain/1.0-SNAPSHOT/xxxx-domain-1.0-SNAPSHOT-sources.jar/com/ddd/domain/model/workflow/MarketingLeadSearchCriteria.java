package com.xxxx.ddd.domain.model.workflow;

import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Tiêu chí tìm kiếm / phân trang marketing lead (filter trên DB).
 */
@Data
@Accessors(chain = true)
public class MarketingLeadSearchCriteria {
    private List<LeadStage> stages = new ArrayList<>();
    private String name;
    private String phone;
    private String category;
    private String source;
    private String careProgress;
    /** true = đã tạo khách hàng, false = chưa tạo khách hàng, null = tất cả. */
    private Boolean customerCreated;
    /** Lọc theo người đang được phân ở chặng Data. */
    private Long assignedAssigneeId;
    /** Chỉ lấy Data có assignment Sales đang hiệu lực, không giới hạn người nhận. */
    private boolean assignedOnly;
    /** Chỉ lấy Data chưa có phân công đang hiệu lực. */
    private boolean unassigned;
    /** Tên chiến dịch trong campaign_names JSON; giá trị đặc biệt __OTHER__ = không phải Tự nhiên. */
    private String campaignName;
    private String code;
    private String query;
    private LocalDateTime createdFrom;
    private LocalDateTime createdTo;
    /** Chỉ lead do actor tạo (Marketing non-manager). */
    private Long createdById;
    /**
     * Marketing non-manager: thấy mọi lead không phải data tự nhiên + lead tự nhiên do chính mình tạo.
     */
    private Long marketingNaturalScopeActorId;
    /** Lead do actor tạo hoặc được giao (Sale restricted). */
    private Long assigneeOrCreatorId;
    /** Dashboard của trưởng phòng: lead do thành viên phòng tạo hoặc đang được giao cho thành viên phòng. */
    private Long saleRoomId;
    /** Trang Data của Sales Manager: chỉ lead đã được giao cho thành viên trong phòng. */
    private boolean assignedSaleRoomOnly;
    /** Chỉ lead có assignment PENDING cho actor (inbox nhận việc). */
    private Long pendingAssigneeId;
    private int pageNo = 1;
    private int pageSize = 10;
    /** fullName | createdAt */
    private String sortBy;
    /** asc | desc */
    private String sortDir;

    public int offset() {
        int page = Math.max(pageNo, 1);
        int size = normalizedPageSize();
        return (page - 1) * size;
    }

    public int normalizedPageSize() {
        int size = pageSize <= 0 ? 10 : pageSize;
        return Math.min(size, 100);
    }

    public int normalizedPageNo() {
        return Math.max(pageNo, 1);
    }
}
