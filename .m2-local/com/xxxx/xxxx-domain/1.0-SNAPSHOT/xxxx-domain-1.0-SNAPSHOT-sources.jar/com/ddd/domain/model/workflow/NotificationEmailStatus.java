package com.xxxx.ddd.domain.model.workflow;

public enum NotificationEmailStatus {
    PENDING,
    SENT,
    FAILED,
    /** Người gửi tắt kênh mail hoặc người nhận không có email. */
    SKIPPED
}
