package com.xxxx.ddd.domain.model.workflow;

/**
 * Các sự kiện sinh thông báo trong luồng marketing.
 */
public enum NotificationType {
    /** Marketing nhập xong, báo quản lý phân việc. */
    LEAD_READY_FOR_ASSIGN,
    /** Quản lý phân dữ liệu marketing cho nhân viên. */
    LEAD_ASSIGNED,
    /** Nhân viên xác nhận đã nhận dữ liệu marketing. */
    LEAD_ACCEPTED,
    /** CSKH đạt L4, dữ liệu vào tab giao nhiệm vụ. */
    LEAD_READY_FOR_TASK,
    /** Quản lý giao nhiệm vụ cho nhân viên. */
    TASK_ASSIGNED,
    /** Nhân viên xác nhận đã nhận nhiệm vụ. */
    TASK_ACCEPTED,
    /** Đơn hàng được tạo tự động. */
    ORDER_CREATED,
    CUSTOMER_CREATED,
    ORDER_EDIT_REQUESTED,
    ORDER_EDIT_APPROVED,
    WAREHOUSE_ADDRESS_REQUIRED,
    WAREHOUSE_ADDRESS_REMINDER,
    WAREHOUSE_DEBT_REQUIRED,
    WAREHOUSE_DEBT_REMINDER,
    CUSTOMER_INACTIVE_ORDER
}
