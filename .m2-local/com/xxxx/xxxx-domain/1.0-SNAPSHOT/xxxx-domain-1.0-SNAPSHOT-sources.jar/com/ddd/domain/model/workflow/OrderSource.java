package com.xxxx.ddd.domain.model.workflow;

/**
 * AUTO: sinh tự động khi nhân viên nhận nhiệm vụ ở chặng giao nhiệm vụ.
 */
public enum OrderSource {
    AUTO,
    MANUAL
}
