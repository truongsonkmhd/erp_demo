package com.xxxx.ddd.domain.model.workflow;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * KH mới/cũ cho tính lương:
 * - Lúc bàn giao: tái bàn giao trong ≤ 30 ngày kể từ lần trước = OLD.
 * - Lúc tạo đơn thủ công: đơn trước của cùng KH trong ≤ 30 ngày (theo createdAt) = OLD.
 */
public final class SalaryCustomerKindRules {

    public static final int RETURNING_CUSTOMER_DAYS = 30;
    public static final String NEW = "NEW";
    public static final String OLD = "OLD";
    public static final String HANDED_OVER = "Đã bàn giao";

    private SalaryCustomerKindRules() {
    }

    public static boolean isHandedOver(String documentStatus) {
        return documentStatus != null && documentStatus.trim().equals(HANDED_OVER);
    }

    public static String resolveKind(LocalDateTime handoverAt, LocalDateTime previousHandoverAt) {
        if (previousHandoverAt == null || handoverAt == null) {
            return NEW;
        }
        long days = ChronoUnit.DAYS.between(previousHandoverAt.toLocalDate(), handoverAt.toLocalDate());
        return days >= 0 && days <= RETURNING_CUSTOMER_DAYS ? OLD : NEW;
    }

    /** NEW nếu chưa có đơn trước hoặc cách lần tạo đơn trước > 30 ngày. */
    public static String resolveKindByPreviousOrderCreatedAt(LocalDateTime createdAt,
                                                             LocalDateTime previousOrderCreatedAt) {
        return resolveKind(createdAt, previousOrderCreatedAt);
    }
}
