package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;

import java.util.List;
import java.util.Optional;

public interface AssignmentRepository {
    Assignment save(Assignment assignment);

    Optional<Assignment> findById(Long id);

    /** Bản ghi phân việc đang hiệu lực (PENDING hoặc ACCEPTED) của một chặng. */
    Optional<Assignment> findCurrent(AssignmentRefType refType, Long refId);

    Optional<Assignment> findCurrentForUpdate(AssignmentRefType refType, Long refId);

    List<Assignment> findCurrentByAssignee(AssignmentRefType refType, Long assigneeId);

    List<Assignment> findHistory(AssignmentRefType refType, Long refId);

    List<Assignment> findByRefTypeAndRefIds(AssignmentRefType refType, List<Long> refIds);
}
