package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.CareReminderSettings;

import java.util.Optional;

public interface CareReminderSettingsRepository {
    Optional<CareReminderSettings> find();
    CareReminderSettings save(CareReminderSettings settings);
}
