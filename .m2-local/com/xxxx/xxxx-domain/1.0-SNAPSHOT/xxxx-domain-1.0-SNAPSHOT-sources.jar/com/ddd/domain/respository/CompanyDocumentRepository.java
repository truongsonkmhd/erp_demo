package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.CompanyDocument;

import java.util.List;
import java.util.Optional;

public interface CompanyDocumentRepository {
    CompanyDocument save(CompanyDocument document);

    Optional<CompanyDocument> findByIdActive(Long id);

    List<CompanyDocument> findVisibleToUser(Long userId);

    List<CompanyDocument> findVisibleByCategoryId(Long categoryId, Long userId);

    List<CompanyDocument> findActiveByCategoryId(Long categoryId);

    long countByCategoryIdActive(Long categoryId);
}
