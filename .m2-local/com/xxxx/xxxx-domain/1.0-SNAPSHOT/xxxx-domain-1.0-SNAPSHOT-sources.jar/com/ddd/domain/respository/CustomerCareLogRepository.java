package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.CustomerCareLog;

import java.util.List;

public interface CustomerCareLogRepository {
    CustomerCareLog save(CustomerCareLog log);

    java.util.Optional<CustomerCareLog> findById(Long id);

    List<CustomerCareLog> findByLeadId(Long leadId);

    boolean existsByLeadIdAndCareProgress(Long leadId, String careProgress);

    boolean existsByLeadIdAndCareProgressExcludingId(Long leadId, String careProgress, Long id);

    void delete(CustomerCareLog log);
}
