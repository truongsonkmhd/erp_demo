package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import com.xxxx.ddd.domain.model.query.OrderSearchCriteria;
import com.xxxx.ddd.domain.model.query.OrderSearchResult;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface CustomerOrderRepository {
    CustomerOrder save(CustomerOrder order);

    Optional<CustomerOrder> findByIdActive(Long id);

    List<CustomerOrder> findAllActive();

    OrderSearchResult search(OrderSearchCriteria criteria);

    List<CustomerOrder> findByCustomerId(Long customerId);

    Optional<CustomerOrder> findByCustomerIdAndContractTypeActive(Long customerId, String contractType);

    List<CustomerOrder> findByLeadId(Long leadId);

    long countByOrderCodePrefix(String prefix);

    long countByContractTypeAndCreatedAtBetween(String contractType, LocalDateTime from, LocalDateTime toExclusive);

    Optional<CustomerOrder> findByOrderCodeActive(String orderCode);

    Optional<CustomerOrder> findFirstByBatchCodeActive(String batchCode);

    /** Đơn Đã bàn giao trong kỳ YYYY-MM (theo documentHandedOverAt). */
    List<CustomerOrder> findSalaryEligibleByPeriod(String periodYearMonth);
}
