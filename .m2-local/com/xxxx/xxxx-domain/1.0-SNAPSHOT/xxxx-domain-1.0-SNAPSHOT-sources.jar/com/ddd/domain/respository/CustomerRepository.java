package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.Customer;

import java.util.List;
import java.util.Optional;

public interface CustomerRepository {
    Customer save(Customer customer);

    Optional<Customer> findByIdActive(Long id);

    Optional<Customer> findByPhoneActive(String phone);

    Optional<Customer> findByCode(String code);

    List<Customer> findAllActive();

    boolean existsByCode(String code);
}
