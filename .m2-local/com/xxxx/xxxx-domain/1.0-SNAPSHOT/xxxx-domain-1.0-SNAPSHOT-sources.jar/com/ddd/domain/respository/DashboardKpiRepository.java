package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.DashboardKpi;

import java.util.List;
import java.util.Optional;

public interface DashboardKpiRepository {
    Optional<DashboardKpi> findByUserIdAndPeriodMonth(Long userId, String periodMonth);
    List<DashboardKpi> findByUserIdsAndPeriodMonth(List<Long> userIds, String periodMonth);
    DashboardKpi save(DashboardKpi kpi);
}
