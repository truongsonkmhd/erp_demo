package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.DashboardRoomKpi;
import java.util.List;
import java.util.Optional;

public interface DashboardRoomKpiRepository {
    Optional<DashboardRoomKpi> findBySaleRoomIdAndPeriodMonth(Long saleRoomId, String periodMonth);
    List<DashboardRoomKpi> findByPeriodMonth(String periodMonth);
    DashboardRoomKpi save(DashboardRoomKpi entity);
}
