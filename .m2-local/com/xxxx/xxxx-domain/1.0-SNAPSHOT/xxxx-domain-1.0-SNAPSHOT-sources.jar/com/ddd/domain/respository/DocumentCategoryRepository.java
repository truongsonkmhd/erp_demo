package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.DocumentCategory;

import java.util.List;
import java.util.Optional;

public interface DocumentCategoryRepository {
    DocumentCategory save(DocumentCategory category);

    Optional<DocumentCategory> findByIdActive(Long id);

    List<DocumentCategory> findVisibleToUser(Long userId);

    boolean existsByNameForOwner(String name, Long ownerId);

    boolean existsByNameForOwnerAndIdNot(String name, Long ownerId, Long id);

    boolean existsByNameShared(String name);

    boolean existsByNameSharedAndIdNot(String name, Long id);
}
