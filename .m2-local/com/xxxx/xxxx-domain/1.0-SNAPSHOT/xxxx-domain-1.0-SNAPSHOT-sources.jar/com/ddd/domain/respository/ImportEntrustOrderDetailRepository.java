package com.xxxx.ddd.domain.respository;
import com.xxxx.ddd.domain.model.entity.ImportEntrustOrderDetail;
import java.util.Optional;
import java.util.List;
public interface ImportEntrustOrderDetailRepository {
    ImportEntrustOrderDetail save(ImportEntrustOrderDetail detail);
    Optional<ImportEntrustOrderDetail> findByOrderId(Long orderId);
    List<ImportEntrustOrderDetail> findAllByOrderId(Iterable<Long> orderIds);
    void deleteByOrderId(Long orderId);
}
