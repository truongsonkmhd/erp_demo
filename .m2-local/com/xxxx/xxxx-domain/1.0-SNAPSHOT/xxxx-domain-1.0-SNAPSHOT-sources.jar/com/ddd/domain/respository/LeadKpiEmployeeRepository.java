package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.LeadKpiEmployee;

import java.util.List;

public interface LeadKpiEmployeeRepository {

    LeadKpiEmployee save(LeadKpiEmployee employee);

    /** Employees for period with user and scores initialized. */
    List<LeadKpiEmployee> findByPeriodId(Long periodId);

    void deleteByPeriodId(Long periodId);

    void delete(LeadKpiEmployee employee);
}
