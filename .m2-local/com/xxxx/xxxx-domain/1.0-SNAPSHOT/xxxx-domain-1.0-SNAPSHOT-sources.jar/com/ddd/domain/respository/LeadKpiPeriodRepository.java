package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.LeadKpiPeriod;

import java.util.Optional;

public interface LeadKpiPeriodRepository {

    LeadKpiPeriod save(LeadKpiPeriod period);

    Optional<LeadKpiPeriod> findByPeriod(String period);

    Optional<LeadKpiPeriod> findById(Long id);
}
