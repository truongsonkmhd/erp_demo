package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.LeadKpiScore;

public interface LeadKpiScoreRepository {

    LeadKpiScore save(LeadKpiScore score);

    void deleteByEmployeeId(Long employeeId);
}
