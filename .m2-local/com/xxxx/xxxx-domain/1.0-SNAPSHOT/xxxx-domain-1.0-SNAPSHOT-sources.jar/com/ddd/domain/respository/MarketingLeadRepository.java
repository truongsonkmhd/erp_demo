package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.workflow.LeadPhoneRef;
import com.xxxx.ddd.domain.model.workflow.LeadStage;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadPage;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadSearchCriteria;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface MarketingLeadRepository {
    MarketingLead save(MarketingLead lead);

    List<MarketingLead> saveAll(List<MarketingLead> leads);

    List<LeadPhoneRef> findAllActivePhoneRefs();

    Optional<MarketingLead> findByIdActive(Long id);

    List<MarketingLead> findAllActive();

    List<MarketingLead> findByIds(Collection<Long> ids);

    List<MarketingLead> findByStages(List<LeadStage> stages);

    MarketingLeadPage search(MarketingLeadSearchCriteria criteria);

    MarketingLeadStatsAggregate stats(MarketingLeadSearchCriteria criteria);

    Optional<MarketingLead> lookup(MarketingLeadSearchCriteria criteria);

    /** Exact phone match among active leads (oldest first). */
    Optional<MarketingLead> findFirstByPhoneActive(String phone);

    /** Remove stale Data -> Customer references when a customer is soft-deleted. */
    int unlinkCustomer(Long customerId);

    /** Distinct campaign names visible under the same scope as search (ignores campaignName filter). */
    List<String> listDistinctCampaignNames(MarketingLeadSearchCriteria criteria);

    boolean existsByCode(String code);

    long countAll();
}
