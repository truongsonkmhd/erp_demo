package com.xxxx.ddd.domain.respository;

import java.util.LinkedHashMap;
import java.util.Map;

/** Aggregate counts for marketing lead dashboard stats. */
public record MarketingLeadStatsAggregate(
        long total,
        long withCareProgress,
        long wrongInsight,
        long customerCreated,
        long marketingSourceTotal,
        Map<String, Long> byStage,
        Map<String, Long> byCareProgress
) {
    public static MarketingLeadStatsAggregate empty() {
        return new MarketingLeadStatsAggregate(0, 0, 0, 0, 0, new LinkedHashMap<>(), new LinkedHashMap<>());
    }
}
