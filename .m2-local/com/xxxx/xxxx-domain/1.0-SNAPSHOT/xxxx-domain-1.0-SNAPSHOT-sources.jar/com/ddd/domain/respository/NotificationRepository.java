package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.Notification;

import java.util.List;
import java.util.Optional;

public interface NotificationRepository {
    Notification save(Notification notification);

    Optional<Notification> findById(Long id);

    List<Notification> findInbox(Long recipientId, int limit);

    List<Notification> findInboxPage(Long recipientId, boolean unreadOnly, Long beforeId, int limit);

    List<Notification> findUnread(Long recipientId);

    long countUnread(Long recipientId);
}
