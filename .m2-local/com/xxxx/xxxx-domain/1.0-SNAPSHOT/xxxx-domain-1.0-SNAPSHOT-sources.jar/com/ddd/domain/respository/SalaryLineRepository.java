package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.SalaryLine;

import java.util.List;

public interface SalaryLineRepository {

    List<SalaryLine> findByPeriodId(Long periodId);

    void deleteByPeriodId(Long periodId);

    void delete(SalaryLine line);

    SalaryLine save(SalaryLine line);
}
