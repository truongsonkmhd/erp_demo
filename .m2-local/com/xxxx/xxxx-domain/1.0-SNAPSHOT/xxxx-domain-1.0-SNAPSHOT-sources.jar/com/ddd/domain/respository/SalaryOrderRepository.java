package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.SalaryOrder;

import java.util.Collection;
import java.util.List;

public interface SalaryOrderRepository {

    void deleteBySalaryLineIdIn(Collection<Long> salaryLineIds);

    SalaryOrder save(SalaryOrder salaryOrder);

    List<SalaryOrder> findByLineId(Long salaryLineId);
}
