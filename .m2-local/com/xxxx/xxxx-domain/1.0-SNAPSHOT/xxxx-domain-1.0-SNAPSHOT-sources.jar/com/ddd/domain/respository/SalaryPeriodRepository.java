package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.SalaryPeriod;

import java.util.Optional;

public interface SalaryPeriodRepository {

    Optional<SalaryPeriod> findByPeriod(String period);

    SalaryPeriod save(SalaryPeriod period);
}
