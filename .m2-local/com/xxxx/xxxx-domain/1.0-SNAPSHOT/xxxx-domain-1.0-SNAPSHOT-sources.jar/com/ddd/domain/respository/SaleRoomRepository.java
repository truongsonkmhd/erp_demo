package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.SaleRoom;

import java.util.List;
import java.util.Optional;

public interface SaleRoomRepository {
    SaleRoom save(SaleRoom room);

    Optional<SaleRoom> findById(Long id);

    Optional<SaleRoom> findByIdActive(Long id);

    List<SaleRoom> findAllActive();

    Optional<SaleRoom> findByLeaderId(Long leaderId);

    boolean existsByCode(String code);

    boolean existsByCodeAndIdNot(String code, Long id);
}
