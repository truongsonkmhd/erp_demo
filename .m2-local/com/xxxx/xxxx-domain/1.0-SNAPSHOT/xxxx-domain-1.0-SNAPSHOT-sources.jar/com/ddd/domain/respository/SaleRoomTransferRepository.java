package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.SaleRoomTransfer;

public interface SaleRoomTransferRepository {
    SaleRoomTransfer save(SaleRoomTransfer transfer);
}
