package com.xxxx.ddd.domain.respository;
import com.xxxx.ddd.domain.model.entity.TransportEntrustOrderDetail;
import java.util.Optional;
import java.util.List;
public interface TransportEntrustOrderDetailRepository {
    TransportEntrustOrderDetail save(TransportEntrustOrderDetail detail);
    Optional<TransportEntrustOrderDetail> findByOrderId(Long orderId);
    List<TransportEntrustOrderDetail> findAllByOrderId(Iterable<Long> orderIds);
    void deleteByOrderId(Long orderId);
}
