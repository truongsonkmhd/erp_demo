package com.xxxx.ddd.domain.respository;

import com.xxxx.ddd.domain.model.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserRepository {
    User save(User user);

    Optional<User> findById(Long id);

    Optional<User> findByIdWithAuth(Long id);

    Optional<User> findByUsernameOrEmailWithAuth(String login);

    Optional<User> findByEmailWithAuth(String email);

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

    boolean existsByUsernameAndIdNot(String username, Long id);

    boolean existsByEmailAndIdNot(String email, Long id);

    List<User> search(String keyword, int offset, int limit);

    long countSearch(String keyword);

    long countByRoleId(Long roleId);

    long countBySaleRoomId(Long saleRoomId);

    List<User> findBySaleRoomId(Long saleRoomId);

    /** Toàn bộ user còn hiệu lực kèm role/permission đã khởi tạo, dùng để lọc theo quyền. */
    List<User> findAllActiveWithAuth();

    /** User chưa bị xóa, gồm cả tài khoản đã khóa, dùng để giữ số liệu lịch sử. */
    List<User> findAllWithAuth();
}
