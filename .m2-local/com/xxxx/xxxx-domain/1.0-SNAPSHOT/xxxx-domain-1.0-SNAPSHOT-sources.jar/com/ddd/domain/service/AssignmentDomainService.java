package com.xxxx.ddd.domain.service;

import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface AssignmentDomainService {

    /**
     * Giao việc cho một người. Nếu đã có bản ghi đang hiệu lực thì bản ghi cũ chuyển
     * REASSIGNED và trỏ superseded_by sang bản ghi mới (cho phép đổi người khi assign).
     */
    Assignment assign(AssignmentRefType refType, Long refId, Long assigneeId, Long assignedById, String note);

    /** Người được giao xác nhận đã nhận. */
    Assignment accept(AssignmentRefType refType, Long refId, Long actingUserId);

    Optional<Assignment> findCurrent(AssignmentRefType refType, Long refId);

    Map<Long, Assignment> findCurrentByRefIds(AssignmentRefType refType, List<Long> refIds);

    List<Assignment> findHistory(AssignmentRefType refType, Long refId);
}
