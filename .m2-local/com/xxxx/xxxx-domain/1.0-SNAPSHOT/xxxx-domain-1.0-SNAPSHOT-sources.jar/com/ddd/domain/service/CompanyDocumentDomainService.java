package com.xxxx.ddd.domain.service;

import com.xxxx.ddd.domain.model.entity.CompanyDocument;

import java.util.List;

public interface CompanyDocumentDomainService {
    List<CompanyDocument> findVisible(Long categoryId, Long userId);

    CompanyDocument getVisibleById(Long id, Long userId);

    CompanyDocument create(CompanyDocument document, Long categoryId, Long uploadedById, boolean canManageShared);

    CompanyDocument update(Long id, String name, Long categoryId, Long actorId, boolean canManageShared);

    void assertCopyTargetIsPersonal(Long targetCategoryId, Long actorId);

    CompanyDocument updateFileMeta(Long id, String fileName, String contentType, long fileSize, String storagePath, Long actorId, boolean canManageShared);

    CompanyDocument updateFileSize(Long id, long fileSize, Long actorId);

    void delete(Long id, Long actorId, boolean canManageShared);
}
