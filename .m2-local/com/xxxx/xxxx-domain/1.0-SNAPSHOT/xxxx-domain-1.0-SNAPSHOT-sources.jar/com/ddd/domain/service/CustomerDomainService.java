package com.xxxx.ddd.domain.service;

import com.xxxx.ddd.domain.model.entity.Customer;
import com.xxxx.ddd.domain.model.entity.MarketingLead;

import java.util.List;
import java.util.Optional;

public interface CustomerDomainService {

    List<Customer> findAll();

    Customer getById(Long id);

    Optional<Customer> findByPhone(String phone);

    /** Tìm khách theo SĐT, chưa có thì tạo mới từ dữ liệu lead. */
    Customer resolveOrCreateFromLead(MarketingLead lead, Long createdById);

    /**
     * Tạo hồ sơ khách hàng. Nếu SĐT đã có thì cập nhật thông tin còn thiếu và trả hồ sơ cũ
     * (1 khách hàng - N đơn, không nhân bản).
     */
    Customer createOrResolve(Customer draft, Long createdById);

    Customer update(Long id, Customer draft);

    void delete(Long id);

    Customer assignCustomerCareStaff(Long customerId, Long staffId);
}
