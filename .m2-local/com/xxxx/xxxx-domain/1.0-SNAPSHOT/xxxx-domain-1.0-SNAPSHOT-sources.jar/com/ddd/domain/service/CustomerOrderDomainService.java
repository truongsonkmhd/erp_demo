package com.xxxx.ddd.domain.service;

import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.query.OrderSearchCriteria;
import com.xxxx.ddd.domain.model.query.OrderSearchResult;

import java.util.List;

public interface CustomerOrderDomainService {

    List<CustomerOrder> findAll();

    OrderSearchResult search(OrderSearchCriteria criteria);

    List<CustomerOrder> findByCustomerId(Long customerId);

    CustomerOrder getById(Long id);

    /** Sinh đơn hàng nháp từ lead sau khi nhân viên nhận nhiệm vụ. Idempotent theo lead. */
    CustomerOrder createFromLead(MarketingLead lead, Long assigneeId);

    /** Tạo đơn thủ công từ khách hàng đã có; chốt NEW/OLD theo cửa sổ 30 ngày (createdAt). */
    CustomerOrder createManual(Long customerId, CustomerOrder patch, Long actorId);

    CustomerOrder update(Long id, CustomerOrder patch);

    CustomerOrder save(CustomerOrder order);

    void delete(Long id);
}
