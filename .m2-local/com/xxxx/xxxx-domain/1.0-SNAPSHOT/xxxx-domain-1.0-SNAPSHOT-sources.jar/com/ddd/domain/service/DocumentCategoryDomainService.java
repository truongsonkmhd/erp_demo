package com.xxxx.ddd.domain.service;

import com.xxxx.ddd.domain.model.entity.DocumentCategory;

import java.util.List;

public interface DocumentCategoryDomainService {
    List<DocumentCategory> findVisible(Long userId);

    DocumentCategory getVisibleById(Long id, Long userId);

    DocumentCategory create(DocumentCategory category, Long ownerId, boolean sharedMenu, boolean canManageSharedMenu);

    DocumentCategory update(Long id, DocumentCategory patch, Long actorId, boolean canManageShared, Boolean sharedMenu);

    void delete(Long id, Long actorId, boolean canManageShared);
}
