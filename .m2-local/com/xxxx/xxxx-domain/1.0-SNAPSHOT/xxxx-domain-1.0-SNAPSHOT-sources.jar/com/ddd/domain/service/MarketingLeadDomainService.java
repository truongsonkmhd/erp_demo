package com.xxxx.ddd.domain.service;

import com.xxxx.ddd.domain.model.entity.Customer;
import com.xxxx.ddd.domain.model.entity.CustomerCareLog;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.workflow.LeadPhoneRef;
import com.xxxx.ddd.domain.model.workflow.LeadStage;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadPage;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadSearchCriteria;
import com.xxxx.ddd.domain.respository.MarketingLeadStatsAggregate;

import java.util.List;
import java.util.Optional;

public interface MarketingLeadDomainService {

    List<MarketingLead> findByStages(List<LeadStage> stages);

    MarketingLeadPage search(MarketingLeadSearchCriteria criteria);

    MarketingLeadStatsAggregate stats(MarketingLeadSearchCriteria criteria);

    Optional<MarketingLead> lookup(MarketingLeadSearchCriteria criteria);

    MarketingLead getById(Long id);

    MarketingLead create(MarketingLead lead, Long createdById);

    /** Batch insert with codes reserved in one pass (sheet import). */
    int batchCreate(List<MarketingLead> leads, Long createdById);

    /** Batch update campaign_names only (sheet import merge). */
    int batchUpdateCampaignNames(List<LeadPhoneRef> updates);

    List<LeadPhoneRef> findAllActivePhoneRefs();

    MarketingLead update(Long id, MarketingLead patch);

    /** Append campaign name if not already present; returns updated lead. */
    MarketingLead appendCampaignName(Long id, String campaignName);

    Optional<MarketingLead> findFirstByPhone(String phone);

    void delete(Long id);

    /** Marketing nhập xong, đánh dấu đã báo quản lý phân việc. */
    MarketingLead markManagerNotified(Long id);

    /** Sau khi phân việc thành công ở một chặng. */
    MarketingLead markAssigned(Long id, boolean taskStage);

    /** Sau khi nhân viên xác nhận đã nhận ở một chặng. */
    MarketingLead markAccepted(Long id, boolean taskStage);

    /** Cập nhật tiến trình CSKH; đạt L4 Ký hợp đồng thì bắt đầu chặng hỗ trợ/giao nhiệm vụ. */
    CustomerCareLog applyCareProgress(Long leadId, String careProgress, String careProgressNote,
                                      Boolean hasIssue, String issueNote, Long changedById);

    CustomerCareLog updateCareLog(Long leadId, Long logId, String careProgress, String careProgressNote, Long actorId);

    void deleteCareLog(Long leadId, Long logId);

    /**
     * Chuyển thủ công sang tab giao nhiệm vụ mà không cần chờ mốc L4.
     */
    MarketingLead requestCreateOrder(Long id);

    List<CustomerCareLog> findCareLogs(Long leadId);

    List<String> listCampaignNameOptions(MarketingLeadSearchCriteria criteria);

    /** Chốt chặng cuối và gắn lead vào khách hàng đã sinh đơn. */
    MarketingLead linkCustomer(Long id, Customer customer);

    void unlinkCustomer(Long customerId);

    MarketingLead markOrderCreated(Long id, Customer customer);
}
