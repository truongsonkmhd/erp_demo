package com.xxxx.ddd.domain.service;

import com.xxxx.ddd.domain.model.entity.SaleRoom;
import com.xxxx.ddd.domain.model.entity.User;

import java.util.List;
import java.util.Set;

public interface SaleRoomDomainService {
    List<SaleRoom> findAll();

    SaleRoom getById(Long id);

    SaleRoom create(SaleRoom room, Long leaderId, Set<Long> memberIds);

    SaleRoom update(Long id, SaleRoom patch, Long leaderId, Set<Long> memberIds);

    void delete(Long id);

    User assignUser(Long userId, Long roomId, String note);

    User clearUserRoom(Long userId, String note);
}
