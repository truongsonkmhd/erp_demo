package com.xxxx.ddd.domain.service;

import com.xxxx.ddd.domain.model.entity.User;

import java.util.List;

public interface UserDomainService {
    User createUser(User user, String roleCode, String levelCode, Long saleRoomId);

    User updateUser(Long id, User patch, String roleCode, String levelCode, Long saleRoomId);

    User updateOwnProfile(Long id, String fullName, String email, String phone);

    User getById(Long id);

    User getByUsernameOrEmail(String login);

    User getByEmail(String email);

    List<User> search(String keyword, int pageNo, int pageSize);

    long countSearch(String keyword);

    void changePassword(Long id, String encodedPassword);

    void deactivate(Long id);
}
