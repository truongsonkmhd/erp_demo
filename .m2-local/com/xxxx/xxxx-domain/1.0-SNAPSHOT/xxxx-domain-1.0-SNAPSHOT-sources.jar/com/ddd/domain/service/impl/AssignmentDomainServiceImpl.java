package com.xxxx.ddd.domain.service.impl;

import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;
import com.xxxx.ddd.domain.model.workflow.AssignmentStatus;
import com.xxxx.ddd.domain.respository.AssignmentRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.AssignmentDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
@Transactional
public class AssignmentDomainServiceImpl implements AssignmentDomainService {

    @Autowired
    private AssignmentRepository assignmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Assignment assign(AssignmentRefType refType, Long refId, Long assigneeId, Long assignedById, String note) {
        if (assigneeId == null) {
            throw new IllegalArgumentException("Chưa chọn nhân viên nhận việc");
        }
        User assignee = userRepository.findById(assigneeId)
                .orElseThrow(() -> new IllegalArgumentException("Nhân viên không tồn tại"));
        if (Boolean.TRUE.equals(assignee.getIsDeleted()) || Boolean.FALSE.equals(assignee.getActive())) {
            throw new IllegalArgumentException("Nhân viên đã bị vô hiệu hoá");
        }

        Optional<Assignment> current = assignmentRepository.findCurrentForUpdate(refType, refId);
        if (current.isPresent() && assigneeId.equals(current.get().getAssignee().getId())) {
            Assignment existing = current.get();
            existing.setNote(note);
            return assignmentRepository.save(existing);
        }

        Assignment created = assignmentRepository.save(new Assignment()
                .setRefType(refType)
                .setRefId(refId)
                .setAssignee(assignee)
                .setAssignedBy(assignedById == null ? null : userRepository.findById(assignedById).orElse(null))
                .setStatus(AssignmentStatus.PENDING)
                .setNote(note)
                .setAssignedAt(LocalDateTime.now()));

        current.ifPresent(previous -> {
            previous.setStatus(AssignmentStatus.REASSIGNED);
            previous.setSupersededById(created.getId());
            assignmentRepository.save(previous);
        });

        return created;
    }

    @Override
    public Assignment accept(AssignmentRefType refType, Long refId, Long actingUserId) {
        Assignment current = assignmentRepository.findCurrent(refType, refId)
                .orElseThrow(() -> new IllegalArgumentException("Chưa có phân việc để nhận"));
        if (current.getStatus() == AssignmentStatus.ACCEPTED) {
            return current;
        }
        if (actingUserId != null && !actingUserId.equals(current.getAssignee().getId())) {
            throw new IllegalArgumentException("Chỉ người được giao mới có thể nhận việc này");
        }
        current.setStatus(AssignmentStatus.ACCEPTED);
        current.setAcceptedAt(LocalDateTime.now());
        return assignmentRepository.save(current);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Assignment> findCurrent(AssignmentRefType refType, Long refId) {
        return assignmentRepository.findCurrent(refType, refId);
    }

    @Override
    @Transactional(readOnly = true)
    public Map<Long, Assignment> findCurrentByRefIds(AssignmentRefType refType, List<Long> refIds) {
        Map<Long, Assignment> byRefId = new HashMap<>();
        // Query đã sắp xếp mới nhất trước nên bản ghi đầu tiên của mỗi refId là bản đang hiệu lực.
        for (Assignment assignment : assignmentRepository.findByRefTypeAndRefIds(refType, refIds)) {
            byRefId.putIfAbsent(assignment.getRefId(), assignment);
        }
        return byRefId;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Assignment> findHistory(AssignmentRefType refType, Long refId) {
        return assignmentRepository.findHistory(refType, refId);
    }
}
