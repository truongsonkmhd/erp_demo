package com.xxxx.ddd.domain.service.impl;

import com.xxxx.ddd.domain.model.entity.CompanyDocument;
import com.xxxx.ddd.domain.model.entity.DocumentCategory;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.CompanyDocumentRepository;
import com.xxxx.ddd.domain.respository.DocumentCategoryRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.CompanyDocumentDomainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class CompanyDocumentDomainServiceImpl implements CompanyDocumentDomainService {

    @Autowired
    private CompanyDocumentRepository companyDocumentRepository;

    @Autowired
    private DocumentCategoryRepository documentCategoryRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public List<CompanyDocument> findVisible(Long categoryId, Long userId) {
        if (categoryId == null) {
            return companyDocumentRepository.findVisibleToUser(userId);
        }
        return companyDocumentRepository.findVisibleByCategoryId(categoryId, userId);
    }

    @Override
    @Transactional(readOnly = true)
    public CompanyDocument getVisibleById(Long id, Long userId) {
        CompanyDocument document = companyDocumentRepository.findByIdActive(id)
                .orElseThrow(() -> new IllegalArgumentException("Document not found"));
        if (!DocumentCategoryDomainServiceImpl.isVisible(document.getCategory(), userId)) {
            throw new IllegalArgumentException("Document not found");
        }
        return document;
    }

    @Override
    public CompanyDocument create(CompanyDocument document, Long categoryId, Long uploadedById, boolean canManageShared) {
        if (document.getName() == null || document.getName().isBlank()) {
            throw new IllegalArgumentException("Document name is required");
        }
        if (document.getFileName() == null || document.getFileName().isBlank()) {
            throw new IllegalArgumentException("File is required");
        }
        if (document.getStoragePath() == null || document.getStoragePath().isBlank()) {
            throw new IllegalArgumentException("File is required");
        }
        DocumentCategory category = requireVisibleCategory(categoryId, uploadedById);
        if (!DocumentCategoryDomainServiceImpl.canWriteDocuments(category, uploadedById, canManageShared)) {
            throw new IllegalArgumentException("You cannot add documents to this menu");
        }
        LocalDateTime now = LocalDateTime.now();
        document.setName(document.getName().trim());
        document.setCategory(category);
        document.setFileSize(document.getFileSize() == null ? 0L : document.getFileSize());
        document.setIsDeleted(false);
        document.setCreatedAt(now);
        document.setUpdatedAt(now);
        if (uploadedById != null) {
            User uploader = userRepository.findById(uploadedById).orElse(null);
            document.setUploadedBy(uploader);
        }
        return companyDocumentRepository.save(document);
    }

    @Override
    public CompanyDocument update(Long id, String name, Long categoryId, Long actorId, boolean canManageShared) {
        CompanyDocument document = getVisibleById(id, actorId);
        assertCanWrite(document.getCategory(), actorId, canManageShared);
        if (name != null && !name.isBlank()) {
            document.setName(name.trim());
        }
        if (categoryId != null && !categoryId.equals(document.getCategory().getId())) {
            DocumentCategory current = document.getCategory();
            DocumentCategory next = requireVisibleCategory(categoryId, actorId);
            boolean currentPersonal = current.getCreatedBy() != null;
            boolean nextPersonal = next.getCreatedBy() != null;
            if (currentPersonal != nextPersonal) {
                throw new IllegalArgumentException("Cannot move documents between fixed and personal menus");
            }
            if (currentPersonal) {
                if (actorId == null
                        || !actorId.equals(current.getCreatedBy().getId())
                        || !actorId.equals(next.getCreatedBy().getId())) {
                    throw new IllegalArgumentException("You can only move documents between your own personal menus");
                }
            }
            if (!DocumentCategoryDomainServiceImpl.canWriteDocuments(next, actorId, canManageShared)) {
                throw new IllegalArgumentException("You cannot add documents to this menu");
            }
            document.setCategory(next);
        }
        document.setUpdatedAt(LocalDateTime.now());
        return companyDocumentRepository.save(document);
    }

    @Override
    public void assertCopyTargetIsPersonal(Long targetCategoryId, Long actorId) {
        DocumentCategory target = requireVisibleCategory(targetCategoryId, actorId);
        if (target.getCreatedBy() == null) {
            throw new IllegalArgumentException("Copy from a fixed menu must go to a personal menu");
        }
        if (actorId == null || !actorId.equals(target.getCreatedBy().getId())) {
            throw new IllegalArgumentException("You can only copy into your own menu");
        }
    }

    @Override
    public CompanyDocument updateFileMeta(Long id, String fileName, String contentType, long fileSize, String storagePath, Long actorId, boolean canManageShared) {
        CompanyDocument document = getVisibleById(id, actorId);
        assertCanWrite(document.getCategory(), actorId, canManageShared);
        document.setFileName(fileName);
        document.setContentType(contentType);
        document.setFileSize(fileSize);
        document.setStoragePath(storagePath);
        document.setUpdatedAt(LocalDateTime.now());
        return companyDocumentRepository.save(document);
    }

    @Override
    public CompanyDocument updateFileSize(Long id, long fileSize, Long actorId) {
        CompanyDocument document = getVisibleById(id, actorId);
        document.setFileSize(fileSize);
        document.setUpdatedAt(LocalDateTime.now());
        return companyDocumentRepository.save(document);
    }

    @Override
    public void delete(Long id, Long actorId, boolean canManageShared) {
        CompanyDocument document = getVisibleById(id, actorId);
        assertCanWrite(document.getCategory(), actorId, canManageShared);
        document.setIsDeleted(true);
        document.setUpdatedAt(LocalDateTime.now());
        companyDocumentRepository.save(document);
    }

    private DocumentCategory requireVisibleCategory(Long categoryId, Long userId) {
        if (categoryId == null) {
            throw new IllegalArgumentException("Category is required");
        }
        DocumentCategory category = documentCategoryRepository.findByIdActive(categoryId)
                .orElseThrow(() -> new IllegalArgumentException("Document category not found"));
        if (!DocumentCategoryDomainServiceImpl.isVisible(category, userId)) {
            throw new IllegalArgumentException("Document category not found");
        }
        return category;
    }

    private static void assertCanWrite(DocumentCategory category, Long actorId, boolean canManageShared) {
        if (!DocumentCategoryDomainServiceImpl.canWriteDocuments(category, actorId, canManageShared)) {
            throw new IllegalArgumentException("You cannot edit documents in this menu");
        }
    }
}
