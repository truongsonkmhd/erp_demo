package com.xxxx.ddd.domain.service.impl;

import com.xxxx.ddd.domain.model.entity.Customer;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.CustomerRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.CustomerDomainService;
import com.xxxx.ddd.domain.util.PhoneNormalizer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Slf4j
@Transactional
public class CustomerDomainServiceImpl implements CustomerDomainService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Customer> findAll() {
        return customerRepository.findAllActive();
    }

    @Override
    @Transactional(readOnly = true)
    public Customer getById(Long id) {
        return customerRepository.findByIdActive(id)
                .orElseThrow(() -> new IllegalArgumentException("Khách hàng không tồn tại"));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Customer> findByPhone(String phone) {
        String normalized = PhoneNormalizer.normalize(phone);
        if (normalized == null) {
            return Optional.empty();
        }
        return findByNormalizedPhone(normalized);
    }

    @Override
    public Customer resolveOrCreateFromLead(MarketingLead lead, Long createdById) {
        if (lead.getCustomer() != null) {
            return lead.getCustomer();
        }
        String phone = PhoneNormalizer.normalize(lead.getPhone());
        return findByNormalizedPhone(phone)
                .orElseGet(() -> create(null, lead.getFullName(), null, lead.getPhone(), lead.getEmail(),
                        lead.getCategory(), null, null, null, null, null,
                        lead.getLeadSource(), null, null, null, null, lead.getNote(), createdById));
    }

    @Override
    public Customer createOrResolve(Customer draft, Long createdById) {
        if (draft.getFullName() == null || draft.getFullName().isBlank()) {
            throw new IllegalArgumentException("Tên khách hàng không được để trống");
        }
        String phone = PhoneNormalizer.normalize(draft.getPhone());
        if (phone == null || phone.isBlank()) {
            throw new IllegalArgumentException("Số điện thoại khách hàng không được để trống");
        }

        Optional<Customer> existing = findByNormalizedPhone(phone);
        if (existing.isPresent()) {
            Customer customer = existing.get();
            applyDraft(customer, draft);
            customer.setUpdatedAt(LocalDateTime.now());
            return customerRepository.save(customer);
        }
        return create(
                draft.getCode(),
                draft.getFullName(),
                draft.getCompanyName(),
                phone,
                draft.getEmail(),
                draft.getCategory(),
                draft.getTaxCode(),
                draft.getBusinessType(),
                draft.getChinaVietnamRateKg(),
                draft.getChinaVietnamRateCbm(),
                draft.getCustomerCareStaff(),
                draft.getLeadSource(),
                draft.getAddress(),
                draft.getProvince(),
                draft.getWard(),
                draft.getDetailAddress(),
                draft.getNote(),
                createdById);
    }

    @Override
    public Customer update(Long id, Customer draft) {
        Customer customer = getById(id);
        if (draft.getFullName() == null || draft.getFullName().isBlank()) {
            throw new IllegalArgumentException("Tên khách hàng không được để trống");
        }
        String phone = PhoneNormalizer.normalize(draft.getPhone());
        if (phone == null || phone.isBlank()) {
            throw new IllegalArgumentException("Số điện thoại khách hàng không được để trống");
        }
        String currentPhone = PhoneNormalizer.normalize(customer.getPhone());
        if (!phone.equals(currentPhone)) {
            findByNormalizedPhone(phone)
                    .filter(existing -> !existing.getId().equals(id))
                    .ifPresent(existing -> { throw new IllegalArgumentException("Số điện thoại đã thuộc khách hàng khác"); });
        }

        String requestedCode = normalizeCode(draft.getCode());
        if (requestedCode != null && !requestedCode.equals(customer.getCode())
                && customerRepository.existsByCode(requestedCode)) {
            throw duplicateCustomerCode(requestedCode);
        }

        if (requestedCode != null) {
            customer.setCode(requestedCode);
        }
        customer.setFullName(draft.getFullName().trim());
        customer.setCompanyName(blankToNull(draft.getCompanyName()));
        customer.setPhone(phone);
        customer.setEmail(blankToNull(draft.getEmail()));
        customer.setCategory(blankToNull(draft.getCategory()));
        customer.setTaxCode(blankToNull(draft.getTaxCode()));
        customer.setBusinessType(blankToNull(draft.getBusinessType()));
        customer.setChinaVietnamRateKg(draft.getChinaVietnamRateKg());
        customer.setChinaVietnamRateCbm(draft.getChinaVietnamRateCbm());
        customer.setLeadSource(blankToNull(draft.getLeadSource()));
        customer.setProvince(blankToNull(draft.getProvince()));
        customer.setWard(blankToNull(draft.getWard()));
        customer.setDetailAddress(blankToNull(draft.getDetailAddress()));
        customer.setAddress(composeAddress(customer.getDetailAddress(), customer.getWard(), customer.getProvince()));
        customer.setNote(blankToNull(draft.getNote()));
        customer.setUpdatedAt(LocalDateTime.now());
        return customerRepository.save(customer);
    }

    @Override
    public void delete(Long id) {
        Customer customer = getById(id);
        customer.setIsDeleted(true);
        customer.setUpdatedAt(LocalDateTime.now());
        customerRepository.save(customer);
    }

    @Override
    public Customer assignCustomerCareStaff(Long customerId, Long staffId) {
        Customer customer = getById(customerId);
        if (staffId == null) {
            customer.setCustomerCareStaff(null);
        } else {
            var staff = userRepository.findById(staffId)
                    .orElseThrow(() -> new IllegalArgumentException("Nhân viên CSKH không tồn tại"));
            String roleCode = staff.getRoleCode();
            if (roleCode == null || !"cskh".equalsIgnoreCase(roleCode.trim())) {
                throw new IllegalArgumentException("Chỉ được phân nhân viên có role CSKH");
            }
            customer.setCustomerCareStaff(staff);
        }
        customer.setUpdatedAt(LocalDateTime.now());
        return customerRepository.save(customer);
    }

    private void applyDraft(Customer customer, Customer draft) {
        if (draft.getFullName() != null && !draft.getFullName().isBlank()) {
            customer.setFullName(draft.getFullName().trim());
        }
        if (draft.getCompanyName() != null) {
            customer.setCompanyName(blankToNull(draft.getCompanyName()));
        }
        if (draft.getEmail() != null) {
            customer.setEmail(draft.getEmail().isBlank() ? customer.getEmail() : draft.getEmail().trim());
        }
        if (draft.getCategory() != null && !draft.getCategory().isBlank()) {
            customer.setCategory(draft.getCategory().trim());
        }
        if (draft.getTaxCode() != null) {
            customer.setTaxCode(blankToNull(draft.getTaxCode()));
        }
        if (draft.getBusinessType() != null) {
            customer.setBusinessType(blankToNull(draft.getBusinessType()));
        }
        if (draft.getChinaVietnamRateKg() != null) {
            customer.setChinaVietnamRateKg(draft.getChinaVietnamRateKg());
        }
        if (draft.getChinaVietnamRateCbm() != null) {
            customer.setChinaVietnamRateCbm(draft.getChinaVietnamRateCbm());
        }
        if (draft.getCustomerCareStaff() != null) {
            customer.setCustomerCareStaff(draft.getCustomerCareStaff());
        }
        if (draft.getLeadSource() != null && !draft.getLeadSource().isBlank()) {
            customer.setLeadSource(draft.getLeadSource().trim());
        }
        boolean addressTouched = draft.getProvince() != null
                || draft.getWard() != null
                || draft.getDetailAddress() != null;
        if (addressTouched) {
            if (draft.getProvince() != null) {
                customer.setProvince(blankToNull(draft.getProvince()));
            }
            if (draft.getWard() != null) {
                customer.setWard(blankToNull(draft.getWard()));
            }
            if (draft.getDetailAddress() != null) {
                customer.setDetailAddress(blankToNull(draft.getDetailAddress()));
            }
            customer.setAddress(composeAddress(
                    customer.getDetailAddress(), customer.getWard(), customer.getProvince()));
        } else if (draft.getAddress() != null && !draft.getAddress().isBlank()) {
            customer.setAddress(draft.getAddress().trim());
        }
        if (draft.getNote() != null && !draft.getNote().isBlank()) {
            customer.setNote(draft.getNote().trim());
        }
    }

    private Optional<Customer> findByNormalizedPhone(String normalizedPhone) {
        if (normalizedPhone == null || normalizedPhone.isBlank()) {
            return Optional.empty();
        }
        Optional<Customer> exact = customerRepository.findByPhoneActive(normalizedPhone);
        if (exact.isPresent()) {
            return exact;
        }
        return customerRepository.findAllActive().stream()
                .filter(customer -> normalizedPhone.equals(PhoneNormalizer.normalize(customer.getPhone())))
                .findFirst();
    }

    private Customer create(String customerCode, String fullName, String companyName, String phone, String email, String category,
                            String taxCode, String businessType,
                            java.math.BigDecimal chinaVietnamRateKg,
                            java.math.BigDecimal chinaVietnamRateCbm,
                            User customerCareStaff,
                            String leadSource, String address, String province, String ward,
                            String detailAddress, String note, Long createdById) {
        String provinceValue = blankToNull(province);
        String wardValue = blankToNull(ward);
        String detailValue = blankToNull(detailAddress);
        String composed = composeAddress(detailValue, wardValue, provinceValue);
        LocalDateTime now = LocalDateTime.now();
        String requestedCode = normalizeCode(customerCode);
        String code = requestedCode == null ? nextCode(phone) : requestedCode;
        Optional<Customer> customerWithCode = customerRepository.findByCode(code);
        if (customerWithCode.isPresent()) {
            Customer existing = customerWithCode.get();
            if (!Boolean.TRUE.equals(existing.getIsDeleted())) {
                throw duplicateCustomerCode(code);
            }
            return restoreDeletedCustomer(existing, fullName, companyName, phone, email, category, taxCode,
                    businessType, chinaVietnamRateKg, chinaVietnamRateCbm, customerCareStaff,
                    leadSource, address, provinceValue, wardValue, detailValue, composed,
                    note, createdById, now);
        }
        Customer customer = new Customer()
                .setCode(code)
                .setFullName(fullName.trim())
                .setCompanyName(blankToNull(companyName))
                .setPhone(phone == null ? null : phone.trim())
                .setEmail(blankToNull(email))
                .setCategory(blankToNull(category))
                .setTaxCode(blankToNull(taxCode))
                .setBusinessType(blankToNull(businessType))
                .setChinaVietnamRateKg(chinaVietnamRateKg)
                .setChinaVietnamRateCbm(chinaVietnamRateCbm)
                .setCustomerCareStaff(customerCareStaff)
                .setLeadSource(blankToNull(leadSource))
                .setAddress(composed != null ? composed : blankToNull(address))
                .setProvince(provinceValue)
                .setWard(wardValue)
                .setDetailAddress(detailValue)
                .setNote(blankToNull(note))
                .setCreatedBy(createdById == null ? null : userRepository.findById(createdById).orElse(null))
                .setIsDeleted(false)
                .setCreatedAt(now)
                .setUpdatedAt(now);
        return customerRepository.save(customer);
    }

    private Customer restoreDeletedCustomer(Customer customer, String fullName, String companyName, String phone,
                                            String email, String category, String taxCode,
                                            String businessType,
                                            java.math.BigDecimal chinaVietnamRateKg,
                                            java.math.BigDecimal chinaVietnamRateCbm,
                                            User customerCareStaff, String leadSource, String address,
                                            String province, String ward, String detailAddress,
                                            String composedAddress, String note, Long createdById,
                                            LocalDateTime now) {
        customer.setFullName(fullName.trim());
        customer.setCompanyName(blankToNull(companyName));
        customer.setPhone(phone == null ? null : phone.trim());
        customer.setEmail(blankToNull(email));
        customer.setCategory(blankToNull(category));
        customer.setTaxCode(blankToNull(taxCode));
        customer.setBusinessType(blankToNull(businessType));
        customer.setChinaVietnamRateKg(chinaVietnamRateKg);
        customer.setChinaVietnamRateCbm(chinaVietnamRateCbm);
        customer.setCustomerCareStaff(customerCareStaff);
        customer.setLeadSource(blankToNull(leadSource));
        customer.setProvince(province);
        customer.setWard(ward);
        customer.setDetailAddress(detailAddress);
        customer.setAddress(composedAddress != null ? composedAddress : blankToNull(address));
        customer.setNote(blankToNull(note));
        customer.setCreatedBy(createdById == null ? customer.getCreatedBy()
                : userRepository.findById(createdById).orElse(customer.getCreatedBy()));
        customer.setIsDeleted(false);
        customer.setUpdatedAt(now);
        return customerRepository.save(customer);
    }

    private static String composeAddress(String detailAddress, String ward, String province) {
        String joined = Stream.of(detailAddress, ward, province)
                .map(CustomerDomainServiceImpl::blankToNull)
                .filter(Objects::nonNull)
                .collect(Collectors.joining(", "));
        return joined.isBlank() ? null : joined;
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private static String normalizeCode(String value) {
        String code = blankToNull(value);
        return code == null ? null : code.toUpperCase();
    }

    private static IllegalArgumentException duplicateCustomerCode(String code) {
        return new IllegalArgumentException(
                "Mã khách hàng " + code
                        + " đã tồn tại (có thể do trùng 4 số cuối điện thoại). Vui lòng nhập mã khác");
    }

    /** F + 4 số cuối SĐT. Mã trùng phải được người dùng sửa thủ công. */
    private String nextCode(String phone) {
        String digits = phone == null ? "" : phone.replaceAll("\\D", "");
        String suffix = digits.length() >= 4 ? digits.substring(digits.length() - 4) : String.format("%04d", (int) (Math.random() * 10000));
        return "F" + suffix;
    }
}
