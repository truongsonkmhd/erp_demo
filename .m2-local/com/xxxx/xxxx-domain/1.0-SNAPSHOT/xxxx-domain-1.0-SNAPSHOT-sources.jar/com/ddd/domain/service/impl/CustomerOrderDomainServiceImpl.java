package com.xxxx.ddd.domain.service.impl;

import com.xxxx.ddd.domain.model.entity.Customer;
import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.workflow.OrderSource;
import com.xxxx.ddd.domain.model.query.OrderSearchCriteria;
import com.xxxx.ddd.domain.model.query.OrderSearchResult;
import com.xxxx.ddd.domain.model.workflow.SalaryCustomerKindRules;
import com.xxxx.ddd.domain.respository.CustomerOrderRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.CustomerDomainService;
import com.xxxx.ddd.domain.service.CustomerOrderDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;

@Service
@Slf4j
@Transactional
public class CustomerOrderDomainServiceImpl implements CustomerOrderDomainService {

    private static final DateTimeFormatter CODE_MONTH = DateTimeFormatter.ofPattern("yyyyMM");

    @Autowired
    private CustomerOrderRepository customerOrderRepository;

    @Autowired
    private CustomerDomainService customerDomainService;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public List<CustomerOrder> findAll() {
        return customerOrderRepository.findAllActive();
    }

    @Override
    @Transactional(readOnly = true)
    public OrderSearchResult search(OrderSearchCriteria criteria) {
        return customerOrderRepository.search(criteria);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CustomerOrder> findByCustomerId(Long customerId) {
        return customerOrderRepository.findByCustomerId(customerId);
    }

    @Override
    @Transactional(readOnly = true)
    public CustomerOrder getById(Long id) {
        return customerOrderRepository.findByIdActive(id)
                .orElseThrow(() -> new IllegalArgumentException("Đơn hàng không tồn tại"));
    }

    @Override
    public CustomerOrder createFromLead(MarketingLead lead, Long assigneeId) {
        List<CustomerOrder> existing = customerOrderRepository.findByLeadId(lead.getId());
        if (!existing.isEmpty()) {
            return existing.get(0);
        }

        Customer customer = customerDomainService.resolveOrCreateFromLead(lead, assigneeId);
        LocalDateTime now = LocalDateTime.now();
        CustomerOrder order = new CustomerOrder()
                .setOrderCode(nextOrderCode(null, null))
                .setCustomer(customer)
                .setLeadId(lead.getId())
                .setCategory(lead.getCategory())
                .setAssignee(assigneeId == null ? null : userRepository.findById(assigneeId).orElse(null))
                .setNotes(lead.getNote())
                .setSource(OrderSource.AUTO)
                .setIsDeleted(false)
                .setCreatedAt(now)
                .setUpdatedAt(now);
        return customerOrderRepository.save(order);
    }

    @Override
    public CustomerOrder createManual(Long customerId, CustomerOrder patch, Long actorId) {
        if (customerId == null) {
            throw new IllegalArgumentException("Khách hàng không hợp lệ");
        }
        Customer customer = customerDomainService.getById(customerId);
        String contractType = patch == null ? null : patch.getContractType();
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime previousCreatedAt = findLatestPreviousOrderCreatedAt(customer.getId(), null);
        String kind = SalaryCustomerKindRules.resolveKindByPreviousOrderCreatedAt(now, previousCreatedAt);

        String requestedOrderCode = patch == null || patch.getOrderCode() == null
                ? null : patch.getOrderCode().trim();
        if ("TRANSPORT_ENTRUST".equalsIgnoreCase(contractType)) {
            if (requestedOrderCode == null || requestedOrderCode.isBlank()) {
                requestedOrderCode = nextOrderCode(contractType, patch == null ? null : patch.getServiceType());
            }
            final String transportOrderCode = requestedOrderCode;
            customerOrderRepository.findByOrderCodeActive(transportOrderCode).ifPresent(existing -> {
                throw new IllegalArgumentException("Mã UTVC đã tồn tại: " + transportOrderCode);
            });
        }
        CustomerOrder order = new CustomerOrder()
                .setOrderCode("IMPORT_ENTRUST".equalsIgnoreCase(contractType)
                        ? nextImportEntrustOrderCode(customer.getCode())
                        : requestedOrderCode)
                .setCustomer(customer)
                .setLeadId(patch != null ? patch.getLeadId() : null)
                .setBatchCode(patch != null ? patch.getBatchCode() : null)
                .setServiceType(patch != null ? patch.getServiceType() : null)
                .setContractType(patch != null ? patch.getContractType() : null)
                .setProductName(patch != null ? patch.getProductName() : null)
                .setCategory(patch != null ? patch.getCategory() : null)
                .setQuantity(patch != null ? patch.getQuantity() : null)
                .setUnitPriceRmb(patch != null ? patch.getUnitPriceRmb() : null)
                .setTotalPaymentAmountVnd(patch != null ? patch.getTotalPaymentAmountVnd() : null)
                .setPaidAt(patch != null ? patch.getPaidAt() : null)
                .setNetProfitVnd(patch != null && patch.getNetProfitVnd() != null
                        ? patch.getNetProfitVnd()
                        : BigDecimal.ZERO)
                .setOrderStatus(patch != null ? patch.getOrderStatus() : null)
                .setShipmentStatus(patch != null ? patch.getShipmentStatus() : null)
                .setFreightPaymentStatus(patch != null ? patch.getFreightPaymentStatus() : null)
                .setDocumentStatus(patch != null ? patch.getDocumentStatus() : null)
                .setSaleOverlayJson(patch != null ? patch.getSaleOverlayJson() : null)
                .setNotes(patch != null ? patch.getNotes() : null)
                .setAssignee(patch != null ? patch.getAssignee() : null)
                .setSalesOwner(patch != null ? patch.getSalesOwner() : null)
                .setSalaryCustomerKind(kind)
                .setSource(OrderSource.MANUAL)
                .setIsDeleted(false)
                .setCreatedAt(now)
                .setUpdatedAt(now);
        return customerOrderRepository.save(order);
    }

    @Override
    public CustomerOrder update(Long id, CustomerOrder patch) {
        CustomerOrder order = getById(id);
        String previousContractType = order.getContractType();
        order.setBatchCode(patch.getBatchCode());
        if ("IMPORT_ENTRUST".equalsIgnoreCase(patch.getContractType())) {
            if (!"IMPORT_ENTRUST".equalsIgnoreCase(previousContractType)
                    || order.getOrderCode() == null || order.getOrderCode().isBlank()) {
                order.setOrderCode(nextImportEntrustOrderCode(order.getCustomer().getCode()));
            }
        } else if (patch.getOrderCode() != null && !patch.getOrderCode().isBlank()) {
            String nextCode = patch.getOrderCode().trim();
            customerOrderRepository.findByOrderCodeActive(nextCode)
                    .filter(existing -> !existing.getId().equals(order.getId()))
                    .ifPresent(existing -> {
                        throw new IllegalArgumentException("Mã đơn hàng đã tồn tại: " + nextCode);
                    });
            order.setOrderCode(nextCode);
        }
        order.setServiceType(patch.getServiceType());
        order.setContractType(patch.getContractType());
        order.setProductName(patch.getProductName());
        order.setCategory(patch.getCategory());
        order.setQuantity(patch.getQuantity());
        order.setUnitPriceRmb(patch.getUnitPriceRmb());
        order.setTotalPaymentAmountVnd(patch.getTotalPaymentAmountVnd());
        order.setPaidAt(patch.getPaidAt());
        if (patch.getNetProfitVnd() != null) {
            order.setNetProfitVnd(patch.getNetProfitVnd());
        } else if (order.getNetProfitVnd() == null) {
            order.setNetProfitVnd(BigDecimal.ZERO);
        }
        order.setOrderStatus(patch.getOrderStatus());
        order.setShipmentStatus(patch.getShipmentStatus());
        order.setFreightPaymentStatus(patch.getFreightPaymentStatus());
        applyDocumentStatusForSalary(order, patch.getDocumentStatus());
        order.setSaleOverlayJson(patch.getSaleOverlayJson());
        order.setNotes(patch.getNotes());
        if (patch.getAssignee() != null) {
            order.setAssignee(patch.getAssignee());
        }
        order.setUpdatedAt(LocalDateTime.now());
        return customerOrderRepository.save(order);
    }

    @Override
    public CustomerOrder save(CustomerOrder order) {
        if (order == null || order.getId() == null) {
            throw new IllegalArgumentException("Đơn hàng không hợp lệ");
        }
        order.setUpdatedAt(LocalDateTime.now());
        return customerOrderRepository.save(order);
    }

    private void applyDocumentStatusForSalary(CustomerOrder order, String nextStatus) {
        boolean wasHandedOver = SalaryCustomerKindRules.isHandedOver(order.getDocumentStatus());
        boolean nowHandedOver = SalaryCustomerKindRules.isHandedOver(nextStatus);
        order.setDocumentStatus(nextStatus);

        if (nowHandedOver) {
            LocalDateTime handoverAt = order.getDocumentHandedOverAt();
            if (handoverAt == null) {
                handoverAt = LocalDateTime.now();
                order.setDocumentHandedOverAt(handoverAt);
            }
            if (order.getSalaryCustomerKind() == null) {
                LocalDateTime previous = findPreviousHandoverAt(order, handoverAt);
                order.setSalaryCustomerKind(SalaryCustomerKindRules.resolveKind(handoverAt, previous));
            }
            return;
        }

        if (wasHandedOver) {
            order.setDocumentHandedOverAt(null);
            // Không xoá kind đã chốt lúc tạo thủ công / bàn giao trước.
        }
    }

    private LocalDateTime findLatestPreviousOrderCreatedAt(Long customerId, Long excludeOrderId) {
        return customerOrderRepository.findByCustomerId(customerId).stream()
                .filter(item -> excludeOrderId == null
                        || item.getId() == null
                        || !item.getId().equals(excludeOrderId))
                .map(CustomerOrder::getCreatedAt)
                .filter(at -> at != null)
                .max(Comparator.naturalOrder())
                .orElse(null);
    }

    private LocalDateTime findPreviousHandoverAt(CustomerOrder current, LocalDateTime handoverAt) {
        if (current.getCustomer() == null || current.getCustomer().getId() == null) {
            return null;
        }
        return customerOrderRepository.findByCustomerId(current.getCustomer().getId()).stream()
                .filter(item -> item.getId() != null && !item.getId().equals(current.getId()))
                .filter(item -> SalaryCustomerKindRules.isHandedOver(item.getDocumentStatus()))
                .map(CustomerOrder::getDocumentHandedOverAt)
                .filter(at -> at != null && !at.isAfter(handoverAt))
                .max(Comparator.naturalOrder())
                .orElse(null);
    }

    @Override
    public void delete(Long id) {
        CustomerOrder order = getById(id);
        order.setIsDeleted(true);
        order.setUpdatedAt(LocalDateTime.now());
        customerOrderRepository.save(order);
    }

    private String nextOrderCode(String contractType, String serviceType) {
        String codeType = "TRANSPORT_ENTRUST".equalsIgnoreCase(contractType)
                || "Ủy thác vận chuyển".equalsIgnoreCase(serviceType)
                ? "UTVC"
                : "IMPORT_ENTRUST".equalsIgnoreCase(contractType)
                || "Ủy thác nhập khẩu".equalsIgnoreCase(serviceType) ? "UTNK" : "HM";
        String prefix = codeType + "-" + LocalDateTime.now().format(CODE_MONTH) + "-";
        long seq = customerOrderRepository.countByOrderCodePrefix(prefix) + 1;
        return prefix + String.format("%04d", seq);
    }

    private String nextImportEntrustOrderCode(String customerCode) {
        String normalizedCustomerCode = customerCode == null ? "KH" : customerCode.trim();
        LocalDate today = LocalDate.now();
        String prefix = normalizedCustomerCode + "-" + today.format(CODE_MONTH) + "-";
        // UTNK được đánh số riêng theo từng khách hàng và từng tháng.
        // Vì vậy tháng mới sẽ tự reset về 001 theo tiền tố mã khách hàng + YYYYMM.
        long seq = customerOrderRepository.countByOrderCodePrefix(prefix) + 1;
        return prefix + String.format("%03d", seq);
    }
}
