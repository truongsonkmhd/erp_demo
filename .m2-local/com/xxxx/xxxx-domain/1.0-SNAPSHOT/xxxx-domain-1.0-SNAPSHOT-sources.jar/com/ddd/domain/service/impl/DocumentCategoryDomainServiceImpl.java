package com.xxxx.ddd.domain.service.impl;

import com.xxxx.ddd.domain.model.entity.CompanyDocument;
import com.xxxx.ddd.domain.model.entity.DocumentCategory;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.CompanyDocumentRepository;
import com.xxxx.ddd.domain.respository.DocumentCategoryRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.DocumentCategoryDomainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class DocumentCategoryDomainServiceImpl implements DocumentCategoryDomainService {

    @Autowired
    private DocumentCategoryRepository documentCategoryRepository;

    @Autowired
    private CompanyDocumentRepository companyDocumentRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public List<DocumentCategory> findVisible(Long userId) {
        return documentCategoryRepository.findVisibleToUser(userId);
    }

    @Override
    @Transactional(readOnly = true)
    public DocumentCategory getVisibleById(Long id, Long userId) {
        DocumentCategory category = documentCategoryRepository.findByIdActive(id)
                .orElseThrow(() -> new IllegalArgumentException("Document category not found"));
        if (!isVisible(category, userId)) {
            throw new IllegalArgumentException("Document category not found");
        }
        return category;
    }

    @Override
    public DocumentCategory create(DocumentCategory category, Long ownerId, boolean sharedMenu, boolean canManageSharedMenu) {
        if (ownerId == null) {
            throw new IllegalArgumentException("Owner is required");
        }
        String name = requireName(category.getName());
        LocalDateTime now = LocalDateTime.now();
        category.setName(name);
        category.setSortOrder(category.getSortOrder() == null ? 0 : category.getSortOrder());
        category.setActive(category.getActive() == null || category.getActive());
        category.setIsDeleted(false);
        category.setCreatedAt(now);
        category.setUpdatedAt(now);

        if (sharedMenu) {
            if (!canManageSharedMenu) {
                throw new IllegalArgumentException("Bạn không có quyền tạo menu cố định dùng chung");
            }
            if (documentCategoryRepository.existsByNameShared(name)) {
                throw new IllegalArgumentException("Category name already exists");
            }
            category.setCreatedBy(null);
            category.setEditable(Boolean.TRUE.equals(category.getEditable()));
        } else {
            if (documentCategoryRepository.existsByNameForOwner(name, ownerId)) {
                throw new IllegalArgumentException("Category name already exists");
            }
            User owner = userRepository.findById(ownerId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
            category.setCreatedBy(owner);
            category.setEditable(true);
        }
        return documentCategoryRepository.save(category);
    }

    @Override
    public DocumentCategory update(Long id, DocumentCategory patch, Long actorId, boolean canManageShared, Boolean sharedMenu) {
        DocumentCategory category = getVisibleById(id, actorId);
        assertCanRenameMenu(category, actorId, canManageShared);

        boolean wantShared = sharedMenu == null ? !isPersonal(category) : Boolean.TRUE.equals(sharedMenu);
        boolean currentlyPersonal = isPersonal(category);

        if (wantShared != !currentlyPersonal) {
            if (!canManageShared) {
                throw new IllegalArgumentException("Bạn không có quyền đổi menu cố định dùng chung");
            }
            if (!wantShared && Boolean.FALSE.equals(category.getEditable())) {
                throw new IllegalArgumentException("Menu cố định hệ thống không thể chuyển thành menu cá nhân");
            }
            if (wantShared) {
                String nameForCheck = patch.getName() != null && !patch.getName().isBlank()
                        ? patch.getName().trim()
                        : category.getName();
                if (documentCategoryRepository.existsByNameSharedAndIdNot(nameForCheck, id)) {
                    throw new IllegalArgumentException("Category name already exists");
                }
                category.setCreatedBy(null);
                category.setEditable(Boolean.TRUE.equals(patch.getEditable()));
            } else {
                User owner = userRepository.findById(actorId)
                        .orElseThrow(() -> new IllegalArgumentException("User not found"));
                String nameForCheck = patch.getName() != null && !patch.getName().isBlank()
                        ? patch.getName().trim()
                        : category.getName();
                if (documentCategoryRepository.existsByNameForOwnerAndIdNot(nameForCheck, actorId, id)) {
                    throw new IllegalArgumentException("Category name already exists");
                }
                category.setCreatedBy(owner);
                category.setEditable(true);
            }
        }

        if (patch.getName() != null && !patch.getName().isBlank()) {
            String name = patch.getName().trim();
            if (isPersonal(category)) {
                if (documentCategoryRepository.existsByNameForOwnerAndIdNot(name, actorId, id)) {
                    throw new IllegalArgumentException("Category name already exists");
                }
            } else if (documentCategoryRepository.existsByNameSharedAndIdNot(name, id)) {
                throw new IllegalArgumentException("Category name already exists");
            }
            category.setName(name);
        }
        if (patch.getSortOrder() != null) {
            category.setSortOrder(patch.getSortOrder());
        }
        if (patch.getActive() != null) {
            category.setActive(patch.getActive());
        }
        boolean lockedShared = !isPersonal(category) && Boolean.FALSE.equals(category.getEditable());
        if (!isPersonal(category) && canManageShared && patch.getEditable() != null && !lockedShared) {
            category.setEditable(patch.getEditable());
        }
        category.setUpdatedAt(LocalDateTime.now());
        return documentCategoryRepository.save(category);
    }

    @Override
    public void delete(Long id, Long actorId, boolean canManageShared) {
        DocumentCategory category = getVisibleById(id, actorId);
        assertCanDeleteMenu(category, actorId, canManageShared);
        LocalDateTime now = LocalDateTime.now();
        for (CompanyDocument document : companyDocumentRepository.findActiveByCategoryId(id)) {
            document.setIsDeleted(true);
            document.setUpdatedAt(now);
            companyDocumentRepository.save(document);
        }
        category.setIsDeleted(true);
        category.setUpdatedAt(now);
        documentCategoryRepository.save(category);
    }

    static boolean isVisible(DocumentCategory category, Long userId) {
        if (category.getCreatedBy() == null) {
            return true;
        }
        return userId != null && userId.equals(category.getCreatedBy().getId());
    }

    public static boolean canWriteDocuments(DocumentCategory category, Long actorId, boolean canManageShared) {
        if (isPersonal(category)) {
            return actorId != null && actorId.equals(category.getCreatedBy().getId());
        }
        return canManageShared;
    }

    private static boolean isPersonal(DocumentCategory category) {
        return category.getCreatedBy() != null;
    }

    private static void assertCanRenameMenu(DocumentCategory category, Long actorId, boolean canManageShared) {
        if (isPersonal(category)) {
            if (actorId == null || !actorId.equals(category.getCreatedBy().getId())) {
                throw new IllegalArgumentException("You can only edit your own menu");
            }
            return;
        }
        if (!canManageShared) {
            throw new IllegalArgumentException("This document category cannot be edited");
        }
    }

    private static void assertCanDeleteMenu(DocumentCategory category, Long actorId, boolean canManageShared) {
        if (isPersonal(category)) {
            if (actorId == null || !actorId.equals(category.getCreatedBy().getId())) {
                throw new IllegalArgumentException("You can only edit your own menu");
            }
            return;
        }
        if (!canManageShared) {
            throw new IllegalArgumentException("This document category cannot be deleted");
        }
    }

    private static String requireName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Category name is required");
        }
        return name.trim();
    }
}
