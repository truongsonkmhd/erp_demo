package com.xxxx.ddd.domain.service.impl;

import com.xxxx.ddd.domain.model.entity.Customer;
import com.xxxx.ddd.domain.model.entity.CustomerCareLog;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.workflow.CareProgressRules;
import com.xxxx.ddd.domain.model.workflow.CampaignNamesJson;
import com.xxxx.ddd.domain.model.workflow.LeadMarketingStatus;
import com.xxxx.ddd.domain.model.workflow.LeadPhoneRef;
import com.xxxx.ddd.domain.model.workflow.LeadStage;
import com.xxxx.ddd.domain.model.workflow.LeadTaskStatus;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadPage;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadSearchCriteria;
import com.xxxx.ddd.domain.respository.CustomerCareLogRepository;
import com.xxxx.ddd.domain.respository.MarketingLeadRepository;
import com.xxxx.ddd.domain.respository.MarketingLeadStatsAggregate;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.MarketingLeadDomainService;
import com.xxxx.ddd.domain.util.PhoneNormalizer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class MarketingLeadDomainServiceImpl implements MarketingLeadDomainService {

    private static final DateTimeFormatter CODE_MONTH = DateTimeFormatter.ofPattern("yyMM");

    @Autowired
    private MarketingLeadRepository marketingLeadRepository;

    @Autowired
    private CustomerCareLogRepository customerCareLogRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public List<MarketingLead> findByStages(List<LeadStage> stages) {
        return marketingLeadRepository.findByStages(stages);
    }

    @Override
    @Transactional(readOnly = true)
    public MarketingLeadPage search(MarketingLeadSearchCriteria criteria) {
        return marketingLeadRepository.search(criteria == null ? new MarketingLeadSearchCriteria() : criteria);
    }

    @Override
    @Transactional(readOnly = true)
    public MarketingLeadStatsAggregate stats(MarketingLeadSearchCriteria criteria) {
        return marketingLeadRepository.stats(criteria == null ? new MarketingLeadSearchCriteria() : criteria);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<MarketingLead> lookup(MarketingLeadSearchCriteria criteria) {
        return marketingLeadRepository.lookup(criteria == null ? new MarketingLeadSearchCriteria() : criteria);
    }

    @Override
    @Transactional(readOnly = true)
    public MarketingLead getById(Long id) {
        return marketingLeadRepository.findByIdActive(id)
                .orElseThrow(() -> new IllegalArgumentException("Dữ liệu marketing không tồn tại"));
    }

    @Override
    public MarketingLead create(MarketingLead lead, Long createdById) {
        if (lead.getFullName() == null || lead.getFullName().isBlank()) {
            throw new IllegalArgumentException("Tên khách hàng không được để trống");
        }
        lead.setPhone(PhoneNormalizer.normalize(lead.getPhone()));
        validateNewPhone(lead.getPhone());
        LocalDateTime now = LocalDateTime.now();
        // Let MySQL's IDENTITY column arbitrate concurrent inserts. The temporary
        // value satisfies the non-null unique code column until the id is assigned.
        lead.setCode("TMP-" + UUID.randomUUID());
        lead.setStage(LeadStage.MARKETING);
        lead.setMarketingStatus(LeadMarketingStatus.DRAFT);
        lead.setTaskStatus(LeadTaskStatus.NONE);
        lead.setIsDeleted(false);
        if (lead.getCreatedAt() == null) {
            lead.setCreatedAt(now);
        }
        lead.setUpdatedAt(now);
        if (createdById != null) {
            lead.setCreatedBy(userRepository.findById(createdById).orElse(null));
        }
        MarketingLead saved = marketingLeadRepository.save(lead);
        saved.setCode(codeFromId(saved.getId(), now));
        return marketingLeadRepository.save(saved);
    }

    @Override
    public int batchCreate(List<MarketingLead> leads, Long createdById) {
        if (leads == null || leads.isEmpty()) {
            return 0;
        }
        LocalDateTime now = LocalDateTime.now();
        String base = "MKT" + now.format(CODE_MONTH);
        long seq = marketingLeadRepository.countAll() + 1;
        var creator = createdById != null ? userRepository.findById(createdById).orElse(null) : null;
        for (MarketingLead lead : leads) {
            if (lead.getFullName() == null || lead.getFullName().isBlank()) {
                throw new IllegalArgumentException("Tên khách hàng không được để trống");
            }
            lead.setPhone(PhoneNormalizer.normalize(lead.getPhone()));
            lead.setCode(reserveCode(base, seq++));
            lead.setStage(LeadStage.MARKETING);
            lead.setMarketingStatus(LeadMarketingStatus.DRAFT);
            lead.setTaskStatus(LeadTaskStatus.NONE);
            lead.setIsDeleted(false);
            if (lead.getCreatedAt() == null) {
                lead.setCreatedAt(now);
            }
            lead.setUpdatedAt(now);
            if (creator != null) {
                lead.setCreatedBy(creator);
            }
        }
        marketingLeadRepository.saveAll(leads);
        return leads.size();
    }

    @Override
    public int batchUpdateCampaignNames(List<LeadPhoneRef> updates) {
        if (updates == null || updates.isEmpty()) {
            return 0;
        }
        List<Long> ids = updates.stream().map(LeadPhoneRef::id).distinct().toList();
        Map<Long, MarketingLead> byId = marketingLeadRepository.findByIds(ids).stream()
                .collect(Collectors.toMap(MarketingLead::getId, Function.identity()));
        LocalDateTime now = LocalDateTime.now();
        List<MarketingLead> dirty = new ArrayList<>();
        for (LeadPhoneRef ref : updates) {
            MarketingLead lead = byId.get(ref.id());
            if (lead == null) {
                continue;
            }
            lead.setCampaignNames(ref.campaignNames());
            lead.setUpdatedAt(now);
            dirty.add(lead);
        }
        if (!dirty.isEmpty()) {
            marketingLeadRepository.saveAll(dirty);
        }
        return dirty.size();
    }

    @Override
    @Transactional(readOnly = true)
    public List<LeadPhoneRef> findAllActivePhoneRefs() {
        return marketingLeadRepository.findAllActivePhoneRefs();
    }

    @Override
    public MarketingLead update(Long id, MarketingLead patch) {
        MarketingLead lead = getById(id);
        if (patch.getFullName() != null && !patch.getFullName().isBlank()) {
            lead.setFullName(patch.getFullName());
        }
        String phone = PhoneNormalizer.normalize(patch.getPhone());
        if (phone == null) {
            throw new IllegalArgumentException("Số điện thoại không được để trống");
        }
        marketingLeadRepository.findFirstByPhoneActive(phone)
                .filter(existing -> !existing.getId().equals(id))
                .ifPresent(existing -> { throw new IllegalArgumentException("Số điện thoại đã tồn tại trong hệ thống"); });
        lead.setPhone(phone);
        lead.setEmail(patch.getEmail());
        lead.setCategory(patch.getCategory());
        lead.setLeadSource(patch.getLeadSource());
        lead.setLeadSourceNote(patch.getLeadSourceNote());
        if (patch.getCampaignNames() != null) {
            lead.setCampaignNames(patch.getCampaignNames());
        }
        lead.setInitialNeed(patch.getInitialNeed());
        lead.setNote(patch.getNote());
        lead.setUpdatedAt(LocalDateTime.now());
        return marketingLeadRepository.save(lead);
    }

    @Override
    public MarketingLead appendCampaignName(Long id, String campaignName) {
        MarketingLead lead = getById(id);
        if (campaignName == null || campaignName.isBlank()) {
            return lead;
        }
        String next = CampaignNamesJson.append(lead.getCampaignNames(), campaignName.trim());
        if (next.equals(lead.getCampaignNames())) {
            return lead;
        }
        lead.setCampaignNames(next);
        lead.setUpdatedAt(LocalDateTime.now());
        return marketingLeadRepository.save(lead);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<MarketingLead> findFirstByPhone(String phone) {
        String normalized = PhoneNormalizer.normalize(phone);
        if (normalized == null) {
            return Optional.empty();
        }
        return marketingLeadRepository.findFirstByPhoneActive(normalized);
    }

    @Override
    public void delete(Long id) {
        MarketingLead lead = getById(id);
        lead.setIsDeleted(true);
        lead.setUpdatedAt(LocalDateTime.now());
        marketingLeadRepository.save(lead);
    }

    @Override
    public MarketingLead markManagerNotified(Long id) {
        MarketingLead lead = getById(id);
        if (lead.getStage() != LeadStage.MARKETING) {
            throw new IllegalArgumentException("Dữ liệu đã qua chặng marketing");
        }
        if (lead.getMarketingStatus() == LeadMarketingStatus.DRAFT) {
            lead.setMarketingStatus(LeadMarketingStatus.NOTIFIED_MANAGER);
        }
        lead.setManagerNotifiedAt(LocalDateTime.now());
        lead.setUpdatedAt(LocalDateTime.now());
        return marketingLeadRepository.save(lead);
    }

    @Override
    public MarketingLead markAssigned(Long id, boolean taskStage) {
        MarketingLead lead = getById(id);
        if (taskStage) {
            if (lead.getStage() != LeadStage.TASK) {
                throw new IllegalArgumentException("Dữ liệu chưa vào tab giao nhiệm vụ");
            }
            lead.setTaskStatus(LeadTaskStatus.ASSIGNED);
        } else {
            if (lead.getStage() != LeadStage.MARKETING) {
                throw new IllegalArgumentException("Dữ liệu đã qua chặng marketing");
            }
            lead.setMarketingStatus(LeadMarketingStatus.ASSIGNED);
        }
        lead.setUpdatedAt(LocalDateTime.now());
        return marketingLeadRepository.save(lead);
    }

    @Override
    public MarketingLead markAccepted(Long id, boolean taskStage) {
        MarketingLead lead = getById(id);
        if (taskStage) {
            lead.setTaskStatus(LeadTaskStatus.ACCEPTED);
        } else {
            lead.setMarketingStatus(LeadMarketingStatus.ACCEPTED);
            // Chỉ lần nhận Data đầu tiên mới chuyển sang chăm sóc. Đổi Sales sau
            // khi đã tạo khách hàng/đơn hàng không được lùi chặng xử lý.
            if (lead.getStage() == LeadStage.MARKETING) {
                lead.setStage(LeadStage.CARE);
            }
        }
        lead.setUpdatedAt(LocalDateTime.now());
        return marketingLeadRepository.save(lead);
    }

    @Override
    public CustomerCareLog applyCareProgress(Long leadId, String careProgress, String careProgressNote,
                                            Boolean hasIssue, String issueNote, Long changedById) {
        if (careProgress == null || careProgress.isBlank()) {
            throw new IllegalArgumentException("Chưa chọn tiến trình chăm sóc");
        }
        if (careProgressNote == null || careProgressNote.isBlank()) {
            throw new IllegalArgumentException("Chưa nhập nội dung trao đổi");
        }
        MarketingLead lead = getById(leadId);
        if (lead.getStage() == LeadStage.MARKETING) {
            lead.setStage(LeadStage.CARE);
            if (lead.getMarketingStatus() == LeadMarketingStatus.ASSIGNED) {
                lead.setMarketingStatus(LeadMarketingStatus.ACCEPTED);
            }
            lead.setUpdatedAt(LocalDateTime.now());
            marketingLeadRepository.save(lead);
        }
        LocalDateTime now = LocalDateTime.now();
        CustomerCareLog saved = customerCareLogRepository.save(new CustomerCareLog()
                .setLeadId(leadId)
                .setCareProgress(careProgress)
                .setCareProgressNote(careProgressNote.trim())
                .setHasIssue(Boolean.TRUE.equals(hasIssue))
                .setIssueNote(issueNote)
                .setChangedBy(changedById == null ? null : userRepository.findById(changedById).orElse(null))
                .setCreatedAt(now));

        lead.setCareProgress(careProgress);
        lead.setCareProgressNote(careProgressNote.trim());
        if (CareProgressRules.isAgreedToUseService(careProgress) && lead.getCareL4At() == null) {
            lead.setCareL4At(now);
            lead.setStage(LeadStage.TASK);
            lead.setTaskStatus(LeadTaskStatus.PENDING);
        }
        lead.setUpdatedAt(now);
        marketingLeadRepository.save(lead);

        return saved;
    }

    @Override
    public CustomerCareLog updateCareLog(Long leadId, Long logId, String careProgress, String careProgressNote,
                                         Long actorId) {
        if (careProgress == null || careProgress.isBlank()) {
            throw new IllegalArgumentException("Chưa chọn tiến trình chăm sóc");
        }
        if (careProgressNote == null || careProgressNote.isBlank()) {
            throw new IllegalArgumentException("Chưa nhập nội dung trao đổi");
        }
        MarketingLead lead = getById(leadId);
        CustomerCareLog log = requireCareLog(leadId, logId);
        String nextProgress = careProgress.trim();
        log.setCareProgress(nextProgress);
        log.setCareProgressNote(careProgressNote.trim());
        if (actorId != null) {
            log.setChangedBy(userRepository.findById(actorId).orElse(null));
        }
        CustomerCareLog saved = customerCareLogRepository.save(log);
        syncLeadCareFromLogs(lead);
        return saved;
    }

    @Override
    public void deleteCareLog(Long leadId, Long logId) {
        MarketingLead lead = getById(leadId);
        CustomerCareLog log = requireCareLog(leadId, logId);
        customerCareLogRepository.delete(log);
        syncLeadCareFromLogs(lead);
    }

    private CustomerCareLog requireCareLog(Long leadId, Long logId) {
        CustomerCareLog log = customerCareLogRepository.findById(logId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy tiến trình chăm sóc"));
        if (!leadId.equals(log.getLeadId())) {
            throw new IllegalArgumentException("Không tìm thấy tiến trình chăm sóc");
        }
        return log;
    }

    private void syncLeadCareFromLogs(MarketingLead lead) {
        List<CustomerCareLog> logs = customerCareLogRepository.findByLeadId(lead.getId());
        LocalDateTime now = LocalDateTime.now();
        if (logs.isEmpty()) {
            lead.setCareProgress(null);
            lead.setCareProgressNote(null);
            revertPendingTaskStage(lead);
            lead.setUpdatedAt(now);
            marketingLeadRepository.save(lead);
            return;
        }
        CustomerCareLog latest = logs.get(0);
        lead.setCareProgress(latest.getCareProgress());
        lead.setCareProgressNote(latest.getCareProgressNote());
        boolean hasL4 = logs.stream().anyMatch(item -> CareProgressRules.isAgreedToUseService(item.getCareProgress()));
        if (hasL4) {
            if (lead.getCareL4At() == null) {
                lead.setCareL4At(now);
            }
            if (lead.getStage() != LeadStage.ORDER_CREATED
                    && (lead.getTaskStatus() == null || lead.getTaskStatus() == LeadTaskStatus.NONE)) {
                lead.setStage(LeadStage.TASK);
                lead.setTaskStatus(LeadTaskStatus.PENDING);
            }
        } else {
            revertPendingTaskStage(lead);
        }
        lead.setUpdatedAt(now);
        marketingLeadRepository.save(lead);
    }

    private static void revertPendingTaskStage(MarketingLead lead) {
        if (lead.getStage() == LeadStage.TASK && lead.getTaskStatus() == LeadTaskStatus.PENDING) {
            lead.setStage(LeadStage.CARE);
            lead.setTaskStatus(LeadTaskStatus.NONE);
            lead.setCareL4At(null);
        }
    }

    @Override
    public MarketingLead requestCreateOrder(Long id) {
        MarketingLead lead = getById(id);
        if (lead.getStage() == LeadStage.ORDER_CREATED || lead.getOrderCreatedAt() != null) {
            throw new IllegalArgumentException("Đơn hàng đã được tạo cho khách hàng này");
        }
        if (lead.getTaskStatus() == LeadTaskStatus.ASSIGNED
                || lead.getTaskStatus() == LeadTaskStatus.ACCEPTED
                || lead.getTaskStatus() == LeadTaskStatus.DONE) {
            throw new IllegalArgumentException("Nhiệm vụ tạo đơn hàng đã được giao");
        }
        if (lead.getStage() != LeadStage.TASK || lead.getTaskStatus() == LeadTaskStatus.NONE) {
            lead.setStage(LeadStage.TASK);
            lead.setTaskStatus(LeadTaskStatus.PENDING);
            lead.setUpdatedAt(LocalDateTime.now());
            return marketingLeadRepository.save(lead);
        }
        return lead;
    }

    @Override
    @Transactional(readOnly = true)
    public List<CustomerCareLog> findCareLogs(Long leadId) {
        return customerCareLogRepository.findByLeadId(leadId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> listCampaignNameOptions(MarketingLeadSearchCriteria criteria) {
        return marketingLeadRepository.listDistinctCampaignNames(criteria);
    }

    @Override
    public MarketingLead linkCustomer(Long id, Customer customer) {
        MarketingLead lead = getById(id);
        if (customer != null) {
            lead.setCustomer(customer);
        }
        lead.setUpdatedAt(LocalDateTime.now());
        return marketingLeadRepository.save(lead);
    }

    @Override
    public void unlinkCustomer(Long customerId) {
        marketingLeadRepository.unlinkCustomer(customerId);
    }

    @Override
    public MarketingLead markOrderCreated(Long id, Customer customer) {
        MarketingLead lead = getById(id);
        if (customer != null) {
            lead.setCustomer(customer);
        }
        lead.setStage(LeadStage.ORDER_CREATED);
        lead.setTaskStatus(LeadTaskStatus.DONE);
        lead.setOrderCreatedAt(LocalDateTime.now());
        lead.setUpdatedAt(LocalDateTime.now());
        return marketingLeadRepository.save(lead);
    }

    private String nextCode() {
        String base = "MKT" + LocalDateTime.now().format(CODE_MONTH);
        return reserveCode(base, marketingLeadRepository.countAll() + 1);
    }

    private void validateNewPhone(String phone) {
        if (phone == null || phone.isBlank()) {
            throw new IllegalArgumentException("Số điện thoại không được để trống");
        }
        if (marketingLeadRepository.findFirstByPhoneActive(phone).isPresent()) {
            throw new IllegalArgumentException("Số điện thoại đã tồn tại trong hệ thống");
        }
    }

    private static String codeFromId(Long id, LocalDateTime createdAt) {
        if (id == null) {
            throw new IllegalStateException("Không thể cấp mã dữ liệu marketing");
        }
        return "MKT" + createdAt.format(CODE_MONTH) + String.format("%04d", id);
    }

    private String reserveCode(String base, long startSeq) {
        long seq = startSeq;
        String candidate = base + String.format("%04d", seq);
        while (marketingLeadRepository.existsByCode(candidate)) {
            candidate = base + String.format("%04d", ++seq);
        }
        return candidate;
    }
}
