package com.xxxx.ddd.domain.service.impl;

import com.xxxx.ddd.domain.model.auth.FixedRoleLevel;
import com.xxxx.ddd.domain.model.entity.Permission;
import com.xxxx.ddd.domain.model.entity.Role;
import com.xxxx.ddd.domain.respository.PermissionRepository;
import com.xxxx.ddd.domain.respository.RoleRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.RoleDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Slf4j
@Transactional
public class RoleDomainServiceImpl implements RoleDomainService {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Role createRole(Role role, Set<String> permissionCodes, Set<String> levelCodes) {
        if (role.getName() == null || role.getName().isBlank()) {
            throw new IllegalArgumentException("Role name is required");
        }
        String code = role.getCode();
        if (code == null || code.isBlank()) {
            code = slugify(role.getName());
            role.setCode(code);
        }
        if (roleRepository.existsByCode(role.getCode())) {
            throw new IllegalArgumentException("Role code already exists");
        }
        LocalDateTime now = LocalDateTime.now();
        role.setIsDeleted(false);
        role.setCreatedAt(now);
        role.setUpdatedAt(now);
        role.setPermissions(resolvePermissions(permissionCodes));
        role.applyEnabledLevels(levelCodes);
        Role saved = roleRepository.save(role);
        log.info("Created role: {}", saved.getCode());
        return roleRepository.findByIdWithDetails(saved.getId()).orElse(saved);
    }

    @Override
    public Role updateRole(Long id, Role patch, Set<String> permissionCodes, Set<String> levelCodes) {
        Role role = getById(id);
        if (patch.getName() != null && !patch.getName().isBlank()) {
            role.setName(patch.getName());
        }
        if (patch.getSummary() != null) {
            role.setSummary(patch.getSummary());
        }
        if (patch.getCode() != null && !patch.getCode().isBlank() && !patch.getCode().equals(role.getCode())) {
            if (roleRepository.existsByCodeAndIdNot(patch.getCode(), id)) {
                throw new IllegalArgumentException("Role code already exists");
            }
            role.setCode(patch.getCode());
        }
        if (permissionCodes != null) {
            role.setPermissions(resolvePermissions(permissionCodes));
        }
        role.applyEnabledLevels(levelCodes);
        role.setUpdatedAt(LocalDateTime.now());
        roleRepository.save(role);
        return roleRepository.findByIdWithDetails(id).orElse(role);
    }

    @Override
    public void deleteRole(Long id) {
        Role role = getById(id);
        long assigned = userRepository.countByRoleId(id);
        if (assigned > 0) {
            throw new IllegalArgumentException("Cannot delete role that is assigned to users");
        }
        role.setIsDeleted(true);
        role.setUpdatedAt(LocalDateTime.now());
        roleRepository.save(role);
        log.info("Deleted role: {}", role.getCode());
    }

    @Override
    public Role getById(Long id) {
        return roleRepository.findByIdWithDetails(id)
                .orElseThrow(() -> new IllegalArgumentException("Role not found"));
    }

    @Override
    public Role getByCode(String code) {
        return roleRepository.findByCodeWithDetails(code)
                .orElseThrow(() -> new IllegalArgumentException("Role not found: " + code));
    }

    @Override
    public List<Role> findAll() {
        return roleRepository.findAllActiveWithDetails();
    }

    @Override
    public void updateLevelPermissions(Long roleId, String levelCode, Set<String> permissionCodes) {
        Role role = getById(roleId);
        if (role.hasNoLevels()) {
            throw new IllegalArgumentException("This role does not use levels");
        }
        FixedRoleLevel.require(levelCode);
        role.replaceLevelPermissions(levelCode, resolvePermissions(permissionCodes));
        role.setUpdatedAt(LocalDateTime.now());
        roleRepository.save(role);
    }

    @Override
    public List<Permission> findAllPermissions() {
        return permissionRepository.findAll();
    }

    @Override
    public Permission createPermission(Permission permission) {
        if (permission.getCode() == null || permission.getCode().isBlank()) {
            throw new IllegalArgumentException("Permission code is required");
        }
        if (permission.getLabel() == null || permission.getLabel().isBlank()) {
            throw new IllegalArgumentException("Permission label is required");
        }
        permission.setCode(slugify(permission.getCode()));
        permission.setLabel(permission.getLabel().trim());
        if (permissionRepository.existsByCode(permission.getCode())) {
            throw new IllegalArgumentException("Permission code already exists");
        }
        return permissionRepository.save(permission);
    }

    @Override
    public Permission updatePermission(String code, Permission patch) {
        if (code == null || code.isBlank()) {
            throw new IllegalArgumentException("Permission code is required");
        }
        Permission permission = permissionRepository.findByCode(code)
                .orElseThrow(() -> new IllegalArgumentException("Permission not found: " + code));
        if (patch.getLabel() == null || patch.getLabel().isBlank()) {
            throw new IllegalArgumentException("Permission label is required");
        }
        permission.setLabel(patch.getLabel().trim());
        permission.setNote(patch.getNote());
        return permissionRepository.save(permission);
    }

    @Override
    public void deletePermission(String code) {
        if (code == null || code.isBlank()) {
            throw new IllegalArgumentException("Permission code is required");
        }
        Permission permission = permissionRepository.findByCode(code)
                .orElseThrow(() -> new IllegalArgumentException("Permission not found: " + code));
        permissionRepository.deleteRoleLevelLinks(permission.getId());
        permissionRepository.deleteRoleLinks(permission.getId());
        permissionRepository.deleteById(permission.getId());
    }

    private Set<Permission> resolvePermissions(Set<String> permissionCodes) {
        if (permissionCodes == null || permissionCodes.isEmpty()) {
            return new HashSet<>();
        }
        List<Permission> found = permissionRepository.findByCodes(permissionCodes);
        if (found.size() != permissionCodes.size()) {
            throw new IllegalArgumentException("One or more permissions were not found");
        }
        return new HashSet<>(found);
    }

    private String slugify(String name) {
        String slug = java.text.Normalizer.normalize(name, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase()
                .replaceAll("[^a-z0-9]+", "_")
                .replaceAll("^_|_$", "");
        if (slug.isBlank()) {
            slug = "role_" + System.currentTimeMillis();
        }
        return slug.length() > 40 ? slug.substring(0, 40) : slug;
    }
}
