package com.xxxx.ddd.domain.service.impl;

import com.xxxx.ddd.domain.model.entity.SaleRoom;
import com.xxxx.ddd.domain.model.entity.SaleRoomTransfer;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.SaleRoomRepository;
import com.xxxx.ddd.domain.respository.SaleRoomTransferRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.SaleRoomDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class SaleRoomDomainServiceImpl implements SaleRoomDomainService {

    @Autowired
    private SaleRoomRepository saleRoomRepository;

    @Autowired
    private SaleRoomTransferRepository saleRoomTransferRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public List<SaleRoom> findAll() {
        return saleRoomRepository.findAllActive();
    }

    @Override
    @Transactional(readOnly = true)
    public SaleRoom getById(Long id) {
        return saleRoomRepository.findByIdActive(id)
                .orElseThrow(() -> new IllegalArgumentException("Sale room not found"));
    }

    @Override
    public SaleRoom create(SaleRoom room, Long leaderId, Set<Long> memberIds) {
        if (room.getName() == null || room.getName().isBlank()) {
            throw new IllegalArgumentException("Room name is required");
        }
        String name = room.getName().trim();
        String code = room.getCode() == null || room.getCode().isBlank() ? slugify(name) : slugify(room.getCode());
        if (saleRoomRepository.existsByCode(code)) {
            throw new IllegalArgumentException("Room code already exists");
        }
        LocalDateTime now = LocalDateTime.now();
        room.setName(name);
        room.setCode(code);
        room.setDescription(trimToNull(room.getDescription()));
        room.setActive(room.getActive() == null || room.getActive());
        room.setIsDeleted(false);
        room.setCreatedAt(now);
        room.setUpdatedAt(now);
        SaleRoom saved = saleRoomRepository.save(room);
        return applyMembers(saved, leaderId, memberIds, "Gán phòng khi tạo phòng Sale");
    }

    @Override
    public SaleRoom update(Long id, SaleRoom patch, Long leaderId, Set<Long> memberIds) {
        SaleRoom room = getById(id);
        if (patch.getName() != null && !patch.getName().isBlank()) {
            room.setName(patch.getName().trim());
        }
        if (patch.getCode() != null && !patch.getCode().isBlank()) {
            String code = slugify(patch.getCode());
            if (saleRoomRepository.existsByCodeAndIdNot(code, id)) {
                throw new IllegalArgumentException("Room code already exists");
            }
            room.setCode(code);
        }
        if (patch.getDescription() != null) {
            room.setDescription(trimToNull(patch.getDescription()));
        }
        if (patch.getActive() != null) {
            room.setActive(patch.getActive());
        }
        room.setUpdatedAt(LocalDateTime.now());
        SaleRoom saved = saleRoomRepository.save(room);
        if (leaderId != null || memberIds != null) {
            return applyMembers(saved, leaderId, memberIds, "Cập nhật thành viên phòng Sale");
        }
        return saved;
    }

    @Override
    public void delete(Long id) {
        SaleRoom room = getById(id);
        long members = userRepository.countBySaleRoomId(id);
        if (members > 0) {
            throw new IllegalArgumentException("Cannot delete a room that still has members. Transfer them first.");
        }
        room.setLeader(null);
        room.setIsDeleted(true);
        room.setActive(false);
        room.setUpdatedAt(LocalDateTime.now());
        saleRoomRepository.save(room);
    }

    @Override
    public User assignUser(Long userId, Long roomId, String note) {
        User user = userRepository.findByIdWithAuth(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        SaleRoom room = roomId == null ? null : getById(roomId);
        return moveUser(user, room, note);
    }

    @Override
    public User clearUserRoom(Long userId, String note) {
        return assignUser(userId, null, note);
    }

    private SaleRoom applyMembers(SaleRoom room, Long leaderId, Set<Long> memberIds, String note) {
        Set<Long> desired = new HashSet<>();
        if (memberIds != null) {
            desired.addAll(memberIds.stream().filter(Objects::nonNull).collect(Collectors.toSet()));
        }
        if (leaderId != null) {
            desired.add(leaderId);
        }

        List<User> currentMembers = userRepository.findBySaleRoomId(room.getId());
        for (User member : currentMembers) {
            if (!desired.contains(member.getId())) {
                moveUser(member, null, note);
            }
        }
        for (Long userId : desired) {
            assignUser(userId, room.getId(), note);
        }

        User leader = null;
        if (leaderId != null) {
            leader = userRepository.findByIdWithAuth(leaderId)
                    .orElseThrow(() -> new IllegalArgumentException("Leader not found"));
            if (leader.getRole() == null || !leader.getRole().isSale()) {
                throw new IllegalArgumentException("Leader must be a Sale user");
            }
            if (leader.getSaleRoom() == null || !room.getId().equals(leader.getSaleRoom().getId())) {
                throw new IllegalArgumentException("Leader must belong to this room");
            }
        }
        room.setLeader(leader);
        room.setUpdatedAt(LocalDateTime.now());
        return saleRoomRepository.save(room);
    }

    private User moveUser(User user, SaleRoom toRoom, String note) {
        if (toRoom != null && (user.getRole() == null || !user.getRole().isSale())) {
            throw new IllegalArgumentException("Only Sale users can belong to a sale room");
        }
        Long fromId = user.getSaleRoom() == null ? null : user.getSaleRoom().getId();
        Long toId = toRoom == null ? null : toRoom.getId();
        if (Objects.equals(fromId, toId)) {
            return user;
        }
        SaleRoom fromRoom = user.getSaleRoom();
        if (fromRoom != null && fromRoom.getLeader() != null && user.getId().equals(fromRoom.getLeader().getId())) {
            SaleRoom managedFrom = saleRoomRepository.findByIdActive(fromRoom.getId()).orElse(fromRoom);
            managedFrom.setLeader(null);
            managedFrom.setUpdatedAt(LocalDateTime.now());
            saleRoomRepository.save(managedFrom);
        }
        user.setSaleRoom(toRoom);
        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);
        SaleRoomTransfer transfer = new SaleRoomTransfer()
                .setUser(user)
                .setFromRoom(fromRoom)
                .setToRoom(toRoom)
                .setNote(note)
                .setTransferredAt(LocalDateTime.now());
        saleRoomTransferRepository.save(transfer);
        return userRepository.findByIdWithAuth(user.getId()).orElse(user);
    }

    private static String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private static String slugify(String name) {
        String slug = java.text.Normalizer.normalize(name, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase()
                .replaceAll("[^a-z0-9]+", "_")
                .replaceAll("^_|_$", "");
        if (slug.isBlank()) {
            slug = "sale_room_" + System.currentTimeMillis();
        }
        return slug.length() > 50 ? slug.substring(0, 50) : slug;
    }
}
