package com.xxxx.ddd.domain.service.impl;

import com.xxxx.ddd.domain.model.auth.FixedRoleLevel;
import com.xxxx.ddd.domain.model.entity.Role;
import com.xxxx.ddd.domain.model.entity.User;
import com.xxxx.ddd.domain.respository.RoleRepository;
import com.xxxx.ddd.domain.respository.UserRepository;
import com.xxxx.ddd.domain.service.SaleRoomDomainService;
import com.xxxx.ddd.domain.service.UserDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class UserDomainServiceImpl implements UserDomainService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private SaleRoomDomainService saleRoomDomainService;

    @Override
    @Transactional
    public User createUser(User user, String roleCode, String levelCode, Long saleRoomId) {
        if (user.getEmail() == null || user.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email is required");
        }
        String email = user.getEmail().trim();
        user.setEmail(email);

        if (user.getUsername() == null || user.getUsername().isBlank()) {
            user.setUsername(generateUniqueUsername(email));
        } else {
            user.setUsername(user.getUsername().trim());
            if (userRepository.existsByUsername(user.getUsername())) {
                throw new IllegalArgumentException("Username already exists");
            }
        }

        if (user.getPassword() == null || user.getPassword().isBlank()) {
            throw new IllegalArgumentException("Password is required");
        }
        if (user.getFullName() == null || user.getFullName().isBlank()) {
            throw new IllegalArgumentException("Full name is required");
        }
        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("Email already exists");
        }

        assignRoleAndLevel(user, roleCode, levelCode);
        LocalDateTime now = LocalDateTime.now();
        user.setActive(user.getActive() == null ? Boolean.TRUE : user.getActive());
        user.setIsDeleted(false);
        user.setCreatedAt(now);
        user.setUpdatedAt(now);
        User saved = userRepository.save(user);
        applySaleRoom(saved, saleRoomId);
        log.info("Created user: {} ({})", saved.getUsername(), saved.getEmail());
        return userRepository.findByIdWithAuth(saved.getId()).orElse(saved);
    }

    private String generateUniqueUsername(String email) {
        String local = email.contains("@") ? email.substring(0, email.indexOf('@')) : email;
        String base = local.replaceAll("[^a-zA-Z0-9._-]", "").toLowerCase();
        if (base.isBlank()) {
            base = "user";
        }
        if (!userRepository.existsByUsername(base)) {
            return base;
        }
        for (int i = 1; i < 1000; i++) {
            String candidate = base + i;
            if (!userRepository.existsByUsername(candidate)) {
                return candidate;
            }
        }
        String fallback = email.toLowerCase().replaceAll("[^a-zA-Z0-9]", "_");
        if (!userRepository.existsByUsername(fallback)) {
            return fallback;
        }
        return fallback + "_" + System.currentTimeMillis();
    }

    @Override
    @Transactional
    public User updateUser(Long id, User patch, String roleCode, String levelCode, Long saleRoomId) {
        User user = getById(id);
        if (patch.getFullName() != null && !patch.getFullName().isBlank()) {
            user.setFullName(patch.getFullName());
        }
        if (patch.getEmail() != null && !patch.getEmail().isBlank()) {
            if (userRepository.existsByEmailAndIdNot(patch.getEmail(), id)) {
                throw new IllegalArgumentException("Email already exists");
            }
            user.setEmail(patch.getEmail());
        }
        if (patch.getUsername() != null && !patch.getUsername().isBlank()) {
            if (userRepository.existsByUsernameAndIdNot(patch.getUsername(), id)) {
                throw new IllegalArgumentException("Username already exists");
            }
            user.setUsername(patch.getUsername());
        }
        if (patch.getPhone() != null) {
            user.setPhone(patch.getPhone());
        }
        if (patch.getBaseSalary() != null) {
            user.setBaseSalary(patch.getBaseSalary());
        }
        if (patch.getActive() != null) {
            user.setActive(patch.getActive());
        }
        if (roleCode != null || levelCode != null) {
            String nextRole = roleCode != null ? roleCode : user.getRoleCode();
            String nextLevel = levelCode != null ? levelCode : user.getLevelCode();
            assignRoleAndLevel(user, nextRole, nextLevel);
        }
        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);
        applySaleRoom(user, saleRoomId);
        return userRepository.findByIdWithAuth(id).orElse(user);
    }

    @Override
    @Transactional
    public User updateOwnProfile(Long id, String fullName, String email, String phone) {
        User user = getById(id);
        String normalizedName = fullName == null ? "" : fullName.trim();
        String normalizedEmail = email == null ? "" : email.trim();
        if (normalizedName.isBlank()) {
            throw new IllegalArgumentException("Họ và tên không được để trống");
        }
        if (normalizedEmail.isBlank()) {
            throw new IllegalArgumentException("Email không được để trống");
        }
        if (phone == null || phone.trim().isBlank()) {
            throw new IllegalArgumentException("Số điện thoại không được để trống");
        }
        if (userRepository.existsByEmailAndIdNot(normalizedEmail, id)) {
            throw new IllegalArgumentException("Email đã được sử dụng");
        }
        user.setFullName(normalizedName);
        user.setEmail(normalizedEmail);
        user.setPhone(phone == null ? null : phone.trim());
        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);
        return userRepository.findByIdWithAuth(id).orElse(user);
    }

    @Override
    @Transactional(readOnly = true)
    public User getById(Long id) {
        return userRepository.findByIdWithAuth(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }

    @Override
    @Transactional(readOnly = true)
    public User getByUsernameOrEmail(String login) {
        return userRepository.findByUsernameOrEmailWithAuth(login)
                .orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));
    }

    @Override
    @Transactional(readOnly = true)
    public User getByEmail(String email) {
        return userRepository.findByEmailWithAuth(email)
                .orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));
    }

    @Override
    @Transactional(readOnly = true)
    public List<User> search(String keyword, int pageNo, int pageSize) {
        int page = Math.max(pageNo, 1);
        int size = pageSize <= 0 ? 10 : pageSize;
        int offset = (page - 1) * size;
        return userRepository.search(keyword, offset, size);
    }

    @Override
    public long countSearch(String keyword) {
        return userRepository.countSearch(keyword);
    }

    @Override
    @Transactional
    public void changePassword(Long id, String encodedPassword) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        user.setPassword(encodedPassword);
        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);
    }

    @Override
    @Transactional
    public void deactivate(Long id) {
        User user = getById(id);
        user.setActive(false);
        user.setIsDeleted(true);
        // Free unique keys so the same email/username can be reused after soft-delete.
        String suffix = "_deleted_" + id + "_" + System.currentTimeMillis();
        if (user.getUsername() != null && !user.getUsername().isBlank()) {
            String nextUsername = user.getUsername() + suffix;
            user.setUsername(nextUsername.length() > 100 ? nextUsername.substring(0, 100) : nextUsername);
        }
        if (user.getEmail() != null && !user.getEmail().isBlank()) {
            String nextEmail = user.getEmail() + suffix;
            user.setEmail(nextEmail.length() > 255 ? nextEmail.substring(0, 255) : nextEmail);
        }
        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);
        log.info("Deactivated user id={}", id);
    }

    private void assignRoleAndLevel(User user, String roleCode, String levelCode) {
        if (roleCode == null || roleCode.isBlank()) {
            throw new IllegalArgumentException("Role is required");
        }
        Role role = roleRepository.findByCodeWithDetails(roleCode)
                .orElseThrow(() -> new IllegalArgumentException("Role not found: " + roleCode));
        if (Boolean.TRUE.equals(role.getIsDeleted())) {
            throw new IllegalArgumentException("Role is deleted: " + roleCode);
        }
        user.setRole(role);
        if (role.hasNoLevels()) {
            user.setLevelCode(null);
        } else if (role.hasOnlyOtherLevel()) {
            user.setLevelCode(FixedRoleLevel.OTHER.getCode());
        } else {
            String resolvedLevel = (levelCode == null || levelCode.isBlank())
                    ? FixedRoleLevel.defaultCode()
                    : FixedRoleLevel.require(levelCode).getCode();
            user.setLevelCode(resolvedLevel);
        }
    }

    private void applySaleRoom(User user, Long saleRoomId) {
        if (user.getId() == null) {
            return;
        }
        boolean isSale = user.getRole() != null && user.getRole().isSale();
        if (!isSale) {
            if (user.getSaleRoom() != null) {
                saleRoomDomainService.clearUserRoom(user.getId(), "Rời vai trò Sale");
            }
            return;
        }
        if (saleRoomId != null) {
            saleRoomDomainService.assignUser(user.getId(), saleRoomId, "Gán phòng Sale");
        } else if (user.getSaleRoom() != null) {
            saleRoomDomainService.clearUserRoom(user.getId(), "Bỏ gán phòng Sale");
        }
    }
}
