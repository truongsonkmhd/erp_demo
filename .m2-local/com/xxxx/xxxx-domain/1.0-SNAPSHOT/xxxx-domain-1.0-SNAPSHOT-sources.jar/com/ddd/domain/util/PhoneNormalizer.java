package com.xxxx.ddd.domain.util;

/**
 * Normalize phone values like {@code p:+84855828666} → {@code 0855828666} for dedupe lookup.
 */
public final class PhoneNormalizer {

    private PhoneNormalizer() {
    }

    public static String normalize(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        String value = raw.trim();
        if (value.regionMatches(true, 0, "p:", 0, 2)) {
            value = value.substring(2).trim();
        }
        value = value.replaceAll("[\\s()-]", "");
        if (value.startsWith("+")) {
            value = value.substring(1);
        }
        value = value.replaceAll("\\D", "");
        if (value.isEmpty()) {
            return null;
        }
        if (value.startsWith("84") && value.length() >= 11) {
            value = "0" + value.substring(2);
        } else if (!value.startsWith("0") && value.length() == 9) {
            value = "0" + value;
        } else if (!value.startsWith("0") && value.length() == 10 && value.startsWith("84")) {
            value = "0" + value.substring(2);
        }
        return value;
    }
}
