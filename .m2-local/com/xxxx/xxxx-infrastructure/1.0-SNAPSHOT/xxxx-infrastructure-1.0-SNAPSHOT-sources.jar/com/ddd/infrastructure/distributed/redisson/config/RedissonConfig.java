package com.xxxx.ddd.infrastructure.distributed.redisson.config;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RedissonConfig {

    @Value("${spring.data.redis.host:127.0.0.1}")
    private String redisHost;

    @Value("${spring.data.redis.port:6319}")
    private int redisPort;

    @Value("${spring.data.redis.password:}")
    private String redisPassword;

    @Bean
    public RedissonClient redissonClient() {
        Config config = new Config();
        var server = config.useSingleServer()
                .setAddress("redis://" + redisHost + ":" + redisPort)
                .setConnectionPoolSize(50)
                .setDatabase(0);
        if (redisPassword != null && !redisPassword.isBlank()) {
            server.setPassword(redisPassword);
        }

        return Redisson.create(config);
    }
    // to sentinel
//    @Bean
//    public RedissonClient redissonClient() {
//        Config config = new Config();
//        config.useSentinelServers()
//                .setMasterName("mymaster") // Tên master như được đặt trong Sentinel
//                .addSentinelAddress(
//                        "redis://localhost:26379",
//                        "redis://localhost:26380",
//                        "redis://localhost:26381"
//                ) // Danh sách Sentinel
//                .setPassword("123456") //
//                .setCheckSentinelsList(false)
//                .setDatabase(0) // Chọn database (mặc định là 0)
//                .setMasterConnectionPoolSize(50)
//                .setMasterConnectionMinimumIdleSize(10)
//                .setSlaveConnectionPoolSize(50)
//                .setSlaveConnectionMinimumIdleSize(10);
//
//
//        return Redisson.create(config);
//    }
}
