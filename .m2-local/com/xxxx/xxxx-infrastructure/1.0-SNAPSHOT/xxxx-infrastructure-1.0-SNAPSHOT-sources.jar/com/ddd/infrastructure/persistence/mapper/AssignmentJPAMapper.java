package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;
import com.xxxx.ddd.domain.model.workflow.AssignmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Lock;
import jakarta.persistence.LockModeType;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AssignmentJPAMapper extends JpaRepository<Assignment, Long> {

    @Query("SELECT a FROM Assignment a LEFT JOIN FETCH a.assignee LEFT JOIN FETCH a.assignedBy WHERE a.refType = :refType AND a.refId = :refId AND a.status IN :statuses ORDER BY a.assignedAt DESC, a.id DESC")
    List<Assignment> findByRefAndStatuses(@Param("refType") AssignmentRefType refType,
                                          @Param("refId") Long refId,
                                          @Param("statuses") List<AssignmentStatus> statuses);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT a FROM Assignment a WHERE a.refType = :refType AND a.refId = :refId AND a.status IN :statuses ORDER BY a.assignedAt DESC, a.id DESC")
    List<Assignment> findByRefAndStatusesForUpdate(@Param("refType") AssignmentRefType refType,
                                                   @Param("refId") Long refId,
                                                   @Param("statuses") List<AssignmentStatus> statuses);

    @Query("SELECT a FROM Assignment a JOIN FETCH a.assignee WHERE a.refType = :refType AND a.assignee.id = :assigneeId AND a.status IN :statuses ORDER BY a.refId, a.id DESC")
    List<Assignment> findCurrentByAssignee(@Param("refType") AssignmentRefType refType,
                                           @Param("assigneeId") Long assigneeId,
                                           @Param("statuses") List<AssignmentStatus> statuses);

    @Query("SELECT a FROM Assignment a LEFT JOIN FETCH a.assignee LEFT JOIN FETCH a.assignedBy WHERE a.refType = :refType AND a.refId = :refId ORDER BY a.assignedAt DESC, a.id DESC")
    List<Assignment> findHistory(@Param("refType") AssignmentRefType refType, @Param("refId") Long refId);

    @Query("SELECT a FROM Assignment a LEFT JOIN FETCH a.assignee LEFT JOIN FETCH a.assignedBy WHERE a.refType = :refType AND a.refId IN :refIds AND a.status IN :statuses ORDER BY a.assignedAt DESC, a.id DESC")
    List<Assignment> findByRefIdsAndStatuses(@Param("refType") AssignmentRefType refType,
                                             @Param("refIds") List<Long> refIds,
                                             @Param("statuses") List<AssignmentStatus> statuses);
}
