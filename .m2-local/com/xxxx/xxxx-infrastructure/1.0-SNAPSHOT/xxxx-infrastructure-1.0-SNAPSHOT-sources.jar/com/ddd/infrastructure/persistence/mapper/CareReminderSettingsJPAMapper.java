package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.CareReminderSettings;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CareReminderSettingsJPAMapper extends JpaRepository<CareReminderSettings, Long> {
}
