package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.CompanyDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface CompanyDocumentJPAMapper extends JpaRepository<CompanyDocument, Long> {

    @Query("""
            SELECT d FROM CompanyDocument d
            LEFT JOIN FETCH d.category c
            LEFT JOIN FETCH c.createdBy
            LEFT JOIN FETCH d.uploadedBy
            WHERE d.id = :id AND (d.isDeleted = false OR d.isDeleted IS NULL)
            """)
    Optional<CompanyDocument> findByIdActive(@Param("id") Long id);

    @Query("""
            SELECT d FROM CompanyDocument d
            LEFT JOIN FETCH d.category c
            LEFT JOIN FETCH c.createdBy
            LEFT JOIN FETCH d.uploadedBy
            WHERE (d.isDeleted = false OR d.isDeleted IS NULL)
              AND (c.createdBy IS NULL OR c.createdBy.id = :userId)
            ORDER BY c.sortOrder ASC, d.createdAt DESC
            """)
    List<CompanyDocument> findVisibleToUser(@Param("userId") Long userId);

    @Query("""
            SELECT d FROM CompanyDocument d
            LEFT JOIN FETCH d.category c
            LEFT JOIN FETCH c.createdBy
            LEFT JOIN FETCH d.uploadedBy
            WHERE c.id = :categoryId
              AND (d.isDeleted = false OR d.isDeleted IS NULL)
              AND (c.createdBy IS NULL OR c.createdBy.id = :userId)
            ORDER BY d.createdAt DESC
            """)
    List<CompanyDocument> findVisibleByCategoryId(@Param("categoryId") Long categoryId, @Param("userId") Long userId);

    @Query("""
            SELECT d FROM CompanyDocument d
            LEFT JOIN FETCH d.category c
            LEFT JOIN FETCH d.uploadedBy
            WHERE c.id = :categoryId
              AND (d.isDeleted = false OR d.isDeleted IS NULL)
            ORDER BY d.createdAt DESC
            """)
    List<CompanyDocument> findActiveByCategoryId(@Param("categoryId") Long categoryId);

    @Query("""
            SELECT COUNT(d) FROM CompanyDocument d
            WHERE d.category.id = :categoryId AND (d.isDeleted = false OR d.isDeleted IS NULL)
            """)
    long countByCategoryIdActive(@Param("categoryId") Long categoryId);
}
