package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.CustomerCareLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CustomerCareLogJPAMapper extends JpaRepository<CustomerCareLog, Long> {

    @Query("SELECT c FROM CustomerCareLog c LEFT JOIN FETCH c.changedBy WHERE c.leadId = :leadId ORDER BY c.createdAt DESC, c.id DESC")
    List<CustomerCareLog> findByLeadId(@Param("leadId") Long leadId);

    @Query("SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM CustomerCareLog c WHERE c.leadId = :leadId AND c.careProgress = :careProgress")
    boolean existsByLeadIdAndCareProgress(@Param("leadId") Long leadId, @Param("careProgress") String careProgress);

    @Query("SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM CustomerCareLog c WHERE c.leadId = :leadId AND c.careProgress = :careProgress AND c.id <> :id")
    boolean existsByLeadIdAndCareProgressExcludingId(
            @Param("leadId") Long leadId,
            @Param("careProgress") String careProgress,
            @Param("id") Long id
    );
}
