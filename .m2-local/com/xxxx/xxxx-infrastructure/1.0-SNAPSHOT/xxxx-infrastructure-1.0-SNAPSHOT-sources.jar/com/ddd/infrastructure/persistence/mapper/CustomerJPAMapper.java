package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface CustomerJPAMapper extends JpaRepository<Customer, Long> {

    @Query("SELECT c FROM Customer c WHERE c.id = :id AND (c.isDeleted = false OR c.isDeleted IS NULL)")
    Optional<Customer> findByIdActive(@Param("id") Long id);

    @Query("SELECT c FROM Customer c WHERE c.phone = :phone AND (c.isDeleted = false OR c.isDeleted IS NULL)")
    List<Customer> findByPhoneActive(@Param("phone") String phone);

    @Query("SELECT c FROM Customer c WHERE LOWER(c.code) = LOWER(:code)")
    Optional<Customer> findByCode(@Param("code") String code);

    @Query("SELECT c FROM Customer c WHERE c.isDeleted = false OR c.isDeleted IS NULL ORDER BY c.createdAt DESC")
    List<Customer> findAllActive();

    @Query("SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM Customer c WHERE LOWER(c.code) = LOWER(:code)")
    boolean existsByCode(@Param("code") String code);
}
