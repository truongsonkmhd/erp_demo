package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface CustomerOrderJPAMapper extends JpaRepository<CustomerOrder, Long> {

    @Query("SELECT o FROM CustomerOrder o LEFT JOIN FETCH o.customer LEFT JOIN FETCH o.assignee WHERE o.id = :id AND (o.isDeleted = false OR o.isDeleted IS NULL)")
    Optional<CustomerOrder> findByIdActive(@Param("id") Long id);

    @Query("SELECT o FROM CustomerOrder o LEFT JOIN FETCH o.customer LEFT JOIN FETCH o.assignee WHERE o.isDeleted = false OR o.isDeleted IS NULL ORDER BY o.createdAt DESC")
    List<CustomerOrder> findAllActive();

    @Query("SELECT o FROM CustomerOrder o LEFT JOIN FETCH o.customer LEFT JOIN FETCH o.assignee WHERE o.customer.id = :customerId AND (o.isDeleted = false OR o.isDeleted IS NULL) ORDER BY o.createdAt DESC")
    List<CustomerOrder> findByCustomerId(@Param("customerId") Long customerId);

    @Query("SELECT o FROM CustomerOrder o LEFT JOIN FETCH o.customer LEFT JOIN FETCH o.assignee WHERE o.customer.id = :customerId AND o.contractType = :contractType AND (o.isDeleted = false OR o.isDeleted IS NULL) ORDER BY o.createdAt DESC")
    List<CustomerOrder> findByCustomerIdAndContractTypeActive(@Param("customerId") Long customerId,
                                                               @Param("contractType") String contractType);

    @Query("SELECT o FROM CustomerOrder o LEFT JOIN FETCH o.customer LEFT JOIN FETCH o.assignee WHERE o.leadId = :leadId AND (o.isDeleted = false OR o.isDeleted IS NULL) ORDER BY o.createdAt DESC")
    List<CustomerOrder> findByLeadId(@Param("leadId") Long leadId);

    @Query("SELECT COUNT(o) FROM CustomerOrder o WHERE o.orderCode LIKE CONCAT(:prefix, '%')")
    long countByOrderCodePrefix(@Param("prefix") String prefix);

    @Query("SELECT COUNT(o) FROM CustomerOrder o WHERE o.contractType = :contractType AND o.createdAt >= :from AND o.createdAt < :toExclusive")
    long countByContractTypeAndCreatedAtBetween(@Param("contractType") String contractType,
                                                @Param("from") LocalDateTime from,
                                                @Param("toExclusive") LocalDateTime toExclusive);

    @Query("SELECT o FROM CustomerOrder o LEFT JOIN FETCH o.customer LEFT JOIN FETCH o.assignee WHERE o.orderCode = :orderCode AND (o.isDeleted = false OR o.isDeleted IS NULL)")
    Optional<CustomerOrder> findByOrderCodeActive(@Param("orderCode") String orderCode);

    @Query("SELECT o FROM CustomerOrder o LEFT JOIN FETCH o.customer LEFT JOIN FETCH o.assignee WHERE o.batchCode = :batchCode AND (o.isDeleted = false OR o.isDeleted IS NULL) ORDER BY o.createdAt DESC")
    List<CustomerOrder> findByBatchCodeActive(@Param("batchCode") String batchCode);

    @Query("""
            SELECT o FROM CustomerOrder o
            LEFT JOIN FETCH o.customer
            LEFT JOIN FETCH o.assignee
            WHERE (o.isDeleted = false OR o.isDeleted IS NULL)
              AND o.documentStatus = 'Đã bàn giao'
              AND o.documentHandedOverAt IS NOT NULL
              AND function('DATE_FORMAT', o.documentHandedOverAt, '%Y-%m') = :period
            ORDER BY o.documentHandedOverAt
            """)
    List<CustomerOrder> findSalaryEligibleByPeriod(@Param("period") String period);
}
