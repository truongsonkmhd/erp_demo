package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.DashboardKpi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DashboardKpiJPAMapper extends JpaRepository<DashboardKpi, Long> {
    @Query("SELECT k FROM DashboardKpi k JOIN FETCH k.user u LEFT JOIN FETCH u.saleRoom WHERE u.id = :userId AND k.periodMonth = :periodMonth")
    Optional<DashboardKpi> findByUserIdAndPeriodMonth(@Param("userId") Long userId, @Param("periodMonth") String periodMonth);

    @Query("SELECT k FROM DashboardKpi k JOIN FETCH k.user u LEFT JOIN FETCH u.saleRoom WHERE u.id IN :userIds AND k.periodMonth = :periodMonth")
    List<DashboardKpi> findByUserIdsAndPeriodMonth(@Param("userIds") List<Long> userIds, @Param("periodMonth") String periodMonth);
}
