package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.DashboardRoomKpi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface DashboardRoomKpiJPAMapper extends JpaRepository<DashboardRoomKpi, Long> {
    @Query("SELECT k FROM DashboardRoomKpi k JOIN FETCH k.saleRoom WHERE k.saleRoom.id = :roomId AND k.periodMonth = :month")
    Optional<DashboardRoomKpi> findOne(@Param("roomId") Long roomId, @Param("month") String month);
    @Query("SELECT k FROM DashboardRoomKpi k JOIN FETCH k.saleRoom WHERE k.periodMonth = :month")
    List<DashboardRoomKpi> findMonth(@Param("month") String month);
}
