package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.DocumentCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DocumentCategoryJPAMapper extends JpaRepository<DocumentCategory, Long> {

    @Query("SELECT c FROM DocumentCategory c LEFT JOIN FETCH c.createdBy WHERE c.id = :id AND (c.isDeleted = false OR c.isDeleted IS NULL)")
    Optional<DocumentCategory> findByIdActive(@Param("id") Long id);

    @Query("""
            SELECT c FROM DocumentCategory c
            LEFT JOIN FETCH c.createdBy
            WHERE (c.isDeleted = false OR c.isDeleted IS NULL)
              AND (c.createdBy IS NULL OR c.createdBy.id = :userId)
            ORDER BY c.sortOrder ASC, c.id ASC
            """)
    List<DocumentCategory> findVisibleToUser(@Param("userId") Long userId);

    @Query("""
            SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM DocumentCategory c
            WHERE LOWER(c.name) = LOWER(:name)
              AND (c.isDeleted = false OR c.isDeleted IS NULL)
              AND c.createdBy.id = :ownerId
            """)
    boolean existsByNameForOwner(@Param("name") String name, @Param("ownerId") Long ownerId);

    @Query("""
            SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM DocumentCategory c
            WHERE LOWER(c.name) = LOWER(:name)
              AND c.id <> :id
              AND (c.isDeleted = false OR c.isDeleted IS NULL)
              AND c.createdBy.id = :ownerId
            """)
    boolean existsByNameForOwnerAndIdNot(@Param("name") String name, @Param("ownerId") Long ownerId, @Param("id") Long id);

    @Query("""
            SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM DocumentCategory c
            WHERE LOWER(c.name) = LOWER(:name)
              AND (c.isDeleted = false OR c.isDeleted IS NULL)
              AND c.createdBy IS NULL
            """)
    boolean existsByNameShared(@Param("name") String name);

    @Query("""
            SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM DocumentCategory c
            WHERE LOWER(c.name) = LOWER(:name)
              AND c.id <> :id
              AND (c.isDeleted = false OR c.isDeleted IS NULL)
              AND c.createdBy IS NULL
            """)
    boolean existsByNameSharedAndIdNot(@Param("name") String name, @Param("id") Long id);
}
