package com.xxxx.ddd.infrastructure.persistence.mapper;
import com.xxxx.ddd.domain.model.entity.ImportEntrustOrderDetail;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ImportEntrustOrderDetailJPAMapper extends JpaRepository<ImportEntrustOrderDetail, Long> {}
