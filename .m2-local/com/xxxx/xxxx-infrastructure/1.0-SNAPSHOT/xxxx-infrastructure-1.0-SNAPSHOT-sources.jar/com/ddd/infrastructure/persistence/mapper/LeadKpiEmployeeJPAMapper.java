package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.LeadKpiEmployee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LeadKpiEmployeeJPAMapper extends JpaRepository<LeadKpiEmployee, Long> {

    @Query("""
            SELECT DISTINCT e FROM LeadKpiEmployee e
            LEFT JOIN FETCH e.user
            LEFT JOIN FETCH e.user.saleRoom
            LEFT JOIN FETCH e.scores
            WHERE e.period.id = :periodId
            """)
    List<LeadKpiEmployee> findByPeriodId(@Param("periodId") Long periodId);

    @Modifying(clearAutomatically = true)
    @Query("DELETE FROM LeadKpiScore s WHERE s.kpiEmployee.period.id = :periodId")
    void deleteScoresByPeriodId(@Param("periodId") Long periodId);

    @Modifying(clearAutomatically = true)
    @Query("DELETE FROM LeadKpiEmployee e WHERE e.period.id = :periodId")
    void deleteByPeriodId(@Param("periodId") Long periodId);
}
