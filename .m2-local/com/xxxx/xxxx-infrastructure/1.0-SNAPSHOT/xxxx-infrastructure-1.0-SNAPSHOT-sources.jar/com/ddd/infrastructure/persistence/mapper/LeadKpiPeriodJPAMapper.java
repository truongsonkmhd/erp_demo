package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.LeadKpiPeriod;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LeadKpiPeriodJPAMapper extends JpaRepository<LeadKpiPeriod, Long> {

    Optional<LeadKpiPeriod> findByPeriod(String period);
}
