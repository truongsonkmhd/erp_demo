package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.LeadKpiScore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LeadKpiScoreJPAMapper extends JpaRepository<LeadKpiScore, Long> {

    @Modifying(clearAutomatically = true)
    @Query("DELETE FROM LeadKpiScore s WHERE s.kpiEmployee.id = :employeeId")
    void deleteByEmployeeId(@Param("employeeId") Long employeeId);
}
