package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.workflow.LeadPhoneRef;
import com.xxxx.ddd.domain.model.workflow.LeadStage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface MarketingLeadJPAMapper extends JpaRepository<MarketingLead, Long> {

    @Query("SELECT l FROM MarketingLead l LEFT JOIN FETCH l.customer LEFT JOIN FETCH l.createdBy WHERE l.id = :id AND (l.isDeleted = false OR l.isDeleted IS NULL)")
    Optional<MarketingLead> findByIdActive(@Param("id") Long id);

    @Query("SELECT l FROM MarketingLead l LEFT JOIN FETCH l.customer LEFT JOIN FETCH l.createdBy WHERE l.isDeleted = false OR l.isDeleted IS NULL ORDER BY l.createdAt DESC")
    List<MarketingLead> findAllActive();

    @Query("SELECT l FROM MarketingLead l LEFT JOIN FETCH l.customer LEFT JOIN FETCH l.createdBy WHERE l.id IN :ids AND (l.isDeleted = false OR l.isDeleted IS NULL)")
    List<MarketingLead> findByIds(@Param("ids") Collection<Long> ids);

    @Query("SELECT l FROM MarketingLead l LEFT JOIN FETCH l.customer LEFT JOIN FETCH l.createdBy WHERE (l.isDeleted = false OR l.isDeleted IS NULL) AND l.stage IN :stages ORDER BY l.createdAt DESC")
    List<MarketingLead> findByStages(@Param("stages") List<LeadStage> stages);

    @Query("SELECT CASE WHEN COUNT(l) > 0 THEN true ELSE false END FROM MarketingLead l WHERE LOWER(l.code) = LOWER(:code)")
    boolean existsByCode(@Param("code") String code);

    @Query("""
            SELECT l FROM MarketingLead l
            LEFT JOIN FETCH l.customer LEFT JOIN FETCH l.createdBy
            WHERE (l.isDeleted = false OR l.isDeleted IS NULL)
              AND l.phone = :phone
            ORDER BY l.createdAt ASC
            """)
    List<MarketingLead> findByPhoneActive(@Param("phone") String phone);

    @Query("""
            SELECT new com.xxxx.ddd.domain.model.workflow.LeadPhoneRef(l.id, l.phone, null)
            FROM MarketingLead l
            WHERE (l.isDeleted = false OR l.isDeleted IS NULL)
              AND l.phone IS NOT NULL
            """)
    List<LeadPhoneRef> findAllActivePhoneRefs();

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE MarketingLead l SET l.customer = null WHERE l.customer.id = :customerId")
    int unlinkCustomer(@Param("customerId") Long customerId);
}
