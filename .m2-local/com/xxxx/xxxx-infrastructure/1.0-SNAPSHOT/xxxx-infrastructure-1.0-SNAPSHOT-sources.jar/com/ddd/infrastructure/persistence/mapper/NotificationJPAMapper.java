package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.Notification;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface NotificationJPAMapper extends JpaRepository<Notification, Long> {

    @Query("SELECT n FROM Notification n LEFT JOIN FETCH n.actor WHERE n.recipient.id = :recipientId ORDER BY n.createdAt DESC, n.id DESC")
    List<Notification> findInbox(@Param("recipientId") Long recipientId, Pageable pageable);

    @Query("""
            SELECT n FROM Notification n LEFT JOIN FETCH n.actor
            WHERE n.recipient.id = :recipientId
              AND (:unreadOnly = false OR n.isRead = false)
              AND (
                    :beforeId IS NULL
                    OR (
                        :beforeCreatedAt IS NOT NULL
                        AND (n.createdAt < :beforeCreatedAt OR (n.createdAt = :beforeCreatedAt AND n.id < :beforeId))
                    )
                    OR (:beforeCreatedAt IS NULL AND n.id < :beforeId)
                  )
            ORDER BY n.createdAt DESC, n.id DESC
            """)
    List<Notification> findInboxPage(@Param("recipientId") Long recipientId,
                                     @Param("unreadOnly") boolean unreadOnly,
                                     @Param("beforeId") Long beforeId,
                                     @Param("beforeCreatedAt") LocalDateTime beforeCreatedAt,
                                     Pageable pageable);

    @Query("SELECT n FROM Notification n LEFT JOIN FETCH n.actor WHERE n.recipient.id = :recipientId AND n.isRead = false ORDER BY n.createdAt DESC, n.id DESC")
    List<Notification> findUnread(@Param("recipientId") Long recipientId);

    @Query("SELECT COUNT(n) FROM Notification n WHERE n.recipient.id = :recipientId AND n.isRead = false")
    long countUnread(@Param("recipientId") Long recipientId);
}
