package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.SalaryLine;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SalaryLineJPAMapper extends JpaRepository<SalaryLine, Long> {

    @Query("SELECT l FROM SalaryLine l JOIN FETCH l.user LEFT JOIN FETCH l.user.saleRoom LEFT JOIN FETCH l.period WHERE l.period.id = :periodId ORDER BY l.user.fullName")
    List<SalaryLine> findByPeriodId(@Param("periodId") Long periodId);

    @Modifying(clearAutomatically = true)
    @Query("DELETE FROM SalaryLine l WHERE l.period.id = :periodId")
    void deleteByPeriodId(@Param("periodId") Long periodId);
}
