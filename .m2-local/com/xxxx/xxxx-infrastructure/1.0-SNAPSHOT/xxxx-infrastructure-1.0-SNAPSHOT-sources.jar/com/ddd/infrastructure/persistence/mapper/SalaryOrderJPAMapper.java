package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.SalaryOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface SalaryOrderJPAMapper extends JpaRepository<SalaryOrder, Long> {

    @Modifying(clearAutomatically = true)
    @Query("DELETE FROM SalaryOrder so WHERE so.salaryLine.id IN :lineIds")
    void deleteBySalaryLineIdIn(@Param("lineIds") Collection<Long> lineIds);

    @Query("SELECT so FROM SalaryOrder so LEFT JOIN FETCH so.order LEFT JOIN FETCH so.customer LEFT JOIN FETCH so.assignee WHERE so.salaryLine.id = :lineId ORDER BY so.handedOverAt")
    List<SalaryOrder> findByLineId(@Param("lineId") Long lineId);
}
