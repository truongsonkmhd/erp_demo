package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.SalaryPeriod;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface SalaryPeriodJPAMapper extends JpaRepository<SalaryPeriod, Long> {

    @Query("SELECT p FROM SalaryPeriod p LEFT JOIN FETCH p.lockedBy WHERE p.period = :period")
    Optional<SalaryPeriod> findByPeriod(@Param("period") String period);
}
