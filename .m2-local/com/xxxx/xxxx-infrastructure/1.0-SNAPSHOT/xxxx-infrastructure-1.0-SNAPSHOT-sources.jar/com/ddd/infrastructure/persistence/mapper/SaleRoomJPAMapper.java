package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.SaleRoom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface SaleRoomJPAMapper extends JpaRepository<SaleRoom, Long> {

    @Query("SELECT r FROM SaleRoom r LEFT JOIN FETCH r.leader WHERE r.id = :id AND (r.isDeleted = false OR r.isDeleted IS NULL)")
    Optional<SaleRoom> findByIdActive(@Param("id") Long id);

    @Query("SELECT r FROM SaleRoom r LEFT JOIN FETCH r.leader WHERE r.isDeleted = false OR r.isDeleted IS NULL ORDER BY r.name")
    List<SaleRoom> findAllActive();

    @Query("SELECT r FROM SaleRoom r LEFT JOIN FETCH r.leader WHERE r.leader.id = :leaderId AND (r.isDeleted = false OR r.isDeleted IS NULL)")
    Optional<SaleRoom> findByLeaderId(@Param("leaderId") Long leaderId);

    @Query("SELECT CASE WHEN COUNT(r) > 0 THEN true ELSE false END FROM SaleRoom r WHERE LOWER(r.code) = LOWER(:code) AND (r.isDeleted = false OR r.isDeleted IS NULL)")
    boolean existsByCode(@Param("code") String code);

    @Query("SELECT CASE WHEN COUNT(r) > 0 THEN true ELSE false END FROM SaleRoom r WHERE LOWER(r.code) = LOWER(:code) AND r.id <> :id AND (r.isDeleted = false OR r.isDeleted IS NULL)")
    boolean existsByCodeAndIdNot(@Param("code") String code, @Param("id") Long id);
}
