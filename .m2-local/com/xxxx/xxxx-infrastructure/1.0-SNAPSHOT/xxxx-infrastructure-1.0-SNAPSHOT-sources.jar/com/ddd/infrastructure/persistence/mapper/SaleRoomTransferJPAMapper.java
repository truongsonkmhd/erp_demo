package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.SaleRoomTransfer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SaleRoomTransferJPAMapper extends JpaRepository<SaleRoomTransfer, Long> {
}
