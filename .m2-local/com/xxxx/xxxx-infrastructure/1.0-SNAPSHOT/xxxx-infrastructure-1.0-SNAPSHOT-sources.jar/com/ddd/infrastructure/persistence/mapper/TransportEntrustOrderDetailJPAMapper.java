package com.xxxx.ddd.infrastructure.persistence.mapper;
import com.xxxx.ddd.domain.model.entity.TransportEntrustOrderDetail;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TransportEntrustOrderDetailJPAMapper extends JpaRepository<TransportEntrustOrderDetail, Long> {}
