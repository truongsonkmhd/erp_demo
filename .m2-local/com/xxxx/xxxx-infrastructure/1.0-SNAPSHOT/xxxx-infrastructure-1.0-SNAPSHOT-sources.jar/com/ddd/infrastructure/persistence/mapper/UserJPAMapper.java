package com.xxxx.ddd.infrastructure.persistence.mapper;

import com.xxxx.ddd.domain.model.entity.User;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserJPAMapper extends JpaRepository<User, Long> {

    @Query("SELECT u FROM User u LEFT JOIN FETCH u.role LEFT JOIN FETCH u.saleRoom WHERE u.id = :id AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    Optional<User> findByIdWithAuth(@Param("id") Long id);

    @Query("SELECT u FROM User u LEFT JOIN FETCH u.role LEFT JOIN FETCH u.saleRoom WHERE (LOWER(u.username) = LOWER(:login) OR LOWER(u.email) = LOWER(:login)) AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    Optional<User> findByUsernameOrEmailWithAuth(@Param("login") String login);

    @Query("SELECT u FROM User u LEFT JOIN FETCH u.role LEFT JOIN FETCH u.saleRoom WHERE LOWER(u.email) = LOWER(:email) AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    Optional<User> findByEmailWithAuth(@Param("email") String email);

    @Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END FROM User u WHERE LOWER(u.username) = LOWER(:username) AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    boolean existsByUsername(@Param("username") String username);

    @Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END FROM User u WHERE LOWER(u.email) = LOWER(:email) AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    boolean existsByEmail(@Param("email") String email);

    @Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END FROM User u WHERE LOWER(u.username) = LOWER(:username) AND u.id <> :id AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    boolean existsByUsernameAndIdNot(@Param("username") String username, @Param("id") Long id);

    @Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END FROM User u WHERE LOWER(u.email) = LOWER(:email) AND u.id <> :id AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    boolean existsByEmailAndIdNot(@Param("email") String email, @Param("id") Long id);

    @Query("SELECT u FROM User u LEFT JOIN FETCH u.role LEFT JOIN FETCH u.saleRoom WHERE (u.isDeleted = false OR u.isDeleted IS NULL) AND (:keyword IS NULL OR :keyword = '' OR LOWER(u.fullName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(u.username) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(u.email) LIKE LOWER(CONCAT('%', :keyword, '%'))) ORDER BY u.updatedAt DESC")
    List<User> search(@Param("keyword") String keyword, Pageable pageable);

    @Query("SELECT COUNT(u) FROM User u WHERE (u.isDeleted = false OR u.isDeleted IS NULL) AND (:keyword IS NULL OR :keyword = '' OR LOWER(u.fullName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(u.username) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(u.email) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    long countSearch(@Param("keyword") String keyword);

    @Query("SELECT COUNT(u) FROM User u WHERE u.role.id = :roleId AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    long countByRoleId(@Param("roleId") Long roleId);

    @Query("SELECT COUNT(u) FROM User u WHERE u.saleRoom.id = :saleRoomId AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    long countBySaleRoomId(@Param("saleRoomId") Long saleRoomId);

    @Query("SELECT u FROM User u LEFT JOIN FETCH u.role LEFT JOIN FETCH u.saleRoom WHERE u.saleRoom.id = :saleRoomId AND (u.isDeleted = false OR u.isDeleted IS NULL)")
    List<User> findBySaleRoomId(@Param("saleRoomId") Long saleRoomId);

    @Query("SELECT u FROM User u LEFT JOIN FETCH u.role LEFT JOIN FETCH u.saleRoom WHERE (u.isDeleted = false OR u.isDeleted IS NULL) AND (u.active = true OR u.active IS NULL) ORDER BY u.fullName")
    List<User> findAllActiveWithAuth();

    @Query("SELECT u FROM User u LEFT JOIN FETCH u.role LEFT JOIN FETCH u.saleRoom WHERE (u.isDeleted = false OR u.isDeleted IS NULL) ORDER BY u.fullName")
    List<User> findAllWithAuth();
}
