package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;
import com.xxxx.ddd.domain.model.workflow.AssignmentStatus;
import com.xxxx.ddd.domain.respository.AssignmentRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.AssignmentJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AssignmentRepositoryImpl implements AssignmentRepository {

    private static final List<AssignmentStatus> LIVE_STATUSES =
            List.of(AssignmentStatus.PENDING, AssignmentStatus.ACCEPTED);

    @Autowired
    private AssignmentJPAMapper assignmentJPAMapper;

    @Override
    public Assignment save(Assignment assignment) {
        return assignmentJPAMapper.save(assignment);
    }

    @Override
    public Optional<Assignment> findById(Long id) {
        return assignmentJPAMapper.findById(id);
    }

    @Override
    public Optional<Assignment> findCurrent(AssignmentRefType refType, Long refId) {
        return assignmentJPAMapper.findByRefAndStatuses(refType, refId, LIVE_STATUSES).stream().findFirst();
    }

    @Override
    public Optional<Assignment> findCurrentForUpdate(AssignmentRefType refType, Long refId) {
        return assignmentJPAMapper.findByRefAndStatusesForUpdate(refType, refId, LIVE_STATUSES).stream().findFirst();
    }

    @Override
    public List<Assignment> findCurrentByAssignee(AssignmentRefType refType, Long assigneeId) {
        return assignmentJPAMapper.findCurrentByAssignee(refType, assigneeId, LIVE_STATUSES);
    }

    @Override
    public List<Assignment> findHistory(AssignmentRefType refType, Long refId) {
        return assignmentJPAMapper.findHistory(refType, refId);
    }

    @Override
    public List<Assignment> findByRefTypeAndRefIds(AssignmentRefType refType, List<Long> refIds) {
        if (refIds == null || refIds.isEmpty()) {
            return List.of();
        }
        return assignmentJPAMapper.findByRefIdsAndStatuses(refType, refIds, LIVE_STATUSES);
    }
}
