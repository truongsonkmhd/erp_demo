package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.CareReminderSettings;
import com.xxxx.ddd.domain.respository.CareReminderSettingsRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.CareReminderSettingsJPAMapper;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class CareReminderSettingsRepositoryImpl implements CareReminderSettingsRepository {
    private final CareReminderSettingsJPAMapper mapper;

    public CareReminderSettingsRepositoryImpl(CareReminderSettingsJPAMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public Optional<CareReminderSettings> find() {
        return mapper.findById(CareReminderSettings.SINGLETON_ID);
    }

    @Override
    public CareReminderSettings save(CareReminderSettings settings) {
        return mapper.save(settings);
    }
}
