package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.CompanyDocument;
import com.xxxx.ddd.domain.respository.CompanyDocumentRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.CompanyDocumentJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CompanyDocumentRepositoryImpl implements CompanyDocumentRepository {

    @Autowired
    private CompanyDocumentJPAMapper companyDocumentJPAMapper;

    @Override
    public CompanyDocument save(CompanyDocument document) {
        return companyDocumentJPAMapper.save(document);
    }

    @Override
    public Optional<CompanyDocument> findByIdActive(Long id) {
        return companyDocumentJPAMapper.findByIdActive(id);
    }

    @Override
    public List<CompanyDocument> findVisibleToUser(Long userId) {
        return companyDocumentJPAMapper.findVisibleToUser(userId);
    }

    @Override
    public List<CompanyDocument> findVisibleByCategoryId(Long categoryId, Long userId) {
        return companyDocumentJPAMapper.findVisibleByCategoryId(categoryId, userId);
    }

    @Override
    public List<CompanyDocument> findActiveByCategoryId(Long categoryId) {
        return companyDocumentJPAMapper.findActiveByCategoryId(categoryId);
    }

    @Override
    public long countByCategoryIdActive(Long categoryId) {
        return companyDocumentJPAMapper.countByCategoryIdActive(categoryId);
    }
}
