package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.CustomerCareLog;
import com.xxxx.ddd.domain.respository.CustomerCareLogRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.CustomerCareLogJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerCareLogRepositoryImpl implements CustomerCareLogRepository {

    @Autowired
    private CustomerCareLogJPAMapper customerCareLogJPAMapper;

    @Override
    public CustomerCareLog save(CustomerCareLog log) {
        return customerCareLogJPAMapper.save(log);
    }

    @Override
    public java.util.Optional<CustomerCareLog> findById(Long id) {
        return customerCareLogJPAMapper.findById(id);
    }

    @Override
    public List<CustomerCareLog> findByLeadId(Long leadId) {
        return customerCareLogJPAMapper.findByLeadId(leadId);
    }

    @Override
    public boolean existsByLeadIdAndCareProgress(Long leadId, String careProgress) {
        return customerCareLogJPAMapper.existsByLeadIdAndCareProgress(leadId, careProgress);
    }

    @Override
    public boolean existsByLeadIdAndCareProgressExcludingId(Long leadId, String careProgress, Long id) {
        return customerCareLogJPAMapper.existsByLeadIdAndCareProgressExcludingId(leadId, careProgress, id);
    }

    @Override
    public void delete(CustomerCareLog log) {
        customerCareLogJPAMapper.delete(log);
    }
}
