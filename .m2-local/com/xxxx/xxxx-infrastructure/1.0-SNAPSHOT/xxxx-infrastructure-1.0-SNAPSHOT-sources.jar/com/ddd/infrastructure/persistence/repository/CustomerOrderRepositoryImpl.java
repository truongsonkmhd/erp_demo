package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.CustomerOrder;
import com.xxxx.ddd.domain.respository.CustomerOrderRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.CustomerOrderJPAMapper;
import com.xxxx.ddd.domain.model.query.OrderSearchCriteria;
import com.xxxx.ddd.domain.model.query.OrderSearchResult;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerOrderRepositoryImpl implements CustomerOrderRepository {

    @Autowired
    private CustomerOrderJPAMapper customerOrderJPAMapper;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public CustomerOrder save(CustomerOrder order) {
        return customerOrderJPAMapper.save(order);
    }

    @Override
    public Optional<CustomerOrder> findByIdActive(Long id) {
        return customerOrderJPAMapper.findByIdActive(id);
    }

    @Override
    public List<CustomerOrder> findAllActive() {
        return customerOrderJPAMapper.findAllActive();
    }

    @Override
    public OrderSearchResult search(OrderSearchCriteria criteria) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<CustomerOrder> dataQuery = cb.createQuery(CustomerOrder.class);
        Root<CustomerOrder> order = dataQuery.from(CustomerOrder.class);
        order.fetch("customer", JoinType.LEFT);
        order.fetch("assignee", JoinType.LEFT);
        dataQuery.select(order).where(buildPredicates(cb, order, criteria));
        dataQuery.orderBy(cb.desc(order.get("createdAt")), cb.desc(order.get("id")));

        int size = Math.min(Math.max(criteria.getPageSize(), 1), 100);
        int page = Math.max(criteria.getPageNo(), 1);
        TypedQuery<CustomerOrder> typed = entityManager.createQuery(dataQuery);
        typed.setFirstResult((page - 1) * size);
        typed.setMaxResults(size);

        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
        Root<CustomerOrder> countRoot = countQuery.from(CustomerOrder.class);
        countQuery.select(cb.count(countRoot)).where(buildPredicates(cb, countRoot, criteria));
        long total = entityManager.createQuery(countQuery).getSingleResult();
        return new OrderSearchResult(typed.getResultList(), total);
    }

    private Predicate[] buildPredicates(CriteriaBuilder cb, Root<CustomerOrder> order, OrderSearchCriteria c) {
        java.util.ArrayList<Predicate> predicates = new java.util.ArrayList<>();
        Join<Object, Object> customer = order.join("customer", JoinType.LEFT);
        Join<Object, Object> salesOwner = order.join("salesOwner", JoinType.LEFT);
        Join<Object, Object> customerCareStaff = customer.join("customerCareStaff", JoinType.LEFT);
        predicates.add(cb.or(cb.isFalse(order.get("isDeleted")), cb.isNull(order.get("isDeleted"))));
        addLike(cb, predicates, order.get("orderCode"), c.getOrderCode());
        addLike(cb, predicates, order.get("batchCode"), c.getBatchCode());
        addLike(cb, predicates, order.get("category"), c.getCategory());
        addLike(cb, predicates, order.get("productName"), c.getProductName());
        addLike(cb, predicates, customer.get("code"), c.getCustomerCode());
        addLike(cb, predicates, customer.get("fullName"), c.getCustomerName());
        addLike(cb, predicates, customer.get("phone"), c.getPhone());
        addLike(cb, predicates, salesOwner.get("fullName"), c.getSalesName());
        addLike(cb, predicates, customerCareStaff.get("fullName"), c.getCustomerCareName());
        if (text(c.getContractType())) predicates.add(cb.equal(order.get("contractType"), c.getContractType()));
        if (c.getCreatedFrom() != null) predicates.add(cb.greaterThanOrEqualTo(order.get("createdAt"), c.getCreatedFrom()));
        if (c.getCreatedToExclusive() != null) predicates.add(cb.lessThan(order.get("createdAt"), c.getCreatedToExclusive()));
        if (c.getAssigneeId() != null) predicates.add(cb.equal(order.get("assignee").get("id"), c.getAssigneeId()));
        if (c.getCustomerCareStaffId() != null) predicates.add(cb.equal(customerCareStaff.get("id"), c.getCustomerCareStaffId()));
        if (c.getCustomerIds() != null) {
            predicates.add(c.getCustomerIds().isEmpty() ? cb.disjunction() : customer.get("id").in(c.getCustomerIds()));
        }
        if (text(c.getQuery())) {
            String q = pattern(c.getQuery());
            predicates.add(cb.or(
                    cb.like(cb.lower(customer.get("code")), q), cb.like(cb.lower(customer.get("fullName")), q),
                    cb.like(cb.lower(customer.get("phone")), q), cb.like(cb.lower(order.get("orderCode")), q),
                    cb.like(cb.lower(order.get("batchCode")), q), cb.like(cb.lower(order.get("productName")), q),
                    cb.like(cb.lower(order.get("category")), q), cb.like(cb.lower(order.get("serviceType")), q),
                    cb.like(cb.lower(order.get("salaryCustomerKind")), q)));
        }
        return predicates.toArray(Predicate[]::new);
    }

    private static void addLike(CriteriaBuilder cb, java.util.List<Predicate> predicates, Path<String> path, String value) {
        if (text(value)) predicates.add(cb.like(cb.lower(path), pattern(value)));
    }
    private static boolean text(String value) { return value != null && !value.isBlank(); }
    private static String pattern(String value) { return "%" + value.trim().toLowerCase(java.util.Locale.ROOT) + "%"; }

    @Override
    public List<CustomerOrder> findByCustomerId(Long customerId) {
        return customerOrderJPAMapper.findByCustomerId(customerId);
    }

    @Override
    public Optional<CustomerOrder> findByCustomerIdAndContractTypeActive(Long customerId, String contractType) {
        return customerOrderJPAMapper.findByCustomerIdAndContractTypeActive(customerId, contractType)
                .stream().findFirst();
    }

    @Override
    public List<CustomerOrder> findByLeadId(Long leadId) {
        return customerOrderJPAMapper.findByLeadId(leadId);
    }

    @Override
    public long countByOrderCodePrefix(String prefix) {
        return customerOrderJPAMapper.countByOrderCodePrefix(prefix);
    }

    @Override
    public long countByContractTypeAndCreatedAtBetween(String contractType, LocalDateTime from,
                                                       LocalDateTime toExclusive) {
        return customerOrderJPAMapper.countByContractTypeAndCreatedAtBetween(contractType, from, toExclusive);
    }

    @Override
    public Optional<CustomerOrder> findByOrderCodeActive(String orderCode) {
        return customerOrderJPAMapper.findByOrderCodeActive(orderCode);
    }

    @Override
    public Optional<CustomerOrder> findFirstByBatchCodeActive(String batchCode) {
        List<CustomerOrder> list = customerOrderJPAMapper.findByBatchCodeActive(batchCode);
        return list.isEmpty() ? Optional.empty() : Optional.of(list.get(0));
    }

    @Override
    public List<CustomerOrder> findSalaryEligibleByPeriod(String periodYearMonth) {
        return customerOrderJPAMapper.findSalaryEligibleByPeriod(periodYearMonth);
    }
}
