package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.Customer;
import com.xxxx.ddd.domain.respository.CustomerRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.CustomerJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerRepositoryImpl implements CustomerRepository {

    @Autowired
    private CustomerJPAMapper customerJPAMapper;

    @Override
    public Customer save(Customer customer) {
        return customerJPAMapper.save(customer);
    }

    @Override
    public Optional<Customer> findByIdActive(Long id) {
        return customerJPAMapper.findByIdActive(id);
    }

    @Override
    public Optional<Customer> findByPhoneActive(String phone) {
        if (phone == null || phone.isBlank()) {
            return Optional.empty();
        }
        return customerJPAMapper.findByPhoneActive(phone.trim()).stream().findFirst();
    }

    @Override
    public Optional<Customer> findByCode(String code) {
        if (code == null || code.isBlank()) {
            return Optional.empty();
        }
        return customerJPAMapper.findByCode(code.trim());
    }

    @Override
    public List<Customer> findAllActive() {
        return customerJPAMapper.findAllActive();
    }

    @Override
    public boolean existsByCode(String code) {
        return customerJPAMapper.existsByCode(code);
    }
}
