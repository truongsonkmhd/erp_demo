package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.DashboardKpi;
import com.xxxx.ddd.domain.respository.DashboardKpiRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.DashboardKpiJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DashboardKpiRepositoryImpl implements DashboardKpiRepository {
    @Autowired private DashboardKpiJPAMapper mapper;
    public Optional<DashboardKpi> findByUserIdAndPeriodMonth(Long userId, String periodMonth) { return mapper.findByUserIdAndPeriodMonth(userId, periodMonth); }
    public List<DashboardKpi> findByUserIdsAndPeriodMonth(List<Long> userIds, String periodMonth) { return userIds.isEmpty() ? List.of() : mapper.findByUserIdsAndPeriodMonth(userIds, periodMonth); }
    public DashboardKpi save(DashboardKpi kpi) { return mapper.save(kpi); }
}
