package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.DashboardRoomKpi;
import com.xxxx.ddd.domain.respository.DashboardRoomKpiRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.DashboardRoomKpiJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class DashboardRoomKpiRepositoryImpl implements DashboardRoomKpiRepository {
    @Autowired private DashboardRoomKpiJPAMapper mapper;
    public Optional<DashboardRoomKpi> findBySaleRoomIdAndPeriodMonth(Long roomId, String month) { return mapper.findOne(roomId, month); }
    public List<DashboardRoomKpi> findByPeriodMonth(String month) { return mapper.findMonth(month); }
    public DashboardRoomKpi save(DashboardRoomKpi entity) { return mapper.save(entity); }
}
