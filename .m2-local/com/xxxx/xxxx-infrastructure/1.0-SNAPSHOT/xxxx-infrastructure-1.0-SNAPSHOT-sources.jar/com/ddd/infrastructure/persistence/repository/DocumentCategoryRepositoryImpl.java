package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.DocumentCategory;
import com.xxxx.ddd.domain.respository.DocumentCategoryRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.DocumentCategoryJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DocumentCategoryRepositoryImpl implements DocumentCategoryRepository {

    @Autowired
    private DocumentCategoryJPAMapper documentCategoryJPAMapper;

    @Override
    public DocumentCategory save(DocumentCategory category) {
        return documentCategoryJPAMapper.save(category);
    }

    @Override
    public Optional<DocumentCategory> findByIdActive(Long id) {
        return documentCategoryJPAMapper.findByIdActive(id);
    }

    @Override
    public List<DocumentCategory> findVisibleToUser(Long userId) {
        return documentCategoryJPAMapper.findVisibleToUser(userId);
    }

    @Override
    public boolean existsByNameForOwner(String name, Long ownerId) {
        return documentCategoryJPAMapper.existsByNameForOwner(name, ownerId);
    }

    @Override
    public boolean existsByNameForOwnerAndIdNot(String name, Long ownerId, Long id) {
        return documentCategoryJPAMapper.existsByNameForOwnerAndIdNot(name, ownerId, id);
    }

    @Override
    public boolean existsByNameShared(String name) {
        return documentCategoryJPAMapper.existsByNameShared(name);
    }

    @Override
    public boolean existsByNameSharedAndIdNot(String name, Long id) {
        return documentCategoryJPAMapper.existsByNameSharedAndIdNot(name, id);
    }
}
