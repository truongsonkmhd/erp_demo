package com.xxxx.ddd.infrastructure.persistence.repository;
import com.xxxx.ddd.domain.model.entity.ImportEntrustOrderDetail;
import com.xxxx.ddd.domain.respository.ImportEntrustOrderDetailRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.ImportEntrustOrderDetailJPAMapper;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;
@Repository
public class ImportEntrustOrderDetailRepositoryImpl implements ImportEntrustOrderDetailRepository {
    private final ImportEntrustOrderDetailJPAMapper mapper;
    public ImportEntrustOrderDetailRepositoryImpl(ImportEntrustOrderDetailJPAMapper mapper) { this.mapper = mapper; }
    public ImportEntrustOrderDetail save(ImportEntrustOrderDetail detail) { return mapper.save(detail); }
    public Optional<ImportEntrustOrderDetail> findByOrderId(Long orderId) { return mapper.findById(orderId); }
    public List<ImportEntrustOrderDetail> findAllByOrderId(Iterable<Long> orderIds) { return mapper.findAllById(orderIds); }
    public void deleteByOrderId(Long orderId) { mapper.deleteById(orderId); }
}
