package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.LeadKpiEmployee;
import com.xxxx.ddd.domain.respository.LeadKpiEmployeeRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.LeadKpiEmployeeJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

@Service
public class LeadKpiEmployeeRepositoryImpl implements LeadKpiEmployeeRepository {

    @Autowired
    private LeadKpiEmployeeJPAMapper leadKpiEmployeeJPAMapper;

    @Override
    public LeadKpiEmployee save(LeadKpiEmployee employee) {
        return leadKpiEmployeeJPAMapper.save(employee);
    }

    @Override
    public List<LeadKpiEmployee> findByPeriodId(Long periodId) {
        List<LeadKpiEmployee> list = leadKpiEmployeeJPAMapper.findByPeriodId(periodId);
        list.sort(Comparator.comparing(LeadKpiEmployee::getId, Comparator.nullsLast(Long::compareTo)));
        return list;
    }

    @Override
    @Transactional
    public void deleteByPeriodId(Long periodId) {
        leadKpiEmployeeJPAMapper.deleteScoresByPeriodId(periodId);
        leadKpiEmployeeJPAMapper.deleteByPeriodId(periodId);
    }

    @Override
    public void delete(LeadKpiEmployee employee) {
        leadKpiEmployeeJPAMapper.delete(employee);
    }
}
