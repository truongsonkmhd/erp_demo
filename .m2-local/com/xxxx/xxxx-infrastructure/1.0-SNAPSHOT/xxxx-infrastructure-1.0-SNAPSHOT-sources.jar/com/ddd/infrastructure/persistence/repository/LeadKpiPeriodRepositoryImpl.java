package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.LeadKpiPeriod;
import com.xxxx.ddd.domain.respository.LeadKpiPeriodRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.LeadKpiPeriodJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LeadKpiPeriodRepositoryImpl implements LeadKpiPeriodRepository {

    @Autowired
    private LeadKpiPeriodJPAMapper leadKpiPeriodJPAMapper;

    @Override
    public LeadKpiPeriod save(LeadKpiPeriod period) {
        return leadKpiPeriodJPAMapper.save(period);
    }

    @Override
    public Optional<LeadKpiPeriod> findByPeriod(String period) {
        return leadKpiPeriodJPAMapper.findByPeriod(period);
    }

    @Override
    public Optional<LeadKpiPeriod> findById(Long id) {
        return leadKpiPeriodJPAMapper.findById(id);
    }
}
