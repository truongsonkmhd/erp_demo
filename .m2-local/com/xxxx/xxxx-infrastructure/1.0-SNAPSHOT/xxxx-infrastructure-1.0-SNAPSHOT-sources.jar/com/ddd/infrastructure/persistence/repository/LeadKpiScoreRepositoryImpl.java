package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.LeadKpiScore;
import com.xxxx.ddd.domain.respository.LeadKpiScoreRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.LeadKpiScoreJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LeadKpiScoreRepositoryImpl implements LeadKpiScoreRepository {

    @Autowired
    private LeadKpiScoreJPAMapper leadKpiScoreJPAMapper;

    @Override
    public LeadKpiScore save(LeadKpiScore score) {
        return leadKpiScoreJPAMapper.save(score);
    }

    @Override
    public void deleteByEmployeeId(Long employeeId) {
        leadKpiScoreJPAMapper.deleteByEmployeeId(employeeId);
    }
}
