package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.Assignment;
import com.xxxx.ddd.domain.model.entity.MarketingLead;
import com.xxxx.ddd.domain.model.workflow.AssignmentRefType;
import com.xxxx.ddd.domain.model.workflow.AssignmentStatus;
import com.xxxx.ddd.domain.model.workflow.CampaignNamesJson;
import com.xxxx.ddd.domain.model.workflow.LeadPhoneRef;
import com.xxxx.ddd.domain.model.workflow.LeadStage;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadPage;
import com.xxxx.ddd.domain.model.workflow.MarketingLeadSearchCriteria;
import com.xxxx.ddd.domain.respository.MarketingLeadRepository;
import com.xxxx.ddd.domain.respository.MarketingLeadStatsAggregate;
import com.xxxx.ddd.infrastructure.persistence.mapper.MarketingLeadJPAMapper;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.CommonAbstractCriteria;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class MarketingLeadRepositoryImpl implements MarketingLeadRepository {

    @Autowired
    private MarketingLeadJPAMapper marketingLeadJPAMapper;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public MarketingLead save(MarketingLead lead) {
        return marketingLeadJPAMapper.save(lead);
    }

    @Override
    public List<MarketingLead> saveAll(List<MarketingLead> leads) {
        if (leads == null || leads.isEmpty()) {
            return List.of();
        }
        return marketingLeadJPAMapper.saveAll(leads);
    }

    @Override
    public List<LeadPhoneRef> findAllActivePhoneRefs() {
        return marketingLeadJPAMapper.findAllActivePhoneRefs();
    }

    @Override
    public Optional<MarketingLead> findByIdActive(Long id) {
        return marketingLeadJPAMapper.findByIdActive(id);
    }

    @Override
    public List<MarketingLead> findAllActive() {
        return marketingLeadJPAMapper.findAllActive();
    }

    @Override
    public List<MarketingLead> findByIds(Collection<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return List.of();
        }
        return marketingLeadJPAMapper.findByIds(ids);
    }

    @Override
    public List<MarketingLead> findByStages(List<LeadStage> stages) {
        if (stages == null || stages.isEmpty()) {
            return marketingLeadJPAMapper.findAllActive();
        }
        return marketingLeadJPAMapper.findByStages(stages);
    }

    @Override
    public MarketingLeadPage search(MarketingLeadSearchCriteria criteria) {
        int pageNo = criteria.normalizedPageNo();
        int pageSize = criteria.normalizedPageSize();

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<Long> countCq = cb.createQuery(Long.class);
        Root<MarketingLead> countRoot = countCq.from(MarketingLead.class);
        countCq.select(cb.countDistinct(countRoot));
        countCq.where(buildPredicates(cb, countCq, countRoot, criteria).toArray(Predicate[]::new));
        long total = entityManager.createQuery(countCq).getSingleResult();
        if (total == 0) {
            return new MarketingLeadPage(List.of(), 0, pageNo, pageSize);
        }

        CriteriaQuery<Long> idCq = cb.createQuery(Long.class);
        Root<MarketingLead> idRoot = idCq.from(MarketingLead.class);
        idCq.select(idRoot.get("id"));
        idCq.where(buildPredicates(cb, idCq, idRoot, criteria).toArray(Predicate[]::new));
        idCq.orderBy(buildOrder(cb, idRoot, criteria));
        TypedQuery<Long> idQuery = entityManager.createQuery(idCq);
        idQuery.setFirstResult(criteria.offset());
        idQuery.setMaxResults(pageSize);
        List<Long> ids = idQuery.getResultList();
        if (ids.isEmpty()) {
            return new MarketingLeadPage(List.of(), total, pageNo, pageSize);
        }

        List<MarketingLead> fetched = marketingLeadJPAMapper.findByIds(ids);
        Map<Long, MarketingLead> byId = fetched.stream()
                .collect(Collectors.toMap(MarketingLead::getId, Function.identity(), (a, b) -> a, LinkedHashMap::new));
        List<MarketingLead> ordered = ids.stream().map(byId::get).filter(item -> item != null).toList();
        return new MarketingLeadPage(ordered, total, pageNo, pageSize);
    }

    @Override
    public MarketingLeadStatsAggregate stats(MarketingLeadSearchCriteria criteria) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<Long> totalCq = cb.createQuery(Long.class);
        Root<MarketingLead> totalRoot = totalCq.from(MarketingLead.class);
        totalCq.select(cb.countDistinct(totalRoot));
        totalCq.where(buildPredicates(cb, totalCq, totalRoot, criteria).toArray(Predicate[]::new));
        long total = entityManager.createQuery(totalCq).getSingleResult();

        CriteriaQuery<Long> marketingSourceCq = cb.createQuery(Long.class);
        Root<MarketingLead> marketingSourceRoot = marketingSourceCq.from(MarketingLead.class);
        List<Predicate> marketingSourcePreds = buildPredicates(cb, marketingSourceCq, marketingSourceRoot, criteria);
        marketingSourcePreds.add(cb.lower(cb.trim(marketingSourceRoot.get("leadSource"))).in("mkt", "marketing"));
        marketingSourceCq.select(cb.countDistinct(marketingSourceRoot));
        marketingSourceCq.where(marketingSourcePreds.toArray(Predicate[]::new));
        long marketingSourceTotal = entityManager.createQuery(marketingSourceCq).getSingleResult();

        CriteriaQuery<Long> careCq = cb.createQuery(Long.class);
        Root<MarketingLead> careRoot = careCq.from(MarketingLead.class);
        List<Predicate> carePreds = buildPredicates(cb, careCq, careRoot, criteria);
        carePreds.add(cb.and(
                cb.isNotNull(careRoot.get("careProgress")),
                cb.notEqual(careRoot.get("careProgress"), "")
        ));
        careCq.select(cb.countDistinct(careRoot));
        careCq.where(carePreds.toArray(Predicate[]::new));
        long withCare = entityManager.createQuery(careCq).getSingleResult();

        CriteriaQuery<Long> customerCq = cb.createQuery(Long.class);
        Root<MarketingLead> customerRoot = customerCq.from(MarketingLead.class);
        List<Predicate> customerPreds = buildPredicates(cb, customerCq, customerRoot, criteria);
        customerPreds.add(cb.isNotNull(customerRoot.get("customer")));
        customerCq.select(cb.countDistinct(customerRoot));
        customerCq.where(customerPreds.toArray(Predicate[]::new));
        long customerCreated = entityManager.createQuery(customerCq).getSingleResult();

        CriteriaQuery<Object[]> stageCq = cb.createQuery(Object[].class);
        Root<MarketingLead> stageRoot = stageCq.from(MarketingLead.class);
        stageCq.multiselect(stageRoot.get("stage"), cb.countDistinct(stageRoot));
        stageCq.where(buildPredicates(cb, stageCq, stageRoot, criteria).toArray(Predicate[]::new));
        stageCq.groupBy(stageRoot.get("stage"));
        Map<String, Long> byStage = new LinkedHashMap<>();
        for (Object[] row : entityManager.createQuery(stageCq).getResultList()) {
            LeadStage stage = (LeadStage) row[0];
            Long count = (Long) row[1];
            byStage.put(stage == null ? "UNKNOWN" : stage.name(), count == null ? 0L : count);
        }
        CriteriaQuery<Object[]> careProgressCq = cb.createQuery(Object[].class);
        Root<MarketingLead> careProgressRoot = careProgressCq.from(MarketingLead.class);
        careProgressCq.multiselect(careProgressRoot.get("careProgress"), cb.countDistinct(careProgressRoot));
        List<Predicate> careProgressPreds = buildPredicates(cb, careProgressCq, careProgressRoot, criteria);
        careProgressPreds.add(cb.isNotNull(careProgressRoot.get("careProgress")));
        careProgressPreds.add(cb.notEqual(careProgressRoot.get("careProgress"), ""));
        careProgressCq.where(careProgressPreds.toArray(Predicate[]::new));
        careProgressCq.groupBy(careProgressRoot.get("careProgress"));
        Map<String, Long> byCareProgress = new LinkedHashMap<>();
        for (Object[] row : entityManager.createQuery(careProgressCq).getResultList()) {
            byCareProgress.put(String.valueOf(row[0]), row[1] == null ? 0L : (Long) row[1]);
        }
        long wrongInsight = byCareProgress.entrySet().stream()
                .filter(entry -> entry.getKey() != null
                        && entry.getKey().trim().toUpperCase(Locale.ROOT).startsWith("K0"))
                .mapToLong(entry -> entry.getValue() == null ? 0L : entry.getValue())
                .sum();
        return new MarketingLeadStatsAggregate(total, withCare, wrongInsight, customerCreated, marketingSourceTotal, byStage, byCareProgress);
    }

    @Override
    public Optional<MarketingLead> lookup(MarketingLeadSearchCriteria criteria) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> idCq = cb.createQuery(Long.class);
        Root<MarketingLead> idRoot = idCq.from(MarketingLead.class);
        idCq.select(idRoot.get("id"));
        idCq.where(buildPredicates(cb, idCq, idRoot, criteria).toArray(Predicate[]::new));
        idCq.orderBy(buildOrder(cb, idRoot, criteria));
        List<Long> ids = entityManager.createQuery(idCq).setMaxResults(1).getResultList();
        if (ids.isEmpty()) {
            return Optional.empty();
        }
        return marketingLeadJPAMapper.findByIdActive(ids.get(0));
    }

    @Override
    public boolean existsByCode(String code) {
        return marketingLeadJPAMapper.existsByCode(code);
    }

    @Override
    public long countAll() {
        return marketingLeadJPAMapper.count();
    }

    private List<Predicate> buildPredicates(
            CriteriaBuilder cb,
            CommonAbstractCriteria cq,
            Root<MarketingLead> root,
            MarketingLeadSearchCriteria criteria
    ) {
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(cb.or(cb.isFalse(root.get("isDeleted")), cb.isNull(root.get("isDeleted"))));

        if (criteria.getStages() != null && !criteria.getStages().isEmpty()) {
            predicates.add(root.get("stage").in(criteria.getStages()));
        }
        if (hasText(criteria.getName())) {
            predicates.add(cb.like(cb.lower(root.get("fullName")), "%" + criteria.getName().trim().toLowerCase() + "%"));
        }
        if (hasText(criteria.getPhone())) {
            predicates.add(cb.like(root.get("phone"), "%" + criteria.getPhone().trim() + "%"));
        }
        if (hasText(criteria.getCategory())) {
            predicates.add(cb.like(cb.lower(root.get("category")), "%" + criteria.getCategory().trim().toLowerCase() + "%"));
        }
        if (hasText(criteria.getSource())) {
            predicates.add(cb.equal(cb.lower(root.get("leadSource")), criteria.getSource().trim().toLowerCase()));
        }
        if (hasText(criteria.getCareProgress())) {
            String careProgress = criteria.getCareProgress().trim().toLowerCase();
            if (careProgress.startsWith("l4")) {
                // Dữ liệu trước khi đổi mã có thể vẫn lưu dưới tiền tố L5.
                predicates.add(cb.or(
                        cb.like(cb.lower(root.get("careProgress")), "l4%"),
                        cb.like(cb.lower(root.get("careProgress")), "l5%")
                ));
            } else {
                predicates.add(cb.equal(cb.lower(root.get("careProgress")), careProgress));
            }
        }
        if (criteria.getCustomerCreated() != null) {
            predicates.add(criteria.getCustomerCreated()
                    ? cb.isNotNull(root.get("customer"))
                    : cb.isNull(root.get("customer")));
        }
        if (hasText(criteria.getCode())) {
            predicates.add(cb.equal(cb.lower(root.get("code")), criteria.getCode().trim().toLowerCase()));
        }
        if (hasText(criteria.getQuery())) {
            String q = "%" + criteria.getQuery().trim().toLowerCase() + "%";
            String phoneQ = "%" + criteria.getQuery().trim().replaceAll("\\D", "") + "%";
            List<Predicate> ors = new ArrayList<>();
            ors.add(cb.like(cb.lower(root.get("fullName")), q));
            ors.add(cb.like(cb.lower(root.get("code")), q));
            if (phoneQ.length() > 2) {
                ors.add(cb.like(root.get("phone"), phoneQ));
            }
            predicates.add(cb.or(ors.toArray(Predicate[]::new)));
        }
        if (criteria.getCreatedFrom() != null) {
            predicates.add(cb.greaterThanOrEqualTo(root.get("createdAt"), criteria.getCreatedFrom()));
        }
        if (criteria.getCreatedTo() != null) {
            predicates.add(cb.lessThanOrEqualTo(root.get("createdAt"), criteria.getCreatedTo()));
        }
        if (criteria.getAssignedAssigneeId() != null || criteria.isAssignedOnly() || criteria.isUnassigned()) {
            Subquery<Long> assigned = cq.subquery(Long.class);
            Root<Assignment> assignment = assigned.from(Assignment.class);
            List<Predicate> assignmentPredicates = new ArrayList<>();
            assignmentPredicates.add(cb.equal(assignment.get("refId"), root.get("id")));
            assignmentPredicates.add(cb.equal(assignment.get("refType"), AssignmentRefType.MARKETING_LEAD));
            assignmentPredicates.add(assignment.get("status").in(AssignmentStatus.PENDING, AssignmentStatus.ACCEPTED));
            if (criteria.getAssignedAssigneeId() != null) {
                assignmentPredicates.add(cb.equal(assignment.get("assignee").get("id"), criteria.getAssignedAssigneeId()));
            }
            if (criteria.isUnassigned()) {
                // "Chưa phân Sales" means there is no active Sales employee currently
                // responsible for the lead. Historical assignments to locked/deleted
                // accounts (or to another role) must not hide the lead from this filter.
                assignmentPredicates.add(cb.isTrue(assignment.get("assignee").get("active")));
                assignmentPredicates.add(cb.or(
                        cb.isFalse(assignment.get("assignee").get("isDeleted")),
                        cb.isNull(assignment.get("assignee").get("isDeleted"))
                ));
                assignmentPredicates.add(cb.equal(
                        cb.lower(assignment.get("assignee").get("role").get("code")),
                        "sale"
                ));
            }
            assigned.select(assignment.get("id"));
            assigned.where(assignmentPredicates.toArray(Predicate[]::new));
            predicates.add(criteria.isUnassigned() ? cb.not(cb.exists(assigned)) : cb.exists(assigned));
        }
        if (criteria.getMarketingNaturalScopeActorId() != null) {
            Long actorId = criteria.getMarketingNaturalScopeActorId();
            predicates.add(cb.equal(root.get("createdBy").get("id"), actorId));
        }
        if (criteria.getCreatedById() != null) {
            predicates.add(cb.equal(root.get("createdBy").get("id"), criteria.getCreatedById()));
        }
        if (criteria.getAssigneeOrCreatorId() != null) {
            Long actorId = criteria.getAssigneeOrCreatorId();
            Subquery<Long> assigned = cq.subquery(Long.class);
            Root<Assignment> a = assigned.from(Assignment.class);
            assigned.select(a.get("refId"));
            assigned.where(
                    cb.equal(a.get("assignee").get("id"), actorId),
                    a.get("refType").in(AssignmentRefType.MARKETING_LEAD, AssignmentRefType.TASK),
                    a.get("status").in(AssignmentStatus.PENDING, AssignmentStatus.ACCEPTED)
            );
            predicates.add(cb.or(
                    cb.equal(root.get("createdBy").get("id"), actorId),
                    root.get("id").in(assigned)
            ));
        }
        if (criteria.getSaleRoomId() != null) {
            Long roomId = criteria.getSaleRoomId();
            Subquery<Long> roomAssigned = cq.subquery(Long.class);
            Root<Assignment> a = roomAssigned.from(Assignment.class);
            roomAssigned.select(a.get("refId"));
            roomAssigned.where(
                    cb.equal(a.get("assignee").get("saleRoom").get("id"), roomId),
                    criteria.isAssignedSaleRoomOnly()
                            ? cb.equal(a.get("refType"), AssignmentRefType.MARKETING_LEAD)
                            : a.get("refType").in(AssignmentRefType.MARKETING_LEAD, AssignmentRefType.TASK),
                    a.get("status").in(AssignmentStatus.PENDING, AssignmentStatus.ACCEPTED)
            );
            Subquery<Long> currentlyAssigned = cq.subquery(Long.class);
            Root<Assignment> current = currentlyAssigned.from(Assignment.class);
            currentlyAssigned.select(current.get("refId"));
            currentlyAssigned.where(
                    cb.equal(current.get("refType"), AssignmentRefType.MARKETING_LEAD),
                    current.get("status").in(AssignmentStatus.PENDING, AssignmentStatus.ACCEPTED)
            );
            predicates.add(criteria.isAssignedSaleRoomOnly()
                    ? cb.or(root.get("id").in(roomAssigned), cb.not(root.get("id").in(currentlyAssigned)))
                    : cb.or(cb.equal(root.get("createdBy").get("saleRoom").get("id"), roomId),
                            root.get("id").in(roomAssigned)));
        }
        if (criteria.getPendingAssigneeId() != null) {
            Long actorId = criteria.getPendingAssigneeId();
            Subquery<Long> pending = cq.subquery(Long.class);
            Root<Assignment> a = pending.from(Assignment.class);
            pending.select(a.get("refId"));
            pending.where(
                    cb.equal(a.get("assignee").get("id"), actorId),
                    a.get("refType").in(AssignmentRefType.MARKETING_LEAD, AssignmentRefType.TASK),
                    cb.equal(a.get("status"), AssignmentStatus.PENDING)
            );
            predicates.add(root.get("id").in(pending));
        }
        return predicates;
    }

    private List<Order> buildOrder(CriteriaBuilder cb, Root<MarketingLead> root, MarketingLeadSearchCriteria criteria) {
        String sortBy = criteria.getSortBy() == null ? "" : criteria.getSortBy().trim();
        String sortDir = criteria.getSortDir() == null ? "" : criteria.getSortDir().trim();
        if (!sortBy.isBlank()) {
            String[] fields = sortBy.split(",");
            String[] dirs = sortDir.split(",");
            List<Order> orders = new ArrayList<>();
            for (int i = 0; i < fields.length; i++) {
                String field = fields[i].trim();
                if (field.isBlank()) {
                    continue;
                }
                String dir = i < dirs.length ? dirs[i].trim() : dirs.length > 0 ? dirs[dirs.length - 1].trim() : "desc";
                boolean asc = "asc".equalsIgnoreCase(dir);
                if ("fullName".equalsIgnoreCase(field)) {
                    orders.add(asc ? cb.asc(cb.lower(root.get("fullName"))) : cb.desc(cb.lower(root.get("fullName"))));
                } else if ("createdAt".equalsIgnoreCase(field)) {
                    orders.add(asc ? cb.asc(root.get("createdAt")) : cb.desc(root.get("createdAt")));
                }
            }
            if (!orders.isEmpty()) {
                orders.add(cb.desc(root.get("id")));
                return orders;
            }
        }
        return List.of(cb.desc(root.get("createdAt")), cb.desc(root.get("id")));
    }

    @Override
    public Optional<MarketingLead> findFirstByPhoneActive(String phone) {
        if (phone == null || phone.isBlank()) {
            return Optional.empty();
        }
        List<MarketingLead> matches = marketingLeadJPAMapper.findByPhoneActive(phone.trim());
        if (matches == null || matches.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(matches.get(0));
    }

    @Override
    public int unlinkCustomer(Long customerId) {
        if (customerId == null) {
            return 0;
        }
        return marketingLeadJPAMapper.unlinkCustomer(customerId);
    }

    @Override
    public List<String> listDistinctCampaignNames(MarketingLeadSearchCriteria criteria) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<String> cq = cb.createQuery(String.class);
        Root<MarketingLead> root = cq.from(MarketingLead.class);
        cq.select(root.get("campaignNames"));
        cq.distinct(true);
        cq.where(buildPredicates(cb, cq, root, criteria).toArray(Predicate[]::new));
        cq.orderBy(cb.asc(root.get("campaignNames")));

        LinkedHashSet<String> names = new LinkedHashSet<>();
        for (String json : entityManager.createQuery(cq).getResultList()) {
            if (json == null || json.isBlank()) {
                continue;
            }
            for (String name : CampaignNamesJson.parse(json)) {
                if (name != null && !name.isBlank()) {
                    names.add(name.trim());
                }
            }
        }
        return new ArrayList<>(names);
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
