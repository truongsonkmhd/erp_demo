package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.Notification;
import com.xxxx.ddd.domain.respository.NotificationRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.NotificationJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class NotificationRepositoryImpl implements NotificationRepository {

    @Autowired
    private NotificationJPAMapper notificationJPAMapper;

    @Override
    public Notification save(Notification notification) {
        return notificationJPAMapper.save(notification);
    }

    @Override
    public Optional<Notification> findById(Long id) {
        return notificationJPAMapper.findById(id);
    }

    @Override
    public List<Notification> findInbox(Long recipientId, int limit) {
        return notificationJPAMapper.findInbox(recipientId, PageRequest.of(0, Math.max(limit, 1)));
    }

    @Override
    public List<Notification> findInboxPage(Long recipientId, boolean unreadOnly, Long beforeId, int limit) {
        LocalDateTime beforeCreatedAt = null;
        if (beforeId != null) {
            beforeCreatedAt = notificationJPAMapper.findById(beforeId)
                    .map(Notification::getCreatedAt)
                    .orElse(null);
        }
        return notificationJPAMapper.findInboxPage(
                recipientId,
                unreadOnly,
                beforeId,
                beforeCreatedAt,
                PageRequest.of(0, Math.max(limit, 1)));
    }

    @Override
    public List<Notification> findUnread(Long recipientId) {
        return notificationJPAMapper.findUnread(recipientId);
    }

    @Override
    public long countUnread(Long recipientId) {
        return notificationJPAMapper.countUnread(recipientId);
    }
}
