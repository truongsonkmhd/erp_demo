package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.Role;
import com.xxxx.ddd.domain.respository.RoleRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.RoleJPAMapper;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class RoleRepositoryImpl implements RoleRepository {

    @Autowired
    private RoleJPAMapper roleJPAMapper;

    @Override
    public Role save(Role role) {
        return roleJPAMapper.save(role);
    }

    @Override
    public Optional<Role> findById(Long id) {
        return roleJPAMapper.findById(id);
    }

    @Override
    public Optional<Role> findByIdWithDetails(Long id) {
        Optional<Role> withPermissions = roleJPAMapper.findByIdWithPermissions(id);
        Optional<Role> withLevelPermissions = roleJPAMapper.findByIdWithLevelPermissions(id);
        if (withPermissions.isEmpty()) {
            return Optional.empty();
        }
        Role role = withPermissions.get();
        withLevelPermissions.ifPresent(value -> role.setLevelPermissions(value.getLevelPermissions()));
        initialize(role);
        return Optional.of(role);
    }

    @Override
    public Optional<Role> findByCode(String code) {
        return roleJPAMapper.findByCode(code);
    }

    @Override
    public Optional<Role> findByCodeWithDetails(String code) {
        Optional<Role> withPermissions = roleJPAMapper.findByCodeWithPermissions(code);
        Optional<Role> withLevelPermissions = roleJPAMapper.findByCodeWithLevelPermissions(code);
        if (withPermissions.isEmpty()) {
            return Optional.empty();
        }
        Role role = withPermissions.get();
        withLevelPermissions.ifPresent(value -> role.setLevelPermissions(value.getLevelPermissions()));
        initialize(role);
        return Optional.of(role);
    }

    @Override
    public List<Role> findAllActiveWithDetails() {
        Map<Long, Role> byId = new LinkedHashMap<>();
        for (Role role : roleJPAMapper.findAllActiveWithPermissions()) {
            byId.put(role.getId(), role);
        }
        for (Role withLevelPermissions : roleJPAMapper.findAllActiveWithLevelPermissions()) {
            Role role = byId.get(withLevelPermissions.getId());
            if (role != null) {
                role.setLevelPermissions(withLevelPermissions.getLevelPermissions());
            } else {
                byId.put(withLevelPermissions.getId(), withLevelPermissions);
            }
        }
        List<Role> roles = new ArrayList<>(byId.values());
        roles.forEach(this::initialize);
        return roles;
    }

    @Override
    public boolean existsByCode(String code) {
        return roleJPAMapper.existsByCode(code);
    }

    @Override
    public boolean existsByCodeAndIdNot(String code, Long id) {
        return roleJPAMapper.existsByCodeAndIdNot(code, id);
    }

    private void initialize(Role role) {
        Hibernate.initialize(role.getPermissions());
        Hibernate.initialize(role.getLevelPermissions());
        if (role.getLevelPermissions() != null) {
            role.getLevelPermissions().forEach(item -> Hibernate.initialize(item.getPermission()));
        }
    }
}
