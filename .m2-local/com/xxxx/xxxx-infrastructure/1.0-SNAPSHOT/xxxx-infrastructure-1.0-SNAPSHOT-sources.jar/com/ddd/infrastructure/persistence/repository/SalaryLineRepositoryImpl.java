package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.SalaryLine;
import com.xxxx.ddd.domain.respository.SalaryLineRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.SalaryLineJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SalaryLineRepositoryImpl implements SalaryLineRepository {

    @Autowired
    private SalaryLineJPAMapper salaryLineJPAMapper;

    @Override
    public List<SalaryLine> findByPeriodId(Long periodId) {
        return salaryLineJPAMapper.findByPeriodId(periodId);
    }

    @Override
    @Transactional
    public void deleteByPeriodId(Long periodId) {
        salaryLineJPAMapper.deleteByPeriodId(periodId);
    }

    @Override
    @Transactional
    public void delete(SalaryLine line) {
        salaryLineJPAMapper.delete(line);
    }

    @Override
    public SalaryLine save(SalaryLine line) {
        return salaryLineJPAMapper.save(line);
    }
}
