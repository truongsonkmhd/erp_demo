package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.SalaryOrder;
import com.xxxx.ddd.domain.respository.SalaryOrderRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.SalaryOrderJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;

@Service
public class SalaryOrderRepositoryImpl implements SalaryOrderRepository {

    @Autowired
    private SalaryOrderJPAMapper salaryOrderJPAMapper;

    @Override
    @Transactional
    public void deleteBySalaryLineIdIn(Collection<Long> salaryLineIds) {
        if (salaryLineIds == null || salaryLineIds.isEmpty()) {
            return;
        }
        salaryOrderJPAMapper.deleteBySalaryLineIdIn(salaryLineIds);
    }

    @Override
    public SalaryOrder save(SalaryOrder salaryOrder) {
        return salaryOrderJPAMapper.save(salaryOrder);
    }

    @Override
    public List<SalaryOrder> findByLineId(Long salaryLineId) {
        return salaryOrderJPAMapper.findByLineId(salaryLineId);
    }
}
