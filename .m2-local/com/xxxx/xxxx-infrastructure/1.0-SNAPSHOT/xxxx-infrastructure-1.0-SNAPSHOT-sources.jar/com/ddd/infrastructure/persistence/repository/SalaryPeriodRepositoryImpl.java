package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.SalaryPeriod;
import com.xxxx.ddd.domain.respository.SalaryPeriodRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.SalaryPeriodJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SalaryPeriodRepositoryImpl implements SalaryPeriodRepository {

    @Autowired
    private SalaryPeriodJPAMapper salaryPeriodJPAMapper;

    @Override
    public Optional<SalaryPeriod> findByPeriod(String period) {
        return salaryPeriodJPAMapper.findByPeriod(period);
    }

    @Override
    public SalaryPeriod save(SalaryPeriod period) {
        return salaryPeriodJPAMapper.save(period);
    }
}
