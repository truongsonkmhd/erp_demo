package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.SaleRoom;
import com.xxxx.ddd.domain.respository.SaleRoomRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.SaleRoomJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SaleRoomRepositoryImpl implements SaleRoomRepository {

    @Autowired
    private SaleRoomJPAMapper saleRoomJPAMapper;

    @Override
    public SaleRoom save(SaleRoom room) {
        return saleRoomJPAMapper.save(room);
    }

    @Override
    public Optional<SaleRoom> findById(Long id) {
        return saleRoomJPAMapper.findById(id);
    }

    @Override
    public Optional<SaleRoom> findByIdActive(Long id) {
        return saleRoomJPAMapper.findByIdActive(id);
    }

    @Override
    public List<SaleRoom> findAllActive() {
        return saleRoomJPAMapper.findAllActive();
    }

    @Override
    public Optional<SaleRoom> findByLeaderId(Long leaderId) {
        if (leaderId == null) {
            return Optional.empty();
        }
        return saleRoomJPAMapper.findByLeaderId(leaderId);
    }

    @Override
    public boolean existsByCode(String code) {
        return saleRoomJPAMapper.existsByCode(code);
    }

    @Override
    public boolean existsByCodeAndIdNot(String code, Long id) {
        return saleRoomJPAMapper.existsByCodeAndIdNot(code, id);
    }
}
