package com.xxxx.ddd.infrastructure.persistence.repository;

import com.xxxx.ddd.domain.model.entity.SaleRoomTransfer;
import com.xxxx.ddd.domain.respository.SaleRoomTransferRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.SaleRoomTransferJPAMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SaleRoomTransferRepositoryImpl implements SaleRoomTransferRepository {

    @Autowired
    private SaleRoomTransferJPAMapper saleRoomTransferJPAMapper;

    @Override
    public SaleRoomTransfer save(SaleRoomTransfer transfer) {
        return saleRoomTransferJPAMapper.save(transfer);
    }
}
