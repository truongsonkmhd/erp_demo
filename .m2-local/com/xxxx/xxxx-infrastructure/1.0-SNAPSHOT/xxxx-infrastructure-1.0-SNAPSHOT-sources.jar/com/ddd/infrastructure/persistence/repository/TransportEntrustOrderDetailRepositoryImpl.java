package com.xxxx.ddd.infrastructure.persistence.repository;
import com.xxxx.ddd.domain.model.entity.TransportEntrustOrderDetail;
import com.xxxx.ddd.domain.respository.TransportEntrustOrderDetailRepository;
import com.xxxx.ddd.infrastructure.persistence.mapper.TransportEntrustOrderDetailJPAMapper;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;
@Repository
public class TransportEntrustOrderDetailRepositoryImpl implements TransportEntrustOrderDetailRepository {
    private final TransportEntrustOrderDetailJPAMapper mapper;
    public TransportEntrustOrderDetailRepositoryImpl(TransportEntrustOrderDetailJPAMapper mapper) { this.mapper = mapper; }
    public TransportEntrustOrderDetail save(TransportEntrustOrderDetail detail) { return mapper.save(detail); }
    public Optional<TransportEntrustOrderDetail> findByOrderId(Long orderId) { return mapper.findById(orderId); }
    public List<TransportEntrustOrderDetail> findAllByOrderId(Iterable<Long> orderIds) { return mapper.findAllById(orderIds); }
    public void deleteByOrderId(Long orderId) { mapper.deleteById(orderId); }
}
