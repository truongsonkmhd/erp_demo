package com.xxxx;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Seeds demo orders into the backend database for local/demo environments.
 * Disabled by default. Enable once with PTS_DEMO_ORDER_SEED_ENABLED=true.
 * Order codes are deterministic, so restarting the backend never duplicates data.
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "pts.demo-order-seed.enabled", havingValue = "true")
public class DemoOrderDataSeeder implements ApplicationRunner {

    private static final int ORDER_COUNT = 30;
    private static final String[] CATEGORIES = {
            "Thiết bị âm thanh, ánh sáng", "Máy móc công nghiệp", "Kim khí, cơ khí",
            "Nguyên liệu, phụ kiện sản xuất may mặc", "Gia dụng", "Nội thất",
            "Hàng tiêu dùng", "Đồ chơi trẻ em", "Đồ decor, mô hình trang trí",
            "Thiết bị vệ sinh", "Vật liệu xây dựng", "Thời trang", "Phụ tùng xe",
            "Hóa chất", "Mỹ phẩm"
    };

    private final JdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper;

    public DemoOrderDataSeeder(JdbcTemplate jdbcTemplate, ObjectMapper objectMapper) {
        this.jdbcTemplate = jdbcTemplate;
        this.objectMapper = objectMapper;
    }

    @Override
    public void run(ApplicationArguments args) {
        List<CustomerRef> customers = jdbcTemplate.query("""
                SELECT id, created_by, customer_care_staff_id
                FROM tbl_customer
                WHERE is_deleted = 0 OR is_deleted IS NULL
                ORDER BY id
                LIMIT 30
                """, (rs, rowNum) -> new CustomerRef(
                rs.getLong("id"),
                nullableLong(rs.getObject("created_by")),
                nullableLong(rs.getObject("customer_care_staff_id"))));

        if (customers.isEmpty()) {
            log.warn("Demo order seed skipped because tbl_customer has no active customer");
            return;
        }

        YearMonth period = YearMonth.now();
        int inserted = 0;
        for (int index = 0; index < ORDER_COUNT; index++) {
            String orderCode = "DEMO-DH-" + period + "-" + String.format("%03d", index + 1);
            Integer exists = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM tbl_order WHERE order_code = ?", Integer.class, orderCode);
            if (exists != null && exists > 0) continue;

            CustomerRef customer = customers.get(index % customers.size());
            LocalDate paidAt = period.atDay(index % period.lengthOfMonth() + 1);
            LocalDateTime createdAt = paidAt.atTime(8 + index % 9, 0);
            BigDecimal serviceProfit = BigDecimal.valueOf(1_200_000L + index % 5 * 350_000L);
            BigDecimal freightProfit = BigDecimal.valueOf(1_800_000L + index % 7 * 420_000L);
            BigDecimal paymentProfit = BigDecimal.valueOf(700_000L + index % 4 * 280_000L);
            BigDecimal otherProfit = index % 3 == 0
                    ? BigDecimal.valueOf(600_000L + index * 25_000L) : BigDecimal.ZERO;
            BigDecimal totalProfit = serviceProfit.add(freightProfit).add(paymentProfit).add(otherProfit);
            String overlay = overlay(index, serviceProfit, freightProfit, paymentProfit, otherProfit, totalProfit);

            jdbcTemplate.update("""
                    INSERT INTO tbl_order (
                        internal_code, order_code, customer_id, batch_code, service_type, contract_type,
                        product_name, category, quantity, unit_price_rmb, total_payment_amount_vnd,
                        paid_at, net_profit_vnd, salary_customer_kind, assignee_id, sales_owner_id,
                        notes, sale_overlay_json, edit_approval_status, source, is_deleted, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    "DEMO-ORDER-" + period.toString().replace("-", "") + "-" + String.format("%03d", index + 1),
                    orderCode, customer.id(), "DEMO-LO-" + String.format("%03d", index + 1),
                    index % 4 == 1 ? "Vận chuyển Trung - Việt" : "Ủy thác nhập khẩu",
                    index % 4 == 1 ? "TRANSPORT_ENTRUST" : "IMPORT_ENTRUST",
                    "Sản phẩm mẫu " + (index + 1), CATEGORIES[index % CATEGORIES.length],
                    BigDecimal.valueOf(10L + index), BigDecimal.valueOf(100L + index * 5L),
                    totalProfit.multiply(BigDecimal.valueOf(4)), paidAt, totalProfit,
                    index % 3 == 0 ? "NEW" : "OLD", customer.careStaffId(), customer.createdById(),
                    "Dữ liệu mẫu backend cho Dashboard Đơn hàng", overlay, "NONE", "MANUAL", false,
                    createdAt, createdAt);
            inserted++;
        }
        log.info("Backend demo order seed finished: {} inserted, {} already existed", inserted, ORDER_COUNT - inserted);
    }

    private String overlay(int index, BigDecimal service, BigDecimal freight, BigDecimal payment,
                           BigDecimal other, BigDecimal total) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("entrustOrderType", index % 4 == 1 ? "TRANSPORT_ENTRUST" : "IMPORT_ENTRUST");
        data.put("transportMode", index % 2 == 0 ? "LTL" : "FTL");
        data.put("calculationUnit", "KG");
        data.put("weightKg", 100 + index * 15);
        data.put("volumeCbm", 1 + index % 5);
        data.put("purchasingFeeVnd", service.multiply(BigDecimal.valueOf(45)).divide(BigDecimal.valueOf(100)));
        data.put("entrustedImportFeeVnd", service.multiply(BigDecimal.valueOf(35)).divide(BigDecimal.valueOf(100)));
        data.put("customsDeclarationFeeVnd", service.multiply(BigDecimal.valueOf(20)).divide(BigDecimal.valueOf(100)));
        data.put("costShippingFeeKg", BigDecimal.valueOf(5_000_000));
        data.put("sellingShippingFeeKg", BigDecimal.valueOf(5_000_000).add(freight));
        data.put("costExchangeRate", BigDecimal.valueOf(3_700));
        data.put("sellingExchangeRate", BigDecimal.valueOf(3_700).add(payment.divide(BigDecimal.valueOf(10_000))));
        data.put("totalCostRmb", BigDecimal.valueOf(10_000));
        data.put("otherProfitVnd", other);
        data.put("costProfitVnd", total);
        data.put("floorProfitVnd", total);
        data.put("totalRevenueVnd", total.multiply(BigDecimal.valueOf(4)));
        try {
            return objectMapper.writeValueAsString(data);
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Cannot serialize demo order overlay", exception);
        }
    }

    private static Long nullableLong(Object value) {
        return value instanceof Number number ? number.longValue() : null;
    }

    private record CustomerRef(Long id, Long createdById, Long careStaffId) { }
}
