package com.xxxx;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/** One-shot, idempotent fixture for testing linked bulk-transfer records in the local demo DB only. */
@Component
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "pts.demo-work-transfer-seed.enabled", havingValue = "true")
public class DemoWorkTransferSeeder implements ApplicationRunner {
    private final JdbcTemplate jdbc;
    private final DataSource dataSource;

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        String database = jdbc.queryForObject("SELECT DATABASE()", String.class);
        String jdbcUrl;
        try (Connection connection = dataSource.getConnection()) {
            jdbcUrl = connection.getMetaData().getURL();
        } catch (Exception exception) {
            throw new IllegalStateException("Cannot verify demo database connection", exception);
        }
        if (!"hoangminh_pts_demo".equals(database)
                || !jdbcUrl.matches("(?i)^jdbc:mysql://[^/]+:3318/hoangminh_pts_demo(?:\\?.*)?$")) {
            throw new IllegalStateException("Work-transfer fixture may only run on hoangminh_pts_demo:3318");
        }
        Long sale = pickUser("sale", "sale_ex2");
        Long care = pickUser("cskh", null);
        if (sale == null || care == null) {
            throw new IllegalStateException("Work-transfer fixture requires existing Sale and CSKH demo users");
        }
        int customers = 0, leads = 0, orders = 0;
        for (int n = 1; n <= 5; n++) {
            String suffix = String.format("%02d", n);
            String customerCode = "WT26KH" + suffix;
            if (!exists("tbl_customer", "code", customerCode)) {
                jdbc.update("""
                    INSERT INTO tbl_customer
                    (code, full_name, company_name, phone, email, category, created_by,
                     customer_care_staff_id, note, is_deleted, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, NOW(), NOW())
                    """, customerCode, "Khách bàn giao mẫu " + suffix,
                        "Doanh nghiệp thử bàn giao " + suffix, "098880" + String.format("%04d", n),
                        "work-transfer-" + suffix + "@demo.local", "Logistics", sale, care,
                        "Dữ liệu mẫu bàn giao hàng loạt; chỉ dùng ở demo");
                customers++;
            }
            Long customerId = idByCode("tbl_customer", customerCode);
            for (String part : List.of("A", "B")) {
                String leadCode = "WT26DATA" + suffix + part;
                if (!exists("tbl_marketing_lead", "code", leadCode)) {
                    jdbc.update("""
                        INSERT INTO tbl_marketing_lead
                        (code, customer_id, full_name, phone, email, category, lead_source,
                         note, stage, marketing_status, task_status, care_progress, care_l4_at,
                         created_by, is_deleted, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, 'Demo', ?, ?, 'ACCEPTED', ?, 'L4', NOW(), ?, 0, NOW(), NOW())
                        """, leadCode, customerId, "Data liên kết " + suffix + part,
                            "097770" + String.format("%04d", n * 10 + (part.equals("A") ? 1 : 2)),
                            "wt-" + suffix + part + "@demo.local", "Logistics",
                            "Dữ liệu mẫu bàn giao: gắn khách hàng và đơn UTVC",
                            part.equals("B") ? "TASK" : "CARE", part.equals("B") ? "ACCEPTED" : "NONE", sale);
                    Long leadId = idByCode("tbl_marketing_lead", leadCode);
                    jdbc.update("""
                        INSERT INTO tbl_assignment
                        (ref_type, ref_id, assignee_id, assigned_by, status, note, assigned_at, accepted_at)
                        VALUES ('MARKETING_LEAD', ?, ?, ?, 'ACCEPTED', 'Fixture bàn giao Sales', NOW(), NOW())
                        """, leadId, sale, sale);
                    if (part.equals("B")) {
                        jdbc.update("""
                            INSERT INTO tbl_assignment
                            (ref_type, ref_id, assignee_id, assigned_by, status, note, assigned_at, accepted_at)
                            VALUES ('TASK', ?, ?, ?, 'ACCEPTED', 'Fixture nhiệm vụ CSKH', NOW(), NOW())
                            """, leadId, care, sale);
                    }
                    leads++;
                }
            }
            Long orderLeadId = idByCode("tbl_marketing_lead", "WT26DATA" + suffix + "B");
            orders += insertOrder("WT26OPEN" + suffix, customerId, orderLeadId, sale, care,
                    null, null, "{\"utvcDebtVnd\":0}");
            orders += insertOrder("WT26DEBT" + suffix, customerId, orderLeadId, sale, care,
                    LocalDate.now().minusDays(5), LocalDateTime.now().minusDays(6), "{\"utvcDebtVnd\":1000000}");
            orders += insertOrder("WT26DONE" + suffix, customerId, orderLeadId, sale, care,
                    LocalDate.now().minusDays(10), LocalDateTime.now().minusDays(11), "{\"utvcDebtVnd\":0}");
        }
        log.info("Demo work-transfer fixture: sale={} ({}), cskh={} ({}), inserted customers={}, leads={}, orders={}",
                username(sale), sale, username(care), care, customers, leads, orders);
    }

    private int insertOrder(String code, Long customerId, Long leadId, Long sale, Long care,
                            LocalDate paidAt, LocalDateTime handedOverAt, String overlay) {
        if (exists("tbl_order", "order_code", code)) return 0;
        jdbc.update("""
            INSERT INTO tbl_order
            (internal_code, order_code, customer_id, lead_id, contract_type, service_type,
             product_name, assignee_id, sales_owner_id, paid_at, document_handed_over_at,
             sale_overlay_json, notes, source, is_deleted, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'TRANSPORT_ENTRUST', 'Ủy thác vận chuyển', ?, ?, ?, ?, ?, ?, ?, 'MANUAL', 0, NOW(), NOW())
            """, "WT-ORDER-" + code, code, customerId, leadId, "Hàng mẫu " + code,
                care, sale, paidAt == null ? null : Date.valueOf(paidAt),
                handedOverAt == null ? null : Timestamp.valueOf(handedOverAt), overlay,
                "Dữ liệu mẫu bàn giao hàng loạt; chỉ dùng ở demo");
        return 1;
    }

    private Long pickUser(String role, String preferredUsername) {
        List<Long> ids = jdbc.queryForList("""
            SELECT u.id FROM tbl_user u JOIN tbl_role r ON r.id = u.role_id
            WHERE LOWER(r.code) = ? AND (u.is_deleted = 0 OR u.is_deleted IS NULL)
            ORDER BY CASE WHEN u.username = ? THEN 0 WHEN u.active = 0 THEN 1 ELSE 2 END, u.id
            LIMIT 1
            """, Long.class, role, preferredUsername == null ? "" : preferredUsername);
        return ids.isEmpty() ? null : ids.get(0);
    }

    private String username(Long id) {
        return jdbc.queryForObject("SELECT username FROM tbl_user WHERE id = ?", String.class, id);
    }

    private boolean exists(String table, String column, String code) {
        return jdbc.queryForObject("SELECT COUNT(*) FROM " + table + " WHERE " + column + " = ?",
                Integer.class, code) > 0;
    }

    private Long idByCode(String table, String code) {
        return jdbc.queryForObject("SELECT id FROM " + table + " WHERE code = ?", Long.class, code);
    }
}
