package com.xxxx;

import com.xxxx.ddd.domain.model.entity.Permission;
import com.xxxx.ddd.domain.model.entity.Role;
import com.xxxx.ddd.domain.service.RoleDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;
import java.util.stream.Collectors;

/** Tạo quyền bàn giao riêng một lần; không cấp lại nếu Admin đã thu hồi quyền về sau. */
@Component
@RequiredArgsConstructor
@Slf4j
public class WorkTransferPermissionBootstrap implements ApplicationRunner {
    private final RoleDomainService roles;

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        seed("bulk_transfer_sale", "Bàn giao hàng loạt - Sale Manager", "sale");
        seed("bulk_transfer_cskh", "Bàn giao hàng loạt - CSKH Manager", "cskh");
    }

    private void seed(String code, String label, String roleCode) {
        boolean existed = roles.findAllPermissions().stream().anyMatch(p -> code.equals(p.getCode()));
        if (existed) return;
        roles.createPermission(new Permission().setCode(code).setLabel(label)
                .setNote("Cho phép bàn giao nhiều hồ sơ cho người phụ trách thay thế"));
        try {
            Role role = roles.getByCode(roleCode);
            for (String level : Set.of("manager", "director")) {
                Set<String> permissions = role.permissionsForLevel(level).stream()
                        .map(Permission::getCode).collect(Collectors.toSet());
                permissions.add(code);
                roles.updateLevelPermissions(role.getId(), level, permissions);
            }
            log.info("Created bulk transfer permission {} for {} Manager/Director", code, roleCode);
        } catch (IllegalArgumentException missingRole) {
            log.warn("Created permission {} but role {} is missing; assign it in the role settings", code, roleCode);
        }
    }
}
